USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        6921  0.0  0.0 725088 15232 ?        Ssl  14:43   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        6940  0.0  0.0   7060  2944 ?        R    14:43   0:00  \_ ps auxfw
root        6946  0.0  0.0      0     0 ?        R    14:43   0:00  \_ [ip]
root        6947  0.0  0.0   4396  2048 ?        R    14:43   0:00  \_ ip a
root        6948  0.0  0.0   4528  2176 ?        R    14:43   0:00  \_ ip -4 n
root        6949  0.0  0.0   3132   256 ?        R    14:43   0:00  \_ ss -t -p -a -i -s -n -e
root        6950  0.0  0.0   4344   512 ?        R    14:43   0:00  \_ ip -6 n
root        6951  0.0  0.0   1408   256 ?        R    14:43   0:00  \_ ip -d -s l
root        6952  0.0  0.0   1496   256 ?        R    14:43   0:00  \_ tc qdisc show
root        6954  0.0  0.0   1060   256 ?        R    14:43   0:00  \_ tc -d -s qdisc show
root        6955  0.0  0.0    300     0 ?        R    14:43   0:00  \_ [ss]
root        6956  0.0  0.0      4     0 ?        R    14:43   0:00  \_ [bash]
root           1  2.2  1.0 880516 165988 ?       Ssl  14:38   0:06 cilium-agent --config-dir=/tmp/cilium/config-map
root         199  0.0  0.0 713924  4480 ?        Sl   14:38   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
