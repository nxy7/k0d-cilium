KVStore:                Ok   Disabled
Kubernetes:             Ok   1.27 (v1.27.4+k0s) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideEnvoyConfig", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumEnvoyConfig", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Secrets", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   True   [eth0 172.17.0.2]
Host firewall:          Disabled
CNI Chaining:           none
Cilium:                 Ok   1.14.1 (v1.14.1-c191ef6f)
NodeMonitor:            Listening for events on 32 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 28/254 allocated from 10.244.0.0/24, 
Allocated addresses:
  10.244.0.106 (cert-manager/cert-manager-78ddc5db85-nbbjs)
  10.244.0.112 (kube-system/metrics-server-7f86dff975-tb5rv)
  10.244.0.123 (openebs/openebs-ndm-cluster-exporter-589554f487-g4gzj)
  10.244.0.124 (streampai/redis-68c95977f4-5ldmf)
  10.244.0.129 (openebs/openebs-ndm-operator-7c667b76f8-8bkbl)
  10.244.0.130 (router)
  10.244.0.132 (streampai/postgres-7c845b6448-hmx74)
  10.244.0.137 (streampai/backend-855f6c7b4-2lvs2)
  10.244.0.143 (openebs/openebs-ndm-node-exporter-bg5c6)
  10.244.0.149 (openebs/openebs-localpv-provisioner-7d6ccb7795-pnpxg)
  10.244.0.159 (streampai/frontend-58b6bf847f-nzgv5)
  10.244.0.160 (streampai/frontend-58b6bf847f-sxngk)
  10.244.0.177 (streampai/streamchat-79dfbb9bb4-5bt4p)
  10.244.0.178 (streampai/pgweb-b74849bb6-rd2fs)
  10.244.0.222 (streampai/backend-855f6c7b4-j4k6m)
  10.244.0.231 (streampai/frontend-58b6bf847f-rm7qs)
  10.244.0.243 (ingress)
  10.244.0.26 (streampai/livestreamdb-6877b6fc75-7w45t)
  10.244.0.29 (health)
  10.244.0.40 (cert-manager/cert-manager-webhook-879c48cd4-qp49t)
  10.244.0.41 (streampai/frontend-58b6bf847f-xgnzm)
  10.244.0.46 (kube-system/hubble-ui-6b468cff75-zwm9s)
  10.244.0.47 (streampai/kratos-77cbf98c8f-k2l6k)
  10.244.0.49 (kube-system/coredns-878bb57ff-lgfbn)
  10.244.0.52 (cert-manager/cert-manager-cainjector-6774f986b-jw7hp)
  10.244.0.62 (streampai/minio-d496dbccf-8rsnz)
  10.244.0.81 (ambassador/traffic-manager-55d995585d-xn8tw)
  10.244.0.86 (kube-system/hubble-relay-777496bf44-h6sbk)
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Host Routing:           Legacy
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      120/120 healthy
  Name                                  Last success   Last error   Count   Message
  cilium-health-ep                      28s ago        never        0       no error   
  dns-garbage-collector-job             36s ago        never        0       no error   
  endpoint-105-regeneration-recovery    never          never        0       no error   
  endpoint-1111-regeneration-recovery   never          never        0       no error   
  endpoint-119-regeneration-recovery    never          never        0       no error   
  endpoint-1288-regeneration-recovery   never          never        0       no error   
  endpoint-1493-regeneration-recovery   never          never        0       no error   
  endpoint-160-regeneration-recovery    never          never        0       no error   
  endpoint-198-regeneration-recovery    never          never        0       no error   
  endpoint-208-regeneration-recovery    never          never        0       no error   
  endpoint-2128-regeneration-recovery   never          never        0       no error   
  endpoint-215-regeneration-recovery    never          never        0       no error   
  endpoint-2207-regeneration-recovery   never          never        0       no error   
  endpoint-2326-regeneration-recovery   never          never        0       no error   
  endpoint-2497-regeneration-recovery   never          never        0       no error   
  endpoint-257-regeneration-recovery    never          never        0       no error   
  endpoint-2747-regeneration-recovery   never          never        0       no error   
  endpoint-2856-regeneration-recovery   never          never        0       no error   
  endpoint-3903-regeneration-recovery   never          never        0       no error   
  endpoint-3933-regeneration-recovery   never          never        0       no error   
  endpoint-4067-regeneration-recovery   never          never        0       no error   
  endpoint-455-regeneration-recovery    never          never        0       no error   
  endpoint-471-regeneration-recovery    never          never        0       no error   
  endpoint-606-regeneration-recovery    never          never        0       no error   
  endpoint-626-regeneration-recovery    never          never        0       no error   
  endpoint-633-regeneration-recovery    never          never        0       no error   
  endpoint-645-regeneration-recovery    never          never        0       no error   
  endpoint-702-regeneration-recovery    never          never        0       no error   
  endpoint-82-regeneration-recovery     never          never        0       no error   
  endpoint-gc                           4m36s ago      never        0       no error   
  ipcache-inject-labels                 29s ago        4m31s ago    0       no error   
  k8s-heartbeat                         6s ago         never        0       no error   
  link-cache                            14s ago        never        0       no error   
  metricsmap-bpf-prom-sync              6s ago         never        0       no error   
  resolve-identity-105                  3m56s ago      never        0       no error   
  resolve-identity-1111                 4m14s ago      never        0       no error   
  resolve-identity-119                  4m28s ago      never        0       no error   
  resolve-identity-1288                 3m51s ago      never        0       no error   
  resolve-identity-1493                 3m56s ago      never        0       no error   
  resolve-identity-160                  4m28s ago      never        0       no error   
  resolve-identity-198                  4m28s ago      never        0       no error   
  resolve-identity-208                  4m22s ago      never        0       no error   
  resolve-identity-2128                 3m56s ago      never        0       no error   
  resolve-identity-215                  3m51s ago      never        0       no error   
  resolve-identity-2207                 4m28s ago      never        0       no error   
  resolve-identity-2326                 4m28s ago      never        0       no error   
  resolve-identity-2497                 3m51s ago      never        0       no error   
  resolve-identity-257                  3m56s ago      never        0       no error   
  resolve-identity-2747                 4m28s ago      never        0       no error   
  resolve-identity-2856                 3m56s ago      never        0       no error   
  resolve-identity-3903                 3m55s ago      never        0       no error   
  resolve-identity-3933                 4m23s ago      never        0       no error   
  resolve-identity-4067                 4m25s ago      never        0       no error   
  resolve-identity-455                  3m32s ago      never        0       no error   
  resolve-identity-471                  3m56s ago      never        0       no error   
  resolve-identity-606                  3m25s ago      never        0       no error   
  resolve-identity-626                  4m28s ago      never        0       no error   
  resolve-identity-633                  4m25s ago      never        0       no error   
  resolve-identity-645                  3m51s ago      never        0       no error   
  resolve-identity-702                  3m33s ago      never        0       no error   
  resolve-identity-82                   4m28s ago      never        0       no error   
  sync-host-ips                         29s ago        never        0       no error   
  sync-lb-maps-with-k8s-services        4m29s ago      never        0       no error   
  sync-policymap-105                    24s ago        never        0       no error   
  sync-policymap-1111                   24s ago        never        0       no error   
  sync-policymap-119                    24s ago        never        0       no error   
  sync-policymap-1288                   24s ago        never        0       no error   
  sync-policymap-1493                   24s ago        never        0       no error   
  sync-policymap-160                    24s ago        never        0       no error   
  sync-policymap-198                    24s ago        never        0       no error   
  sync-policymap-208                    24s ago        never        0       no error   
  sync-policymap-2128                   24s ago        never        0       no error   
  sync-policymap-215                    24s ago        never        0       no error   
  sync-policymap-2207                   24s ago        never        0       no error   
  sync-policymap-2326                   24s ago        never        0       no error   
  sync-policymap-2497                   24s ago        never        0       no error   
  sync-policymap-257                    24s ago        never        0       no error   
  sync-policymap-2747                   24s ago        never        0       no error   
  sync-policymap-2856                   24s ago        never        0       no error   
  sync-policymap-3903                   24s ago        never        0       no error   
  sync-policymap-3933                   24s ago        never        0       no error   
  sync-policymap-4067                   24s ago        never        0       no error   
  sync-policymap-455                    24s ago        never        0       no error   
  sync-policymap-471                    24s ago        never        0       no error   
  sync-policymap-606                    24s ago        never        0       no error   
  sync-policymap-626                    24s ago        never        0       no error   
  sync-policymap-633                    24s ago        never        0       no error   
  sync-policymap-645                    24s ago        never        0       no error   
  sync-policymap-702                    24s ago        never        0       no error   
  sync-policymap-82                     24s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (105)      6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1111)     4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (119)      5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1288)     9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1493)     5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (160)      8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (198)      6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (208)      12s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2128)     6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (215)      9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2207)     6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2326)     6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2497)     10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (257)      6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2747)     6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2856)     6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3903)     4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3933)     13s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (4067)     4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (455)      12s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (471)      6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (606)      5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (626)      7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (633)      5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (645)      9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (702)      13s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (82)       8s ago         never        0       no error   
  sync-utime                            29s ago        never        0       no error   
  template-dir-watcher                  never          never        0       no error   
  write-cni-file                        4m36s ago      never        0       no error   
Proxy Status:            OK, ip 10.244.0.130, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 256, max 65535
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 25.49   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 True
  Socket LB:              Enabled
  Socket LB Tracing:      Enabled
  Socket LB Coverage:     Full
  Devices:                eth0 172.17.0.2
  Mode:                   SNAT
  Backend Selection:      Random
  Session Affinity:       Enabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  XDP Acceleration:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Enabled (Range: 30000-32767) 
  - LoadBalancer:   Enabled 
  - externalIPs:    Enabled 
  - HostPort:       Enabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   73193
  TCP connection tracking       146386
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           146386
  Neighbor table                146386
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              73193
  Tunnel                        65536
Encryption:         Disabled        
Cluster health:     1/1 reachable   (2023-09-05T14:41:57Z)
  Name              IP              Node        Endpoints
  k0s (localhost)   172.17.0.2      reachable   reachable
