1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN mode DEFAULT group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00 promiscuity 0 minmtu 0 maxmtu 0 addrgenmode eui64 numtxqueues 1 numrxqueues 1 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
     267304887   98440      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
     267304887   98440      0       0       0       0 
2: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 66:ff:ee:41:ce:cc brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
            58       1      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
         17327     137      0       0       0       0 
3: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 06:e2:fc:10:79:52 brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         17327     137      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
            58       1      0       0       0       0 
4: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UNKNOWN mode DEFAULT group default qlen 1000
    link/ether ee:56:e2:38:61:c1 brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    vxlan external id 0 srcport 0 0 dstport 8472 nolearning ttl auto ageing 300 udpcsum noudp6zerocsumtx noudp6zerocsumrx addrgenmode eui64 numtxqueues 1 numrxqueues 1 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
             0       0      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
             0       0      0       0       0       0 
6: lxc_health@if5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether d2:69:21:fd:bb:63 brd ff:ff:ff:ff:ff:ff link-netns cilium-health promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
          2989      37      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
          3826      46      0       0       0       0 
10: lxc4731b84c7f23@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 96:f2:93:19:ee:19 brd ff:ff:ff:ff:ff:ff link-netnsid 3 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         37677     362      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        124156     359      0       0       0       0 
12: lxcd5f50712b795@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether aa:29:0a:cd:a9:c7 brd ff:ff:ff:ff:ff:ff link-netnsid 5 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         28740     312      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        188757     291      0       0       0       0 
14: lxc3ad9da7138e0@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 56:1c:8b:59:c2:f3 brd ff:ff:ff:ff:ff:ff link-netnsid 6 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        214104    1214      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        814410    1170      0       0       0       0 
16: lxc8f4963f4d794@if15: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether ae:85:3f:ed:55:fa brd ff:ff:ff:ff:ff:ff link-netnsid 13 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         18652     204      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
         22290     272      0       0       0       0 
18: lxc2553a1209f7b@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 42:ca:ed:d2:b3:59 brd ff:ff:ff:ff:ff:ff link-netnsid 10 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         26937     286      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        186228     263      0       0       0       0 
20: lxce015178ea3e5@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 92:61:43:a6:2b:2d brd ff:ff:ff:ff:ff:ff link-netnsid 8 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
           956      12      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
             0       0      0       0       0       0 
22: lxc85e32e5f3830@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 2e:62:28:11:42:11 brd ff:ff:ff:ff:ff:ff link-netnsid 11 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        276485     906      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        391925    1092      0       0       0       0 
24: lxc5aa26ecaf428@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 0a:c0:f0:54:67:48 brd ff:ff:ff:ff:ff:ff link-netnsid 7 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        144376    1198      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        203337    1221      0       0       0       0 
26: lxcc4f2ad3599a9@if25: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 62:da:ec:6b:90:90 brd ff:ff:ff:ff:ff:ff link-netnsid 12 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        105936     931      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       2226885     791      0       0       0       0 
28: lxca6e942e43be4@if27: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 56:d6:36:07:e9:45 brd ff:ff:ff:ff:ff:ff link-netnsid 9 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         70057     444      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
         73265     501      0       0       0       0 
30: lxc74e3fcbb5020@if29: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 3e:6f:6a:ae:ce:4c brd ff:ff:ff:ff:ff:ff link-netnsid 2 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        114518    1063      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       2883349     937      0       0       0       0 
32: lxc99e06d89f0fa@if31: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether de:fb:8f:a5:eb:ca brd ff:ff:ff:ff:ff:ff link-netnsid 4 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
          1495      18      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
          1351       8      0       0       0       0 
34: lxcd4296424070a@if33: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 6e:fd:8e:af:03:32 brd ff:ff:ff:ff:ff:ff link-netnsid 14 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
          1425      17      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
           941       8      0       0       0       0 
36: lxca3bc785de088@if35: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 9e:8b:cf:03:5f:32 brd ff:ff:ff:ff:ff:ff link-netnsid 15 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         24076      34      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
          5033      34      0       0       0       0 
38: lxc7cd25424e3c0@if37: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether d6:fc:9b:b6:91:9f brd ff:ff:ff:ff:ff:ff link-netnsid 16 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         13871     132      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
         20788     116      0       0       0       0 
40: lxc7e22bb71519c@if39: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 2e:9c:eb:75:07:90 brd ff:ff:ff:ff:ff:ff link-netnsid 17 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         12037      31      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
          4399      30      0       0       0       0 
44: lxcdc89b647f006@if43: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether ba:5e:3c:1c:65:9b brd ff:ff:ff:ff:ff:ff link-netnsid 19 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         27271      32      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
          4417      30      0       0       0       0 
48: lxc2d7efae318fd@if47: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 96:02:0a:e8:cd:1f brd ff:ff:ff:ff:ff:ff link-netnsid 21 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
          6929      30      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
          3840      28      0       0       0       0 
58: lxcf80faf7bf140@if57: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether e6:02:e8:77:37:28 brd ff:ff:ff:ff:ff:ff link-netnsid 26 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
          4681      49      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
          5463      36      0       0       0       0 
60: lxc4889aef29f33@if59: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 52:3b:a8:33:de:89 brd ff:ff:ff:ff:ff:ff link-netnsid 27 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
          3377      48      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
          3221      22      0       0       0       0 
63: eth0@if64: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 02:42:ac:11:00:02 brd ff:ff:ff:ff:ff:ff link-netnsid 0 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
    1270015423  118472      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
     122276311   96652      0       0       0       0 
65: lxc7f62068e89e0@if64: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 26:63:ac:d3:10:0f brd ff:ff:ff:ff:ff:ff link-netnsid 29 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         10132      93      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
         12026      94      0       0       0       0 
67: lxcc57ce94121eb@if66: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 1a:aa:9c:85:68:59 brd ff:ff:ff:ff:ff:ff link-netnsid 30 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         44126     328      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        267354     328      0       0       0       0 
69: lxcf0882de5a2d1@if68: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether f2:f7:49:10:e6:ad brd ff:ff:ff:ff:ff:ff link-netnsid 20 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         12520      72      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
         15427      65      0       0       0       0 
71: lxc14e2da0d3f54@if70: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 42:8a:b8:70:f8:45 brd ff:ff:ff:ff:ff:ff link-netnsid 24 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         13987      86      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
         25124      79      0       0       0       0 
73: lxc155b3629c0eb@if72: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 72:c9:e8:7a:6a:98 brd ff:ff:ff:ff:ff:ff link-netnsid 28 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 32 numrxqueues 32 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
        200567    1933      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        266056    1933      0       0       0       0 
