[
  {
    "containers": [
      {
        "cgroup-id": 90540,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod343b04d8-3d0d-45d9-b5ed-86ccdbaaec31/e6e0370b0c0d274a1ee6320f064cec282e5d004567e9e0d7050cdbae05f747e5"
      }
    ],
    "ips": [
      "10.244.0.40"
    ],
    "name": "cert-manager-webhook-879c48cd4-qp49t",
    "namespace": "cert-manager"
  },
  {
    "containers": [
      {
        "cgroup-id": 94240,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podfe548dcc-8789-48c8-8288-488a9aa4c04a/070bd0d3b9bd1fefe1efcfaff7f99a366718df9ae84f2f499a0a33d38114f6eb"
      },
      {
        "cgroup-id": 92686,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podfe548dcc-8789-48c8-8288-488a9aa4c04a/88778d17a8681072ae03ad3eb49624e5c363c293e7ab6c3cb28db039d22b35a8"
      }
    ],
    "ips": [
      "10.244.0.46"
    ],
    "name": "hubble-ui-6b468cff75-zwm9s",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 94388,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podf0b3c79a-07b4-42c7-9f55-2d91bce52e02/ed577f6f72142bcce52d2f78ce2f55696f872650d562ac063ebbad7021a14ff2"
      }
    ],
    "ips": [
      "10.244.0.159"
    ],
    "name": "frontend-58b6bf847f-nzgv5",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 88246,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/burstable/podde74130d-b039-4a9f-a47d-920f4c13beb1/44ae9903bcb2bdc69d69b6d8256db0affeec5d8a266781acdd6b4dd2aba83502"
      }
    ],
    "ips": [
      "172.17.0.2"
    ],
    "name": "cilium-9ccqc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 90984,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podb70abd3d-f201-47fb-b585-022349956460/b084a78b39597ed66d467e9ed512498913fcad8322542072ea9e3521727afb06"
      }
    ],
    "ips": [
      "10.244.0.123"
    ],
    "name": "openebs-ndm-cluster-exporter-589554f487-g4gzj",
    "namespace": "openebs"
  },
  {
    "containers": [
      {
        "cgroup-id": 95942,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod88475714-5951-4aab-a470-f84bf90fb096/a45fde5a6f4b7e5f4c50e4367fc08b4cf2f2afcabc63544bce58b1d481772b9e"
      }
    ],
    "ips": [
      "10.244.0.26"
    ],
    "name": "livestreamdb-6877b6fc75-7w45t",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 90910,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/burstable/pod65e9d483-85fe-46a1-8495-00ad7e6976b5/3cb8a14d05d37835cdabafe08a31567d18eb9b765c42ddb326bacc9c114f4417"
      }
    ],
    "ips": [
      "10.244.0.49"
    ],
    "name": "coredns-878bb57ff-lgfbn",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 90170,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/poda7b488b1-0655-46ab-adb6-30f63d99fb5d/725d428b5275e07be852804494ee4312d5293777e8019a4b3218ce38b39b3076"
      }
    ],
    "ips": [
      "10.244.0.52"
    ],
    "name": "cert-manager-cainjector-6774f986b-jw7hp",
    "namespace": "cert-manager"
  },
  {
    "containers": [
      {
        "cgroup-id": 89356,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/poddd555fad-2599-4f22-82aa-2257f3cb7e76/cb550c40e049136568af0bf652b590e6f0f4adf65cc7ba3b684186161c30fb3d"
      }
    ],
    "ips": [
      "172.17.0.2"
    ],
    "name": "openebs-ndm-c7p7w",
    "namespace": "openebs"
  },
  {
    "containers": [
      {
        "cgroup-id": 94166,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podd119b32f-ca31-4f9b-8088-0db67b1c8973/06c7d313c5d18e26194a7f8998c147e0c49fdf8209a8710cba7a6a4713d7cc54"
      }
    ],
    "ips": [
      "10.244.0.47"
    ],
    "name": "kratos-77cbf98c8f-k2l6k",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 94018,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod03f5212b-d699-4f61-ae05-c46e665bc3d6/9c8b8a2d1d90a6079660ffb9e69cc934c28c7cfda1f31ce709e8bfd428247b98"
      }
    ],
    "ips": [
      "10.244.0.231"
    ],
    "name": "frontend-58b6bf847f-rm7qs",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 90392,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/poda59b6fe3-6d31-4327-8171-f2f23daf9d20/586abc3041698bfe13828ab4b1474c1c8ae7c1877565107e56f41dd8697ed2ee"
      }
    ],
    "ips": [
      "10.244.0.129"
    ],
    "name": "openebs-ndm-operator-7c667b76f8-8bkbl",
    "namespace": "openebs"
  },
  {
    "containers": [
      {
        "cgroup-id": 95646,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod277efc27-e3ef-40fd-a32d-a920a41b4c2c/71def5443f42f601b1201a85dc93edb18bd5f60c8ab3299f2bf7577e4527eef1"
      }
    ],
    "ips": [
      "10.244.0.124"
    ],
    "name": "redis-68c95977f4-5ldmf",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 96164,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod62e6decf-830f-4d18-a2e1-b5c5ab392b19/9a075d89ecbc1cf217e13adfac036575fa9bae2e487609fa264b958152c3cbcb"
      }
    ],
    "ips": [
      "10.244.0.132"
    ],
    "name": "postgres-7c845b6448-hmx74",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 90466,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/burstable/pod448e990e-961f-4e6d-abe0-f7f97efba492/b47b21d5e9b26374e953f5813a4269e88d71312eea9d42d675cd8f9a95abaa8d"
      }
    ],
    "ips": [
      "10.244.0.112"
    ],
    "name": "metrics-server-7f86dff975-tb5rv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 90836,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod4745369b-f5b5-4403-bfb0-1ab1940e0dd0/fe531199b532bcf179b4eda20f88a9626c48f22a8ac12c505e00d5218b5d13ea"
      }
    ],
    "ips": [
      "10.244.0.106"
    ],
    "name": "cert-manager-78ddc5db85-nbbjs",
    "namespace": "cert-manager"
  },
  {
    "containers": [
      {
        "cgroup-id": 90688,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod1b9028b7-c7f2-43d2-abcf-baa49db879e3/4663798fff68e004985ea294f9d52bcc3479321bfd847fe37147fd4355b03f98"
      }
    ],
    "ips": [
      "10.244.0.149"
    ],
    "name": "openebs-localpv-provisioner-7d6ccb7795-pnpxg",
    "namespace": "openebs"
  },
  {
    "containers": [
      {
        "cgroup-id": 96312,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podf478d693-c623-423f-b3de-f45229f45150/612832e179654c543fa75f42180d3213854a09fbaf00adb128e132c8d42051e5"
      }
    ],
    "ips": [
      "10.244.0.177"
    ],
    "name": "streamchat-79dfbb9bb4-5bt4p",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 93352,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod49dcbada-10c5-4230-8ca6-09b8a0187c9d/ab7f1506121a0b67871fafcf594df7cc1c8f25210cfb29774d4e63febfff60ac"
      }
    ],
    "ips": [
      "10.244.0.86"
    ],
    "name": "hubble-relay-777496bf44-h6sbk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 93574,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podcd539a42-97c2-4fe1-a6dd-d0950a06286e/8b12648ed79dbc58c8e5f3a865c43a939c251ebee33ef6a3f6b516fedefd36aa"
      }
    ],
    "ips": [
      "10.244.0.222"
    ],
    "name": "backend-855f6c7b4-j4k6m",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 95498,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod6951dcb8-577e-415f-bd2c-fc9398ae1e7c/18a2aedb0c22e165f3e4164b6f5ea5db0fbce6c68708440fe924f3c0a637193c"
      }
    ],
    "ips": [
      "10.244.0.81"
    ],
    "name": "traffic-manager-55d995585d-xn8tw",
    "namespace": "ambassador"
  },
  {
    "containers": [
      {
        "cgroup-id": 90614,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod76a9876a-cb69-454f-8661-c82a89f669b2/52dd4c7897815c8d46d7c4ea31355544236c37169026e5c0c50173fc0f8cc204"
      }
    ],
    "ips": [
      "10.244.0.143"
    ],
    "name": "openebs-ndm-node-exporter-bg5c6",
    "namespace": "openebs"
  },
  {
    "containers": [
      {
        "cgroup-id": 94092,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod171df4b5-ae18-48de-b989-8def46a2f735/daf97eecd0de47d668680a3e42c80f4eadf33ae0a647d4ee11b6be11fdfa0b8f"
      }
    ],
    "ips": [
      "10.244.0.41"
    ],
    "name": "frontend-58b6bf847f-xgnzm",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 94462,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/poda7afe9d5-c427-4452-8ba5-aa73273b062a/76fc62543be30e9fa07fa0c06184b63b48117ff15bcf318b39b72c435d146815"
      }
    ],
    "ips": [
      "10.244.0.160"
    ],
    "name": "frontend-58b6bf847f-sxngk",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 93500,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod8ed04157-bd6f-4b85-9b09-64e181b24455/5ea1e4f7bbf314e0c016c6f8367e1f5897f2158f85a8bc0747197eac7a19c26c"
      }
    ],
    "ips": [
      "10.244.0.137"
    ],
    "name": "backend-855f6c7b4-2lvs2",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 96016,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod42939137-fb3c-4671-be78-ffad88d5effa/4ea70fa7ca9277694910a7791a2516a6b8f6cd3afec913e95606dea3f606290f"
      }
    ],
    "ips": [
      "10.244.0.62"
    ],
    "name": "minio-d496dbccf-8rsnz",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 96460,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod34e37066-ae94-4a73-8d49-c23fe42d6dab/e293a121236cbabd11a92e7cd2b16c99adc4ab855c8538ba4d1fcff46940d953"
      }
    ],
    "ips": [
      "10.244.0.178"
    ],
    "name": "pgweb-b74849bb6-rd2fs",
    "namespace": "streampai"
  }
]

