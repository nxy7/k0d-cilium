## Map: cilium_policy_02747
Cache is disabled


## Map: cilium_policy_00105
Cache is disabled


## Map: cilium_policy_00471
Cache is disabled


## Map: cilium_runtime_config
Cache is disabled


## Map: cilium_lxc
Key              Value                                                                                            State   Error
10.244.0.129:0   id=2326  sec_id=19125 flags=0x0000 ifindex=10  mac=2E:7D:11:22:A4:40 nodemac=96:F2:93:19:EE:19   sync    
10.244.0.143:0   id=82    sec_id=40792 flags=0x0000 ifindex=12  mac=F2:0F:57:B3:6C:28 nodemac=AA:29:0A:CD:A9:C7   sync    
10.244.0.123:0   id=4067  sec_id=62607 flags=0x0000 ifindex=18  mac=96:D2:F4:A7:BB:C0 nodemac=42:CA:ED:D2:B3:59   sync    
10.244.0.81:0    id=2497  sec_id=4626  flags=0x0000 ifindex=67  mac=32:B7:61:05:6B:B1 nodemac=1A:AA:9C:85:68:59   sync    
10.244.0.124:0   id=645   sec_id=20103 flags=0x0000 ifindex=60  mac=42:1D:71:D0:63:FC nodemac=52:3B:A8:33:DE:89   sync    
10.244.0.29:0    id=160   sec_id=4     flags=0x0000 ifindex=6   mac=62:3B:02:92:50:78 nodemac=D2:69:21:FD:BB:63   sync    
10.244.0.49:0    id=633   sec_id=31330 flags=0x0000 ifindex=24  mac=4A:C9:92:BD:4D:EE nodemac=0A:C0:F0:54:67:48   sync    
10.244.0.112:0   id=2747  sec_id=10281 flags=0x0000 ifindex=22  mac=66:05:5C:95:ED:56 nodemac=2E:62:28:11:42:11   sync    
10.244.0.106:0   id=626   sec_id=6602  flags=0x0000 ifindex=30  mac=86:DA:B5:28:CC:22 nodemac=3E:6F:6A:AE:CE:4C   sync    
10.244.0.137:0   id=257   sec_id=22996 flags=0x0000 ifindex=32  mac=76:EA:FD:64:AA:73 nodemac=DE:FB:8F:A5:EB:CA   sync    
10.244.0.159:0   id=1493  sec_id=29809 flags=0x0000 ifindex=44  mac=CA:77:CB:4E:1C:80 nodemac=BA:5E:3C:1C:65:9B   sync    
10.244.0.40:0    id=198   sec_id=17675 flags=0x0000 ifindex=28  mac=AE:BF:FE:6B:BA:0D nodemac=56:D6:36:07:E9:45   sync    
10.244.0.149:0   id=2207  sec_id=63175 flags=0x0000 ifindex=14  mac=FA:8E:C3:46:E1:72 nodemac=56:1C:8B:59:C2:F3   sync    
10.244.0.222:0   id=2856  sec_id=22996 flags=0x0000 ifindex=34  mac=F2:AA:EC:70:BA:10 nodemac=6E:FD:8E:AF:03:32   sync    
10.244.0.177:0   id=1288  sec_id=10456 flags=0x0000 ifindex=65  mac=CA:87:CB:2D:C5:29 nodemac=26:63:AC:D3:10:0F   sync    
10.244.0.41:0    id=471   sec_id=29809 flags=0x0000 ifindex=40  mac=6A:0F:F8:EE:78:20 nodemac=2E:9C:EB:75:07:90   sync    
10.244.0.160:0   id=3903  sec_id=29809 flags=0x0000 ifindex=48  mac=4A:D8:6E:BC:92:E7 nodemac=96:02:0A:E8:CD:1F   sync    
10.244.0.178:0   id=215   sec_id=43844 flags=0x0000 ifindex=58  mac=2E:AA:55:F4:55:5D nodemac=E6:02:E8:77:37:28   sync    
10.244.0.26:0    id=702   sec_id=12173 flags=0x0000 ifindex=69  mac=D2:77:D5:FC:41:BC nodemac=F2:F7:49:10:E6:AD   sync    
10.244.0.62:0    id=455   sec_id=12060 flags=0x0000 ifindex=71  mac=A6:EE:91:65:9A:32 nodemac=42:8A:B8:70:F8:45   sync    
10.244.0.132:0   id=606   sec_id=5148  flags=0x0000 ifindex=73  mac=FE:76:8C:09:97:60 nodemac=72:C9:E8:7A:6A:98   sync    
10.244.0.52:0    id=119   sec_id=5710  flags=0x0000 ifindex=26  mac=7A:B6:AD:7C:CA:04 nodemac=62:DA:EC:6B:90:90   sync    
10.244.0.86:0    id=208   sec_id=44885 flags=0x0000 ifindex=16  mac=4E:F0:2D:CA:14:AD nodemac=AE:85:3F:ED:55:FA   sync    
10.244.0.46:0    id=3933  sec_id=290   flags=0x0000 ifindex=20  mac=16:B6:3C:F9:FF:C8 nodemac=92:61:43:A6:2B:2D   sync    
10.244.0.231:0   id=105   sec_id=29809 flags=0x0000 ifindex=36  mac=EA:46:93:6D:E7:E6 nodemac=9E:8B:CF:03:5F:32   sync    
10.244.0.47:0    id=2128  sec_id=36400 flags=0x0000 ifindex=38  mac=5A:C9:E6:AB:85:D9 nodemac=D6:FC:9B:B6:91:9F   sync    

## Map: cilium_lb4_source_range
Cache is empty


## Map: cilium_policy_01111
Cache is disabled


## Map: cilium_policy_00626
Cache is disabled


## Map: cilium_policy_03903
Cache is disabled


## Map: cilium_policy_00633
Cache is disabled


## Map: cilium_policy_04067
Cache is disabled


## Map: cilium_ipcache
Key               Value                                                State   Error
10.244.0.29/32    identity=4 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.244.0.49/32    identity=31330 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.231/32   identity=29809 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.81/32    identity=4626 encryptkey=0 tunnelendpoint=0.0.0.0    sync    
10.244.0.178/32   identity=43844 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.143/32   identity=40792 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.40/32    identity=17675 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.129/32   identity=19125 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.160/32   identity=29809 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.124/32   identity=20103 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.46/32    identity=290 encryptkey=0 tunnelendpoint=0.0.0.0     sync    
10.244.0.47/32    identity=36400 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.159/32   identity=29809 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.62/32    identity=12060 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.177/32   identity=10456 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.149/32   identity=63175 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.112/32   identity=10281 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.86/32    identity=44885 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.222/32   identity=22996 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.137/32   identity=22996 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.243/32   identity=8 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
172.17.0.2/32     identity=1 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.244.0.123/32   identity=62607 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.41/32    identity=29809 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.52/32    identity=5710 encryptkey=0 tunnelendpoint=0.0.0.0    sync    
10.244.0.26/32    identity=12173 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.132/32   identity=5148 encryptkey=0 tunnelendpoint=0.0.0.0    sync    
0.0.0.0/0         identity=2 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.244.0.130/32   identity=1 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.244.0.106/32   identity=6602 encryptkey=0 tunnelendpoint=0.0.0.0    sync    

## Map: cilium_lb4_services_v2
Key                   Value                      State   Error
0.0.0.0:30888         30008 0 (200) [0x2 0x4]    sync    
10.110.101.73:443     0 1 (181) [0x0 0x0]        sync    
10.96.0.10:53         0 1 (96) [0x0 0x0]         sync    
10.96.0.10:9153       0 1 (97) [0x0 0x0]         sync    
10.97.110.167:9000    0 1 (192) [0x0 0x0]        sync    
10.109.161.190:8081   0 1 (194) [0x0 0x0]        sync    
10.97.78.2:80         30008 0 (197) [0x0 0x4]    sync    
10.109.194.147:443    0 1 (201) [0x0 0x0]        sync    
10.97.217.47:80       0 1 (182) [0x0 0x0]        sync    
10.100.176.195:443    0 1 (186) [0x0 0x0]        sync    
10.108.174.65:7000    0 0 (188) [0x0 0x0]        sync    
10.105.1.38:5432      0 1 (191) [0x0 0x0]        sync    
10.97.110.167:9001    0 1 (193) [0x0 0x0]        sync    
10.98.188.83:6379     0 1 (196) [0x0 0x0]        sync    
10.96.0.1:443         0 1 (92) [0x0 0x0]         sync    
10.102.58.195:3000    0 4 (189) [0x0 0x0]        sync    
10.101.105.189:4433   0 1 (190) [0x0 0x0]        sync    
172.17.8.187:80       30008 0 (198) [0x60 0x4]   sync    
10.104.81.197:9402    0 1 (183) [0x0 0x0]        sync    
10.104.68.211:80      0 1 (184) [0x0 0x0]        sync    
10.110.16.102:443     0 1 (185) [0x0 0x10]       sync    
10.99.236.194:7000    0 2 (187) [0x0 0x0]        sync    
10.103.2.13:5432      0 1 (195) [0x0 0x0]        sync    
172.17.0.2:30888      30008 0 (199) [0x42 0x4]   sync    

## Map: cilium_lb4_reverse_nat
Key   Value                 State   Error
198   172.17.8.187:80       sync    
199   172.17.0.2:30888      sync    
96    10.96.0.10:53         sync    
192   10.97.110.167:9000    sync    
191   10.105.1.38:5432      sync    
195   10.103.2.13:5432      sync    
196   10.98.188.83:6379     sync    
200   0.0.0.0:30888         sync    
187   10.99.236.194:7000    sync    
189   10.102.58.195:3000    sync    
184   10.104.68.211:80      sync    
185   10.110.16.102:443     sync    
193   10.97.110.167:9001    sync    
194   10.109.161.190:8081   sync    
201   10.109.194.147:443    sync    
182   10.97.217.47:80       sync    
183   10.104.81.197:9402    sync    
97    10.96.0.10:9153       sync    
186   10.100.176.195:443    sync    
188   10.108.174.65:7000    sync    
190   10.101.105.189:4433   sync    
197   10.97.78.2:80         sync    
181   10.110.101.73:443     sync    
92    10.96.0.1:443         sync    

## Map: cilium_lb4_affinity
Cache is disabled


## Map: cilium_policy_01493
Cache is disabled


## Map: cilium_policy_00606
Cache is disabled


## Map: cilium_policy_00208
Cache is disabled


## Map: cilium_policy_00119
Cache is disabled


## Map: cilium_policy_00455
Cache is disabled


## Map: cilium_lb_affinity_match
Cache is empty


## Map: cilium_policy_02856
Cache is disabled


## Map: cilium_policy_00257
Cache is disabled


## Map: cilium_policy_00702
Cache is disabled


## Map: cilium_policy_00645
Cache is disabled


## Map: cilium_tunnel_map
Cache is empty


## Map: cilium_lb4_backends_v3
Key   Value                State   Error
176   ANY://10.244.0.106   sync    
186   ANY://10.244.0.46    sync    
181   ANY://10.244.0.137   sync    
183   ANY://10.244.0.231   sync    
184   ANY://10.244.0.222   sync    
185   ANY://10.244.0.47    sync    
190   ANY://10.244.0.124   sync    
177   ANY://10.244.0.49    sync    
178   ANY://10.244.0.49    sync    
179   ANY://10.244.0.112   sync    
193   ANY://10.244.0.62    sync    
188   ANY://10.244.0.160   sync    
192   ANY://10.244.0.26    sync    
194   ANY://10.244.0.62    sync    
174   ANY://172.17.0.2     sync    
180   ANY://10.244.0.86    sync    
182   ANY://10.244.0.41    sync    
195   ANY://10.244.0.132   sync    
196   ANY://10.244.0.178   sync    
175   ANY://10.244.0.40    sync    
187   ANY://10.244.0.159   sync    
189   ANY://10.244.0.81    sync    

## Map: cilium_policy_00198
Cache is disabled


## Map: cilium_policy_03933
Cache is disabled


## Map: cilium_policy_01288
Cache is disabled


## Map: cilium_policy_00082
Cache is disabled


## Map: cilium_policy_02326
Cache is disabled


## Map: cilium_policy_02207
Cache is disabled


## Map: cilium_policy_00215
Cache is disabled


## Map: cilium_policy_00160
Cache is disabled


## Map: cilium_policy_02128
Cache is disabled


## Map: cilium_policy_02497
Cache is disabled


## Map: cilium_auth_map
Cache is disabled


## Map: cilium_node_map
Cache is disabled


## Map: cilium_metrics
Cache is disabled


## Map: cilium_l2_responder_v4
Cache is disabled


