KEY             VALUE
AgentLiveness   5803262867121
UTimeOffset     3308435937500000
