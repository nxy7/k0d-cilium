top - 14:43:24 up  1:36,  0 users,  load average: 0.56, 0.80, 0.81
Tasks:  16 total,  10 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 33.7 us, 58.0 sy,  0.0 ni,  8.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :  15915.0 total,    386.6 free,   5376.4 used,  10152.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   9919.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   7064 root      20   0    2928   1152   1152 R  66.7   0.0   0:00.10 cat
   7071 root      20   0  786424  61056  41600 S  26.7   0.4   0:00.04 cilium
   6921 root      20   0  725664  16748  10368 S  20.0   0.1   0:00.04 cilium-+
   7072 root      20   0  786424  60416  41728 S  20.0   0.4   0:00.03 cilium
   7143 root      20   0  785144  58496  40960 R  20.0   0.4   0:00.03 cilium
      1 root      20   0  880516 165988  70016 S  13.3   1.0   0:06.22 cilium-+
   7181 root      20   0  785336  45440  36352 R  13.3   0.3   0:00.02 cilium
   7160 root      20   0  785080  39552  31872 R   6.7   0.2   0:00.01 cilium
   7162 root      20   0  785592  45184  36736 R   6.7   0.3   0:00.01 cilium
    199 root      20   0  713924   4480   3712 S   0.0   0.0   0:00.00 cilium-+
   6957 root      20   0    7180   3072   2688 R   0.0   0.0   0:00.00 top
   7194 root      20   0  784248  21248  17664 R   0.0   0.1   0:00.00 cilium
   7201 root      20   0  783992  16384  13824 R   0.0   0.1   0:00.00 cilium
   7202 root      20   0  783736  19840  16896 R   0.0   0.1   0:00.00 cilium
   7209 root      20   0  783480   8704   8064 S   0.0   0.1   0:00.00 cilium
   7213 root      20   0    4360   2688   2560 R   0.0   0.0   0:00.00 bash
