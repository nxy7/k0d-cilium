markdown output at /tmp/cilium-bugtool-20230905-144324.214+0000-UTC-3695944902/cmd/cilium-debuginfo-20230905-144324.327+0000-UTC.md
json output at /tmp/cilium-bugtool-20230905-144324.214+0000-UTC-3695944902/cmd/cilium-debuginfo-20230905-144324.327+0000-UTC.json
