[
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.40",
          "nodeName": "k0s",
          "port": 10250,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cert-manager-webhook",
        "namespace": "cert-manager",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.110.101.73",
        "port": 443,
        "scope": "external"
      },
      "id": 181
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.40",
            "nodeName": "k0s",
            "port": 10250,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cert-manager-webhook",
          "namespace": "cert-manager",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.110.101.73",
          "port": 443,
          "scope": "external"
        },
        "id": 181
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.47",
          "nodeName": "k0s",
          "port": 4433,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kratos",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.101.105.189",
        "port": 4433,
        "scope": "external"
      },
      "id": 190
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.47",
            "nodeName": "k0s",
            "port": 4433,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kratos",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.101.105.189",
          "port": 4433,
          "scope": "external"
        },
        "id": 190
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "172.17.0.2",
          "port": 6443,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kubernetes",
        "namespace": "default",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.96.0.1",
        "port": 443,
        "scope": "external"
      },
      "id": 92
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "172.17.0.2",
            "port": 6443,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kubernetes",
          "namespace": "default",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.96.0.1",
          "port": 443,
          "scope": "external"
        },
        "id": 92
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cilium-gateway-sgtw",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "NodePort"
      },
      "frontend-address": {
        "ip": "0.0.0.0",
        "port": 30888,
        "scope": "external"
      },
      "id": 200
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cilium-gateway-sgtw",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "NodePort"
        },
        "frontend-address": {
          "ip": "0.0.0.0",
          "port": 30888,
          "scope": "external"
        },
        "id": 200
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.86",
          "nodeName": "k0s",
          "port": 4245,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "hubble-relay",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.97.217.47",
        "port": 80,
        "scope": "external"
      },
      "id": 182
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.86",
            "nodeName": "k0s",
            "port": 4245,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "hubble-relay",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.97.217.47",
          "port": 80,
          "scope": "external"
        },
        "id": 182
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "172.17.0.2",
          "nodeName": "k0s",
          "port": 4244,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Local",
        "name": "hubble-peer",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.110.16.102",
        "port": 443,
        "scope": "external"
      },
      "id": 185
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "172.17.0.2",
            "nodeName": "k0s",
            "port": 4244,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Local",
          "name": "hubble-peer",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.110.16.102",
          "port": 443,
          "scope": "external"
        },
        "id": 185
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.137",
          "nodeName": "k0s",
          "port": 7000,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.244.0.222",
          "nodeName": "k0s",
          "port": 7000,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "backend",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.99.236.194",
        "port": 7000,
        "scope": "external"
      },
      "id": 187
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.137",
            "nodeName": "k0s",
            "port": 7000,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.244.0.222",
            "nodeName": "k0s",
            "port": 7000,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "backend",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.99.236.194",
          "port": 7000,
          "scope": "external"
        },
        "id": 187
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.41",
          "nodeName": "k0s",
          "port": 3000,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.244.0.231",
          "nodeName": "k0s",
          "port": 3000,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.244.0.159",
          "nodeName": "k0s",
          "port": 3000,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.244.0.160",
          "nodeName": "k0s",
          "port": 3000,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "frontend",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.102.58.195",
        "port": 3000,
        "scope": "external"
      },
      "id": 189
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.41",
            "nodeName": "k0s",
            "port": 3000,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.244.0.231",
            "nodeName": "k0s",
            "port": 3000,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.244.0.159",
            "nodeName": "k0s",
            "port": 3000,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.244.0.160",
            "nodeName": "k0s",
            "port": 3000,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "frontend",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.102.58.195",
          "port": 3000,
          "scope": "external"
        },
        "id": 189
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cilium-gateway-sgtw",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "NodePort"
      },
      "frontend-address": {
        "ip": "172.17.0.2",
        "port": 30888,
        "scope": "external"
      },
      "id": 199
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cilium-gateway-sgtw",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "NodePort"
        },
        "frontend-address": {
          "ip": "172.17.0.2",
          "port": 30888,
          "scope": "external"
        },
        "id": 199
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.46",
          "nodeName": "k0s",
          "port": 8081,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "hubble-ui",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.104.68.211",
        "port": 80,
        "scope": "external"
      },
      "id": 184
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.46",
            "nodeName": "k0s",
            "port": 8081,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "hubble-ui",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.104.68.211",
          "port": 80,
          "scope": "external"
        },
        "id": 184
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cilium-gateway-sgtw",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.97.78.2",
        "port": 80,
        "scope": "external"
      },
      "id": 197
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cilium-gateway-sgtw",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.97.78.2",
          "port": 80,
          "scope": "external"
        },
        "id": 197
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.49",
          "nodeName": "k0s",
          "port": 53,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kube-dns",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.96.0.10",
        "port": 53,
        "scope": "external"
      },
      "id": 96
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.49",
            "nodeName": "k0s",
            "port": 53,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kube-dns",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.96.0.10",
          "port": 53,
          "scope": "external"
        },
        "id": 96
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cilium-gateway-sgtw",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "LoadBalancer"
      },
      "frontend-address": {
        "ip": "172.17.8.187",
        "port": 80,
        "scope": "external"
      },
      "id": 198
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cilium-gateway-sgtw",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "LoadBalancer"
        },
        "frontend-address": {
          "ip": "172.17.8.187",
          "port": 80,
          "scope": "external"
        },
        "id": 198
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.112",
          "nodeName": "k0s",
          "port": 10250,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "metrics-server",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.176.195",
        "port": 443,
        "scope": "external"
      },
      "id": 186
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.112",
            "nodeName": "k0s",
            "port": 10250,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "metrics-server",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.176.195",
          "port": 443,
          "scope": "external"
        },
        "id": 186
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.81",
          "nodeName": "k0s",
          "port": 443,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "agent-injector",
        "namespace": "ambassador",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.109.194.147",
        "port": 443,
        "scope": "external"
      },
      "id": 201
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.81",
            "nodeName": "k0s",
            "port": 443,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "agent-injector",
          "namespace": "ambassador",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.109.194.147",
          "port": 443,
          "scope": "external"
        },
        "id": 201
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.62",
          "nodeName": "k0s",
          "port": 9000,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "minio",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.97.110.167",
        "port": 9000,
        "scope": "external"
      },
      "id": 192
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.62",
            "nodeName": "k0s",
            "port": 9000,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "minio",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.97.110.167",
          "port": 9000,
          "scope": "external"
        },
        "id": 192
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.178",
          "nodeName": "k0s",
          "port": 8081,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "pgweb",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.109.161.190",
        "port": 8081,
        "scope": "external"
      },
      "id": 194
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.178",
            "nodeName": "k0s",
            "port": 8081,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "pgweb",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.109.161.190",
          "port": 8081,
          "scope": "external"
        },
        "id": 194
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.132",
          "nodeName": "k0s",
          "port": 5432,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "postgres",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.103.2.13",
        "port": 5432,
        "scope": "external"
      },
      "id": 195
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.132",
            "nodeName": "k0s",
            "port": 5432,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "postgres",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.103.2.13",
          "port": 5432,
          "scope": "external"
        },
        "id": 195
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "coqui",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.108.174.65",
        "port": 7000,
        "scope": "external"
      },
      "id": 188
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "coqui",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.108.174.65",
          "port": 7000,
          "scope": "external"
        },
        "id": 188
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.106",
          "nodeName": "k0s",
          "port": 9402,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cert-manager",
        "namespace": "cert-manager",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.104.81.197",
        "port": 9402,
        "scope": "external"
      },
      "id": 183
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.106",
            "nodeName": "k0s",
            "port": 9402,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cert-manager",
          "namespace": "cert-manager",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.104.81.197",
          "port": 9402,
          "scope": "external"
        },
        "id": 183
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.26",
          "nodeName": "k0s",
          "port": 5432,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "livestreamdb",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.105.1.38",
        "port": 5432,
        "scope": "external"
      },
      "id": 191
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.26",
            "nodeName": "k0s",
            "port": 5432,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "livestreamdb",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.105.1.38",
          "port": 5432,
          "scope": "external"
        },
        "id": 191
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.62",
          "nodeName": "k0s",
          "port": 9001,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "minio",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.97.110.167",
        "port": 9001,
        "scope": "external"
      },
      "id": 193
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.62",
            "nodeName": "k0s",
            "port": 9001,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "minio",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.97.110.167",
          "port": 9001,
          "scope": "external"
        },
        "id": 193
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.124",
          "nodeName": "k0s",
          "port": 6379,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "redis",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.98.188.83",
        "port": 6379,
        "scope": "external"
      },
      "id": 196
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.124",
            "nodeName": "k0s",
            "port": 6379,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "redis",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.98.188.83",
          "port": 6379,
          "scope": "external"
        },
        "id": 196
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.49",
          "nodeName": "k0s",
          "port": 9153,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kube-dns",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.96.0.10",
        "port": 9153,
        "scope": "external"
      },
      "id": 97
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.49",
            "nodeName": "k0s",
            "port": 9153,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kube-dns",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.96.0.10",
          "port": 9153,
          "scope": "external"
        },
        "id": 97
      }
    }
  }
]

