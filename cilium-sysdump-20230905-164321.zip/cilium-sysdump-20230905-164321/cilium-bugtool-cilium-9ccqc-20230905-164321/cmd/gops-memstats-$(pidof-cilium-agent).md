alloc: 39.66MB (41583024 bytes)
total-alloc: 673.78MB (706505608 bytes)
sys: 99.41MB (104243299 bytes)
lookups: 0
mallocs: 8684012
frees: 8344021
heap-alloc: 39.66MB (41583024 bytes)
heap-sys: 76.38MB (80084992 bytes)
heap-idle: 21.29MB (22323200 bytes)
heap-in-use: 55.09MB (57761792 bytes)
heap-released: 2.16MB (2260992 bytes)
heap-objects: 339991
stack-in-use: 7.62MB (7995392 bytes)
stack-sys: 7.62MB (7995392 bytes)
stack-mspan-inuse: 962.50KB (985600 bytes)
stack-mspan-sys: 1.18MB (1240320 bytes)
stack-mcache-inuse: 14.06KB (14400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 2.10MB (2204323 bytes)
gc-sys: 10.43MB (10936256 bytes)
next-gc: when heap-alloc >= 68.08MB (71388712 bytes)
last-gc: 2023-09-05 14:43:06.842738998 +0000 UTC
gc-pause-total: 1.874363ms
gc-pause: 29638
gc-pause-end: 1693924986842738998
num-gc: 30
num-forced-gc: 0
gc-cpu-fraction: 8.875342928897697e-05
enable-gc: true
debug-gc: false
