 14:43:24 up  1:36,  0 users,  load average: 0.56, 0.80, 0.81
