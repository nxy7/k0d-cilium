Error: bpf obj get (/sys/fs/bpf/tc/globals/cilium_capture4_rules): No such file or directory
> Error while running 'bpftool map dump pinned /sys/fs/bpf/tc/globals/cilium_capture4_rules':  exit status 255

