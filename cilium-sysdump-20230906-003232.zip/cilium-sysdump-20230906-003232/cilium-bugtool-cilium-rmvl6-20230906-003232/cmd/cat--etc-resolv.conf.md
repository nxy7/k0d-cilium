nameserver 192.168.100.1
options edns0
