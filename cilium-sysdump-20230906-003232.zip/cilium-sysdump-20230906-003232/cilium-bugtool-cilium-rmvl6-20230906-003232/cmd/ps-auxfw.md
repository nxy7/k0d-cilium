USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         372  0.0  0.0 725344 15232 ?        Ssl  22:32   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         391  0.0  0.0   7060  2944 ?        R    22:32   0:00  \_ ps auxfw
root         393  0.0  0.0      0     0 ?        R    22:32   0:00  \_ [ip]
root         394  0.0  0.0   4528  2816 ?        R    22:32   0:00  \_ ip -d -s l
root         395  0.0  0.0   4396   512 ?        R    22:32   0:00  \_ ip -6 r
root         398  0.0  0.0   4396  2048 ?        R    22:32   0:00  \_ ip a
root         399  0.0  0.0   2592   384 ?        R    22:32   0:00  \_ tc qdisc show
root         401  0.0  0.0   4404   896 ?        R    22:32   0:00  \_ ip -6 n
root         403  0.0  0.0   3808   896 ?        R    22:32   0:00  \_ ss -t -p -a -i -s -n -e
root         405  0.0  0.0   4360  3200 ?        R    22:32   0:00  \_ bash -c ss -u -p -a -i -s -n -e
root         406  0.0  0.0   4360  2944 ?        R    22:32   0:00  \_ bash -c tc -d -s qdisc show
root           1  2.5  0.9 879940 161224 ?       Ssl  22:29   0:05 cilium-agent --config-dir=/tmp/cilium/config-map
root         202  0.0  0.0 713924  4608 ?        Sl   22:29   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
