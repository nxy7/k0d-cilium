filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc9ad5d7a32906 direct-action not_in_hw id 1200 tag a97b197d69042187 jited 
