filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc119ad3dfee62 direct-action not_in_hw id 698 tag 46cd7f2056cd4f46 jited 
