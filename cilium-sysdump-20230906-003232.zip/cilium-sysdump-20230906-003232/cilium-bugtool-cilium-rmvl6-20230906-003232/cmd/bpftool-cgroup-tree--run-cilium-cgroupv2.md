CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2
63       cgroup_inet_ingress multi           sd_fw_ingress  
62       cgroup_inet_egress multi           sd_fw_egress   
565      cgroup_inet4_connect multi           cil_sock4_connect
571      cgroup_inet6_connect multi           cil_sock6_connect
569      cgroup_inet4_post_bind multi           cil_sock4_post_bind
573      cgroup_inet6_post_bind multi           cil_sock6_post_bind
566      cgroup_udp4_sendmsg multi           cil_sock4_sendmsg
564      cgroup_udp6_sendmsg multi           cil_sock6_sendmsg
567      cgroup_udp4_recvmsg multi           cil_sock4_recvmsg
570      cgroup_udp6_recvmsg multi           cil_sock6_recvmsg
572      cgroup_inet4_getpeername multi           cil_sock4_getpeername
568      cgroup_inet6_getpeername multi           cil_sock6_getpeername
/run/cilium/cgroupv2/sys-fs-fuse-connections.mount
    65       cgroup_inet_ingress multi           sd_fw_ingress  
    64       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/sys-kernel-config.mount
    67       cgroup_inet_ingress multi           sd_fw_ingress  
    66       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/sys-kernel-debug.mount
    38       cgroup_inet_ingress multi           sd_fw_ingress  
    37       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/kubepods/burstable/pod084a0d96-c0ca-4446-ba33-7384bedbded0/9169d26a2b4b3beab82860d26489525d651a2ff8093b056157b2c1774f5a97b4
    850      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/burstable/pod084a0d96-c0ca-4446-ba33-7384bedbded0/151792f0fdade94a6ab4b9ff6d3c9c2346d0a303b3ff954713819801b503ad09
    706      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/burstable/pod63e1d74e-df17-4aca-b7b6-ea5641d432c9/8e8011bf783211cec57f9559edd52f4c5a3a7ecc2d5a56cba2a691d1ee556113
    713      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/burstable/pod63e1d74e-df17-4aca-b7b6-ea5641d432c9/9c480a18486ab467ea28e75ebe2cdaed62cda78cf70250f92226d00afa195b53
    853      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/burstable/pod3e841622-3e54-4198-bd63-a164f910ab69/5090eca49eb5554d36b0a5ebea069fb59ef20a33766b4ba5add2c9b7ab7a943d
    242      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/burstable/pod3e841622-3e54-4198-bd63-a164f910ab69/1ad0f9d68c8aadada819642d6639f52415ada46d12fb8dddfffdc9eec6b660f5
    213      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod06d88d3e-51c3-40be-be7b-65e80614fc68/ebde194e68a8e17a16216517c53159f12003cbd9029af48ea91a70ff5f2a88b8
    923      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod06d88d3e-51c3-40be-be7b-65e80614fc68/e18ef58515f5f53361911d0617ff8fd16926314e799bfe91a035e86d0f0fb596
    793      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod606c066a-a5b8-45d3-8fa4-5f7168bf0a44/c8553fb5b519150cabc9c5b90aeae822a1f2bec257737d8e5764de4228461d84
    1037     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod606c066a-a5b8-45d3-8fa4-5f7168bf0a44/2bc1407b967a11509a0085f66e1235d4a7f5dab07edab3b7bec229ffec67b1fa
    980      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poda034ea01-f046-4c4f-a869-357017a837fa/9c7f0f6b03e857ebb62537fad16f4b5115f839725b53b520e31b0d37fe0c0636
    1341     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pode3de3505-e395-44b3-b4e7-ea288bda4005/6427c9b4239cfdf63f3799f2d090e38d1f1e88ada96de4d1dca6cfb1ce96f162
    1132     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poda823db44-abb0-4af8-ae18-8845df5a9dcd/daf2c48a05fd7f0e944fc695a0a53ba42082a8de9dbab3407e524a16436ce85e
    1272     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poda823db44-abb0-4af8-ae18-8845df5a9dcd/459bf8797b7d1673acfe370f34ef4d7a0a9b97d699b3b62dcc6b70aa2a97619d
    1350     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod5feb89ee-797a-4175-b128-3405259a613a/b7b6a14d032c51f97abff9bdafa8c4d2a94ac2d572636540ccd7594e3a4b0aab
    1031     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod5feb89ee-797a-4175-b128-3405259a613a/41e16986146af4f54bb604a2afc0a502b69f12f6b2366ef28c2843c9c67935c6
    1081     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poda7ad93c9-0624-4f8c-9159-757dc58ef138/c063250423da2f65ccaf123a90c47b59db666213204dece61764ab8a21de3899
    215      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poda7ad93c9-0624-4f8c-9159-757dc58ef138/d189eb3ee3c8700212663c27087983fa210e6cdb8f8e6259730d252d5147cbe3
    230      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podc11076ae-e37a-40c5-b3bf-e7642d284b1f/6e084173eef1e91231c5ac0fbf1c8ec1f479c27aba73d9ff0188b7d447706cbf
    929      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podc11076ae-e37a-40c5-b3bf-e7642d284b1f/d9b78e007989b543e98450adc0bb5ba9d266d6dee39f592919eabb5fb5fa416a
    809      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod34a47f5d-ecee-499d-a5b5-859ef218ff38/403654b891623b7ba035d536b5df6bbb2abc413efc9aa1c5dcd53f9dc33bd70d
    1040     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod34a47f5d-ecee-499d-a5b5-859ef218ff38/87e65a379e60675236ca60ef952f36495b5873fa58bdd4c2418cb15a6855e01d
    983      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podfc8fc111-8ad6-4c41-83ea-be6ceef74879/e99337d384b1ca0076fa257bc7b4978d019ae81dbe63f97290064a7ba274c8ee
    1344     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podfc8fc111-8ad6-4c41-83ea-be6ceef74879/8b026a6321b274f26f2d437099b9ba3dde49a0fa93bbf89b3abfca8c326cbfa8
    1247     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod11149348-f595-4ce3-9fd0-87c09b5dd1e8/7b175ce2c35a9e499a5f3d03193e1a36deb19e8cc6c213af26548e816a130e69
    812      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod11149348-f595-4ce3-9fd0-87c09b5dd1e8/975df9b7f91301093085bd7763c2efb78bca87c555e7f059470c2b34cb28acb6
    712      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod44660fac-e031-4d6a-827e-628237a55c86/e55c9bdcea3483c5233046907f0ee0a7a438138add4d1bfba105459f3eab16f6
    1009     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod44660fac-e031-4d6a-827e-628237a55c86/01d14bda9e679beb2f5b81de2c9c3a453ad614318bc4e9cf757ce90fbab75bdf
    1075     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podcee536de-330f-4f00-b0e4-7dab27714bb9/06b7dfa9480f3f6ecbfa4d505b966463d32d9dcc2f4a0033627539fdcea557d3
    1034     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podcee536de-330f-4f00-b0e4-7dab27714bb9/d3b4ca7c843b3bbb28524d620ea8d17b853d987a3f954ad37d42df0ec02f02b1
    1084     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podc0fda2d0-8b88-4050-a083-c416c3895858/d06d1aba98fd88d3057ed0d45ae53b31b45d979a1cdbf29bcce716808a26090b
    1199     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod43eb3d25-bd86-4160-a94c-8b912d594141/670ebea5e63ce61d79c48774e5f843e96cec83f71329ee344c55cd906ed336c0
    917      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod43eb3d25-bd86-4160-a94c-8b912d594141/0946b93b2ee27340a189b5d93817618c022d0e180afb8a6fe460ee99b244c820
    774      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod3b1fcd9d-d335-428d-a30c-8dc7d3c0af93/1c07fd48260112bb2722e277b67226d9cbe2864253ffb363599c85096761386e
    1316     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod0f532e25-e23d-4ec4-9381-fb942155dc79/2b7a79c00592f33a60f83ac4c576436831d8ae289d3e786ac7ec88d9f37b92b1
    1322     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod0f532e25-e23d-4ec4-9381-fb942155dc79/be53e4a8b0f16b3792de127300c49d8baa09c69b4ddba82e1b7714291e96eef3
    1241     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podcf3d3b19-62f6-4a4b-8d62-38e9cb470bac/b49ff8a3e068cbdd3406e098d0ea7b997ee7e99396ceed00180fcd05f6ea5ef5
    856      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podcf3d3b19-62f6-4a4b-8d62-38e9cb470bac/ad95ab4f4e03894ef55ada79694b91f86bf83ca8a93c4fd1f22b5cedab58576f
    771      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod0da85bef-bfe1-4158-a34b-993487b0b2cc/a366f681d628820fc6a7d9bfa03edd08709c03d5ed75feca4fa74ba3a7c1c027
    1244     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod9c3014d1-ad23-49df-a56e-38c1ae44aa7a/e0ad0276b5ccb3a7302788f9619a36f86d71e0199bba5fa10b227535f1d8afb4
    558      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod9c3014d1-ad23-49df-a56e-38c1ae44aa7a/99184ef7f7e41f6f60c92e30e3932c4c1fab4fd6a01fff2cd62a64b8e8df7977
    926      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod39c38926-f754-444d-93e6-848bec64959d/ccf8dc2c9ccd9b44995384d3c0facf63d27524691df96cee11f9a9633f444b31
    920      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod39c38926-f754-444d-93e6-848bec64959d/486bbdf08d9bed9530a795f187db01512e51cdce743663378be1d853ca880783
    777      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod05f4922c-8ee3-4d1f-89fd-e569f55c2ec1/15e1feddfe3e3f557c79e97dd04bca696e08114894bd02b4444cdce49d14a1f8
    1072     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poda7ee5c34-93db-49aa-b0d7-32cc7c889b48/e4c5d5e548addd6309cb0e34c83754e74f1d66d635aaecef004e0249b903f82e
    938      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poda7ee5c34-93db-49aa-b0d7-32cc7c889b48/9b722d814a1495c35df48589888a3a4eedd2e33dddf49e2794db04b910cd8399
    768      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poda7ee5c34-93db-49aa-b0d7-32cc7c889b48/7c1ecdcf5e7d9a76c76aabbb00e2736be74c40753ebe94ba4e898b768c2394d3
    886      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podfde70740-4f52-49f5-8405-99f1699eafcf/1faff8cc5033bc3368fc1a19163283c030e618bd8e401bacc5778e4172e47bff
    1288     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podfde70740-4f52-49f5-8405-99f1699eafcf/3177d351810b1f585403ef3dc7ec03984bdf80fe077cb070e46f35b94b58b7e7
    1353     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poda52e1fe4-dfef-4968-88d8-c74958126547/46fb723adaf22bde4b8cb293301e5a949c6e2053116c18e3061d2a93a3c50868
    932      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poda52e1fe4-dfef-4968-88d8-c74958126547/f986f007001ef98c955e615153cdb755b34344f44998e0a990fa4f463bf1041f
    828      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podb0309da3-6764-41e7-8c61-152d3e73a0f7/5eb5f93958c50a266a180bc2ee8517f16b76985cc3527a66e51be726cf39bfae
    214      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podb0309da3-6764-41e7-8c61-152d3e73a0f7/e11d464e6c3290d782b08b1d4a9b79da70e676048bc25910d3f710c016263458
    239      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podded09562-41f7-45ac-a9a9-4dadd7e5cc96/b582b00b7d3cfc94ac86a50a68fab00736171bcd7dfc5fd267c0459a3996611c
    1078     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podded09562-41f7-45ac-a9a9-4dadd7e5cc96/b9910c98c458bf0697bddfec664fa42b3cc708b3d239e3ed6209741250da4103
    1028     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod1a82fe38-9e0c-4339-a814-1d06a35f9bef/d3e522bdc3969af4a63a67ae805bbee84772d3bfd857602dc57402207cfdc8f3
    844      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod1a82fe38-9e0c-4339-a814-1d06a35f9bef/ad6ea9c03b86c083c9c42995fc721279d5b19363855908a3777f3392287f821e
    935      cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod05548f0e-b7d3-4ea8-9031-b4d83d7539fc/cb25a2782566466c0428dbf15700bc8148c7577763bdec45b37cb9ad7b09f4f9
    1195     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod05548f0e-b7d3-4ea8-9031-b4d83d7539fc/97825c0efeb6e54e338e040b9e5cbfdfc1f84a8887b8e0b1fe0754117214d8ef
    1056     cgroup_device   multi                          
/run/cilium/cgroupv2/dev-mqueue.mount
    36       cgroup_inet_ingress multi           sd_fw_ingress  
    35       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/user.slice
    161      cgroup_inet_ingress multi           sd_fw_ingress  
    160      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/user.slice/user-1000.slice
    163      cgroup_inet_ingress multi           sd_fw_ingress  
    162      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/user.slice/user-1000.slice/user@1000.service
    167      cgroup_inet_ingress multi           sd_fw_ingress  
    166      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/user.slice/user-1000.slice/session-1.scope
    169      cgroup_inet_ingress multi           sd_fw_ingress  
    168      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/init.scope
    24       cgroup_inet_ingress multi           sd_fw_ingress  
    23       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice
    61       cgroup_inet_ingress multi           sd_fw_ingress  
    60       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/system-systemd\x2dfsck.slice
    30       cgroup_inet_ingress multi           sd_fw_ingress  
    29       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    75       cgroup_inet_ingress multi           sd_fw_ingress  
    74       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/docker.service
    184      cgroup_inet_ingress multi           sd_fw_ingress  
    183      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/polkit.service
    142      cgroup_inet_ingress multi           sd_fw_ingress  
    141      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/rtkit-daemon.service
    175      cgroup_inet_ingress multi           sd_fw_ingress  
    174      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/bluetooth.service
    117      cgroup_inet_ingress multi           sd_fw_ingress  
    116      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/accounts-daemon.service
    130      cgroup_inet_ingress multi           sd_fw_ingress  
    129      cgroup_inet_egress multi           sd_fw_egress   
    128      cgroup_device   multi           sd_devices     
/run/cilium/cgroupv2/system.slice/cups.socket
    103      cgroup_inet_ingress multi           sd_fw_ingress  
    102      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/wpa_supplicant.service
    188      cgroup_inet_ingress multi           sd_fw_ingress  
    187      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/system-modprobe.slice
    28       cgroup_inet_ingress multi           sd_fw_ingress  
    27       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/ModemManager.service
    190      cgroup_inet_ingress multi           sd_fw_ingress  
    189      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    53       cgroup_inet_ingress multi           sd_fw_ingress  
    52       cgroup_inet_egress multi           sd_fw_egress   
    51       cgroup_device   multi           sd_devices     
/run/cilium/cgroupv2/system.slice/syncthing.service
    155      cgroup_inet_ingress multi           sd_fw_ingress  
    154      cgroup_inet_egress multi           sd_fw_egress   
    153      cgroup_device   multi           sd_devices     
/run/cilium/cgroupv2/system.slice/power-profiles-daemon.service
    173      cgroup_inet_ingress multi           sd_fw_ingress  
    172      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/display-manager.service
    159      cgroup_inet_ingress multi           sd_fw_ingress  
    158      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/colord.service
    179      cgroup_inet_ingress multi           sd_fw_ingress  
    178      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/NetworkManager.service
    144      cgroup_inet_ingress multi           sd_fw_ingress  
    143      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/boot-efi.mount
    79       cgroup_inet_ingress multi           sd_fw_ingress  
    78       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/nscd.service
    192      cgroup_inet_ingress multi           sd_fw_ingress  
    191      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/cups-browsed.service
    137      cgroup_inet_ingress multi           sd_fw_ingress  
    136      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/docker.socket
    105      cgroup_inet_ingress multi           sd_fw_ingress  
    104      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/cups.service
    152      cgroup_inet_ingress multi           sd_fw_ingress  
    151      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/upower.service
    171      cgroup_inet_ingress multi           sd_fw_ingress  
    170      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/systemd-oomd.service
    92       cgroup_inet_ingress multi           sd_fw_ingress  
    91       cgroup_inet_egress multi           sd_fw_egress   
    90       cgroup_device   multi           sd_devices     
/run/cilium/cgroupv2/system.slice/udisks2.service
    177      cgroup_inet_ingress multi           sd_fw_ingress  
    176      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/acpid.service
    109      cgroup_inet_ingress multi           sd_fw_ingress  
    108      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/dbus.service
    119      cgroup_inet_ingress multi           sd_fw_ingress  
    118      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/systemd-timesyncd.service
    95       cgroup_inet_ingress multi           sd_fw_ingress  
    94       cgroup_inet_egress multi           sd_fw_egress   
    93       cgroup_device   multi           sd_devices     
/run/cilium/cgroupv2/system.slice/avahi-daemon.service
    115      cgroup_inet_ingress multi           sd_fw_ingress  
    114      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    133      cgroup_inet_ingress multi           sd_fw_ingress  
    132      cgroup_inet_egress multi           sd_fw_egress   
    131      cgroup_device   multi           sd_devices     
/run/cilium/cgroupv2/system.slice/docker-16ff54fdf6f472ffa4fa833ca1dc5d7a4ea980efe7a556de1057ac2196ac0896.scope
    203      cgroup_inet_ingress multi           sd_fw_ingress  
    202      cgroup_inet_egress multi           sd_fw_egress   
    206      cgroup_device   multi                          
/run/cilium/cgroupv2/proc-sys-fs-binfmt_misc.mount
    87       cgroup_inet_ingress multi           sd_fw_ingress  
    86       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/dev-hugepages.mount
    34       cgroup_inet_ingress multi           sd_fw_ingress  
    33       cgroup_inet_egress multi           sd_fw_egress   
