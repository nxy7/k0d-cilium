Total: 627
TCP:   435 (estab 95, closed 289, orphaned 0, timewait 174)

Transport Total     IP        IPv6
RAW	  2         2         0        
UDP	  3         2         1        
TCP	  146       111       35       
INET	  151       115       36       
FRAG	  0         0         0        

State  Recv-Q Send-Q Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0          127.0.0.1:38671      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=32)) ino:60356 sk:50d6 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0            0.0.0.0:8472       0.0.0.0:*    ino:59065 sk:50d7 cgroup:/ <->                                                  
UNCONN 0      0               [::]:8472          [::]:*    ino:59064 sk:50d8 cgroup:/ v6only:1 <->                                         
