key: 01 00 00 00  value: 44 02 00 00
key: 07 00 00 00  value: 43 02 00 00
key: 0f 00 00 00  value: 45 02 00 00
key: 11 00 00 00  value: 41 02 00 00
key: 24 00 00 00  value: 40 02 00 00
key: 26 00 00 00  value: 42 02 00 00
Found 6 elements
