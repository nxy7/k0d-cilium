[
  {
    "containers": [
      {
        "cgroup-id": 11087,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod11149348-f595-4ce3-9fd0-87c09b5dd1e8/7b175ce2c35a9e499a5f3d03193e1a36deb19e8cc6c213af26548e816a130e69"
      }
    ],
    "ips": [
      "10.244.0.157"
    ],
    "name": "openebs-ndm-node-exporter-xwb7s",
    "namespace": "openebs"
  },
  {
    "containers": [
      {
        "cgroup-id": 11975,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podc11076ae-e37a-40c5-b3bf-e7642d284b1f/6e084173eef1e91231c5ac0fbf1c8ec1f479c27aba73d9ff0188b7d447706cbf"
      }
    ],
    "ips": [
      "10.244.0.194"
    ],
    "name": "openebs-localpv-provisioner-7d6ccb7795-czbsm",
    "namespace": "openebs"
  },
  {
    "containers": [
      {
        "cgroup-id": 16933,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/poda823db44-abb0-4af8-ae18-8845df5a9dcd/459bf8797b7d1673acfe370f34ef4d7a0a9b97d699b3b62dcc6b70aa2a97619d"
      }
    ],
    "ips": [
      "10.244.0.167"
    ],
    "name": "postgres-7c845b6448-rs4t6",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 16489,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod0f532e25-e23d-4ec4-9381-fb942155dc79/2b7a79c00592f33a60f83ac4c576436831d8ae289d3e786ac7ec88d9f37b92b1"
      }
    ],
    "ips": [
      "10.244.0.202"
    ],
    "name": "redis-68c95977f4-jf9bx",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 17007,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podfde70740-4f52-49f5-8405-99f1699eafcf/3177d351810b1f585403ef3dc7ec03984bdf80fe077cb070e46f35b94b58b7e7"
      }
    ],
    "ips": [
      "10.244.0.242"
    ],
    "name": "livestreamdb-6877b6fc75-qmm5g",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 16785,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podfc8fc111-8ad6-4c41-83ea-be6ceef74879/e99337d384b1ca0076fa257bc7b4978d019ae81dbe63f97290064a7ba274c8ee"
      }
    ],
    "ips": [
      "10.244.0.133"
    ],
    "name": "traffic-manager-55d995585d-brtlj",
    "namespace": "ambassador"
  },
  {
    "containers": [
      {
        "cgroup-id": 14565,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podcee536de-330f-4f00-b0e4-7dab27714bb9/d3b4ca7c843b3bbb28524d620ea8d17b853d987a3f954ad37d42df0ec02f02b1"
      }
    ],
    "ips": [
      "10.244.0.220"
    ],
    "name": "frontend-58b6bf847f-br98b",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 14047,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod34a47f5d-ecee-499d-a5b5-859ef218ff38/403654b891623b7ba035d536b5df6bbb2abc413efc9aa1c5dcd53f9dc33bd70d"
      }
    ],
    "ips": [
      "10.244.0.118"
    ],
    "name": "backend-855f6c7b4-ljz8j",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 11383,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/burstable/pod084a0d96-c0ca-4446-ba33-7384bedbded0/9169d26a2b4b3beab82860d26489525d651a2ff8093b056157b2c1774f5a97b4"
      }
    ],
    "ips": [
      "10.244.0.228"
    ],
    "name": "metrics-server-7f86dff975-6286h",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 12197,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/poda7ee5c34-93db-49aa-b0d7-32cc7c889b48/e4c5d5e548addd6309cb0e34c83754e74f1d66d635aaecef004e0249b903f82e"
      },
      {
        "cgroup-id": 11605,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/poda7ee5c34-93db-49aa-b0d7-32cc7c889b48/7c1ecdcf5e7d9a76c76aabbb00e2736be74c40753ebe94ba4e898b768c2394d3"
      }
    ],
    "ips": [
      "10.244.0.9"
    ],
    "name": "hubble-ui-6b468cff75-nxd77",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 11457,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/burstable/pod63e1d74e-df17-4aca-b7b6-ea5641d432c9/9c480a18486ab467ea28e75ebe2cdaed62cda78cf70250f92226d00afa195b53"
      }
    ],
    "ips": [
      "10.244.0.223"
    ],
    "name": "coredns-878bb57ff-r6bcw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 11753,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod39c38926-f754-444d-93e6-848bec64959d/ccf8dc2c9ccd9b44995384d3c0facf63d27524691df96cee11f9a9633f444b31"
      }
    ],
    "ips": [
      "10.244.0.135"
    ],
    "name": "cert-manager-78ddc5db85-5w8zx",
    "namespace": "cert-manager"
  },
  {
    "containers": [
      {
        "cgroup-id": 13973,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod606c066a-a5b8-45d3-8fa4-5f7168bf0a44/c8553fb5b519150cabc9c5b90aeae822a1f2bec257737d8e5764de4228461d84"
      }
    ],
    "ips": [
      "10.244.0.180"
    ],
    "name": "backend-855f6c7b4-p8vjz",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 14343,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod44660fac-e031-4d6a-827e-628237a55c86/01d14bda9e679beb2f5b81de2c9c3a453ad614318bc4e9cf757ce90fbab75bdf"
      }
    ],
    "ips": [
      "10.244.0.8"
    ],
    "name": "frontend-58b6bf847f-mvjq9",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 11531,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podcf3d3b19-62f6-4a4b-8d62-38e9cb470bac/b49ff8a3e068cbdd3406e098d0ea7b997ee7e99396ceed00180fcd05f6ea5ef5"
      }
    ],
    "ips": [
      "10.244.0.90"
    ],
    "name": "cert-manager-webhook-879c48cd4-r5snx",
    "namespace": "cert-manager"
  },
  {
    "containers": [
      {
        "cgroup-id": 15083,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod05548f0e-b7d3-4ea8-9031-b4d83d7539fc/cb25a2782566466c0428dbf15700bc8148c7577763bdec45b37cb9ad7b09f4f9"
      }
    ],
    "ips": [
      "10.244.0.75"
    ],
    "name": "kratos-77cbf98c8f-ds6vd",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 14417,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podded09562-41f7-45ac-a9a9-4dadd7e5cc96/b582b00b7d3cfc94ac86a50a68fab00736171bcd7dfc5fd267c0459a3996611c"
      }
    ],
    "ips": [
      "10.244.0.101"
    ],
    "name": "frontend-58b6bf847f-m8jq6",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 10273,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod9c3014d1-ad23-49df-a56e-38c1ae44aa7a/4f2f698c082b73001840aded4a38e21c124bc75a5fb64239af20f49ddbaa01b1"
      },
      {
        "cgroup-id": 11901,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod9c3014d1-ad23-49df-a56e-38c1ae44aa7a/99184ef7f7e41f6f60c92e30e3932c4c1fab4fd6a01fff2cd62a64b8e8df7977"
      }
    ],
    "ips": [
      "172.17.0.2"
    ],
    "name": "openebs-ndm-jpjzt",
    "namespace": "openebs"
  },
  {
    "containers": [
      {
        "cgroup-id": 11827,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod06d88d3e-51c3-40be-be7b-65e80614fc68/ebde194e68a8e17a16216517c53159f12003cbd9029af48ea91a70ff5f2a88b8"
      }
    ],
    "ips": [
      "10.244.0.23"
    ],
    "name": "hubble-relay-777496bf44-dqbz5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 14491,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod5feb89ee-797a-4175-b128-3405259a613a/41e16986146af4f54bb604a2afc0a502b69f12f6b2366ef28c2843c9c67935c6"
      }
    ],
    "ips": [
      "10.244.0.12"
    ],
    "name": "frontend-58b6bf847f-mxkjg",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 9163,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/burstable/pod3e841622-3e54-4198-bd63-a164f910ab69/5090eca49eb5554d36b0a5ebea069fb59ef20a33766b4ba5add2c9b7ab7a943d"
      }
    ],
    "ips": [
      "172.17.0.2"
    ],
    "name": "cilium-rmvl6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8867,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/poda7ad93c9-0624-4f8c-9159-757dc58ef138/d189eb3ee3c8700212663c27087983fa210e6cdb8f8e6259730d252d5147cbe3"
      }
    ],
    "ips": [
      "172.17.0.2"
    ],
    "name": "cilium-envoy-plk8x",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 12049,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/poda52e1fe4-dfef-4968-88d8-c74958126547/46fb723adaf22bde4b8cb293301e5a949c6e2053116c18e3061d2a93a3c50868"
      }
    ],
    "ips": [
      "10.244.0.159"
    ],
    "name": "cert-manager-cainjector-6774f986b-q46zg",
    "namespace": "cert-manager"
  },
  {
    "containers": [
      {
        "cgroup-id": 11679,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod43eb3d25-bd86-4160-a94c-8b912d594141/670ebea5e63ce61d79c48774e5f843e96cec83f71329ee344c55cd906ed336c0"
      }
    ],
    "ips": [
      "10.244.0.54"
    ],
    "name": "openebs-ndm-cluster-exporter-589554f487-vj6lq",
    "namespace": "openebs"
  },
  {
    "containers": [
      {
        "cgroup-id": 12123,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod1a82fe38-9e0c-4339-a814-1d06a35f9bef/ad6ea9c03b86c083c9c42995fc721279d5b19363855908a3777f3392287f821e"
      }
    ],
    "ips": [
      "10.244.0.126"
    ],
    "name": "openebs-ndm-operator-7c667b76f8-5v8jv",
    "namespace": "openebs"
  }
]

