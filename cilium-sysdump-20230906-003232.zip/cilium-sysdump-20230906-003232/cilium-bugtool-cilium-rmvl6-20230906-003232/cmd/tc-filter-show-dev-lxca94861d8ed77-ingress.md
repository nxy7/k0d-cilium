filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxca94861d8ed77 direct-action not_in_hw id 945 tag 9f81282c7df089a5 jited 
