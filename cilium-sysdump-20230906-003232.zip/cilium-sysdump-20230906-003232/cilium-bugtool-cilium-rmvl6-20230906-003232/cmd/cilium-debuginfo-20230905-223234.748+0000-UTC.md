# Cilium debug information

#### Cilium version

```
1.14.1 c191ef6f 2023-08-10T18:54:57+02:00 go version go1.20.7 linux/amd64
```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.27 (v1.27.4+k0s) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideEnvoyConfig", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumEnvoyConfig", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Secrets", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   True   [eth0 172.17.0.2]
Host firewall:          Disabled
CNI Chaining:           none
Cilium:                 Ok   1.14.1 (v1.14.1-c191ef6f)
NodeMonitor:            Listening for events on 32 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 31/254 allocated from 10.244.0.0/24, 
Allocated addresses:
  10.244.0.101 (streampai/frontend-58b6bf847f-m8jq6)
  10.244.0.118 (streampai/backend-855f6c7b4-ljz8j)
  10.244.0.12 (streampai/frontend-58b6bf847f-mxkjg)
  10.244.0.126 (openebs/openebs-ndm-operator-7c667b76f8-5v8jv)
  10.244.0.132 (health)
  10.244.0.133 (ambassador/traffic-manager-55d995585d-brtlj)
  10.244.0.135 (cert-manager/cert-manager-78ddc5db85-5w8zx)
  10.244.0.148 (streampai/minio-d496dbccf-8lwv6)
  10.244.0.157 (openebs/openebs-ndm-node-exporter-xwb7s)
  10.244.0.159 (cert-manager/cert-manager-cainjector-6774f986b-q46zg)
  10.244.0.167 (streampai/postgres-7c845b6448-rs4t6)
  10.244.0.180 (streampai/backend-855f6c7b4-p8vjz)
  10.244.0.194 (openebs/openebs-localpv-provisioner-7d6ccb7795-czbsm)
  10.244.0.202 (streampai/redis-68c95977f4-jf9bx)
  10.244.0.220 (streampai/frontend-58b6bf847f-br98b)
  10.244.0.222 (streampai/pgweb-b74849bb6-757xs)
  10.244.0.223 (kube-system/coredns-878bb57ff-r6bcw)
  10.244.0.228 (kube-system/metrics-server-7f86dff975-6286h)
  10.244.0.23 (kube-system/hubble-relay-777496bf44-dqbz5)
  10.244.0.230 (ingress)
  10.244.0.242 (streampai/livestreamdb-6877b6fc75-qmm5g)
  10.244.0.37 (streampai/postgres-migrations-tzn7j)
  10.244.0.42 (ambassador/uninstall-agents-r95rd)
  10.244.0.54 (openebs/openebs-ndm-cluster-exporter-589554f487-vj6lq)
  10.244.0.59 (router)
  10.244.0.75 (streampai/kratos-77cbf98c8f-ds6vd)
  10.244.0.8 (streampai/frontend-58b6bf847f-mvjq9)
  10.244.0.80 (streampai/streamchat-79dfbb9bb4-2dtq5)
  10.244.0.9 (kube-system/hubble-ui-6b468cff75-nxd77)
  10.244.0.90 (cert-manager/cert-manager-webhook-879c48cd4-r5snx)
  10.244.0.98 (streampai/create-minio-buckets-8m6q5)
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Host Routing:           Legacy
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      132/132 healthy
  Name                                  Last success   Last error   Count   Message
  cilium-health-ep                      15s ago        never        0       no error   
  dns-garbage-collector-job             22s ago        never        0       no error   
  endpoint-1018-regeneration-recovery   never          never        0       no error   
  endpoint-104-regeneration-recovery    never          never        0       no error   
  endpoint-1055-regeneration-recovery   never          never        0       no error   
  endpoint-1187-regeneration-recovery   never          never        0       no error   
  endpoint-133-regeneration-recovery    never          never        0       no error   
  endpoint-142-regeneration-recovery    never          never        0       no error   
  endpoint-1784-regeneration-recovery   never          never        0       no error   
  endpoint-1785-regeneration-recovery   never          never        0       no error   
  endpoint-210-regeneration-recovery    never          never        0       no error   
  endpoint-235-regeneration-recovery    never          never        0       no error   
  endpoint-2422-regeneration-recovery   never          never        0       no error   
  endpoint-243-regeneration-recovery    never          never        0       no error   
  endpoint-2550-regeneration-recovery   never          never        0       no error   
  endpoint-2675-regeneration-recovery   never          never        0       no error   
  endpoint-281-regeneration-recovery    never          never        0       no error   
  endpoint-2870-regeneration-recovery   never          never        0       no error   
  endpoint-3122-regeneration-recovery   never          never        0       no error   
  endpoint-3130-regeneration-recovery   never          never        0       no error   
  endpoint-3475-regeneration-recovery   never          never        0       no error   
  endpoint-353-regeneration-recovery    never          never        0       no error   
  endpoint-3656-regeneration-recovery   never          never        0       no error   
  endpoint-3692-regeneration-recovery   never          never        0       no error   
  endpoint-401-regeneration-recovery    never          never        0       no error   
  endpoint-441-regeneration-recovery    never          never        0       no error   
  endpoint-516-regeneration-recovery    never          never        0       no error   
  endpoint-546-regeneration-recovery    never          never        0       no error   
  endpoint-688-regeneration-recovery    never          never        0       no error   
  endpoint-889-regeneration-recovery    never          never        0       no error   
  endpoint-895-regeneration-recovery    never          never        0       no error   
  endpoint-913-regeneration-recovery    never          never        0       no error   
  endpoint-gc                           3m22s ago      never        0       no error   
  ipcache-inject-labels                 16s ago        3m17s ago    0       no error   
  k8s-heartbeat                         23s ago        never        0       no error   
  link-cache                            16s ago        never        0       no error   
  metricsmap-bpf-prom-sync              2s ago         never        0       no error   
  resolve-identity-1018                 54s ago        never        0       no error   
  resolve-identity-104                  3m15s ago      never        0       no error   
  resolve-identity-1055                 3m12s ago      never        0       no error   
  resolve-identity-1187                 41s ago        never        0       no error   
  resolve-identity-133                  41s ago        never        0       no error   
  resolve-identity-142                  3m14s ago      never        0       no error   
  resolve-identity-1784                 57s ago        never        0       no error   
  resolve-identity-1785                 3m14s ago      never        0       no error   
  resolve-identity-210                  35s ago        never        0       no error   
  resolve-identity-235                  3m11s ago      never        0       no error   
  resolve-identity-2422                 57s ago        never        0       no error   
  resolve-identity-243                  55s ago        never        0       no error   
  resolve-identity-2550                 3m15s ago      never        0       no error   
  resolve-identity-2675                 3m9s ago       never        0       no error   
  resolve-identity-281                  25s ago        never        0       no error   
  resolve-identity-2870                 57s ago        never        0       no error   
  resolve-identity-3122                 52s ago        never        0       no error   
  resolve-identity-3130                 57s ago        never        0       no error   
  resolve-identity-3475                 51s ago        never        0       no error   
  resolve-identity-353                  3m15s ago      never        0       no error   
  resolve-identity-3656                 2m55s ago      never        0       no error   
  resolve-identity-3692                 51s ago        never        0       no error   
  resolve-identity-401                  57s ago        never        0       no error   
  resolve-identity-441                  3m14s ago      never        0       no error   
  resolve-identity-516                  3m14s ago      never        0       no error   
  resolve-identity-546                  56s ago        never        0       no error   
  resolve-identity-688                  57s ago        never        0       no error   
  resolve-identity-889                  51s ago        never        0       no error   
  resolve-identity-895                  3m12s ago      never        0       no error   
  resolve-identity-913                  3m15s ago      never        0       no error   
  sync-host-ips                         16s ago        never        0       no error   
  sync-lb-maps-with-k8s-services        3m16s ago      never        0       no error   
  sync-policymap-1018                   25s ago        never        0       no error   
  sync-policymap-104                    25s ago        never        0       no error   
  sync-policymap-1055                   25s ago        never        0       no error   
  sync-policymap-1187                   25s ago        never        0       no error   
  sync-policymap-133                    25s ago        never        0       no error   
  sync-policymap-142                    25s ago        never        0       no error   
  sync-policymap-1784                   25s ago        never        0       no error   
  sync-policymap-1785                   25s ago        never        0       no error   
  sync-policymap-210                    25s ago        never        0       no error   
  sync-policymap-235                    25s ago        never        0       no error   
  sync-policymap-2422                   25s ago        never        0       no error   
  sync-policymap-243                    25s ago        never        0       no error   
  sync-policymap-2550                   25s ago        never        0       no error   
  sync-policymap-2675                   25s ago        never        0       no error   
  sync-policymap-281                    25s ago        never        0       no error   
  sync-policymap-2870                   25s ago        never        0       no error   
  sync-policymap-3122                   25s ago        never        0       no error   
  sync-policymap-3130                   25s ago        never        0       no error   
  sync-policymap-3475                   25s ago        never        0       no error   
  sync-policymap-353                    25s ago        never        0       no error   
  sync-policymap-3656                   25s ago        never        0       no error   
  sync-policymap-3692                   25s ago        never        0       no error   
  sync-policymap-401                    25s ago        never        0       no error   
  sync-policymap-441                    25s ago        never        0       no error   
  sync-policymap-516                    25s ago        never        0       no error   
  sync-policymap-546                    25s ago        never        0       no error   
  sync-policymap-688                    25s ago        never        0       no error   
  sync-policymap-889                    25s ago        never        0       no error   
  sync-policymap-895                    25s ago        never        0       no error   
  sync-policymap-913                    25s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1018)     2s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (104)      5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1055)     1s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1187)     1s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (133)      1s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (142)      3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1784)     7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1785)     3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (210)      5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (235)      10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2422)     6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (243)      4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2550)     5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2675)     9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (281)      5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2870)     7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3122)     10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3130)     7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3475)     10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (353)      4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3656)     5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3692)     10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (401)      7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (441)      2s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (516)      2s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (546)      5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (688)      7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (889)      10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (895)      1s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (913)      5s ago         never        0       no error   
  sync-utime                            16s ago        never        0       no error   
  template-dir-watcher                  never          never        0       no error   
  write-cni-file                        3m22s ago      never        0       no error   
Proxy Status:            OK, ip 10.244.0.59, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 256, max 65535
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 25.92   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 True
  Socket LB:              Enabled
  Socket LB Tracing:      Enabled
  Socket LB Coverage:     Full
  Devices:                eth0 172.17.0.2
  Mode:                   SNAT
  Backend Selection:      Random
  Session Affinity:       Enabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  XDP Acceleration:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Enabled (Range: 30000-32767) 
  - LoadBalancer:   Enabled 
  - externalIPs:    Enabled 
  - HostPort:       Enabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   73193
  TCP connection tracking       146386
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           146386
  Neighbor table                146386
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              73193
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
mesh-auth-rotated-identities-queue-size:1024
tofqdns-proxy-response-max-delay:100ms
http-normalize-path:true
ipv4-native-routing-cidr:
enable-pmtu-discovery:false
cgroup-root:/run/cilium/cgroupv2
ipam-cilium-node-update-rate:15s
mesh-auth-enabled:true
sidecar-istio-proxy-image:cilium/istio_proxy
dnsproxy-lock-count:128
vtep-endpoint:
local-router-ipv4:
conntrack-gc-interval:0s
k8s-kubeconfig-path:
bpf-ct-timeout-service-tcp-grace:1m0s
enable-health-checking:true
vtep-mac:
tofqdns-pre-cache:
hubble-event-buffer-capacity:4095
l2-announcements-retry-period:2s
proxy-idle-timeout-seconds:60
bpf-root:/sys/fs/bpf
egress-masquerade-interfaces:
ipv6-node:auto
ip-allocation-timeout:2m0s
policy-trigger-interval:1s
hubble-metrics:
bpf-lb-rss-ipv6-src-cidr:
enable-remote-node-identity:true
datapath-mode:veth
cni-chaining-mode:none
debug-verbose:envoy
enable-node-port:false
bgp-announce-pod-cidr:false
mke-cgroup-mount:
dnsproxy-concurrency-processing-grace-period:0s
enable-runtime-device-detection:false
enable-ipsec:false
k8s-require-ipv6-pod-cidr:false
l2-pod-announcements-interface:
dns-policy-unload-on-shutdown:false
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
enable-bpf-tproxy:false
bpf-nat-global-max:524288
keep-config:false
tunnel:
encrypt-interface:
debug:false
pprof-address:localhost
enable-identity-mark:true
bpf-ct-timeout-service-any:1m0s
hubble-export-file-compress:false
procfs:/host/proc
bpf-ct-timeout-service-tcp:6h0m0s
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
bgp-config-path:/var/lib/cilium/bgp/config.yaml
local-router-ipv6:
prepend-iptables-chains:true
enable-ipv4-big-tcp:false
version:false
http-403-msg:
hubble-monitor-events:
endpoint-gc-interval:5m0s
enable-tracing:false
api-rate-limit:
enable-mke:false
l2-announcements-renew-deadline:5s
ipv6-range:auto
enable-ipv4:true
unmanaged-pod-watcher-interval:15
ipv6-mcast-device:
enable-auto-protect-node-port-range:true
identity-change-grace-period:5s
iptables-random-fully:false
enable-xt-socket-fallback:true
hubble-event-queue-size:0
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
bpf-map-dynamic-size-ratio:0.0025
enable-wireguard-userspace-fallback:false
bpf-lb-sock-hostns-only:false
bpf-fragments-map-max:8192
srv6-encap-mode:reduced
auto-direct-node-routes:false
identity-gc-interval:15m0s
bpf-lb-map-max:65536
ipv4-node:auto
fqdn-regex-compile-lru-size:1024
cluster-name:default
enable-ipv6-big-tcp:false
enable-k8s-networkpolicy:true
ip-masq-agent-config-path:/etc/config/ip-masq-agent
enable-hubble-recorder-api:true
bpf-lb-source-range-map-max:0
prometheus-serve-addr::9962
enable-k8s:true
ipv6-native-routing-cidr:
k8s-sync-timeout:3m0s
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
tofqdns-min-ttl:0
node-port-bind-protection:true
install-egress-gateway-routes:false
set-cilium-node-taints:true
ipam-multi-pool-pre-allocation:default=8
vtep-mask:
k8s-namespace:kube-system
enable-k8s-terminating-endpoint:true
enable-ipv6-ndp:false
hubble-recorder-sink-queue-size:1024
operator-api-serve-addr:127.0.0.1:9234
proxy-prometheus-port:0
bpf-ct-timeout-regular-tcp:6h0m0s
metrics:
routing-mode:tunnel
remove-cilium-node-taints:true
labels:
enable-ipv4-egress-gateway:false
monitor-aggregation:medium
max-controller-interval:0
single-cluster-route:false
kvstore-lease-ttl:15m0s
hubble-disable-tls:false
bpf-lb-dev-ip-addr-inherit:
cflags:
tofqdns-enable-dns-compression:true
enable-local-redirect-policy:false
gateway-api-secrets-namespace:cilium-secrets
disable-endpoint-crd:false
tofqdns-idle-connection-grace-period:0s
node-port-mode:snat
ipv4-range:auto
bpf-lb-algorithm:random
proxy-max-requests-per-connection:0
enable-nat46x64-gateway:false
bpf-lb-dsr-l4-xlate:frontend
bpf-lb-rss-ipv4-src-cidr:
fixed-identity-mapping:
enable-policy:default
disable-iptables-feeder-rules:
enable-sctp:false
allow-localhost:auto
custom-cni-conf:false
node-port-range:
k8s-heartbeat-timeout:30s
hubble-prefer-ipv6:false
enable-icmp-rules:true
restore:true
endpoint-status:
enable-service-topology:false
enable-bpf-masquerade:false
cmdref:
dnsproxy-concurrency-limit:0
policy-audit-mode:false
enable-srv6:false
hubble-export-file-max-backups:5
external-envoy-proxy:true
policy-queue-size:100
enable-cilium-endpoint-slice:false
bgp-announce-lb-ip:false
kube-proxy-replacement:true
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
enable-endpoint-routes:false
disable-cnp-status-updates:true
http-retry-count:3
enable-monitor:true
crd-wait-timeout:5m0s
k8s-service-proxy-name:
agent-labels:
ipam:kubernetes
kvstore-periodic-sync:5m0s
l2-announcements-lease-duration:15s
route-metric:0
hubble-socket-path:/var/run/cilium/hubble.sock
ipv6-cluster-alloc-cidr:f00d::/64
cni-log-file:/var/run/cilium/cilium-cni.log
http-retry-timeout:0
pprof-port:6060
enable-k8s-event-handover:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
egress-gateway-policy-map-max:16384
annotate-k8s-node:false
ipv6-pod-subnets:
bpf-lb-acceleration:disabled
preallocate-bpf-maps:false
enable-bbr:false
encrypt-node:false
synchronize-k8s-nodes:true
install-no-conntrack-iptables-rules:false
kube-proxy-replacement-healthz-bind-address:
enable-bgp-control-plane:false
trace-payloadlen:128
enable-host-legacy-routing:false
bpf-ct-timeout-regular-tcp-fin:10s
tunnel-port:0
enable-wireguard:false
trace-sock:true
clustermesh-config:/var/lib/cilium/clustermesh/
exclude-local-address:
kvstore-connectivity-timeout:2m0s
dns-max-ips-per-restored-rule:1000
label-prefix-file:
tofqdns-proxy-port:0
http-request-timeout:3600
bpf-auth-map-max:524288
bpf-lb-external-clusterip:false
gops-port:9890
monitor-aggregation-interval:5s
node-port-algorithm:random
ipsec-key-rotation-duration:5m0s
state-dir:/var/run/cilium
agent-health-port:9879
allocator-list-timeout:3m0s
join-cluster:false
bpf-ct-timeout-regular-tcp-syn:1m0s
enable-k8s-api-discovery:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
enable-host-port:false
egress-gateway-reconciliation-trigger-interval:1s
proxy-connect-timeout:2
bypass-ip-availability-upon-restore:false
enable-ip-masq-agent:false
devices:eth0
mesh-auth-mutual-listener-port:0
enable-ipv6:false
ipv4-service-loopback-address:169.254.42.1
enable-gateway-api-secrets-sync:true
http-max-grpc-timeout:0
bpf-neigh-global-max:524288
enable-envoy-config:true
bpf-lb-mode:snat
tunnel-protocol:vxlan
bpf-lb-service-backend-map-max:0
enable-endpoint-health-checking:true
read-cni-conf:
ipv4-pod-subnets:
tofqdns-max-deferred-connection-deletes:10000
bpf-map-event-buffers:
log-system-load:false
k8s-require-ipv4-pod-cidr:false
install-iptables-rules:true
vtep-cidr:
cluster-id:0
bpf-policy-map-max:16384
enable-stale-cilium-endpoint-cleanup:true
enable-l2-neigh-discovery:true
direct-routing-device:
bpf-ct-global-tcp-max:524288
cilium-endpoint-gc-interval:5m0s
kvstore:
use-cilium-internal-ip-for-ipsec:false
bpf-ct-global-any-max:262144
enable-health-check-nodeport:true
enable-host-firewall:false
k8s-service-cache-size:128
bpf-lb-affinity-map-max:0
enable-ipv6-masquerade:true
vlan-bpf-bypass:
lib-dir:/var/lib/cilium
enable-unreachable-routes:false
iptables-lock-timeout:5s
mesh-auth-queue-size:1024
enable-ipv4-masquerade:true
cluster-health-port:4240
enable-cilium-api-server-access:
bpf-lb-maglev-table-size:16381
cni-exclusive:true
enable-ipsec-key-watcher:true
config-dir:/tmp/cilium/config-map
cni-chaining-target:
hubble-recorder-storage-path:/var/run/cilium/pcaps
enable-bpf-clock-probe:false
certificates-directory:/var/run/cilium/certs
bpf-lb-sock:false
tofqdns-dns-reject-response-code:refused
ipv4-service-range:auto
k8s-client-burst:10
enable-bandwidth-manager:false
enable-well-known-identities:false
hubble-export-file-path:
mesh-auth-gc-interval:5m0s
mesh-auth-spire-admin-socket:
enable-xdp-prefilter:false
monitor-queue-size:0
enable-vtep:false
log-driver:
hubble-export-file-max-size-mb:10
http-idle-timeout:0
cnp-node-status-gc-interval:0s
bpf-sock-rev-map-max:262144
ipsec-key-file:
arping-refresh-period:30s
proxy-gid:1337
envoy-log:
enable-external-ips:false
kvstore-opt:
set-cilium-is-up-condition:true
bpf-lb-dsr-dispatch:opt
hubble-metrics-server:
agent-liveness-update-interval:1s
enable-local-node-route:true
enable-gateway-api:true
ipv6-service-range:auto
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
enable-high-scale-ipcache:false
enable-ipv4-fragment-tracking:true
socket-path:/var/run/cilium/cilium.sock
mtu:0
proxy-max-connection-duration-seconds:0
skip-cnp-status-startup-clean:false
endpoint-queue-size:25
derive-masquerade-ip-addr-from-device:
log-opt:
auto-create-cilium-node-resource:true
pprof:false
local-max-addr-scope:252
kvstore-max-consecutive-quorum-errors:2
monitor-aggregation-flags:all
allow-icmp-frag-needed:true
enable-l2-announcements:true
bpf-filter-priority:1
bpf-lb-service-map-max:0
enable-l7-proxy:true
enable-recorder:false
node-port-acceleration:disabled
k8s-client-qps:5
enable-k8s-endpoint-slice:true
identity-restore-grace-period:10m0s
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
enable-svc-source-range-check:true
tofqdns-endpoint-max-ip-per-hostname:50
enable-l2-pod-announcements:false
enable-custom-calls:false
disable-envoy-version-check:false
enable-session-affinity:false
config:
egress-multi-home-ip-rule-compat:false
envoy-config-timeout:2m0s
enable-cilium-health-api-server-access:
hubble-listen-address::4244
nodes-gc-interval:5m0s
config-sources:config-map:kube-system/cilium-config
dnsproxy-lock-timeout:500ms
hubble-skip-unknown-cgroup-ids:true
k8s-api-server:
identity-allocation-mode:crd
enable-hubble:true
bpf-ct-timeout-regular-any:1m0s
bpf-lb-maglev-map-max:0
bpf-lb-rev-nat-map-max:0
identity-heartbeat-timeout:30m0s
```


#### Service list

```
ID   Frontend              Service Type   Backend                            
1    10.108.118.97:443     ClusterIP      1 => 10.244.0.228:10250 (active)   
2    10.110.36.32:9402     ClusterIP      1 => 10.244.0.135:9402 (active)    
3    10.96.9.116:443       ClusterIP      1 => 10.244.0.90:10250 (active)    
4    10.96.0.1:443         ClusterIP      1 => 172.17.0.2:6443 (active)      
5    10.100.194.198:443    ClusterIP      1 => 172.17.0.2:4244 (active)      
6    10.100.226.243:80     ClusterIP      1 => 10.244.0.23:4245 (active)     
7    10.101.180.15:80      ClusterIP      1 => 10.244.0.9:8081 (active)      
8    10.96.0.10:53         ClusterIP      1 => 10.244.0.223:53 (active)      
9    10.96.0.10:9153       ClusterIP      1 => 10.244.0.223:9153 (active)    
10   10.101.253.206:7000   ClusterIP      1 => 10.244.0.180:7000 (active)    
                                          2 => 10.244.0.118:7000 (active)    
11   10.107.249.151:7000   ClusterIP                                         
12   10.104.78.187:3000    ClusterIP      1 => 10.244.0.8:3000 (active)      
                                          2 => 10.244.0.12:3000 (active)     
                                          3 => 10.244.0.220:3000 (active)    
                                          4 => 10.244.0.101:3000 (active)    
13   10.98.191.110:4433    ClusterIP      1 => 10.244.0.75:4433 (active)     
14   10.110.82.62:5432     ClusterIP      1 => 10.244.0.242:5432 (active)    
15   10.104.163.144:9000   ClusterIP                                         
16   10.104.163.144:9001   ClusterIP                                         
17   10.102.204.154:8081   ClusterIP                                         
18   10.102.212.184:5432   ClusterIP      1 => 10.244.0.167:5432 (active)    
19   10.102.231.26:6379    ClusterIP      1 => 10.244.0.202:6379 (active)    
20   10.106.139.3:80       ClusterIP                                         
21   172.17.39.148:80      LoadBalancer                                      
22   172.17.0.2:31956      NodePort                                          
23   0.0.0.0:31956         NodePort                                          
24   10.109.73.183:443     ClusterIP      1 => 10.244.0.133:443 (active)     
```

#### Kernel version

```
6.5.0
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                   IPv6   IPv4           STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                      
104        Disabled           Disabled          16036      k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs               10.244.0.157   ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator                                               
                                                           k8s:io.kubernetes.pod.namespace=openebs                                                                     
                                                           k8s:name=openebs-ndm-node-exporter                                                                          
                                                           k8s:openebs.io/component-name=ndm-node-exporter                                                             
                                                           k8s:openebs.io/version=3.4.0                                                                                
133        Disabled           Disabled          2536       k8s:app=livestreamdb                                                                 10.244.0.242   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
142        Disabled           Disabled          45914      k8s:app.kubernetes.io/name=hubble-ui                                                 10.244.0.9     ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                        
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=hubble-ui                                                                                       
210        Disabled           Disabled          32223      k8s:app=minio                                                                        10.244.0.148   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
235        Disabled           Disabled          49098      k8s:app.kubernetes.io/component=cainjector                                           10.244.0.159   ready   
                                                           k8s:app.kubernetes.io/instance=cert-manager                                                                 
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                       
                                                           k8s:app.kubernetes.io/name=cainjector                                                                       
                                                           k8s:app.kubernetes.io/version=v1.10.0                                                                       
                                                           k8s:app=cainjector                                                                                          
                                                           k8s:helm.sh/chart=cert-manager-v1.10.0                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager                                 
                                                           k8s:io.cilium.k8s.namespace.labels.name=cert-manager                                                        
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-cainjector                                             
                                                           k8s:io.kubernetes.pod.namespace=cert-manager                                                                
243        Disabled           Disabled          6361       k8s:batch.kubernetes.io/controller-uid=43e60661-5d04-4a29-a73b-dcc82646c2e0          10.244.0.37    ready   
                                                           k8s:batch.kubernetes.io/job-name=postgres-migrations                                                        
                                                           k8s:controller-uid=43e60661-5d04-4a29-a73b-dcc82646c2e0                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
                                                           k8s:job-name=postgres-migrations                                                                            
281        Disabled           Disabled          34488      k8s:app.kubernetes.io/instance=traffic-manager                                       10.244.0.42    ready   
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                       
                                                           k8s:batch.kubernetes.io/controller-uid=7dee02bf-27a1-4197-8878-fa09be2be628                                 
                                                           k8s:batch.kubernetes.io/job-name=uninstall-agents                                                           
                                                           k8s:controller-uid=7dee02bf-27a1-4197-8878-fa09be2be628                                                     
                                                           k8s:helm.sh/chart=telepresence-2.14.0                                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=ambassador                                   
                                                           k8s:io.cilium.k8s.namespace.labels.name=ambassador                                                          
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=ambassador                                                                  
                                                           k8s:job-name=uninstall-agents                                                                               
353        Disabled           Disabled          5031       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system           10.244.0.223   ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=kube-dns                                                                                        
401        Disabled           Disabled          17496      k8s:app=frontend                                                                     10.244.0.220   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
441        Disabled           Disabled          4302       k8s:app.kubernetes.io/component=controller                                           10.244.0.135   ready   
                                                           k8s:app.kubernetes.io/instance=cert-manager                                                                 
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                       
                                                           k8s:app.kubernetes.io/name=cert-manager                                                                     
                                                           k8s:app.kubernetes.io/version=v1.10.0                                                                       
                                                           k8s:app=cert-manager                                                                                        
                                                           k8s:helm.sh/chart=cert-manager-v1.10.0                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager                                 
                                                           k8s:io.cilium.k8s.namespace.labels.name=cert-manager                                                        
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=cert-manager                                                        
                                                           k8s:io.kubernetes.pod.namespace=cert-manager                                                                
516        Disabled           Disabled          12645      k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs               10.244.0.54    ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator                                               
                                                           k8s:io.kubernetes.pod.namespace=openebs                                                                     
                                                           k8s:name=openebs-ndm-cluster-exporter                                                                       
                                                           k8s:openebs.io/component-name=ndm-cluster-exporter                                                          
                                                           k8s:openebs.io/version=3.4.0                                                                                
546        Disabled           Disabled          22396      k8s:app=kratos                                                                       10.244.0.75    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
688        Disabled           Disabled          37704      k8s:app=backend                                                                      10.244.0.180   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
889        Disabled           Disabled          32231      k8s:app=traffic-manager                                                              10.244.0.133   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=ambassador                                   
                                                           k8s:io.cilium.k8s.namespace.labels.name=ambassador                                                          
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=traffic-manager                                                     
                                                           k8s:io.kubernetes.pod.namespace=ambassador                                                                  
                                                           k8s:telepresence=manager                                                                                    
895        Disabled           Disabled          20017      k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs               10.244.0.194   ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator                                               
                                                           k8s:io.kubernetes.pod.namespace=openebs                                                                     
                                                           k8s:name=openebs-localpv-provisioner                                                                        
                                                           k8s:openebs.io/component-name=openebs-localpv-provisioner                                                   
                                                           k8s:openebs.io/version=3.4.0                                                                                
913        Disabled           Disabled          4          reserved:health                                                                      10.244.0.132   ready   
1018       Disabled           Disabled          20605      k8s:batch.kubernetes.io/controller-uid=aa83000c-3d5d-4270-9633-d07fb4777077          10.244.0.98    ready   
                                                           k8s:batch.kubernetes.io/job-name=create-minio-buckets                                                       
                                                           k8s:controller-uid=aa83000c-3d5d-4270-9633-d07fb4777077                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
                                                           k8s:job-name=create-minio-buckets                                                                           
1055       Disabled           Disabled          55452      k8s:app.kubernetes.io/name=hubble-relay                                              10.244.0.23    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                        
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay                                                        
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=hubble-relay                                                                                    
1187       Disabled           Disabled          53642      k8s:app=postgres                                                                     10.244.0.167   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
1784       Disabled           Disabled          17496      k8s:app=frontend                                                                     10.244.0.12    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
1785       Disabled           Disabled          37048      k8s:app.kubernetes.io/component=webhook                                              10.244.0.90    ready   
                                                           k8s:app.kubernetes.io/instance=cert-manager                                                                 
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                       
                                                           k8s:app.kubernetes.io/name=webhook                                                                          
                                                           k8s:app.kubernetes.io/version=v1.10.0                                                                       
                                                           k8s:app=webhook                                                                                             
                                                           k8s:helm.sh/chart=cert-manager-v1.10.0                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager                                 
                                                           k8s:io.cilium.k8s.namespace.labels.name=cert-manager                                                        
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-webhook                                                
                                                           k8s:io.kubernetes.pod.namespace=cert-manager                                                                
2422       Disabled           Disabled          17496      k8s:app=frontend                                                                     10.244.0.101   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
2550       Disabled           Disabled          31997      k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system           10.244.0.228   ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=metrics-server                                                      
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=metrics-server                                                                                  
2675       Disabled           Disabled          15689      k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs               10.244.0.126   ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator                                               
                                                           k8s:io.kubernetes.pod.namespace=openebs                                                                     
                                                           k8s:name=openebs-ndm-operator                                                                               
                                                           k8s:openebs.io/component-name=ndm-operator                                                                  
                                                           k8s:openebs.io/version=3.4.0                                                                                
2870       Disabled           Disabled          37704      k8s:app=backend                                                                      10.244.0.118   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
3122       Disabled           Disabled          20924      k8s:app=pgweb                                                                        10.244.0.222   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
3130       Disabled           Disabled          17496      k8s:app=frontend                                                                     10.244.0.8     ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
3475       Disabled           Disabled          1728       k8s:app=redis                                                                        10.244.0.202   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
3656       Disabled           Disabled          1          k8s:node-role.kubernetes.io/control-plane=true                                                      ready   
                                                           k8s:node.k0sproject.io/role=control-plane                                                                   
                                                           reserved:host                                                                                               
3692       Disabled           Disabled          27280      k8s:app=streamchat                                                                   10.244.0.80    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
```

#### BPF Policy Get 104

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    26878   286       0        

```


#### BPF CT List 104

```
Invalid argument: unknown type 104
```


#### Endpoint Get 104

```
[
  {
    "id": 104,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-104-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "43c72b0d-3d8f-40d1-b145-ecc35f13040c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-104",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:29:18.994Z",
            "success-count": 1
          },
          "uuid": "c390b08d-7fc3-4e0c-b909-908ea2efad2f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-104",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.320Z",
            "success-count": 23
          },
          "uuid": "ce16132a-6372-4eb4-b4d4-945ab7e826bd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (104)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:29.219Z",
            "success-count": 21
          },
          "uuid": "2f470331-95b2-4588-8c77-524c1e018f6c"
        }
      ],
      "external-identifiers": {
        "container-id": "975df9b7f91301093085bd7763c2efb78bca87c555e7f059470c2b34cb28acb6",
        "k8s-namespace": "openebs",
        "k8s-pod-name": "openebs-ndm-node-exporter-xwb7s",
        "pod-name": "openebs/openebs-ndm-node-exporter-xwb7s"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 16036,
        "labels": [
          "k8s:openebs.io/version=3.4.0",
          "k8s:name=openebs-ndm-node-exporter",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:openebs.io/component-name=ndm-node-exporter"
        ]
      },
      "labels": {
        "derived": [
          "k8s:controller-revision-hash=65597f5db8",
          "k8s:pod-template-generation=1"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:name=openebs-ndm-node-exporter",
          "k8s:openebs.io/component-name=ndm-node-exporter",
          "k8s:openebs.io/version=3.4.0"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "namedPorts": [
        {
          "name": "metrics",
          "port": 9101,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.157",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "7e:5c:19:11:58:5f",
        "interface-index": 13,
        "interface-name": "lxc119ad3dfee62",
        "mac": "5e:b2:a1:6e:61:c5"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 16036,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 16036,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 104

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 104

```
Timestamp              Status   State                   Message
2023-09-05T22:32:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T22:31:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:37Z   OK       regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T22:31:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T22:29:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:29:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:24Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T22:29:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:29:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:29:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:18Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:29:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:29:18Z   OK       ready                   Set identity for this endpoint
2023-09-05T22:29:18Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 16036

```
ID      LABELS
16036   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator
        k8s:io.kubernetes.pod.namespace=openebs
        k8s:name=openebs-ndm-node-exporter
        k8s:openebs.io/component-name=ndm-node-exporter
        k8s:openebs.io/version=3.4.0

```


#### BPF Policy Get 133

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6914    44        0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    1727    19        0        

```


#### BPF CT List 133

```
Invalid argument: unknown type 133
```


#### Endpoint Get 133

```
[
  {
    "id": 133,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-133-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "72cfda90-ae8e-421b-a515-928a0ddfe59e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-133",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:31:53.162Z",
            "success-count": 1
          },
          "uuid": "45c6bb87-dd84-415e-8857-75c47cea129b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-133",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.321Z",
            "success-count": 4
          },
          "uuid": "72e3db8e-be38-4ac0-b31a-dbb2cfe0d206"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (133)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:33.170Z",
            "success-count": 6
          },
          "uuid": "3724b0ef-07af-4a58-b4ff-efc119df6c67"
        }
      ],
      "external-identifiers": {
        "container-id": "1faff8cc5033bc3368fc1a19163283c030e618bd8e401bacc5778e4172e47bff",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "livestreamdb-6877b6fc75-qmm5g",
        "pod-name": "streampai/livestreamdb-6877b6fc75-qmm5g"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2536,
        "labels": [
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=livestreamdb",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6877b6fc75"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=livestreamdb",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.242",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "16:71:e1:94:80:51",
        "interface-index": 71,
        "interface-name": "lxc8b90fe1d5b0f",
        "mac": "b2:70:1f:e7:23:6a"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2536,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2536,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 133

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 133

```
Timestamp              Status   State                   Message
2023-09-05T22:32:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:31:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:31:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:31:53Z   OK       ready                   Set identity for this endpoint
2023-09-05T22:31:53Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2536

```
ID     LABELS
2536   k8s:app=livestreamdb
       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
       k8s:io.cilium.k8s.namespace.labels.name=streampai
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=default
       k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 142

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 142

```
Invalid argument: unknown type 142
```


#### Endpoint Get 142

```
[
  {
    "id": 142,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-142-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "9536872c-bc29-4160-8713-8987880fe6ec"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-142",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:29:20.406Z",
            "success-count": 1
          },
          "uuid": "eafd08b0-2861-4959-ace7-c515a5724589"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-142",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.319Z",
            "success-count": 22
          },
          "uuid": "c6ad9bdf-0fe9-4583-8b6b-3026795afdca"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (142)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:31.619Z",
            "success-count": 21
          },
          "uuid": "5161e2e9-41f8-4821-a67a-e2ea78aec552"
        }
      ],
      "external-identifiers": {
        "container-id": "9b722d814a1495c35df48589888a3a4eedd2e33dddf49e2794db04b910cd8399",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "hubble-ui-6b468cff75-nxd77",
        "pod-name": "kube-system/hubble-ui-6b468cff75-nxd77"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 45914,
        "labels": [
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app.kubernetes.io/name=hubble-ui",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:k8s-app=hubble-ui",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.kubernetes.pod.namespace=kube-system"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6b468cff75"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=hubble-ui",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=hubble-ui"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "namedPorts": [
        {
          "name": "grpc",
          "port": 8090,
          "protocol": "TCP"
        },
        {
          "name": "http",
          "port": 8081,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.9",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "86:ab:c1:4a:36:e4",
        "interface-index": 21,
        "interface-name": "lxc346fa36d29b0",
        "mac": "5e:f7:8a:65:de:ce"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 45914,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 45914,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 142

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 142

```
Timestamp              Status    State                   Message
2023-09-05T22:32:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:38Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:38Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK        ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T22:31:37Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:37Z   OK        regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T22:31:37Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T22:29:25Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:25Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:25Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:25Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:24Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:29:24Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:24Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T22:29:24Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:29:23Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:23Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:23Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:23Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:22Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:22Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:22Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:22Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:21Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:21Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:21Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:21Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:20Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:20Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:20Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:20Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:20Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:29:20Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:20Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:29:20Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:29:20Z   OK        ready                   Set identity for this endpoint
2023-09-05T22:29:19Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:19Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 45914

```
ID      LABELS
45914   k8s:app.kubernetes.io/name=hubble-ui
        k8s:app.kubernetes.io/part-of=cilium
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=hubble-ui

```


#### BPF Policy Get 210

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    1630    17        0        

```


#### BPF CT List 210

```
Invalid argument: unknown type 210
```


#### Endpoint Get 210

```
[
  {
    "id": 210,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-210-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "ff28cd54-7997-4839-8dc0-42b814b03999"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-210",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:31:59.373Z",
            "success-count": 1
          },
          "uuid": "9bdea8fb-9463-4d5c-aa65-db00c1aec1ae"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-210",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.320Z",
            "success-count": 2
          },
          "uuid": "b7262cd5-deba-4fe9-a87a-e2222e21bfb0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (210)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:29.380Z",
            "success-count": 5
          },
          "uuid": "29c61365-8f6d-401a-a0bc-419c121f740d"
        }
      ],
      "external-identifiers": {
        "container-id": "1c07fd48260112bb2722e277b67226d9cbe2864253ffb363599c85096761386e",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "minio-d496dbccf-8lwv6",
        "pod-name": "streampai/minio-d496dbccf-8lwv6"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 32223,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=minio",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=d496dbccf"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=minio",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.148",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "5e:1f:19:56:b9:5d",
        "interface-index": 73,
        "interface-name": "lxc655b8d0b3ee4",
        "mac": "c6:db:b8:08:23:3e"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 32223,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 32223,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 210

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 210

```
Timestamp              Status    State                   Message
2023-09-05T22:32:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:31:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:31:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:31:59Z   OK        ready                   Set identity for this endpoint
2023-09-05T22:31:59Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 32223

```
ID      LABELS
32223   k8s:app=minio
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 235

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    91596   760       0        

```


#### BPF CT List 235

```
Invalid argument: unknown type 235
```


#### Endpoint Get 235

```
[
  {
    "id": 235,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-235-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b16765bc-7c2f-4cf0-a8bf-9f791fb7efc1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-235",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:29:23.677Z",
            "success-count": 1
          },
          "uuid": "a7317626-0985-4d09-8325-1ad3832eb12a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-235",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.321Z",
            "success-count": 19
          },
          "uuid": "b51bdbfe-02d3-4aaa-8beb-99fdd4220508"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (235)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:33.818Z",
            "success-count": 21
          },
          "uuid": "ba5ff8eb-0005-4371-9469-93b62ab45f73"
        }
      ],
      "external-identifiers": {
        "container-id": "f986f007001ef98c955e615153cdb755b34344f44998e0a990fa4f463bf1041f",
        "k8s-namespace": "cert-manager",
        "k8s-pod-name": "cert-manager-cainjector-6774f986b-q46zg",
        "pod-name": "cert-manager/cert-manager-cainjector-6774f986b-q46zg"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 49098,
        "labels": [
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.kubernetes.pod.namespace=cert-manager",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:app.kubernetes.io/component=cainjector",
          "k8s:app.kubernetes.io/version=v1.10.0",
          "k8s:helm.sh/chart=cert-manager-v1.10.0",
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-cainjector",
          "k8s:app.kubernetes.io/name=cainjector",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:app=cainjector"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6774f986b"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/component=cainjector",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=cainjector",
          "k8s:app.kubernetes.io/version=v1.10.0",
          "k8s:app=cainjector",
          "k8s:helm.sh/chart=cert-manager-v1.10.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-cainjector",
          "k8s:io.kubernetes.pod.namespace=cert-manager"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.159",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "f6:97:a7:99:8d:68",
        "interface-index": 31,
        "interface-name": "lxca6c1d0c986ff",
        "mac": "5a:ee:b1:7f:7c:f5"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 49098,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 49098,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 235

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 235

```
Timestamp              Status   State                   Message
2023-09-05T22:32:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T22:31:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:37Z   OK       regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T22:31:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T22:29:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:29:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:24Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T22:29:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:29:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:29:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:23Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:29:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:29:23Z   OK       ready                   Set identity for this endpoint
2023-09-05T22:29:23Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 49098

```
ID      LABELS
49098   k8s:app.kubernetes.io/component=cainjector
        k8s:app.kubernetes.io/instance=cert-manager
        k8s:app.kubernetes.io/managed-by=Helm
        k8s:app.kubernetes.io/name=cainjector
        k8s:app.kubernetes.io/version=v1.10.0
        k8s:app=cainjector
        k8s:helm.sh/chart=cert-manager-v1.10.0
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager
        k8s:io.cilium.k8s.namespace.labels.name=cert-manager
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-cainjector
        k8s:io.kubernetes.pod.namespace=cert-manager

```


#### BPF Policy Get 243

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    384     4         0        

```


#### BPF CT List 243

```
Invalid argument: unknown type 243
```


#### Endpoint Get 243

```
[
  {
    "id": 243,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-243-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "6a79d66f-f15f-4340-9b9d-22755118cf96"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-243",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:31:38.908Z",
            "success-count": 1
          },
          "uuid": "77e71481-bab2-43f8-8f1f-c79f03a4a5c1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-243",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.321Z",
            "success-count": 12
          },
          "uuid": "0d32d5f4-7112-4769-b14f-ef167cb58821"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (243)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:30.110Z",
            "success-count": 7
          },
          "uuid": "be916828-a66f-4c20-bb3d-dcdc9c4be7c1"
        }
      ],
      "external-identifiers": {
        "container-id": "15e1feddfe3e3f557c79e97dd04bca696e08114894bd02b4444cdce49d14a1f8",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "postgres-migrations-tzn7j",
        "pod-name": "streampai/postgres-migrations-tzn7j"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6361,
        "labels": [
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:batch.kubernetes.io/controller-uid=43e60661-5d04-4a29-a73b-dcc82646c2e0",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:batch.kubernetes.io/job-name=postgres-migrations",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:controller-uid=43e60661-5d04-4a29-a73b-dcc82646c2e0",
          "k8s:job-name=postgres-migrations"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "k8s:batch.kubernetes.io/controller-uid=43e60661-5d04-4a29-a73b-dcc82646c2e0",
          "k8s:batch.kubernetes.io/job-name=postgres-migrations",
          "k8s:controller-uid=43e60661-5d04-4a29-a73b-dcc82646c2e0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:job-name=postgres-migrations"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.37",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "56:7d:67:49:1a:95",
        "interface-index": 49,
        "interface-name": "lxca9dd546d2ddb",
        "mac": "86:e1:6a:ae:07:14"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6361,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6361,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 243

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 243

```
Timestamp              Status    State                   Message
2023-09-05T22:32:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:31:38Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:31:38Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:31:38Z   OK        ready                   Set identity for this endpoint
2023-09-05T22:31:38Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 6361

```
ID     LABELS
6361   k8s:batch.kubernetes.io/controller-uid=43e60661-5d04-4a29-a73b-dcc82646c2e0
       k8s:batch.kubernetes.io/job-name=postgres-migrations
       k8s:controller-uid=43e60661-5d04-4a29-a73b-dcc82646c2e0
       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
       k8s:io.cilium.k8s.namespace.labels.name=streampai
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=default
       k8s:io.kubernetes.pod.namespace=streampai
       k8s:job-name=postgres-migrations

```


#### BPF Policy Get 281

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 281

```
Invalid argument: unknown type 281
```


#### Endpoint Get 281

```
[
  {
    "id": 281,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-281-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "2ab17c0d-11e5-43c5-9bb2-a76bf30cf5ba"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-281",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.358Z",
            "success-count": 1
          },
          "uuid": "ee851f41-39a1-48c2-888d-9ec2a4629666"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-281",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.420Z",
            "success-count": 1
          },
          "uuid": "97b869c1-a672-46b3-8673-8a4afe3838d7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (281)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:29.364Z",
            "success-count": 4
          },
          "uuid": "5aa1dd1d-d35d-414f-803a-c884dcb91203"
        }
      ],
      "external-identifiers": {
        "container-id": "9c7f0f6b03e857ebb62537fad16f4b5115f839725b53b520e31b0d37fe0c0636",
        "k8s-namespace": "ambassador",
        "k8s-pod-name": "uninstall-agents-r95rd",
        "pod-name": "ambassador/uninstall-agents-r95rd"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 34488,
        "labels": [
          "k8s:helm.sh/chart=telepresence-2.14.0",
          "k8s:job-name=uninstall-agents",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=ambassador",
          "k8s:batch.kubernetes.io/controller-uid=7dee02bf-27a1-4197-8878-fa09be2be628",
          "k8s:io.cilium.k8s.namespace.labels.name=ambassador",
          "k8s:app.kubernetes.io/instance=traffic-manager",
          "k8s:io.kubernetes.pod.namespace=ambassador",
          "k8s:batch.kubernetes.io/job-name=uninstall-agents",
          "k8s:controller-uid=7dee02bf-27a1-4197-8878-fa09be2be628",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app.kubernetes.io/managed-by=Helm"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/instance=traffic-manager",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:batch.kubernetes.io/controller-uid=7dee02bf-27a1-4197-8878-fa09be2be628",
          "k8s:batch.kubernetes.io/job-name=uninstall-agents",
          "k8s:controller-uid=7dee02bf-27a1-4197-8878-fa09be2be628",
          "k8s:helm.sh/chart=telepresence-2.14.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=ambassador",
          "k8s:io.cilium.k8s.namespace.labels.name=ambassador",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=ambassador",
          "k8s:job-name=uninstall-agents"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: updated security labels)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.42",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "5e:52:c6:1a:ac:89",
        "interface-index": 75,
        "interface-name": "lxcba34e313be1c",
        "mac": "f6:ae:47:aa:2c:62"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 34488,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 34488,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 281

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 281

```
Timestamp              Status    State                   Message
2023-09-05T22:32:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:32:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:32:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:32:09Z   OK        ready                   Set identity for this endpoint
2023-09-05T22:32:09Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:32:09Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 34488

```
ID      LABELS
34488   k8s:app.kubernetes.io/instance=traffic-manager
        k8s:app.kubernetes.io/managed-by=Helm
        k8s:batch.kubernetes.io/controller-uid=7dee02bf-27a1-4197-8878-fa09be2be628
        k8s:batch.kubernetes.io/job-name=uninstall-agents
        k8s:controller-uid=7dee02bf-27a1-4197-8878-fa09be2be628
        k8s:helm.sh/chart=telepresence-2.14.0
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=ambassador
        k8s:io.cilium.k8s.namespace.labels.name=ambassador
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=ambassador
        k8s:job-name=uninstall-agents

```


#### BPF Policy Get 353

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    27945   257       0        
Allow    Ingress     1          ANY          NONE         disabled    51076   584       0        
Allow    Egress      0          ANY          NONE         disabled    13734   152       0        

```


#### BPF CT List 353

```
Invalid argument: unknown type 353
```


#### Endpoint Get 353

```
[
  {
    "id": 353,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-353-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "da3000eb-cd71-4f7b-931a-3d8ff4dc5b6f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-353",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:29:19.017Z",
            "success-count": 1
          },
          "uuid": "2def75c9-7c45-41bb-a86c-5bbd59ec2bc3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-353",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.320Z",
            "success-count": 23
          },
          "uuid": "ae6974a2-405d-45ac-83b3-4d3975f03345"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (353)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:29.816Z",
            "success-count": 21
          },
          "uuid": "25735abf-1f15-4df3-9104-ecce5ff6b659"
        }
      ],
      "external-identifiers": {
        "container-id": "8e8011bf783211cec57f9559edd52f4c5a3a7ecc2d5a56cba2a691d1ee556113",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-878bb57ff-r6bcw",
        "pod-name": "kube-system/coredns-878bb57ff-r6bcw"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5031,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=878bb57ff"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.223",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "ee:d1:ba:89:c0:1d",
        "interface-index": 19,
        "interface-name": "lxccedcb6c151a5",
        "mac": "de:e7:f6:be:e0:bc"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5031,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5031,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 353

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 353

```
Timestamp              Status   State                   Message
2023-09-05T22:32:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T22:31:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:37Z   OK       regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T22:31:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T22:29:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:29:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:24Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T22:29:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:29:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:29:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:19Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:29:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:29:19Z   OK       ready                   Set identity for this endpoint
2023-09-05T22:29:18Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 5031

```
ID     LABELS
5031   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=coredns
       k8s:io.kubernetes.pod.namespace=kube-system
       k8s:k8s-app=kube-dns

```


#### BPF Policy Get 401

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3240    18        0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 401

```
Invalid argument: unknown type 401
```


#### Endpoint Get 401

```
[
  {
    "id": 401,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-401-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "4435d04a-b67e-4e8d-aa93-17b61dcaa33b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-401",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:31:37.228Z",
            "success-count": 1
          },
          "uuid": "0143794e-1fff-40a4-8a3a-a2ead0cda0e7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-401",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.320Z",
            "success-count": 13
          },
          "uuid": "48d26c14-96b5-449f-ae13-41f63bfc9aa5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (401)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:27.237Z",
            "success-count": 7
          },
          "uuid": "4a40f0ac-939b-4f78-95de-bf9e574b2c56"
        }
      ],
      "external-identifiers": {
        "container-id": "06b7dfa9480f3f6ecbfa4d505b966463d32d9dcc2f4a0033627539fdcea557d3",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "frontend-58b6bf847f-br98b",
        "pod-name": "streampai/frontend-58b6bf847f-br98b"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 17496,
        "labels": [
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=58b6bf847f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.220",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "02:46:51:46:a9:dd",
        "interface-index": 39,
        "interface-name": "lxcf9603e308e74",
        "mac": "5e:d8:40:f2:1f:db"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 17496,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 17496,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 401

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 401

```
Timestamp              Status   State                   Message
2023-09-05T22:32:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:31:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:37Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:31:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:31:37Z   OK       ready                   Set identity for this endpoint
2023-09-05T22:31:37Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 17496

```
ID      LABELS
17496   k8s:app=frontend
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 441

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    0        0         0        
Allow    Egress      0          ANY          NONE         disabled    101104   938       0        

```


#### BPF CT List 441

```
Invalid argument: unknown type 441
```


#### Endpoint Get 441

```
[
  {
    "id": 441,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-441-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "fdaf27d6-efd5-47b0-ad50-98a28e7faf13"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-441",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:29:20.446Z",
            "success-count": 1
          },
          "uuid": "e02c87d0-d9f2-43df-99c3-c87a83ae66c9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-441",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.319Z",
            "success-count": 22
          },
          "uuid": "f91ec64b-bdec-4abe-99cc-a517fa9eeb2b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (441)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:32.217Z",
            "success-count": 21
          },
          "uuid": "dc144341-a676-4bd5-be57-804f8ea69cd5"
        }
      ],
      "external-identifiers": {
        "container-id": "486bbdf08d9bed9530a795f187db01512e51cdce743663378be1d853ca880783",
        "k8s-namespace": "cert-manager",
        "k8s-pod-name": "cert-manager-78ddc5db85-5w8zx",
        "pod-name": "cert-manager/cert-manager-78ddc5db85-5w8zx"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4302,
        "labels": [
          "k8s:io.kubernetes.pod.namespace=cert-manager",
          "k8s:app=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:app.kubernetes.io/component=controller",
          "k8s:app.kubernetes.io/name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager",
          "k8s:helm.sh/chart=cert-manager-v1.10.0",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app.kubernetes.io/version=v1.10.0",
          "k8s:app.kubernetes.io/instance=cert-manager"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=78ddc5db85"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/component=controller",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=cert-manager",
          "k8s:app.kubernetes.io/version=v1.10.0",
          "k8s:app=cert-manager",
          "k8s:helm.sh/chart=cert-manager-v1.10.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager",
          "k8s:io.kubernetes.pod.namespace=cert-manager"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "namedPorts": [
        {
          "name": "http-metrics",
          "port": 9402,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.135",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "16:36:68:00:c9:7a",
        "interface-index": 29,
        "interface-name": "lxcf3d11662b2bf",
        "mac": "d6:d6:aa:16:b0:8e"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4302,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4302,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 441

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 441

```
Timestamp              Status    State                   Message
2023-09-05T22:32:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:38Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:38Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK        ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T22:31:37Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:37Z   OK        regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T22:31:37Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T22:29:25Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:25Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:25Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:25Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:24Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:29:24Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:24Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T22:29:24Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:29:23Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:23Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:23Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:23Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:22Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:22Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:22Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:22Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:21Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:21Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:21Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:21Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:20Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:20Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:20Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:20Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:20Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:29:20Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:20Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:29:20Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:29:20Z   OK        ready                   Set identity for this endpoint
2023-09-05T22:29:19Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:19Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 4302

```
ID     LABELS
4302   k8s:app.kubernetes.io/component=controller
       k8s:app.kubernetes.io/instance=cert-manager
       k8s:app.kubernetes.io/managed-by=Helm
       k8s:app.kubernetes.io/name=cert-manager
       k8s:app.kubernetes.io/version=v1.10.0
       k8s:app=cert-manager
       k8s:helm.sh/chart=cert-manager-v1.10.0
       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager
       k8s:io.cilium.k8s.namespace.labels.name=cert-manager
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=cert-manager
       k8s:io.kubernetes.pod.namespace=cert-manager

```


#### BPF Policy Get 516

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    26295   277       0        

```


#### BPF CT List 516

```
Invalid argument: unknown type 516
```


#### Endpoint Get 516

```
[
  {
    "id": 516,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-516-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f808e2dc-addc-4797-abb4-26e6389fabbd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-516",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:29:20.406Z",
            "success-count": 1
          },
          "uuid": "52402074-43c5-432b-abb8-6e69847f306e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-516",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.320Z",
            "success-count": 22
          },
          "uuid": "c9242afc-d8d2-4bf8-af53-3ea2fac06389"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (516)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:32.019Z",
            "success-count": 21
          },
          "uuid": "2b0ca8e9-19ba-4e66-97fb-38bc40528e7d"
        }
      ],
      "external-identifiers": {
        "container-id": "0946b93b2ee27340a189b5d93817618c022d0e180afb8a6fe460ee99b244c820",
        "k8s-namespace": "openebs",
        "k8s-pod-name": "openebs-ndm-cluster-exporter-589554f487-vj6lq",
        "pod-name": "openebs/openebs-ndm-cluster-exporter-589554f487-vj6lq"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 12645,
        "labels": [
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:openebs.io/component-name=ndm-cluster-exporter",
          "k8s:openebs.io/version=3.4.0",
          "k8s:name=openebs-ndm-cluster-exporter",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=589554f487"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:name=openebs-ndm-cluster-exporter",
          "k8s:openebs.io/component-name=ndm-cluster-exporter",
          "k8s:openebs.io/version=3.4.0"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "namedPorts": [
        {
          "name": "metrics",
          "port": 9100,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.54",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "fe:a9:c4:07:57:e2",
        "interface-index": 17,
        "interface-name": "lxc8a558cabb5a1",
        "mac": "06:79:dc:82:b2:75"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 12645,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 12645,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 516

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 516

```
Timestamp              Status    State                   Message
2023-09-05T22:32:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:38Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:38Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK        ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T22:31:37Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:37Z   OK        regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T22:31:37Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T22:29:25Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:25Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:25Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:25Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:24Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:29:24Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:24Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T22:29:24Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:29:23Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:23Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:23Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:23Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:22Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:22Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:22Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:22Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:21Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:21Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:21Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:21Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:20Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:20Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:20Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:20Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:20Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:29:20Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:20Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:29:20Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:29:20Z   OK        ready                   Set identity for this endpoint
2023-09-05T22:29:19Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:19Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 12645

```
ID      LABELS
12645   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator
        k8s:io.kubernetes.pod.namespace=openebs
        k8s:name=openebs-ndm-cluster-exporter
        k8s:openebs.io/component-name=ndm-cluster-exporter
        k8s:openebs.io/version=3.4.0

```


#### BPF Policy Get 546

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    11241   103       0        

```


#### BPF CT List 546

```
Invalid argument: unknown type 546
```


#### Endpoint Get 546

```
[
  {
    "id": 546,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-546-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d260a66e-09f3-4ab4-ace0-b526bb28da11"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-546",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:31:38.507Z",
            "success-count": 1
          },
          "uuid": "192a418b-e31b-4035-a667-3e887f891bb5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-546",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.319Z",
            "success-count": 12
          },
          "uuid": "01e4a5e1-83ce-4c8e-82da-1fbcd2d2856a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (546)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:29.113Z",
            "success-count": 7
          },
          "uuid": "3c3d6336-d6a0-4ed3-9315-a5cbfb302d97"
        }
      ],
      "external-identifiers": {
        "container-id": "97825c0efeb6e54e338e040b9e5cbfdfc1f84a8887b8e0b1fe0754117214d8ef",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "kratos-77cbf98c8f-ds6vd",
        "pod-name": "streampai/kratos-77cbf98c8f-ds6vd"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 22396,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=kratos",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=77cbf98c8f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=kratos",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.75",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "12:c0:ff:cd:b8:c2",
        "interface-index": 45,
        "interface-name": "lxc0ef1ae825717",
        "mac": "32:14:8f:c6:23:f1"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 22396,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 22396,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 546

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 546

```
Timestamp              Status    State                   Message
2023-09-05T22:32:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:31:38Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:31:38Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:31:38Z   OK        ready                   Set identity for this endpoint
2023-09-05T22:31:38Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 22396

```
ID      LABELS
22396   k8s:app=kratos
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 688

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    726     4         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 688

```
Invalid argument: unknown type 688
```


#### Endpoint Get 688

```
[
  {
    "id": 688,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-688-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "88a839d8-3dae-48e9-91ad-9d21cc0cd4fa"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-688",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:31:37.137Z",
            "success-count": 1
          },
          "uuid": "68d0d9f0-1193-4609-9cbe-edfb0abee304"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-688",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.319Z",
            "success-count": 13
          },
          "uuid": "fa8a2ce1-4421-40bb-a2db-6f5d3de5d11b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (688)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:27.144Z",
            "success-count": 7
          },
          "uuid": "b7343c1f-cc3a-4e94-aaa7-b742d34ebd25"
        }
      ],
      "external-identifiers": {
        "container-id": "2bc1407b967a11509a0085f66e1235d4a7f5dab07edab3b7bec229ffec67b1fa",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "backend-855f6c7b4-p8vjz",
        "pod-name": "streampai/backend-855f6c7b4-p8vjz"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 37704,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=backend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=855f6c7b4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=backend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.180",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "22:b8:46:8f:47:d8",
        "interface-index": 35,
        "interface-name": "lxca94861d8ed77",
        "mac": "4a:53:50:f4:58:5a"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 37704,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 37704,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 688

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 688

```
Timestamp              Status   State                   Message
2023-09-05T22:32:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:31:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:37Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:31:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:31:37Z   OK       ready                   Set identity for this endpoint
2023-09-05T22:31:37Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 37704

```
ID      LABELS
37704   k8s:app=backend
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 889

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    38812   281       0        

```


#### BPF CT List 889

```
Invalid argument: unknown type 889
```


#### Endpoint Get 889

```
[
  {
    "id": 889,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-889-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "8574d4c9-995a-4b23-85ad-724ee461d28c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-889",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:31:43.148Z",
            "success-count": 1
          },
          "uuid": "cd2fa8c1-821b-4fa2-b096-8d7dfb6caa3d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-889",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.320Z",
            "success-count": 7
          },
          "uuid": "c5504089-743f-494e-b9a3-51071fdf5e75"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (889)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:34.712Z",
            "success-count": 7
          },
          "uuid": "125bb84b-2ba1-4968-91cc-4adadab15ead"
        }
      ],
      "external-identifiers": {
        "container-id": "8b026a6321b274f26f2d437099b9ba3dde49a0fa93bbf89b3abfca8c326cbfa8",
        "k8s-namespace": "ambassador",
        "k8s-pod-name": "traffic-manager-55d995585d-brtlj",
        "pod-name": "ambassador/traffic-manager-55d995585d-brtlj"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 32231,
        "labels": [
          "k8s:io.cilium.k8s.policy.serviceaccount=traffic-manager",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=traffic-manager",
          "k8s:telepresence=manager",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=ambassador",
          "k8s:io.cilium.k8s.namespace.labels.name=ambassador",
          "k8s:io.kubernetes.pod.namespace=ambassador"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=55d995585d"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=traffic-manager",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=ambassador",
          "k8s:io.cilium.k8s.namespace.labels.name=ambassador",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=traffic-manager",
          "k8s:io.kubernetes.pod.namespace=ambassador",
          "k8s:telepresence=manager"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "namedPorts": [
        {
          "name": "api",
          "port": 8081,
          "protocol": "TCP"
        },
        {
          "name": "grpc-trace",
          "port": 15766,
          "protocol": "TCP"
        },
        {
          "name": "https",
          "port": 443,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.133",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "22:40:09:0d:1f:d1",
        "interface-index": 67,
        "interface-name": "lxc59e096dd7e22",
        "mac": "76:69:df:92:d5:f8"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 32231,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 32231,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 889

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 889

```
Timestamp              Status    State                   Message
2023-09-05T22:32:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:31:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:31:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:31:43Z   OK        ready                   Set identity for this endpoint
2023-09-05T22:31:43Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 32231

```
ID      LABELS
32231   k8s:app=traffic-manager
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=ambassador
        k8s:io.cilium.k8s.namespace.labels.name=ambassador
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=traffic-manager
        k8s:io.kubernetes.pod.namespace=ambassador
        k8s:telepresence=manager

```


#### BPF Policy Get 895

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    0        0         0        
Allow    Egress      0          ANY          NONE         disabled    154266   879       0        

```


#### BPF CT List 895

```
Invalid argument: unknown type 895
```


#### Endpoint Get 895

```
[
  {
    "id": 895,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-895-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "ac25176b-8ce7-4ac4-a8b1-853c920c7560"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-895",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:29:22.647Z",
            "success-count": 1
          },
          "uuid": "d0048727-ab17-46f9-8044-a371e51666d9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-895",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.321Z",
            "success-count": 20
          },
          "uuid": "312b31ec-9a00-4c4c-ace2-6e3c782cb888"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (895)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:33.219Z",
            "success-count": 21
          },
          "uuid": "13817971-3ab0-4184-846a-de15838f7fdd"
        }
      ],
      "external-identifiers": {
        "container-id": "d9b78e007989b543e98450adc0bb5ba9d266d6dee39f592919eabb5fb5fa416a",
        "k8s-namespace": "openebs",
        "k8s-pod-name": "openebs-localpv-provisioner-7d6ccb7795-czbsm",
        "pod-name": "openebs/openebs-localpv-provisioner-7d6ccb7795-czbsm"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 20017,
        "labels": [
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:name=openebs-localpv-provisioner",
          "k8s:openebs.io/component-name=openebs-localpv-provisioner",
          "k8s:openebs.io/version=3.4.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7d6ccb7795"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:name=openebs-localpv-provisioner",
          "k8s:openebs.io/component-name=openebs-localpv-provisioner",
          "k8s:openebs.io/version=3.4.0"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.194",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "ea:64:6a:77:dd:e8",
        "interface-index": 25,
        "interface-name": "lxc37782ef37adb",
        "mac": "22:87:9b:cc:b1:b2"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 20017,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 20017,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 895

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 895

```
Timestamp              Status   State                   Message
2023-09-05T22:32:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T22:31:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:37Z   OK       regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T22:31:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T22:29:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:29:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:24Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T22:29:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:29:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:29:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:22Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:29:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:29:22Z   OK       ready                   Set identity for this endpoint
2023-09-05T22:29:22Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 20017

```
ID      LABELS
20017   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator
        k8s:io.kubernetes.pod.namespace=openebs
        k8s:name=openebs-localpv-provisioner
        k8s:openebs.io/component-name=openebs-localpv-provisioner
        k8s:openebs.io/version=3.4.0

```


#### BPF Policy Get 913

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    2875    33        0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 913

```
Invalid argument: unknown type 913
```


#### Endpoint Get 913

```
[
  {
    "id": 913,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-913-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f2930bc8-1c77-45a7-8f72-db207c4e4488"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-913",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:29:19.729Z",
            "success-count": 1
          },
          "uuid": "355c3f80-de78-4cf5-8ab9-00b7d554f3d7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-913",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.320Z",
            "success-count": 23
          },
          "uuid": "616fd83a-5455-4588-b69a-77a6bd86dfe3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (913)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:29.740Z",
            "success-count": 21
          },
          "uuid": "d450dedf-7da4-46db-a42a-cc30d46c6876"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.132",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "2a:44:f8:9e:32:a0",
        "interface-index": 6,
        "interface-name": "lxc_health",
        "mac": "36:1f:36:03:34:ff"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 913

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 913

```
Timestamp              Status   State                   Message
2023-09-05T22:32:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T22:31:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:37Z   OK       regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T22:31:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T22:29:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:29:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:24Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T22:29:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:29:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:29:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:19Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:29:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:29:19Z   OK       ready                   Set identity for this endpoint
2023-09-05T22:29:18Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 1018

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    832     8         0        

```


#### BPF CT List 1018

```
Invalid argument: unknown type 1018
```


#### Endpoint Get 1018

```
[
  {
    "id": 1018,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1018-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5957d97c-c1a6-490c-93c6-d7cdb90166a2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1018",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:31:39.907Z",
            "success-count": 1
          },
          "uuid": "a4decba3-62b0-48e7-b5d6-c16127ca8e0f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-1018",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.320Z",
            "success-count": 11
          },
          "uuid": "3a10fee5-526f-4c39-8c6f-55a8eca31899"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1018)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:31.910Z",
            "success-count": 7
          },
          "uuid": "3596ab3d-ce14-4daf-aba7-cf785fd6bf20"
        }
      ],
      "external-identifiers": {
        "container-id": "6427c9b4239cfdf63f3799f2d090e38d1f1e88ada96de4d1dca6cfb1ce96f162",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "create-minio-buckets-8m6q5",
        "pod-name": "streampai/create-minio-buckets-8m6q5"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 20605,
        "labels": [
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:controller-uid=aa83000c-3d5d-4270-9633-d07fb4777077",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:batch.kubernetes.io/controller-uid=aa83000c-3d5d-4270-9633-d07fb4777077",
          "k8s:job-name=create-minio-buckets",
          "k8s:batch.kubernetes.io/job-name=create-minio-buckets"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "k8s:batch.kubernetes.io/controller-uid=aa83000c-3d5d-4270-9633-d07fb4777077",
          "k8s:batch.kubernetes.io/job-name=create-minio-buckets",
          "k8s:controller-uid=aa83000c-3d5d-4270-9633-d07fb4777077",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:job-name=create-minio-buckets"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.98",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "8a:73:1e:76:c5:8f",
        "interface-index": 55,
        "interface-name": "lxc6ad0c51d5075",
        "mac": "c6:49:39:cb:e2:dd"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 20605,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 20605,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1018

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1018

```
Timestamp              Status    State                   Message
2023-09-05T22:32:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:31:39Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:31:39Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:31:39Z   OK        ready                   Set identity for this endpoint
2023-09-05T22:31:39Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 20605

```
ID      LABELS
20605   k8s:batch.kubernetes.io/controller-uid=aa83000c-3d5d-4270-9633-d07fb4777077
        k8s:batch.kubernetes.io/job-name=create-minio-buckets
        k8s:controller-uid=aa83000c-3d5d-4270-9633-d07fb4777077
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai
        k8s:job-name=create-minio-buckets

```


#### BPF Policy Get 1055

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    9100    140       0        
Allow    Egress      0          ANY          NONE         disabled    8895    74        0        

```


#### BPF CT List 1055

```
Invalid argument: unknown type 1055
```


#### Endpoint Get 1055

```
[
  {
    "id": 1055,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1055-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b58d7551-13e5-40ca-83de-ed8eb3a8ea21"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1055",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:29:21.846Z",
            "success-count": 1
          },
          "uuid": "bdd89487-4b5a-4a5b-b850-fb540b59f6f1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-1055",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.320Z",
            "success-count": 21
          },
          "uuid": "74b4a801-16b7-460b-895c-2f8eec434004"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1055)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:32.819Z",
            "success-count": 21
          },
          "uuid": "2ec3a94a-ede6-425c-ba42-05948933a688"
        }
      ],
      "external-identifiers": {
        "container-id": "e18ef58515f5f53361911d0617ff8fd16926314e799bfe91a035e86d0f0fb596",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "hubble-relay-777496bf44-dqbz5",
        "pod-name": "kube-system/hubble-relay-777496bf44-dqbz5"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 55452,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:k8s-app=hubble-relay",
          "k8s:app.kubernetes.io/name=hubble-relay",
          "k8s:app.kubernetes.io/part-of=cilium"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=777496bf44"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=hubble-relay",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=hubble-relay"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "namedPorts": [
        {
          "name": "grpc",
          "port": 4245,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.23",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "a2:ea:d1:a6:14:9a",
        "interface-index": 23,
        "interface-name": "lxcfe16b37f78d3",
        "mac": "ae:12:f7:ae:27:82"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 55452,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 55452,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1055

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1055

```
Timestamp              Status    State                   Message
2023-09-05T22:32:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:38Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:38Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK        ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T22:31:37Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:37Z   OK        regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T22:31:37Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T22:29:25Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:25Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:25Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:25Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:24Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:29:24Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:24Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T22:29:24Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:29:23Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:23Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:23Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:23Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:22Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:22Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:22Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:22Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:21Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:21Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:21Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:21Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:29:21Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:21Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:29:21Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:29:21Z   OK        ready                   Set identity for this endpoint
2023-09-05T22:29:20Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:20Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 55452

```
ID      LABELS
55452   k8s:app.kubernetes.io/name=hubble-relay
        k8s:app.kubernetes.io/part-of=cilium
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=hubble-relay

```


#### BPF Policy Get 1187

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    247189   1812      0        
Allow    Ingress     1          ANY          NONE         disabled    0        0         0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 1187

```
Invalid argument: unknown type 1187
```


#### Endpoint Get 1187

```
[
  {
    "id": 1187,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1187-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d6028c3a-30d0-45d9-a022-90494264e565"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1187",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:31:52.981Z",
            "success-count": 1
          },
          "uuid": "17a6db51-159e-409c-8e75-73ac37c7a7e6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-1187",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.320Z",
            "success-count": 4
          },
          "uuid": "5c8e13f0-c4d7-492c-a4d8-33e135887757"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1187)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:32.988Z",
            "success-count": 6
          },
          "uuid": "58262b0b-e26c-45ef-a78a-d959bb64ceb8"
        }
      ],
      "external-identifiers": {
        "container-id": "daf2c48a05fd7f0e944fc695a0a53ba42082a8de9dbab3407e524a16436ce85e",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "postgres-7c845b6448-rs4t6",
        "pod-name": "streampai/postgres-7c845b6448-rs4t6"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 53642,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=postgres"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7c845b6448"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=postgres",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.167",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "1e:9f:a5:91:f9:99",
        "interface-index": 69,
        "interface-name": "lxc12be36577ae9",
        "mac": "ea:47:f9:8c:d8:eb"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 53642,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 53642,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1187

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1187

```
Timestamp              Status    State                   Message
2023-09-05T22:32:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:31:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:31:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:31:52Z   OK        ready                   Set identity for this endpoint
2023-09-05T22:31:52Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 53642

```
ID      LABELS
53642   k8s:app=postgres
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 1784

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4538    25        0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1784

```
Invalid argument: unknown type 1784
```


#### Endpoint Get 1784

```
[
  {
    "id": 1784,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1784-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "02cdbb68-ae79-447e-b1b0-e8038af44d80"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1784",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:31:37.243Z",
            "success-count": 1
          },
          "uuid": "4883249f-a3bb-4466-b909-bf7a444de728"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-1784",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.321Z",
            "success-count": 13
          },
          "uuid": "4049f849-2ca0-411a-886b-b27f679f48e9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1784)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:27.711Z",
            "success-count": 7
          },
          "uuid": "9d11a87e-9ee7-4bdf-9fd5-5460efeba933"
        }
      ],
      "external-identifiers": {
        "container-id": "b7b6a14d032c51f97abff9bdafa8c4d2a94ac2d572636540ccd7594e3a4b0aab",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "frontend-58b6bf847f-mxkjg",
        "pod-name": "streampai/frontend-58b6bf847f-mxkjg"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 17496,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=frontend"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=58b6bf847f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.12",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "fa:58:b1:0e:2b:19",
        "interface-index": 41,
        "interface-name": "lxc4d1095406f91",
        "mac": "aa:52:0f:0e:0b:da"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 17496,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 17496,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1784

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1784

```
Timestamp              Status   State                   Message
2023-09-05T22:32:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:31:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:37Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:31:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:31:37Z   OK       ready                   Set identity for this endpoint
2023-09-05T22:31:37Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 17496

```
ID      LABELS
17496   k8s:app=frontend
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 1785

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    47852   354       0        
Allow    Egress      0          ANY          NONE         disabled    6628    32        0        

```


#### BPF CT List 1785

```
Invalid argument: unknown type 1785
```


#### Endpoint Get 1785

```
[
  {
    "id": 1785,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1785-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5d82abe9-59a6-4607-b82a-b276041fc035"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1785",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:29:20.406Z",
            "success-count": 1
          },
          "uuid": "5e8e9d89-55df-43d7-af53-c46a995dcad1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-1785",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.321Z",
            "success-count": 22
          },
          "uuid": "872b0c55-4d86-43e5-926b-670ca40a4051"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1785)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:31.418Z",
            "success-count": 21
          },
          "uuid": "3a2ff64c-b9da-49ac-a6a3-cde4cdf11972"
        }
      ],
      "external-identifiers": {
        "container-id": "ad95ab4f4e03894ef55ada79694b91f86bf83ca8a93c4fd1f22b5cedab58576f",
        "k8s-namespace": "cert-manager",
        "k8s-pod-name": "cert-manager-webhook-879c48cd4-r5snx",
        "pod-name": "cert-manager/cert-manager-webhook-879c48cd4-r5snx"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 37048,
        "labels": [
          "k8s:app.kubernetes.io/name=webhook",
          "k8s:helm.sh/chart=cert-manager-v1.10.0",
          "k8s:io.kubernetes.pod.namespace=cert-manager",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:app.kubernetes.io/component=webhook",
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app.kubernetes.io/version=v1.10.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-webhook",
          "k8s:app=webhook"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=879c48cd4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/component=webhook",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=webhook",
          "k8s:app.kubernetes.io/version=v1.10.0",
          "k8s:app=webhook",
          "k8s:helm.sh/chart=cert-manager-v1.10.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-webhook",
          "k8s:io.kubernetes.pod.namespace=cert-manager"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "namedPorts": [
        {
          "name": "healthcheck",
          "port": 6080,
          "protocol": "TCP"
        },
        {
          "name": "https",
          "port": 10250,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.90",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "62:dd:3a:27:65:b4",
        "interface-index": 15,
        "interface-name": "lxc4848deb1985a",
        "mac": "fa:c1:4d:f6:e6:20"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 37048,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 37048,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1785

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1785

```
Timestamp              Status    State                   Message
2023-09-05T22:32:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:38Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:38Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK        ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T22:31:37Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:37Z   OK        regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T22:31:37Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T22:29:25Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:25Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:25Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:25Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:24Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:29:24Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:24Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T22:29:24Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:29:23Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:23Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:23Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:23Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:22Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:22Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:22Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:22Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:21Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:21Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:21Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:21Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:20Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:20Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:20Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:20Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:20Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:29:20Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:20Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:29:20Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:29:20Z   OK        ready                   Set identity for this endpoint
2023-09-05T22:29:19Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:19Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 37048

```
ID      LABELS
37048   k8s:app.kubernetes.io/component=webhook
        k8s:app.kubernetes.io/instance=cert-manager
        k8s:app.kubernetes.io/managed-by=Helm
        k8s:app.kubernetes.io/name=webhook
        k8s:app.kubernetes.io/version=v1.10.0
        k8s:app=webhook
        k8s:helm.sh/chart=cert-manager-v1.10.0
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager
        k8s:io.cilium.k8s.namespace.labels.name=cert-manager
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-webhook
        k8s:io.kubernetes.pod.namespace=cert-manager

```


#### BPF Policy Get 2422

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3727    19        0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2422

```
Invalid argument: unknown type 2422
```


#### Endpoint Get 2422

```
[
  {
    "id": 2422,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2422-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "00b9aca2-1a00-495a-87e0-e907ea3c5ae1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2422",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:31:37.283Z",
            "success-count": 1
          },
          "uuid": "a5a84d2e-cb26-436b-b4a0-fca9a96c3569"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-2422",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.321Z",
            "success-count": 13
          },
          "uuid": "f7248396-dda7-47f0-a40c-60955012dae2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2422)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:27.910Z",
            "success-count": 7
          },
          "uuid": "743e2751-efcc-4689-a7aa-0cadc07683e7"
        }
      ],
      "external-identifiers": {
        "container-id": "b9910c98c458bf0697bddfec664fa42b3cc708b3d239e3ed6209741250da4103",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "frontend-58b6bf847f-m8jq6",
        "pod-name": "streampai/frontend-58b6bf847f-m8jq6"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 17496,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=frontend"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=58b6bf847f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.101",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "f2:cb:09:1d:6c:0f",
        "interface-index": 43,
        "interface-name": "lxc983f3c9d1402",
        "mac": "ba:e5:1e:d4:e6:b8"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 17496,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 17496,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2422

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2422

```
Timestamp              Status   State                   Message
2023-09-05T22:32:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:31:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:37Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:31:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:31:37Z   OK       ready                   Set identity for this endpoint
2023-09-05T22:31:37Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 17496

```
ID      LABELS
17496   k8s:app=frontend
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 2550

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    70768   620       0        
Allow    Egress      0          ANY          NONE         disabled    23769   209       0        

```


#### BPF CT List 2550

```
Invalid argument: unknown type 2550
```


#### Endpoint Get 2550

```
[
  {
    "id": 2550,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2550-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "79b8fa9d-5be0-4ffb-aadd-13d68b1f47a6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2550",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:29:18.903Z",
            "success-count": 1
          },
          "uuid": "a699e72d-a21f-4c33-be69-2357675d6577"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-2550",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.319Z",
            "success-count": 23
          },
          "uuid": "c2d59bc6-2dca-4eff-a056-5b6a244daa77"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2550)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:28.918Z",
            "success-count": 21
          },
          "uuid": "281cb1e6-c7fb-42e0-b44b-221d5a48ddb5"
        }
      ],
      "external-identifiers": {
        "container-id": "151792f0fdade94a6ab4b9ff6d3c9c2346d0a303b3ff954713819801b503ad09",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "metrics-server-7f86dff975-6286h",
        "pod-name": "kube-system/metrics-server-7f86dff975-6286h"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 31997,
        "labels": [
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:k8s-app=metrics-server",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:io.cilium.k8s.policy.serviceaccount=metrics-server"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7f86dff975"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=metrics-server",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=metrics-server"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "namedPorts": [
        {
          "name": "https",
          "port": 10250,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.228",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "b2:17:91:38:41:61",
        "interface-index": 9,
        "interface-name": "lxcd9fdefc20bbb",
        "mac": "8e:2d:49:6e:fa:ff"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 31997,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 31997,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2550

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2550

```
Timestamp              Status    State                   Message
2023-09-05T22:32:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:38Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:38Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK        ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T22:31:37Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:37Z   OK        regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T22:31:37Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T22:29:25Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:25Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:25Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:25Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:24Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:29:24Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:24Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T22:29:24Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:29:23Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:23Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:23Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:23Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:22Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:22Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:22Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:22Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:21Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:21Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:21Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:21Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:20Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:20Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:20Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:20Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:20Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:20Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:20Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:20Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:29:19Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:18Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:29:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:29:18Z   OK        ready                   Set identity for this endpoint
2023-09-05T22:29:18Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:18Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 31997

```
ID      LABELS
31997   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=metrics-server
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=metrics-server

```


#### BPF Policy Get 2675

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    12278   143       0        
Allow    Egress      0          ANY          NONE         disabled    10984   85        0        

```


#### BPF CT List 2675

```
Invalid argument: unknown type 2675
```


#### Endpoint Get 2675

```
[
  {
    "id": 2675,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2675-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "6f590c18-01e2-4839-8f92-0a51c92b6758"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2675",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:29:25.065Z",
            "success-count": 1
          },
          "uuid": "c535aaaa-afd6-4006-9dc2-c29226729b13"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-2675",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.320Z",
            "success-count": 17
          },
          "uuid": "eb0e9de6-d879-4d66-88a7-74896b50408e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2675)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:35.077Z",
            "success-count": 21
          },
          "uuid": "05181e2b-f913-4fa6-b293-b5763ef6d89b"
        }
      ],
      "external-identifiers": {
        "container-id": "d3e522bdc3969af4a63a67ae805bbee84772d3bfd857602dc57402207cfdc8f3",
        "k8s-namespace": "openebs",
        "k8s-pod-name": "openebs-ndm-operator-7c667b76f8-5v8jv",
        "pod-name": "openebs/openebs-ndm-operator-7c667b76f8-5v8jv"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 15689,
        "labels": [
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:name=openebs-ndm-operator",
          "k8s:openebs.io/component-name=ndm-operator",
          "k8s:openebs.io/version=3.4.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7c667b76f8"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:name=openebs-ndm-operator",
          "k8s:openebs.io/component-name=ndm-operator",
          "k8s:openebs.io/version=3.4.0"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.126",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "7e:d3:c9:fa:4b:77",
        "interface-index": 27,
        "interface-name": "lxc7bc95390c700",
        "mac": "1a:2b:d9:bb:36:a0"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 15689,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 15689,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2675

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2675

```
Timestamp              Status   State                   Message
2023-09-05T22:32:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T22:31:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:37Z   OK       regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T22:31:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T22:29:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:29:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:25Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:29:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:29:25Z   OK       ready                   Set identity for this endpoint
2023-09-05T22:29:25Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 15689

```
ID      LABELS
15689   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator
        k8s:io.kubernetes.pod.namespace=openebs
        k8s:name=openebs-ndm-operator
        k8s:openebs.io/component-name=ndm-operator
        k8s:openebs.io/version=3.4.0

```


#### BPF Policy Get 2870

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1138    4         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2870

```
Invalid argument: unknown type 2870
```


#### Endpoint Get 2870

```
[
  {
    "id": 2870,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2870-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "3e53917a-198a-467f-ad4d-d66d2162b1fb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2870",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:31:37.148Z",
            "success-count": 1
          },
          "uuid": "3495f24c-c6aa-4ddb-8083-b6f308cdb1b8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-2870",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.319Z",
            "success-count": 13
          },
          "uuid": "31b34dea-15be-4337-a153-29ddc147043a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2870)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:37.157Z",
            "success-count": 8
          },
          "uuid": "14cee42e-05b2-4497-842c-2e45667f432e"
        }
      ],
      "external-identifiers": {
        "container-id": "87e65a379e60675236ca60ef952f36495b5873fa58bdd4c2418cb15a6855e01d",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "backend-855f6c7b4-ljz8j",
        "pod-name": "streampai/backend-855f6c7b4-ljz8j"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 37704,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=backend",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=855f6c7b4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=backend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.118",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "a2:e5:9b:6f:1a:c1",
        "interface-index": 33,
        "interface-name": "lxcf7c2ea09d41d",
        "mac": "f2:90:77:72:49:3f"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 37704,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 37704,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2870

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2870

```
Timestamp              Status   State                   Message
2023-09-05T22:32:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:31:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:37Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:31:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:31:37Z   OK       ready                   Set identity for this endpoint
2023-09-05T22:31:37Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 37704

```
ID      LABELS
37704   k8s:app=backend
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 3122

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    2903    22        0        

```


#### BPF CT List 3122

```
Invalid argument: unknown type 3122
```


#### Endpoint Get 3122

```
[
  {
    "id": 3122,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3122-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "4b2dc938-40b7-4fff-a0dc-490667d35e38"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3122",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:31:42.508Z",
            "success-count": 1
          },
          "uuid": "a113711a-1a40-4573-b1ad-3cfcdf077095"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-3122",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.321Z",
            "success-count": 8
          },
          "uuid": "19b12db9-b8f1-4b3b-bef0-eca6dda4bf93"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3122)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:34.111Z",
            "success-count": 7
          },
          "uuid": "6ce9bdd6-a69a-47e5-87b2-cc20ae7d237b"
        }
      ],
      "external-identifiers": {
        "container-id": "d06d1aba98fd88d3057ed0d45ae53b31b45d979a1cdbf29bcce716808a26090b",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "pgweb-b74849bb6-757xs",
        "pod-name": "streampai/pgweb-b74849bb6-757xs"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 20924,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=pgweb"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=b74849bb6"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=pgweb",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.222",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "5e:5a:0f:ec:8d:ee",
        "interface-index": 59,
        "interface-name": "lxcc5cc5cdac255",
        "mac": "be:fe:16:9a:ca:fb"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 20924,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 20924,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3122

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3122

```
Timestamp              Status    State                   Message
2023-09-05T22:32:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:31:42Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:31:42Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:31:42Z   OK        ready                   Set identity for this endpoint
2023-09-05T22:31:42Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 20924

```
ID      LABELS
20924   k8s:app=pgweb
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 3130

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3825    21        0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3130

```
Invalid argument: unknown type 3130
```


#### Endpoint Get 3130

```
[
  {
    "id": 3130,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3130-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "44bc85ad-65ba-4508-88d7-1378cb2910eb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3130",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:31:37.184Z",
            "success-count": 1
          },
          "uuid": "169804f3-a3f3-478b-9e14-03c4ad0bc201"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-3130",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.320Z",
            "success-count": 13
          },
          "uuid": "64daccb0-f87c-4033-8e27-dc060486c543"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3130)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:37.193Z",
            "success-count": 8
          },
          "uuid": "00eac4b1-dec7-4611-aee0-ad5ac6112321"
        }
      ],
      "external-identifiers": {
        "container-id": "e55c9bdcea3483c5233046907f0ee0a7a438138add4d1bfba105459f3eab16f6",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "frontend-58b6bf847f-mvjq9",
        "pod-name": "streampai/frontend-58b6bf847f-mvjq9"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 17496,
        "labels": [
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=58b6bf847f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.8",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "22:9f:12:96:40:88",
        "interface-index": 37,
        "interface-name": "lxcc21955409817",
        "mac": "02:d2:7b:9c:53:13"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 17496,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 17496,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3130

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3130

```
Timestamp              Status   State                   Message
2023-09-05T22:32:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:31:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:37Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:31:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:31:37Z   OK       ready                   Set identity for this endpoint
2023-09-05T22:31:37Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 17496

```
ID      LABELS
17496   k8s:app=frontend
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 3475

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    507     5         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3475

```
Invalid argument: unknown type 3475
```


#### Endpoint Get 3475

```
[
  {
    "id": 3475,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3475-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "12d1daed-67dc-4b4f-9dda-c4062ddf1e6f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3475",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:31:43.108Z",
            "success-count": 1
          },
          "uuid": "637df586-1794-4880-85b1-9c58f10aa5e3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-3475",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.319Z",
            "success-count": 7
          },
          "uuid": "257f7771-7b21-45fa-bd45-4d497610e79a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3475)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:34.310Z",
            "success-count": 7
          },
          "uuid": "e4f0dc5f-8588-4bb5-94de-28f9c79434c8"
        }
      ],
      "external-identifiers": {
        "container-id": "be53e4a8b0f16b3792de127300c49d8baa09c69b4ddba82e1b7714291e96eef3",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "redis-68c95977f4-jf9bx",
        "pod-name": "streampai/redis-68c95977f4-jf9bx"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1728,
        "labels": [
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=redis",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=68c95977f4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=redis",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.202",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "3a:5c:e0:e1:7c:4f",
        "interface-index": 63,
        "interface-name": "lxc9ad5d7a32906",
        "mac": "3a:36:37:42:87:11"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1728,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1728,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3475

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3475

```
Timestamp              Status    State                   Message
2023-09-05T22:32:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:31:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:31:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:31:43Z   OK        ready                   Set identity for this endpoint
2023-09-05T22:31:43Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 1728

```
ID     LABELS
1728   k8s:app=redis
       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
       k8s:io.cilium.k8s.namespace.labels.name=streampai
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=default
       k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 3656

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3656

```
Invalid argument: unknown type 3656
```


#### Endpoint Get 3656

```
[
  {
    "id": 3656,
    "spec": {
      "label-configuration": {
        "user": [
          "k8s:node-role.kubernetes.io/control-plane=true"
        ]
      },
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3656-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "e27bc2e6-ebc0-4152-98ea-cdab27f84184"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3656",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:29:39.017Z",
            "success-count": 2
          },
          "uuid": "9f964984-0652-40bb-9c71-a83e9b3acaf9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-3656",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.321Z",
            "success-count": 23
          },
          "uuid": "2f811edd-8440-4e00-8d11-abc4e27cc663"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3656)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:29.027Z",
            "success-count": 22
          },
          "uuid": "56429ccf-af7b-4600-a7b7-4f0c21b0a75a"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "k8s:node-role.kubernetes.io/control-plane=true",
          "reserved:host",
          "k8s:node.k0sproject.io/role=control-plane"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.k0sproject.io/role=control-plane",
          "reserved:host"
        ],
        "realized": {
          "user": [
            "k8s:node-role.kubernetes.io/control-plane=true"
          ]
        },
        "security-relevant": [
          "k8s:node-role.kubernetes.io/control-plane=true",
          "k8s:node.k0sproject.io/role=control-plane",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "12:5e:03:5e:34:97",
        "interface-name": "cilium_host",
        "mac": "12:5e:03:5e:34:97"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {
          "user": [
            "k8s:node-role.kubernetes.io/control-plane=true"
          ]
        },
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3656

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3656

```
Timestamp              Status   State                   Message
2023-09-05T22:32:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:42Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:41Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:40Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:39Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T22:31:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:37Z   OK       regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T22:31:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T22:29:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:29:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:39Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:29:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:29:39Z   OK       ready                   Set identity for this endpoint
2023-09-05T22:29:39Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2023-09-05T22:29:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:29:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:24Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T22:29:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:29:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:22Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:29:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:29:20Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:29:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:29:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2023-09-05T22:29:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:29:18Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:29:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:29:18Z   OK       ready                   Set identity for this endpoint
2023-09-05T22:29:18Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host
     reserved:kube-apiserver

```


#### BPF Policy Get 3692

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    2564    24        0        

```


#### BPF CT List 3692

```
Invalid argument: unknown type 3692
```


#### Endpoint Get 3692

```
[
  {
    "id": 3692,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3692-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b52028b8-4135-41a5-99d9-5b9c393b3eeb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3692",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:31:43.108Z",
            "success-count": 1
          },
          "uuid": "25effe0b-b142-4b4b-bd11-31889fbe8120"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-3692",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:09.320Z",
            "success-count": 7
          },
          "uuid": "58e605a5-4083-4f32-a0fb-85c9a8c4d034"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3692)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T22:32:34.510Z",
            "success-count": 7
          },
          "uuid": "7f8cfb99-f317-4254-adb4-b4e1ecb5699b"
        }
      ],
      "external-identifiers": {
        "container-id": "a366f681d628820fc6a7d9bfa03edd08709c03d5ed75feca4fa74ba3a7c1c027",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "streamchat-79dfbb9bb4-2dtq5",
        "pod-name": "streampai/streamchat-79dfbb9bb4-2dtq5"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 27280,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=streamchat"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=79dfbb9bb4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=streamchat",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T22:32:09Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.80",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "3e:ca:91:1e:97:a8",
        "interface-index": 65,
        "interface-name": "lxc81cfe30fa5c2",
        "mac": "ea:f0:05:f0:34:ee"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 27280,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 27280,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3692

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3692

```
Timestamp              Status    State                   Message
2023-09-05T22:32:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:32:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:32:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:32:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:45Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T22:31:45Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:45Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T22:31:45Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T22:31:44Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T22:31:44Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:44Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T22:31:44Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:43Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T22:31:43Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T22:31:43Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T22:31:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T22:31:43Z   OK        ready                   Set identity for this endpoint
2023-09-05T22:31:43Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:42Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:41Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T22:31:40Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 27280

```
ID      LABELS
27280   k8s:app=streamchat
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### Policy get

```
:
 []
Revision: 2

```


#### Cilium memory map


```
00400000-02bf5000 r-xp 00000000 08:02 39085379                           /usr/bin/cilium-agent
02bf5000-0577f000 r--p 027f5000 08:02 39085379                           /usr/bin/cilium-agent
0577f000-058a3000 rw-p 0537f000 08:02 39085379                           /usr/bin/cilium-agent
058a3000-06036000 rw-p 00000000 00:00 0 
c000000000-c003200000 rw-p 00000000 00:00 0 
c003200000-c004c00000 rw-p 00000000 00:00 0 
c004c00000-c005000000 rw-p 00000000 00:00 0 
c005000000-c005400000 rw-p 00000000 00:00 0 
c005400000-c008000000 ---p 00000000 00:00 0 
7fdee75a2000-7fdee76b7000 rw-p 00000000 00:00 0 
7fdee76b7000-7fdee76f8000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee76f8000-7fdee7739000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee7739000-7fdee777a000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee777a000-7fdee77bb000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee77bb000-7fdee77fc000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee77fc000-7fdee783d000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee783d000-7fdee787e000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee787e000-7fdee78bf000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee78bf000-7fdee7900000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee7900000-7fdee7941000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee7941000-7fdee7982000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee7982000-7fdee79c3000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee79c3000-7fdee7a03000 rw-p 00000000 00:00 0 
7fdee7a03000-7fdee7a05000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee7a05000-7fdee7a07000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee7a07000-7fdee7a09000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee7a09000-7fdee7a0b000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee7a0b000-7fdee7a0d000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee7a0d000-7fdee7a0f000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee7a0f000-7fdee7a11000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee7a11000-7fdee7a13000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee7a13000-7fdee7a15000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee7a15000-7fdee7a17000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee7a17000-7fdee7a19000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee7a19000-7fdee7a1b000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7fdee7a1b000-7fdeea400000 rw-p 00000000 00:00 0 
7fdeea400000-7fdeea600000 rw-p 00000000 00:00 0 
7fdeea600000-7fdeea73d000 rw-p 00000000 00:00 0 
7fdeea73d000-7fdefacb6000 ---p 00000000 00:00 0 
7fdefacb6000-7fdefacb7000 rw-p 00000000 00:00 0 
7fdefacb7000-7fdf0cb66000 ---p 00000000 00:00 0 
7fdf0cb66000-7fdf0cb67000 rw-p 00000000 00:00 0 
7fdf0cb67000-7fdf0ef3c000 ---p 00000000 00:00 0 
7fdf0ef3c000-7fdf0ef3d000 rw-p 00000000 00:00 0 
7fdf0ef3d000-7fdf0f3b6000 ---p 00000000 00:00 0 
7fdf0f3b6000-7fdf0f3b7000 rw-p 00000000 00:00 0 
7fdf0f3b7000-7fdf0f436000 ---p 00000000 00:00 0 
7fdf0f436000-7fdf0f496000 rw-p 00000000 00:00 0 
7ffe01334000-7ffe01355000 rw-p 00000000 00:00 0                          [stack]
7ffe013c0000-7ffe013c4000 r--p 00000000 00:00 0                          [vvar]
7ffe013c4000-7ffe013c6000 r-xp 00000000 00:00 0                          [vdso]
ffffffffff600000-ffffffffff601000 --xp 00000000 00:00 0                  [vsyscall]

```


#### ipam

```
<nil>
```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0xc0015ccaf0)({
 Events: (chan k8s.ServiceEvent) (cap=128) 0xc000f44b40,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=23) {
  (k8s.ServiceID) openebs/openebs-ndm-node-exporter-service: (*k8s.Service)(0xc000a58790)(frontends:[]/ports=[metrics]/selector=map[name:openebs-ndm-node-exporter]),
  (k8s.ServiceID) kube-system/cilium-envoy: (*k8s.Service)(0xc000a58bb0)(frontends:[]/ports=[envoy-metrics]/selector=map[k8s-app:cilium-envoy]),
  (k8s.ServiceID) streampai/backend: (*k8s.Service)(0xc000ca4000)(frontends:[10.101.253.206]/ports=[http]/selector=map[app:backend]),
  (k8s.ServiceID) streampai/coqui: (*k8s.Service)(0xc000a58dc0)(frontends:[10.107.249.151]/ports=[http]/selector=map[app:coqui]),
  (k8s.ServiceID) streampai/pgweb: (*k8s.Service)(0xc000a58fd0)(frontends:[10.102.204.154]/ports=[http]/selector=map[app:pgweb]),
  (k8s.ServiceID) streampai/redis: (*k8s.Service)(0xc000475a20)(frontends:[10.102.231.26]/ports=[http]/selector=map[app:redis]),
  (k8s.ServiceID) openebs/openebs-ndm-cluster-exporter-service: (*k8s.Service)(0xc000a58b00)(frontends:[]/ports=[metrics]/selector=map[name:openebs-ndm-cluster-exporter]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0xc000a58c60)(frontends:[10.100.194.198]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) streampai/livestreamdb: (*k8s.Service)(0xc0049e22c0)(frontends:[10.110.82.62]/ports=[]/selector=map[app:livestreamdb]),
  (k8s.ServiceID) streampai/postgres: (*k8s.Service)(0xc000475970)(frontends:[10.102.212.184]/ports=[]/selector=map[app:postgres]),
  (k8s.ServiceID) streampai/cilium-gateway-sgtw: (*k8s.Service)(0xc000475b80)(frontends:[10.106.139.3]/ports=[port-80]/selector=map[]),
  (k8s.ServiceID) ambassador/traffic-manager: (*k8s.Service)(0xc003f6e2c0)(frontends:[]/ports=[api grpc-trace]/selector=map[app:traffic-manager telepresence:manager]),
  (k8s.ServiceID) streampai/minio: (*k8s.Service)(0xc000a58f20)(frontends:[10.104.163.144]/ports=[main console]/selector=map[app:minio]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0xc000a58580)(frontends:[10.96.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0xc000a586e0)(frontends:[10.96.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) cert-manager/cert-manager: (*k8s.Service)(0xc000a58840)(frontends:[10.110.36.32]/ports=[tcp-prometheus-servicemonitor]/selector=map[app.kubernetes.io/component:controller app.kubernetes.io/instance:cert-manager app.kubernetes.io/name:cert-manager]),
  (k8s.ServiceID) cert-manager/cert-manager-webhook: (*k8s.Service)(0xc000a588f0)(frontends:[10.96.9.116]/ports=[https]/selector=map[app.kubernetes.io/component:webhook app.kubernetes.io/instance:cert-manager app.kubernetes.io/name:webhook]),
  (k8s.ServiceID) kube-system/hubble-ui: (*k8s.Service)(0xc000a589a0)(frontends:[10.101.180.15]/ports=[http]/selector=map[k8s-app:hubble-ui]),
  (k8s.ServiceID) streampai/frontend: (*k8s.Service)(0xc0049e2210)(frontends:[10.104.78.187]/ports=[http]/selector=map[app:frontend]),
  (k8s.ServiceID) kube-system/hubble-relay: (*k8s.Service)(0xc000a58630)(frontends:[10.100.226.243]/ports=[]/selector=map[k8s-app:hubble-relay]),
  (k8s.ServiceID) kube-system/metrics-server: (*k8s.Service)(0xc000a58a50)(frontends:[10.108.118.97]/ports=[https]/selector=map[k8s-app:metrics-server]),
  (k8s.ServiceID) streampai/kratos: (*k8s.Service)(0xc001e02420)(frontends:[10.98.191.110]/ports=[http]/selector=map[app:kratos]),
  (k8s.ServiceID) ambassador/agent-injector: (*k8s.Service)(0xc002ff4840)(frontends:[10.109.73.183]/ports=[https]/selector=map[app:traffic-manager telepresence:manager])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=19) {
  (k8s.ServiceID) streampai/coqui: (*k8s.EndpointSlices)(0xc001024000)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=11) "coqui-2f5w9": (*k8s.Endpoints)(0xc002578750)()
   }
  }),
  (k8s.ServiceID) streampai/kratos: (*k8s.EndpointSlices)(0xc000a83148)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=12) "kratos-4hv5x": (*k8s.Endpoints)(0xc002826680)(10.244.0.75:4433/TCP)
   }
  }),
  (k8s.ServiceID) streampai/livestreamdb: (*k8s.EndpointSlices)(0xc00073d988)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=18) "livestreamdb-g8rc5": (*k8s.Endpoints)(0xc000834270)(10.244.0.242:5432/TCP)
   }
  }),
  (k8s.ServiceID) streampai/pgweb: (*k8s.EndpointSlices)(0xc00073d998)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=11) "pgweb-bl8fd": (*k8s.Endpoints)(0xc004094270)()
   }
  }),
  (k8s.ServiceID) streampai/redis: (*k8s.EndpointSlices)(0xc000a83168)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=11) "redis-n588x": (*k8s.Endpoints)(0xc002ffe680)(10.244.0.202:6379/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0xc000aa4088)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-mzmb4": (*k8s.Endpoints)(0xc002f200d0)(172.17.0.2:4244/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-ui: (*k8s.EndpointSlices)(0xc000aa4098)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=15) "hubble-ui-crcpx": (*k8s.Endpoints)(0xc001713110)(10.244.0.9:8081/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0xc000aa40a0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-c55tr": (*k8s.Endpoints)(0xc0024eef70)(10.244.0.223:53/TCP,10.244.0.223:53/UDP,10.244.0.223:9153/TCP)
   }
  }),
  (k8s.ServiceID) streampai/postgres: (*k8s.EndpointSlices)(0xc000a83158)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "postgres-pwnqw": (*k8s.Endpoints)(0xc001ea28f0)(10.244.0.167:5432/TCP)
   }
  }),
  (k8s.ServiceID) ambassador/agent-injector: (*k8s.EndpointSlices)(0xc0005c7ca0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "agent-injector-6zrht": (*k8s.Endpoints)(0xc000a9aa90)(10.244.0.133:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/metrics-server: (*k8s.EndpointSlices)(0xc000aba010)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "metrics-server-4grsv": (*k8s.Endpoints)(0xc001570750)(10.244.0.228:10250/TCP)
   }
  }),
  (k8s.ServiceID) cert-manager/cert-manager: (*k8s.EndpointSlices)(0xc000aba028)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=18) "cert-manager-6b2kw": (*k8s.Endpoints)(0xc0017125b0)(10.244.0.135:9402/TCP)
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0xc000aba038)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0xc000a25a00)(172.17.0.2:6443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-relay: (*k8s.EndpointSlices)(0xc000aa4090)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=18) "hubble-relay-59tk9": (*k8s.Endpoints)(0xc002579c70)(10.244.0.23:4245/TCP)
   }
  }),
  (k8s.ServiceID) streampai/backend: (*k8s.EndpointSlices)(0xc0013eedd8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=13) "backend-plw5j": (*k8s.Endpoints)(0xc00169e410)(10.244.0.118:7000/TCP,10.244.0.180:7000/TCP)
   }
  }),
  (k8s.ServiceID) streampai/cilium-gateway-sgtw: (*k8s.EndpointSlices)(0xc000a836b8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=25) "cilium-gateway-sgtw-mmq5w": (*k8s.Endpoints)(0xc0008f7860)(192.192.192.192:9999/TCP)
   }
  }),
  (k8s.ServiceID) cert-manager/cert-manager-webhook: (*k8s.EndpointSlices)(0xc000aba030)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=26) "cert-manager-webhook-v9txm": (*k8s.Endpoints)(0xc000472410)(10.244.0.90:10250/TCP)
   }
  }),
  (k8s.ServiceID) streampai/frontend: (*k8s.EndpointSlices)(0xc000a83140)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "frontend-jglfl": (*k8s.Endpoints)(0xc001e5a270)(10.244.0.101:3000/TCP,10.244.0.12:3000/TCP,10.244.0.220:3000/TCP,10.244.0.8:3000/TCP)
   }
  }),
  (k8s.ServiceID) streampai/minio: (*k8s.EndpointSlices)(0xc0013eedf0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=11) "minio-hkggb": (*k8s.Endpoints)(0xc0017120d0)()
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 nodeAddressing: (*linux.linuxNodeAddressing)(0x5e20750)({
  ipv6: (linux.addressFamilyIPv6) {
  },
  ipv4: (linux.addressFamilyIPv4) {
  }
 }),
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption


