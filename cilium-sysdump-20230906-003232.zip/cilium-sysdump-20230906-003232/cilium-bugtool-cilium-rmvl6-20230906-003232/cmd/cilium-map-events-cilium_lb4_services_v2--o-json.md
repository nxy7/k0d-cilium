{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.118.97:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:16.804Z",
  "value": "0 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.36.32:9402",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:16.804Z",
  "value": "0 0 (2) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.9.116:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:16.804Z",
  "value": "0 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.1:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:16.804Z",
  "value": "1 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.1:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:16.804Z",
  "value": "0 1 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.194.198:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:16.804Z",
  "value": "0 0 (5) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.226.243:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:16.804Z",
  "value": "0 0 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.180.15:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:16.804Z",
  "value": "0 0 (7) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:53",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:16.804Z",
  "value": "0 0 (8) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:9153",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:16.804Z",
  "value": "0 0 (9) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.194.198:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:19.440Z",
  "value": "2 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.194.198:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:19.440Z",
  "value": "0 1 (5) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.118.97:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:30.170Z",
  "value": "0 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:53",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:32.172Z",
  "value": "0 0 (8) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:9153",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:32.172Z",
  "value": "0 0 (9) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:9153",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:33.175Z",
  "value": "3 0 (9) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:9153",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:33.175Z",
  "value": "0 1 (9) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:53",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:33.175Z",
  "value": "4 0 (8) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:53",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:33.175Z",
  "value": "0 1 (8) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.9.116:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:35.177Z",
  "value": "0 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.9.116:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:42.206Z",
  "value": "5 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.9.116:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:42.206Z",
  "value": "0 1 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.36.32:9402",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:43.190Z",
  "value": "6 0 (2) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.36.32:9402",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:43.190Z",
  "value": "0 1 (2) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.226.243:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:48.197Z",
  "value": "0 0 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.226.243:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:48.202Z",
  "value": "7 0 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.226.243:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:48.202Z",
  "value": "0 1 (6) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.118.97:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:52.199Z",
  "value": "8 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.118.97:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:29:52.199Z",
  "value": "0 1 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.180.15:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:30:01.220Z",
  "value": "9 0 (7) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.180.15:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:30:01.220Z",
  "value": "0 1 (7) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.253.206:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:36.615Z",
  "value": "0 0 (10) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.249.151:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:36.624Z",
  "value": "0 0 (11) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.78.187:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:36.633Z",
  "value": "0 0 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.191.110:4433",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:36.641Z",
  "value": "0 0 (13) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.82.62:5432",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:36.651Z",
  "value": "0 0 (14) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.163.144:9000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:36.660Z",
  "value": "0 0 (15) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.163.144:9001",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:36.660Z",
  "value": "0 0 (16) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.204.154:8081",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:36.686Z",
  "value": "0 0 (17) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.212.184:5432",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:36.693Z",
  "value": "0 0 (18) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.231.26:6379",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:36.701Z",
  "value": "0 0 (19) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.139.3:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:36.971Z",
  "value": "0 0 (20) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.39.148:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:36.971Z",
  "value": "0 0 (21) [0x60 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.0.2:31956",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:36.971Z",
  "value": "0 0 (22) [0x42 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:31956",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:36.971Z",
  "value": "0 0 (23) [0x2 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.39.148:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:37.103Z",
  "value": "5430 0 (21) [0x60 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.0.2:31956",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:37.103Z",
  "value": "5430 0 (22) [0x42 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:31956",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:37.103Z",
  "value": "5430 0 (23) [0x2 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.139.3:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:37.103Z",
  "value": "5430 0 (20) [0x0 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.0.2:31956",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:37.112Z",
  "value": "5430 0 (22) [0x42 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.39.148:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:37.112Z",
  "value": "5430 0 (21) [0x60 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:31956",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:37.112Z",
  "value": "5430 0 (23) [0x2 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.139.3:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:37.112Z",
  "value": "5430 0 (20) [0x0 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.253.206:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:37.112Z",
  "value": "0 0 (10) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.78.187:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:37.112Z",
  "value": "0 0 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.191.110:4433",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:37.112Z",
  "value": "0 0 (13) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.163.144:9001",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:37.112Z",
  "value": "0 0 (16) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.163.144:9000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:37.112Z",
  "value": "0 0 (15) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.204.154:8081",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:37.112Z",
  "value": "0 0 (17) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.73.183:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:38.916Z",
  "value": "0 0 (24) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.78.187:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:39.354Z",
  "value": "10 0 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.78.187:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:39.354Z",
  "value": "0 1 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.78.187:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:39.358Z",
  "value": "10 0 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.78.187:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:39.358Z",
  "value": "11 0 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.78.187:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:39.358Z",
  "value": "0 2 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.253.206:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:39.362Z",
  "value": "12 0 (10) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.253.206:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:39.362Z",
  "value": "0 1 (10) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.78.187:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:39.368Z",
  "value": "10 0 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.78.187:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:39.368Z",
  "value": "11 0 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.78.187:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:39.368Z",
  "value": "13 0 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.78.187:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:39.368Z",
  "value": "0 3 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.78.187:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:39.372Z",
  "value": "10 0 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.78.187:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:39.372Z",
  "value": "11 0 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.78.187:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:39.372Z",
  "value": "13 0 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.78.187:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:39.372Z",
  "value": "14 0 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.78.187:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:39.372Z",
  "value": "0 4 (12) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.253.206:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:39.377Z",
  "value": "12 0 (10) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.253.206:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:39.377Z",
  "value": "15 0 (10) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.253.206:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:39.377Z",
  "value": "0 2 (10) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.191.110:4433",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:43.367Z",
  "value": "16 0 (13) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.191.110:4433",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:31:43.367Z",
  "value": "0 1 (13) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.204.154:8081",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:32:03.410Z",
  "value": "0 0 (17) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.231.26:6379",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:32:07.415Z",
  "value": "17 0 (19) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.231.26:6379",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:32:07.415Z",
  "value": "0 1 (19) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.73.183:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:32:11.424Z",
  "value": "18 0 (24) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.73.183:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:32:11.424Z",
  "value": "0 1 (24) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.212.184:5432",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:32:19.437Z",
  "value": "19 0 (18) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.212.184:5432",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:32:19.437Z",
  "value": "0 1 (18) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.82.62:5432",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:32:27.450Z",
  "value": "20 0 (14) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.82.62:5432",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T22:32:27.450Z",
  "value": "0 1 (14) [0x0 0x0]"
}

