markdown output at /tmp/cilium-bugtool-20230905-223234.63+0000-UTC-2040383974/cmd/cilium-debuginfo-20230905-223234.748+0000-UTC.md
json output at /tmp/cilium-bugtool-20230905-223234.63+0000-UTC-2040383974/cmd/cilium-debuginfo-20230905-223234.748+0000-UTC.json
