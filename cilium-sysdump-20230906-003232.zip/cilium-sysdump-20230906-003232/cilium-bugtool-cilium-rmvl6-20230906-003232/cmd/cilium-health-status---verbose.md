Probe time:   2023-09-05T22:32:20Z
Nodes:
  k0s (localhost):
    Host connectivity to 172.17.0.2:
      ICMP to stack:   OK, RTT=73.404µs
      HTTP to agent:   OK, RTT=141.94µs
    Endpoint connectivity to 10.244.0.132:
      ICMP to stack:   OK, RTT=89.613µs
      HTTP to agent:   OK, RTT=151.059µs
