qdisc noqueue 0: dev lo root refcnt 2 
qdisc noqueue 0: dev eth0 root refcnt 2 
qdisc clsact ffff: dev eth0 parent ffff:fff1 
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
qdisc noqueue 0: dev lxc_health root refcnt 2 
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
qdisc noqueue 0: dev lxcd9fdefc20bbb root refcnt 2 
qdisc clsact ffff: dev lxcd9fdefc20bbb parent ffff:fff1 
qdisc noqueue 0: dev lxc119ad3dfee62 root refcnt 2 
qdisc clsact ffff: dev lxc119ad3dfee62 parent ffff:fff1 
qdisc noqueue 0: dev lxc4848deb1985a root refcnt 2 
qdisc clsact ffff: dev lxc4848deb1985a parent ffff:fff1 
qdisc noqueue 0: dev lxc8a558cabb5a1 root refcnt 2 
qdisc clsact ffff: dev lxc8a558cabb5a1 parent ffff:fff1 
qdisc noqueue 0: dev lxccedcb6c151a5 root refcnt 2 
qdisc clsact ffff: dev lxccedcb6c151a5 parent ffff:fff1 
qdisc noqueue 0: dev lxc346fa36d29b0 root refcnt 2 
qdisc clsact ffff: dev lxc346fa36d29b0 parent ffff:fff1 
qdisc noqueue 0: dev lxcfe16b37f78d3 root refcnt 2 
qdisc clsact ffff: dev lxcfe16b37f78d3 parent ffff:fff1 
qdisc noqueue 0: dev lxc37782ef37adb root refcnt 2 
qdisc clsact ffff: dev lxc37782ef37adb parent ffff:fff1 
qdisc noqueue 0: dev lxc7bc95390c700 root refcnt 2 
qdisc clsact ffff: dev lxc7bc95390c700 parent ffff:fff1 
qdisc noqueue 0: dev lxcf3d11662b2bf root refcnt 2 
qdisc clsact ffff: dev lxcf3d11662b2bf parent ffff:fff1 
qdisc noqueue 0: dev lxca6c1d0c986ff root refcnt 2 
qdisc clsact ffff: dev lxca6c1d0c986ff parent ffff:fff1 
qdisc noqueue 0: dev lxcf7c2ea09d41d root refcnt 2 
qdisc clsact ffff: dev lxcf7c2ea09d41d parent ffff:fff1 
qdisc noqueue 0: dev lxca94861d8ed77 root refcnt 2 
qdisc clsact ffff: dev lxca94861d8ed77 parent ffff:fff1 
qdisc noqueue 0: dev lxcc21955409817 root refcnt 2 
qdisc clsact ffff: dev lxcc21955409817 parent ffff:fff1 
qdisc noqueue 0: dev lxcf9603e308e74 root refcnt 2 
qdisc clsact ffff: dev lxcf9603e308e74 parent ffff:fff1 
qdisc noqueue 0: dev lxc4d1095406f91 root refcnt 2 
qdisc clsact ffff: dev lxc4d1095406f91 parent ffff:fff1 
qdisc noqueue 0: dev lxc983f3c9d1402 root refcnt 2 
qdisc clsact ffff: dev lxc983f3c9d1402 parent ffff:fff1 
qdisc noqueue 0: dev lxc0ef1ae825717 root refcnt 2 
qdisc clsact ffff: dev lxc0ef1ae825717 parent ffff:fff1 
qdisc noqueue 0: dev lxca9dd546d2ddb root refcnt 2 
qdisc clsact ffff: dev lxca9dd546d2ddb parent ffff:fff1 
qdisc noqueue 0: dev lxc6ad0c51d5075 root refcnt 2 
qdisc clsact ffff: dev lxc6ad0c51d5075 parent ffff:fff1 
qdisc noqueue 0: dev lxcc5cc5cdac255 root refcnt 2 
qdisc clsact ffff: dev lxcc5cc5cdac255 parent ffff:fff1 
qdisc noqueue 0: dev lxc9ad5d7a32906 root refcnt 2 
qdisc clsact ffff: dev lxc9ad5d7a32906 parent ffff:fff1 
qdisc noqueue 0: dev lxc81cfe30fa5c2 root refcnt 2 
qdisc clsact ffff: dev lxc81cfe30fa5c2 parent ffff:fff1 
qdisc noqueue 0: dev lxc59e096dd7e22 root refcnt 2 
qdisc clsact ffff: dev lxc59e096dd7e22 parent ffff:fff1 
qdisc noqueue 0: dev lxc12be36577ae9 root refcnt 2 
qdisc clsact ffff: dev lxc12be36577ae9 parent ffff:fff1 
qdisc noqueue 0: dev lxc8b90fe1d5b0f root refcnt 2 
qdisc clsact ffff: dev lxc8b90fe1d5b0f parent ffff:fff1 
qdisc noqueue 0: dev lxc655b8d0b3ee4 root refcnt 2 
qdisc clsact ffff: dev lxc655b8d0b3ee4 parent ffff:fff1 
qdisc noqueue 0: dev lxcba34e313be1c root refcnt 2 
qdisc clsact ffff: dev lxcba34e313be1c parent ffff:fff1 
