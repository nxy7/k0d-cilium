1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
2: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 22:a0:a3:d3:1e:0c brd ff:ff:ff:ff:ff:ff
3: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 12:5e:03:5e:34:97 brd ff:ff:ff:ff:ff:ff
    inet 10.244.0.59/32 scope global cilium_host
       valid_lft forever preferred_lft forever
4: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 22:3a:34:52:dd:f0 brd ff:ff:ff:ff:ff:ff
6: lxc_health@if5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:44:f8:9e:32:a0 brd ff:ff:ff:ff:ff:ff link-netns cilium-health
7: eth0@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 02:42:ac:11:00:02 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet 172.17.0.2/16 brd 172.17.255.255 scope global eth0
       valid_lft forever preferred_lft forever
9: lxcd9fdefc20bbb@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether b2:17:91:38:41:61 brd ff:ff:ff:ff:ff:ff link-netnsid 2
13: lxc119ad3dfee62@if12: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:5c:19:11:58:5f brd ff:ff:ff:ff:ff:ff link-netnsid 5
15: lxc4848deb1985a@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 62:dd:3a:27:65:b4 brd ff:ff:ff:ff:ff:ff link-netnsid 6
17: lxc8a558cabb5a1@if16: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether fe:a9:c4:07:57:e2 brd ff:ff:ff:ff:ff:ff link-netnsid 7
19: lxccedcb6c151a5@if18: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether ee:d1:ba:89:c0:1d brd ff:ff:ff:ff:ff:ff link-netnsid 4
21: lxc346fa36d29b0@if20: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 86:ab:c1:4a:36:e4 brd ff:ff:ff:ff:ff:ff link-netnsid 8
23: lxcfe16b37f78d3@if22: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether a2:ea:d1:a6:14:9a brd ff:ff:ff:ff:ff:ff link-netnsid 11
25: lxc37782ef37adb@if24: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether ea:64:6a:77:dd:e8 brd ff:ff:ff:ff:ff:ff link-netnsid 10
27: lxc7bc95390c700@if26: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:d3:c9:fa:4b:77 brd ff:ff:ff:ff:ff:ff link-netnsid 13
29: lxcf3d11662b2bf@if28: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 16:36:68:00:c9:7a brd ff:ff:ff:ff:ff:ff link-netnsid 9
31: lxca6c1d0c986ff@if30: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether f6:97:a7:99:8d:68 brd ff:ff:ff:ff:ff:ff link-netnsid 12
33: lxcf7c2ea09d41d@if32: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether a2:e5:9b:6f:1a:c1 brd ff:ff:ff:ff:ff:ff link-netnsid 3
35: lxca94861d8ed77@if34: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 22:b8:46:8f:47:d8 brd ff:ff:ff:ff:ff:ff link-netnsid 14
37: lxcc21955409817@if36: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 22:9f:12:96:40:88 brd ff:ff:ff:ff:ff:ff link-netnsid 15
39: lxcf9603e308e74@if38: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 02:46:51:46:a9:dd brd ff:ff:ff:ff:ff:ff link-netnsid 16
41: lxc4d1095406f91@if40: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether fa:58:b1:0e:2b:19 brd ff:ff:ff:ff:ff:ff link-netnsid 17
43: lxc983f3c9d1402@if42: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether f2:cb:09:1d:6c:0f brd ff:ff:ff:ff:ff:ff link-netnsid 18
45: lxc0ef1ae825717@if44: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 12:c0:ff:cd:b8:c2 brd ff:ff:ff:ff:ff:ff link-netnsid 19
49: lxca9dd546d2ddb@if48: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 56:7d:67:49:1a:95 brd ff:ff:ff:ff:ff:ff link-netnsid 20
55: lxc6ad0c51d5075@if54: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:73:1e:76:c5:8f brd ff:ff:ff:ff:ff:ff link-netnsid 22
59: lxcc5cc5cdac255@if58: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:5a:0f:ec:8d:ee brd ff:ff:ff:ff:ff:ff link-netnsid 25
63: lxc9ad5d7a32906@if62: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:5c:e0:e1:7c:4f brd ff:ff:ff:ff:ff:ff link-netnsid 28
65: lxc81cfe30fa5c2@if64: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:ca:91:1e:97:a8 brd ff:ff:ff:ff:ff:ff link-netnsid 29
67: lxc59e096dd7e22@if66: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 22:40:09:0d:1f:d1 brd ff:ff:ff:ff:ff:ff link-netnsid 30
69: lxc12be36577ae9@if68: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:9f:a5:91:f9:99 brd ff:ff:ff:ff:ff:ff link-netnsid 21
71: lxc8b90fe1d5b0f@if70: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 16:71:e1:94:80:51 brd ff:ff:ff:ff:ff:ff link-netnsid 27
73: lxc655b8d0b3ee4@if72: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:1f:19:56:b9:5d brd ff:ff:ff:ff:ff:ff link-netnsid 26
75: lxcba34e313be1c@if74: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:52:c6:1a:ac:89 brd ff:ff:ff:ff:ff:ff link-netnsid 31
