filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxccedcb6c151a5 direct-action not_in_hw id 630 tag e23368cf52066be4 jited 
