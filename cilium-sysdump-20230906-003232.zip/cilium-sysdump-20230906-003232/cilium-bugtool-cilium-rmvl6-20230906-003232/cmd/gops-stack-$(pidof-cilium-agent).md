goroutine 84 [running]:
runtime/pprof.writeGoroutineStacks({0x3b88080, 0xc000aa44f8})
	/usr/local/go/src/runtime/pprof/pprof.go:703 +0x70
runtime/pprof.writeGoroutine({0x3b88080?, 0xc000aa44f8?}, 0xc002d5e000?)
	/usr/local/go/src/runtime/pprof/pprof.go:692 +0x2b
runtime/pprof.(*Profile).WriteTo(0x360ff0b?, {0x3b88080?, 0xc000aa44f8?}, 0xc?)
	/usr/local/go/src/runtime/pprof/pprof.go:329 +0x14b
github.com/google/gops/agent.handle({0x7fdee79ceb30?, 0xc000aa44f8}, {0xc001018000?, 0x1?, 0x1?})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:200 +0xe5
github.com/google/gops/agent.listen({0x3bb3640, 0xc001a653b0})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:144 +0x1bc
created by github.com/google/gops/agent.Listen
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:122 +0x390

goroutine 1 [select, 3 minutes]:
github.com/cilium/cilium/pkg/hive.(*Hive).waitForSignalOrShutdown(0xc000db12c0)
	/go/src/github.com/cilium/cilium/pkg/hive/hive.go:217 +0x17f
github.com/cilium/cilium/pkg/hive.(*Hive).Run(0xc000db12c0)
	/go/src/github.com/cilium/cilium/pkg/hive/hive.go:198 +0x147
github.com/cilium/cilium/daemon/cmd.runApp(0x588ea40?, {0x35fe3fd?, 0x1?, 0x1?})
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:67 +0xe5
github.com/spf13/cobra.(*Command).execute(0x588ea40, {0xc000072050, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:944 +0x847
github.com/spf13/cobra.(*Command).ExecuteC(0x588ea40)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1068 +0x3bd
github.com/spf13/cobra.(*Command).Execute(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:992
github.com/cilium/cilium/daemon/cmd.Execute()
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:78 +0x65
main.main()
	/go/src/github.com/cilium/cilium/daemon/main.go:9 +0x17

goroutine 67 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc000ca7440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:314 +0xa7
created by k8s.io/client-go/util/workqueue.newQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1bc

goroutine 68 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000ca75c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 526 [select, 3 minutes]:
github.com/cilium/cilium/pkg/datapath/loader.(*objectCache).watchTemplatesDirectory(0xc000cf25f0, {0x3bb56d8, 0xc000cf3720})
	/go/src/github.com/cilium/cilium/pkg/datapath/loader/cache.go:342 +0x225
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00124b440, {0xc000b1dbc0, 0x0, 0x3805780, 0x0, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000cf3720}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 75 [select]:
io.(*pipe).read(0xc000b1f200, {0xc001882169, 0xfe97, 0x3b99110?})
	/usr/local/go/src/io/pipe.go:57 +0xb1
io.(*PipeReader).Read(0x0?, {0xc001882169?, 0xc00175ab10?, 0xc000da1c20?})
	/usr/local/go/src/io/pipe.go:136 +0x25
bufio.(*Scanner).Scan(0xc00459ef28)
	/usr/local/go/src/bufio/scan.go:214 +0x876
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0?, 0xc001024680, 0xc000da8940)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x11f
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x3d1

goroutine 76 [select, 3 minutes]:
io.(*pipe).read(0xc000b1f260, {0xc00041c21c, 0xfde4, 0x3b99110?})
	/usr/local/go/src/io/pipe.go:57 +0xb1
io.(*PipeReader).Read(0x0?, {0xc00041c21c?, 0xc00175ab10?, 0xc000da1c20?})
	/usr/local/go/src/io/pipe.go:136 +0x25
bufio.(*Scanner).Scan(0xc0009e1f28)
	/usr/local/go/src/bufio/scan.go:214 +0x876
github.com/sirupsen/logrus.(*Entry).writerScanner(0xc00013ffd0?, 0xc001024690, 0xc000da8960)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x11f
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x3d1

goroutine 77 [select, 3 minutes]:
io.(*pipe).read(0xc000b1f2c0, {0xc0007ba000, 0x10000, 0x423325?})
	/usr/local/go/src/io/pipe.go:57 +0xb1
io.(*PipeReader).Read(0x7fdee7b5e488?, {0xc0007ba000?, 0x40e05d?, 0x0?})
	/usr/local/go/src/io/pipe.go:136 +0x25
bufio.(*Scanner).Scan(0xc00042ff28)
	/usr/local/go/src/bufio/scan.go:214 +0x876
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0?, 0xc0010246a0, 0xc000da8980)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x11f
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x3d1

goroutine 78 [select, 3 minutes]:
io.(*pipe).read(0xc000b1f320, {0xc001892000, 0x10000, 0x423325?})
	/usr/local/go/src/io/pipe.go:57 +0xb1
io.(*PipeReader).Read(0x59193d0?, {0xc001892000?, 0x0?, 0x100000000000000?})
	/usr/local/go/src/io/pipe.go:136 +0x25
bufio.(*Scanner).Scan(0xc000171f28)
	/usr/local/go/src/bufio/scan.go:214 +0x876
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0?, 0xc0010246b0, 0xc000da89a0)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x11f
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x3d1

goroutine 372 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001ea0000, 0xc001afc360, 0xc00046a3c0, 0xc0008aafa0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 30 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction.func1()
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:19 +0x67
created by github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:17 +0x9c

goroutine 188 [chan receive]:
github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch.func1()
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:147 +0x77
created by github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:139 +0x72

goroutine 189 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0011d0e60)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 190 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0011d0f00)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 85 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7fdee7ecbe18, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc000a34000?, 0xc000173d00?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc000a34000)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc000a34000)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*TCPListener).accept(0xc000a32048)
	/usr/local/go/src/net/tcpsock_posix.go:148 +0x25
net.(*TCPListener).Accept(0xc000a32048)
	/usr/local/go/src/net/tcpsock.go:297 +0x3d
net/http.(*Server).Serve(0xc0011ae000, {0x3bb3640, 0xc000a32048})
	/usr/local/go/src/net/http/server.go:3059 +0x385
net/http.(*Server).ListenAndServe(0xc0011ae000)
	/usr/local/go/src/net/http/server.go:2988 +0x7d
github.com/cilium/cilium/pkg/metrics.NewRegistry.func1.1()
	/go/src/github.com/cilium/cilium/pkg/metrics/registry.go:89 +0xb1
created by github.com/cilium/cilium/pkg/metrics.NewRegistry.func1
	/go/src/github.com/cilium/cilium/pkg/metrics/registry.go:87 +0xca

goroutine 220 [select]:
github.com/cilium/cilium/pkg/cgroups/manager.(*CgroupManager).processPodEvents(0xc00025fbd0)
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:243 +0x95
created by github.com/cilium/cilium/pkg/cgroups/manager.initManager
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:213 +0x1d6

goroutine 219 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000abd9a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 195 [IO wait]:
internal/poll.runtime_pollWait(0x7fdee7ecbd28, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001ab0900?, 0xc00165c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001ab0900, {0xc00165c000, 0x8000, 0x8000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc001ab0900, {0xc00165c000?, 0x7ffb?, 0xc001028180?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000722018, {0xc00165c000?, 0xc00165c000?, 0x5?})
	/usr/local/go/src/net/net.go:183 +0x45
crypto/tls.(*atLeastReader).Read(0xc0047d64b0, {0xc00165c000?, 0xc0047d64b0?, 0x0?})
	/usr/local/go/src/crypto/tls/conn.go:788 +0x3d
bytes.(*Buffer).ReadFrom(0xc000a36290, {0x3b720a0, 0xc0047d64b0})
	/usr/local/go/src/bytes/buffer.go:202 +0x98
crypto/tls.(*Conn).readFromUntil(0xc000a36000, {0x7fdee7a5b840?, 0xc000a32060}, 0x8000?)
	/usr/local/go/src/crypto/tls/conn.go:810 +0xe5
crypto/tls.(*Conn).readRecordOrCCS(0xc000a36000, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:617 +0x116
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:583
crypto/tls.(*Conn).Read(0xc000a36000, {0xc000a5b000, 0x1000, 0xc000dc87d0?})
	/usr/local/go/src/crypto/tls/conn.go:1316 +0x16f
bufio.(*Reader).Read(0xc000815d40, {0xc000a48200, 0x9, 0xc00080fd38?})
	/usr/local/go/src/bufio/bufio.go:237 +0x1bb
io.ReadAtLeast({0x3b71ea0, 0xc000815d40}, {0xc000a48200, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
golang.org/x/net/http2.readFrameHeader({0xc000a48200?, 0x9?, 0xc000000000?}, {0x3b71ea0?, 0xc000815d40?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x6e
golang.org/x/net/http2.(*Framer).ReadFrame(0xc000a481c0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x95
golang.org/x/net/http2.(*clientConnReadLoop).run(0xc00080ff98)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2251 +0x12e
golang.org/x/net/http2.(*ClientConn).readLoop(0xc000bc7080)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2146 +0x6f
created by golang.org/x/net/http2.(*Transport).newClientConn
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:818 +0xc1f

goroutine 88 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001ac7b00, {0xc001006b80, 0x0, 0x3805780, 0x6fc23ac00, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00025e8c0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 721 [select, 3 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync.func1(0xc000a444e0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:871 +0x276
created by github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:863 +0x65

goroutine 387 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 453 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001e02868, 0x77)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000b23860?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001e02840, 0xc001734900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0007fe3c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc001734990}, 0x1, 0xc001ba6000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0007fe438?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0007fe3c0, 0xc001ba6000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 1114 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc000b20cd0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002868900, {0xc001118ef0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc000b20cd0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1112 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000abd4a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 94 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001ade0d8, 0xc)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000ef5a00?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001ade0b0, 0xc001adcdb0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000abd720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc001adce40}, 0x1, 0xc000a3a3c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000abd798?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000abd720, 0xc000a3a3c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 244 [chan receive]:
github.com/cilium/cilium/pkg/bgpv1/manager.(*diffStore[...]).run(0x3bca6c0)
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/diffstore.go:105 +0x185
created by github.com/cilium/cilium/pkg/bgpv1/manager.(*diffStore[...]).Start
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/diffstore.go:85 +0x12a

goroutine 96 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 209 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc001abfd40}, {0x7fdee7ab0f60, 0xc001ade0b0}, {0x3be8e60?, 0x35bf660}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0015c41c0, {0x0?, 0x0?}, 0xc000a3a3c0, 0xc001006e60?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0015c41c0, 0xc000a3a3c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001a74d80?, {0x3b878e0, 0xc00025ec80}, 0x1, 0xc000a3a3c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0015c41c0, 0xc000a3a3c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 212 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0015c41c0, 0xc000a3a3c0, 0xc001ab9da0, 0xc000144fa0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 213 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000212180, 0xc0001e6100)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0x7250616d65686353?, 0x100b4ff0173706f?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 214 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0002121c8, 0xf)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc001436d68?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc0002121b0, {0xc0014ef65c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc0014ef65c?, 0xc001436d08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7fdee7aafda0, 0xc000212180}, {0xc0014ef65c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc001a65c68, {0xc0028ba000, 0x2000, 0x2500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc00025ed70, 0xc0045b2000?, {0x3b9d990, 0xc003b77040})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001007320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001abfd40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 44 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0004740d8, 0x23)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0006f0e80?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0004740b0, 0xc000458990)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0004660a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc00143a240}, 0x1, 0xc00046a360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000466118?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0004660a0, 0xc00046a360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 39 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000510048, 0xe)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc00044dd68?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000510030, {0xc003a439e0, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0xc003a439e0?}, {0xc003a439e0?, 0xc00044dd08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7fdee7aafda0, 0xc000510000}, {0xc003a439e0, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc000452288, {0xc00033ac00, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000264050, 0xc001369ae0?, {0x3b9d990, 0xc002468480})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0010c2020)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00045a840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 233 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001456000, 0xc00046a360, 0xc000a3bc80, 0xc0006b9ec0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 192 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc00045af80}, {0x7fdee7ab0f60, 0xc0004740b0}, {0x3be8e60?, 0x35c0560}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001456000, {0x0?, 0x0?}, 0xc00046a360, 0xc001030080?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001456000, 0xc00046a360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00143e080?, {0x3b878e0, 0xc000246140}, 0x1, 0xc00046a360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001456000, 0xc00046a360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 41 [chan receive]:
github.com/cilium/cilium/pkg/bgpv1/manager.(*diffStore[...]).run(0x3bca720)
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/diffstore.go:105 +0x185
created by github.com/cilium/cilium/pkg/bgpv1/manager.(*diffStore[...]).Start
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/diffstore.go:85 +0x12a

goroutine 231 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000a38c10, 0x1a)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0006b9da0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 206 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000a58238, 0xe)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000ed5140?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000a58210, 0xc001b3e000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0018f8640)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc001b3e090}, 0x1, 0xc000a3ae40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0018f86b8?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0018f8640, 0xc000a3ae40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 230 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0006b9ec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 208 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 225 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc00045a840}, {0x7fdee7ab0f60, 0xc000a58210}, {0x3be8e60?, 0x35c01a0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc000a482a0, {0x0?, 0x0?}, 0xc000a3ae40, 0xc001028580?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc000a482a0, 0xc000a3ae40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001b3c040?, {0x3b878e0, 0xc000385680}, 0x1, 0xc000a3ae40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc000a482a0, 0xc000a3ae40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 228 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc000a482a0, 0xc000a3ae40, 0xc000a3b5c0, 0xc001b2afa0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 191 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 229 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000510000, 0xc00040b400)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0x73694c207b207463?, 0x697274735d5b2074?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 232 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 234 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000510180, 0xc00040b800)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0x73694c207b207463?, 0x697274735d5b2074?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 46 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0005101c8, 0x25)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc00016cd68?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc0005101b0, {0xc002f5572c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc002f5572c?, 0xc00016cd08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7fdee7aafda0, 0xc000510180}, {0xc002f5572c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc000452600, {0xc00304e000, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000264410, 0xc00430fc00?, {0x3b9d990, 0xc0044ac180})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0010c20c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00045af80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 47 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0010944e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 48 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00045b010, 0x45)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0010943c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 257 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 748 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7fdee7a5f0d0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001fc2480?, 0xc002a0fed0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001fc2480, {0xc002a0fed0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:31
os.(*File).Read(0xc00073c078, {0xc002a0fed0?, 0x0?, 0x0?})
	/usr/local/go/src/os/file.go:118 +0x5e
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc0006da7d0)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:356 +0xdf
created by github.com/fsnotify/fsnotify.NewWatcher
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:150 +0x1b0

goroutine 218 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc001ddc000?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 251 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00145d8c0, {0xc0010326a0, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000246320}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 252 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 253 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 254 [chan receive, 3 minutes]:
github.com/cilium/workerpool.(*WorkerPool).run(0xc000246370, {0x3bb56d8?, 0xc000246460})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:173 +0x65
created by github.com/cilium/workerpool.NewWithContext
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:68 +0x14e

goroutine 255 [select]:
github.com/cilium/cilium/pkg/node/manager.(*manager).backgroundSync(0xc001176f80, {0x3bb56d8, 0xc000246460})
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:301 +0x2a5
github.com/cilium/workerpool.(*WorkerPool).run.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:181 +0x82
created by github.com/cilium/workerpool.(*WorkerPool).run
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:178 +0x4e

goroutine 256 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7fdee7ecbc38, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc00145a3c0?, 0xc001e8fed0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00145a3c0, {0xc001e8fed0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:31
os.(*File).Read(0xc000a82020, {0xc001e8fed0?, 0x3b64c00?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x5e
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc000246500)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:356 +0xdf
created by github.com/fsnotify/fsnotify.NewWatcher
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:150 +0x1b0

goroutine 273 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001e1a900, {0xc0010328b0, 0x0, 0x3805780, 0x0, 0x0, 0x2540be400, 0x0, {0x3bb56d8, 0xc0002465a0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 274 [select, 3 minutes]:
github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).watchForDirectoryChanges(0xc000f8a540)
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:233 +0x117
created by github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).Start
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:207 +0x3be

goroutine 275 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7fdee7ecbb48, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001454200?, 0x0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001454200)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc001454200)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*UnixListener).accept(0x407565?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x1c
net.(*UnixListener).Accept(0xc00143b1d0)
	/usr/local/go/src/net/unixsock.go:260 +0x3d
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2(0xc001030320, {0x3bb56d8?, 0xc000635b30}, 0x0?)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:83 +0xef
created by github.com/cilium/cilium/pkg/monitor/agent.ServeMonitorAPI
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:69 +0x19f

goroutine 334 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0008330e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 277 [select]:
github.com/cilium/cilium/pkg/l2announcer.(*L2Announcer).run(0xc001a9f8c0, {0x3bb5780, 0xc00143b470})
	/go/src/github.com/cilium/cilium/pkg/l2announcer/l2announcer.go:188 +0x4bf
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc0000ce050, {0x3bb5780, 0xc00143b470}, 0x0?, {{{0xc000fc44e0, 0x1, 0x1}}, {0x3be6410, 0xc0015ccd20}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:267 +0x530
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 278 [select]:
github.com/cilium/cilium/pkg/hive/job.(*jobTimer).start(0xc0000ce0f0, {0x3bb5780, 0xc00143b4d0}, 0x0?, {{{0xc000fc44e0, 0x1, 0x1}}, {0x3be6410, 0xc0015ccd20}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:384 +0x3c5
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 259 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2.func1()
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:78 +0x32
created by github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:77 +0xb4

goroutine 374 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0009be1c8, 0x4)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc002bce2d0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc0009be1b0, {0xc001f62c01, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc001f62c01?, 0x2?, 0x3613591?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc0001f4640)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0001f4640)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc0001f4640, {0x30221e0, 0xc0017e55a8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0008ae1b0, {0xc000aeb800, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0006daa00, 0xc003a74380?, {0x3b9d990, 0xc003a68d40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001030d20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00143cbc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 286 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001ea43d0, 0x1a)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc001095ec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 291 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc0007da0d8, 0x1)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc001030220?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0007da0b0, 0xc0007d41e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0007fe000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc0007d4270}, 0x1, 0xc001afc360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0007fe078?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0007fe000, 0xc001afc360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 376 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 293 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 294 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc00143cbc0}, {0x7fdee7ab0f60, 0xc0007da0b0}, {0x3be8e60?, 0x358e620}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001ea0000, {0x0?, 0x0?}, 0xc001afc360, 0xc001030680?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001ea0000, 0xc001afc360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc000841ec8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0007d8080?, {0x3b878e0, 0xc000408370}, 0x1, 0xc001afc360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001ea0000, 0xc001afc360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 530 [select, 3 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc0010c8840}, {0x7fdee7ab0f60, 0xc00067ba20}, {0x3be8e60?, 0x359a3a0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc000a48540, {0x0?, 0x0?}, 0xc001afc2a0, 0xc00111cce0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc000a48540, 0xc001afc2a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0007d8400?, {0x3b878e0, 0xc000376190}, 0x1, 0xc001afc2a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc000a48540, 0xc001afc2a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 279 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7fdee7ecba58, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001454380?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001454380)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc001454380)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*UnixListener).accept(0x444640?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x1c
net.(*UnixListener).Accept(0xc00143b5f0)
	/usr/local/go/src/net/unixsock.go:260 +0x3d
google.golang.org/grpc.(*Server).Serve(0xc001e1c000, {0x3bb3670?, 0xc00143b5f0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:821 +0x475
github.com/cilium/cilium/pkg/envoy.startXDSGRPCServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:56 +0xb1
created by github.com/cilium/cilium/pkg/envoy.startXDSGRPCServer
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:54 +0x198

goroutine 280 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7fdee7ecb968, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001454500?, 0x47b945?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001454500)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc001454500)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*UnixListener).accept(0x444640?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x1c
net.(*UnixListener).AcceptUnix(0xc001e1e2a0)
	/usr/local/go/src/net/unixsock.go:247 +0x3d
github.com/cilium/cilium/pkg/envoy.StartAccessLogServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:69 +0x59
created by github.com/cilium/cilium/pkg/envoy.StartAccessLogServer
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:65 +0x514

goroutine 281 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/envoy.StartAccessLogServer.func2()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:87 +0x35
created by github.com/cilium/cilium/pkg/envoy.StartAccessLogServer
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:86 +0x590

goroutine 3193 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0001ae000, {0xc00088cee8, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc003733e00}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 221 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001f02a20, {0x3805ba0, 0x0, 0x3805780, 0x12a05f200, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0006da460}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 222 [select]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).k8sServiceHandler(0xc001847340)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:677 +0xfd
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).RunK8sServiceHandler
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:690 +0x56

goroutine 223 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001f039e0, {0xc001db7940, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0006da730}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 385 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000833260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 283 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc000a58028, 0x3)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0002d49e0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000a58000, 0xc001bac0f0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0018f8000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc0008ae270}, 0x1, 0xc000a3bf80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0018f8078?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0018f8000, 0xc000a3bf80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 335 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00081b150, 0x1b)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc000832fc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 307 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7fdee7ecb698, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001de0a00?, 0x3b72040?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001de0a00)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc001de0a00)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*TCPListener).accept(0xc001ddc510)
	/usr/local/go/src/net/tcpsock_posix.go:148 +0x25
net.(*TCPListener).Accept(0xc001ddc510)
	/usr/local/go/src/net/tcpsock.go:297 +0x3d
github.com/miekg/dns.(*Server).serveTCP(0xc0001e7200, {0x3bb3640?, 0xc001ddc510})
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:454 +0x148
github.com/miekg/dns.(*Server).ActivateAndServe(0xc0001e7200)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:372 +0x17c
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc0001e7200)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:670 +0x20c
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:662 +0x939

goroutine 308 [IO wait]:
internal/poll.runtime_pollWait(0x7fdee7ecb878, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001de0a80?, 0xc000868000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsgInet4(0xc001de0a80, {0xc000868000, 0x200, 0x200}, {0xc00081e660, 0x2c, 0x2c}, 0xc001ea67c8?, 0x40c409?)
	/usr/local/go/src/internal/poll/fd_unix.go:331 +0x359
net.(*netFD).readMsgInet4(0xc001de0a80, {0xc000868000?, 0xc001e3cc00?, 0xc001ea6858?}, {0xc00081e660?, 0xc004285000?, 0x36?}, 0x440758?, 0x35?)
	/usr/local/go/src/net/fd_posix.go:84 +0x37
net.(*UDPConn).readMsg(0x72?, {0xc000868000?, 0x416130?, 0xffffffffffffffff?}, {0xc00081e660?, 0x0?, 0x0?})
	/usr/local/go/src/net/udpsock_posix.go:101 +0x16b
net.(*UDPConn).ReadMsgUDPAddrPort(0xc0005c6528, {0xc000868000?, 0x7fdee7ecb878?, 0x47bc5e?}, {0xc00081e660?, 0xc001ea69d0?, 0x47ba2e?})
	/usr/local/go/src/net/udpsock.go:203 +0x53
net.(*UDPConn).ReadMsgUDP(0xc001f05e00?, {0xc000868000?, 0x58c6760?, 0xc00149b2e0?}, {0xc00081e660?, 0xc001ea6a30?, 0x40e107?})
	/usr/local/go/src/net/udpsock.go:191 +0x2a
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*sessionUDPFactory).ReadRequest(0xc0005c6528?, 0xc0005c6528)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/udp.go:178 +0x5f
github.com/miekg/dns.(*Server).readUDP(0xc0001e7300, 0xc0005c6528, 0xc00497eaa0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:688 +0xed
github.com/miekg/dns.defaultReader.ReadUDP({0xc0001e7300?}, 0x3b88020?, 0xc00497eaa0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:174 +0x19
github.com/miekg/dns.(*Server).serveUDP(0xc0001e7300, {0x3bc4870?, 0xc0005c6528?})
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:510 +0x2ae
github.com/miekg/dns.(*Server).ActivateAndServe(0xc0001e7300)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:367 +0x125
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc0001e7300)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:670 +0x20c
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:662 +0x939

goroutine 452 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 271 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 388 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0008333e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 373 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0009be180, 0xc000864800)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 386 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc00081b1d0, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc000833140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 676 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc000a48540, 0xc001afc2a0, 0xc0010cfce0, 0x1001010385ff2e00?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 336 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 664 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7fdee7ecb4b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc00117e6c0?, 0xc001cd5ed0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00117e6c0, {0xc001cd5ed0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:31
os.(*File).Read(0xc00064caa0, {0xc001cd5ed0?, 0x65736e6f70736552?, 0xe2ff0173706f7250?})
	/usr/local/go/src/os/file.go:118 +0x5e
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc00014db80)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:356 +0xdf
created by github.com/fsnotify/fsnotify.NewWatcher
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:150 +0x1b0

goroutine 1332 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7fdee7e08678, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc0010dd500?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0010dd500)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc0010dd500)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*TCPListener).accept(0xc0007eb3b0)
	/usr/local/go/src/net/tcpsock_posix.go:148 +0x25
net.(*TCPListener).Accept(0xc0007eb3b0)
	/usr/local/go/src/net/tcpsock.go:297 +0x3d
net/http.(*Server).Serve(0xc000366780, {0x3bb3640, 0xc0007eb3b0})
	/usr/local/go/src/net/http/server.go:3059 +0x385
net/http.(*Server).ListenAndServe(0xc000366780)
	/usr/local/go/src/net/http/server.go:2988 +0x7d
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:35
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:365 +0x2f
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:364 +0x85

goroutine 377 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc00143d340}, {0x7fdee7ab0f60, 0xc000a58000}, {0x3be8e60?, 0x358fc00}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001ea00e0, {0x0?, 0x0?}, 0xc000a3bf80, 0xc00116b860?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001ea00e0, 0xc000a3bf80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc000b0fec8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00143f680?, {0x3b878e0, 0xc0006dabe0}, 0x1, 0xc000a3bf80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001ea00e0, 0xc000a3bf80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 529 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 4125 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc004063db0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001ae9320, {0xc0010099e0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc004063db0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 269 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0007fd8c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 270 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00045a790, 0x12)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0007fd7a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 383 [chan receive]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).podsInit.func1.1()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:123 +0x131
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).podsInit.func1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:121 +0xf8

goroutine 677 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc00096f200, 0xc001314700)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa00000001?, 0xc0007ccfa0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 450 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc00145b620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 285 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000950060)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 1115 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0014ccf78?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 451 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00143d4d0, 0xef)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc00145b500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 1653 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00129b9e0, {0xc0011a2f90, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002d1efa0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 266 [select, 1 minutes]:
reflect.rselect({0xc002ec5680, 0x9, 0xc000a52798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc0014a0400?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001410570, {0x3bb5780, 0xc001f45bc0}, 0xc0007e8070, {0x7fdee7ab84a8, 0xc001071480}, 0xc001afc960, {0x36c7bac?, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001410570, {0x3bb5780, 0xc001f45bc0}, {0x7fdee7ab84a8?, 0xc001071480?}, {0x36c7bac, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamClusters(0xc0007ceb30?, {0x3bc6cb0, 0xc001071480})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:107 +0x70
github.com/cilium/proxy/go/envoy/service/cluster/v3._ClusterDiscoveryService_StreamClusters_Handler({0x34ffc60?, 0xc001410570}, {0x3bc0368?, 0xc0011ae0f0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:332 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001e1c000, {0x3bcc8e0, 0xc001c04b60}, 0xc0008b0120, 0xc00143bec0, 0x5880860, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001e1c000, {0x3bcc8e0, 0xc001c04b60}, 0xc0008b0120, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 263 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0xc0002640a0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x115
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0xc001de8000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x91
google.golang.org/grpc/internal/transport.NewServerTransport.func2()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:341 +0xda
created by google.golang.org/grpc/internal/transport.NewServerTransport
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:338 +0x1bb3

goroutine 264 [select, 3 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0xc001c04b60)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1155 +0x233
created by google.golang.org/grpc/internal/transport.NewServerTransport
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:344 +0x1bf8

goroutine 265 [IO wait]:
internal/poll.runtime_pollWait(0x7fdee7ecb788, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001454180?, 0xc001c1c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001454180, {0xc001c1c000, 0x8000, 0x8000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc001454180, {0xc001c1c000?, 0x1060100000000?, 0x8?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000a82000, {0xc001c1c000?, 0xc001c04d00?, 0x0?})
	/usr/local/go/src/net/net.go:183 +0x45
bufio.(*Reader).Read(0xc0007fc720, {0xc0015c4040, 0x9, 0x0?})
	/usr/local/go/src/bufio/bufio.go:237 +0x1bb
io.ReadAtLeast({0x3b71ea0, 0xc0007fc720}, {0xc0015c4040, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
golang.org/x/net/http2.readFrameHeader({0xc0015c4040?, 0x9?, 0xc004847818?}, {0x3b71ea0?, 0xc0007fc720?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x6e
golang.org/x/net/http2.(*Framer).ReadFrame(0xc0015c4000)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x95
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0xc001c04b60, 0x6e697274530d0101?, 0x7961727241724f67?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:642 +0x167
google.golang.org/grpc.(*Server).serveStreams(0xc001e1c000, {0x3bcc8e0?, 0xc001c04b60})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:946 +0x162
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:889 +0x46
created by google.golang.org/grpc.(*Server).handleRawConn
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:888 +0x185

goroutine 329 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc000264370, {0xc001ddd240, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc000264370, {0xc001ddd240?, 0xc0007ec018?, 0xc001ef5560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc000458420, {0xc001ddd240?, 0xc001ef55d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc000458420}, {0xc001ddd240, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc0008b0120, {0xc001ddd240, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc001ddd230, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc001ef57a8?, 0xc0008b0120, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7fdee7ab8480, 0x5e20750}, 0xc001ef59f8?, {0x0?, 0x0?}, {0x3472d60, 0xc000979360}, 0xc00119d0e0?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc0011ae0f0, {0x3472d60?, 0xc000979360})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/cluster/v3.(*clusterDiscoveryServiceStreamClustersServer).Recv(0xc001071480)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:351 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc0007e8070?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 331 [select, 1 minutes]:
reflect.rselect({0xc000a2ed80, 0x9, 0xc000f16798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc000b46600?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001410570, {0x3bb5780, 0xc0004585a0}, 0xc001446070, {0x7fdee7bbe5a8, 0xc001076210}, 0xc00144e300, {0x36cf89b?, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001410570, {0x3bb5780, 0xc0004585a0}, {0x7fdee7bbe5a8?, 0xc001076210?}, {0x36cf89b, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamListeners(0xc0007ceb30?, {0x3bc6e10, 0xc001076210})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:79 +0x70
github.com/cilium/proxy/go/envoy/service/listener/v3._ListenerDiscoveryService_StreamListeners_Handler({0x34ffc60?, 0xc001410570}, {0x3bc0368?, 0xc0003663c0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:359 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001e1c000, {0x3bcc8e0, 0xc001c04b60}, 0xc000839320, 0xc001e1e000, 0x5880900, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001e1c000, {0x3bcc8e0, 0xc001c04b60}, 0xc000839320, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 267 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc0004fe5a0, {0xc000452130, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc0004fe5a0, {0xc000452130?, 0xc001a951d0?, 0xc001461560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc000818990, {0xc000452130?, 0xc0014615d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc000818990}, {0xc000452130, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc000839320, {0xc000452130, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc000452120, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc0014617a8?, 0xc000839320, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7fdee7ab8480, 0x5e20750}, 0xc0014619f8?, {0x0?, 0x0?}, {0x3472d60, 0xc00237cc80}, 0xc0007fd260?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc0003663c0, {0x3472d60?, 0xc00237cc80})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/listener/v3.(*listenerDiscoveryServiceStreamListenersServer).Recv(0xc001076210)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:378 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc001446070?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 438 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 2946 [IO wait]:
internal/poll.runtime_pollWait(0x7fdee7e08588, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001d64e00?, 0xc001ee5000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsg(0xc001d64e00, {0xc001ee5000, 0x1000, 0x1000}, {0x0, 0x0, 0x0}, 0x8?)
	/usr/local/go/src/internal/poll/fd_unix.go:304 +0x3aa
net.(*netFD).readMsg(0xc001d64e00, {0xc001ee5000?, 0x0?, 0x0?}, {0x0?, 0xc003bfd7d0?, 0xc003bfd7a0?}, 0x4134d7?)
	/usr/local/go/src/net/fd_posix.go:78 +0x37
net.(*UnixConn).readMsg(0xc00073daf8, {0xc001ee5000?, 0x2716d3a?, 0x2fcad80?}, {0x0?, 0xc0033120d0?, 0xc?})
	/usr/local/go/src/net/unixsock_posix.go:115 +0x4f
net.(*UnixConn).ReadMsgUnix(0xc00073daf8, {0xc001ee5000?, 0xc0045d1bb8?, 0x2?}, {0x0?, 0xc13608f244787671?, 0x21f7d04315?})
	/usr/local/go/src/net/unixsock.go:143 +0x3c
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn(0xc001032ce0, {0x3bb56d8?, 0xc0002466e0}, 0xc00073daf8)
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:118 +0x1a6
created by github.com/cilium/cilium/pkg/envoy.StartAccessLogServer.func1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:82 +0x138

goroutine 389 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc00081b250, 0x8)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0008332c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 390 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 287 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 381 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0009be480, 0xc000865000)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa01b92f01?, 0xc001b92fa0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 380 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001ea00e0, 0xc000a3bf80, 0xc00046b2c0, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 382 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0009be4c8, 0x6)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc00291b830?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc0009be4b0, {0xc001b8e001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc001b8e001?, 0x2?, 0x3613591?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc0001f4a00)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0001f4a00)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc0001f4a00, {0x30221e0, 0xc0017a1ad0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0017344e0, {0xc000aea000, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0006db0e0, 0xc003c790e0?, {0x3b9d990, 0xc003a90e80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0010317a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00143d340)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 398 [select]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).nodeEventLoop(0xc001847340, 0xc001164e60, 0xc0007f96c0?)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/node.go:67 +0x13b
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).NodesInit.func1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/node.go:55 +0x1b8

goroutine 1108 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001414106, 0x10, 0x1a}, {0xc00178a9c0, 0x24}, 0xc00213bf78?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 418 [select]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).serviceEventLoop(0xc001847340, 0xc0011651cc, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:41 +0x131
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).servicesInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:29 +0x1b8

goroutine 634 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc000c4ed40}, {0x7fdee7ab0f60, 0xc0006eca50}, {0x3be8e60?, 0x358dde0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0017e2540, {0x0?, 0x0?}, 0xc00118a480, 0xc000b23460?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0017e2540, 0xc00118a480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000939380?, {0x3b878e0, 0xc000b21810}, 0x1, 0xc00118a480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0017e2540, 0xc00118a480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 420 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000833b60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 421 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000a38010, 0x7)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc000833a40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 422 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 423 [select]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).namespacesInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:48 +0xce
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).namespacesInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:46 +0x20a

goroutine 743 [select, 3 minutes]:
github.com/cilium/cilium/pkg/hubble/observer.(*namespaceManager).Run(0x0?, {0x3bb56d8, 0xc0000ce230})
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/namespace_manager.go:50 +0xea
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:175 +0x141e

goroutine 426 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000833ce0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 427 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000a380d0, 0x45)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc000833bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 428 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 429 [select]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).endpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:43 +0xf8
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).endpointsInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:41 +0x285

goroutine 1400 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00135cb40, {0xc0015d24a0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001f651d0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 431 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc0004754c8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x505167?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0004754a0, 0xc000a38200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000467400)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc000db6300}, 0x1, 0xc001afcb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000467478?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000467400, 0xc001afcb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).networkPoliciesInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/network_policy.go:74 +0x35a

goroutine 465 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc000475578, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x505167?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000475550, 0xc000a38380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0004674a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc001dd5230}, 0x1, 0xc001afcb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000467518?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0004674a0, 0xc001afcb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).tlsSecretInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/secret.go:90 +0x253

goroutine 466 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNetworkPoliciesInit.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_network_policy.go:108 +0x372
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNetworkPoliciesInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_network_policy.go:89 +0x158

goroutine 2935 [select]:
reflect.rselect({0xc00290b200, 0x9, 0xc002bd6798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc000b47800?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001410570, {0x3bb5780, 0xc000bd8d50}, 0xc001c60540, {0x7fdee7ae8e50, 0xc00072db30}, 0xc0008b6b40, {0x36f79e0?, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001410570, {0x3bb5780, 0xc000bd8d50}, {0x7fdee7ae8e50?, 0xc00072db30?}, {0x36f79e0, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamEndpoints(0xc002142b30?, {0x3bc6d60, 0xc00072db30})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:121 +0x70
github.com/cilium/proxy/go/envoy/service/endpoint/v3._EndpointDiscoveryService_StreamEndpoints_Handler({0x34ffc60?, 0xc001410570}, {0x3bc0368?, 0xc002ec04b0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:338 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001e1c000, {0x3bcc8e0, 0xc001c04b60}, 0xc001480fc0, 0xc00143be30, 0x58808a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001e1c000, {0x3bcc8e0, 0xc001c04b60}, 0xc001480fc0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 747 [chan receive, 3 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func3()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:236 +0x3e
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:235 +0x238c

goroutine 1416 [IO wait]:
internal/poll.runtime_pollWait(0x7fdee7a5e860, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc000b39380?, 0xc0016b6000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc000b39380, {0xc0016b6000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc000b39380, {0xc0016b6000?, 0x2?, 0x588a5a0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000a82158, {0xc0016b6000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*persistConn).Read(0xc00135d440, {0xc0016b6000?, 0x44d520?, 0xc000dedec8?})
	/usr/local/go/src/net/http/transport.go:1943 +0x4e
bufio.(*Reader).fill(0xc00180e8a0)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc00180e8a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*persistConn).readLoop(0xc00135d440)
	/usr/local/go/src/net/http/transport.go:2107 +0x1ac
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1765 +0x16ea

goroutine 470 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNodeInit(0xc001847340, {0x3bf05a0, 0xc000b976b0}, 0xc0011651b0)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:136 +0x656
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).enableK8sWatchers
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:557 +0x5c5

goroutine 471 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEndpointsInit(0xc001847340, {0x3bf05a0, 0xc000b976b0}, 0xc0011651b0)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:101 +0x76
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).initCiliumEndpointOrSlices
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:1074 +0x152

goroutine 368 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000ef72d0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 354 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 455 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 436 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0007da4f8, 0x3)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000e1a9e0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0007da4d0, 0xc000389230)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000f82960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc00015c2a0}, 0x1, 0xc001afc240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000f829d8?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000f82960, 0xc001afc240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 456 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc001759180}, {0x7fdee7ab0f60, 0xc001e02840}, {0x3be8e60?, 0x35bfa20}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001ea0540, {0x0?, 0x0?}, 0xc001ba6000, 0xc001031940?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001ea0540, 0xc001ba6000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001b3c280?, {0x3b878e0, 0xc0006db8b0}, 0x1, 0xc001ba6000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001ea0540, 0xc001ba6000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 1171 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001414886, 0x10, 0x1a}, {0xc00178b7d0, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 666 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0017e2540, 0xc00118a480, 0xc00115a780, 0xc00014db80?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 474 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000475628, 0x28)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000294b60?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000475600, 0xc000a386c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000467540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc0016442d0}, 0x1, 0xc00083f800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0004675b8?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000467540, 0xc00083f800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEndpointsInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:99 +0x6a

goroutine 475 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0x0?)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x37
created by github.com/cilium/cilium/pkg/kvstore.Connected
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x72

goroutine 1086 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001dc04e6, 0x10, 0x1a}, {0xc001b30870, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 486 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 439 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc0013d7d80}, {0x7fdee7ab0f60, 0xc0007da4d0}, {0x3be8e60?, 0x35bf2a0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0015c42a0, {0x0?, 0x0?}, 0xc001afc240, 0xc0010c2800?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0015c42a0, 0xc001afc240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000465180?, {0x3b878e0, 0xc000265e00}, 0x1, 0xc001afc240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0015c42a0, 0xc001afc240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 476 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 238 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000814300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 239 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc0013d6110, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0008141e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 240 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 492 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0015c42a0, 0xc001afc240, 0xc00016b1a0, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 341 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc000c65e68, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x505167?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000c65e40, 0xc0002162a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0011d08c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc000216330}, 0x1, 0xc001afc1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0011d0938?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0011d08c0, 0xc001afc1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 343 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 497 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000814480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 498 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc0013d62d0, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc000814360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 494 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001ea0540, 0xc001ba6000, 0xc00016b9e0, 0xc002135fb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 499 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 500 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000814600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 344 [select, 3 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc0010c8c00}, {0x7fdee7ab0f60, 0xc000c65e40}, {0x3be8e60?, 0x35a2620}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc00157a0e0, {0x0?, 0x0?}, 0xc001afc1e0, 0xc0010281c0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc00157a0e0, 0xc001afc1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00186e040?, {0x3b878e0, 0xc0002fc320}, 0x1, 0xc001afc1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc00157a0e0, 0xc001afc1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 501 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc0013d6390, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0008144e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 502 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 679 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc00157a0e0, 0xc001afc1e0, 0xc0013541e0, 0x65520e010103ddff?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 504 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc000cd1a48, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0014cac18?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000cd1a20, 0xc000156c60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000bbe780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc000156d50}, 0x1, 0xc001afc300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000bbe7f8?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000bbe780, 0xc001afc300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 477 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc00143d8c0}, {0x7fdee7ab0f60, 0xc000475550}, {0x3be8e60?, 0x35bfde0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0014568c0, {0x0?, 0x0?}, 0xc001afcb40, 0xc0011b4400?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0014568c0, 0xc001afcb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00081d580?, {0x3b878e0, 0xc0004ffe00}, 0x1, 0xc001afcb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0014568c0, 0xc001afcb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 514 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc00067ba48, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x505167?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc00067ba20, 0xc000cf5230)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000ad4000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc001badf50}, 0x1, 0xc001afc2a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000ad4078?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000ad4000, 0xc001afc2a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 1116 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002868d80, {0xc000539ab0, 0x0, 0xc001db2360, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000b20d70}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 575 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0014568c0, 0xc001afcb40, 0xc000f61bc0, 0xbaff0173616d6568?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 507 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 355 [select, 3 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc00143d840}, {0x7fdee7ab0f60, 0xc0004754a0}, {0x3be8e60?, 0x35c1460}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001db4000, {0x0?, 0x0?}, 0xc001afcb40, 0xc0012401a0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001db4000, 0xc001afcb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0013d2140?, {0x3b878e0, 0xc0006b21e0}, 0x1, 0xc001afcb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001db4000, 0xc001afcb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 493 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc00096e480, 0xc00096cf00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa010c0701?, 0xc0001417a0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 580 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001db4000, 0xc001afcb40, 0xc000f24d80, 0x2f73656974726570?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 508 [select, 3 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc00143dcc0}, {0x7fdee7ab0f60, 0xc000cd1a20}, {0x3be8e60?, 0x3589640}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001768000, {0x0?, 0x0?}, 0xc001afc300, 0xc00014e6c0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001768000, 0xc001afc300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000b74400?, {0x3b878e0, 0xc00014caf0}, 0x1, 0xc001afc300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001768000, 0xc001afc300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 495 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc00096e600, 0xc00096d700)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa0163cb01?, 0xc001b92fa0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 487 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc0010c81c0}, {0x7fdee7ab0f60, 0xc000475600}, {0x3be8e60?, 0x358d5a0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc00019a0e0, {0x0?, 0x0?}, 0xc00083f800, 0xc0002fe160?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc00019a0e0, 0xc00083f800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0006f2ec0?, {0x3b878e0, 0xc0005c8320}, 0x1, 0xc00083f800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc00019a0e0, 0xc00083f800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 674 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001768000, 0xc001afc300, 0xc0010cf920, 0xc00213ffb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 623 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc00019a0e0, 0xc00083f800, 0xc0010cf440, 0xc001759080?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 680 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc00096f380, 0xc001314b00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa01390001?, 0xc001e12fa0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 576 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000dfe180, 0xc000df8900)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa01165201?, 0xc001e11fa0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 58 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc0006ec918, 0x3)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0004f5660?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0006ec8f0, 0xc000e38000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000df0000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc001dd54d0}, 0x1, 0xc000f60180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000df0078?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000df0000, 0xc000f60180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNodeInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:134 +0x64a

goroutine 59 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0x6f20656874206d6f?)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x37
created by github.com/cilium/cilium/pkg/kvstore.Connected
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x72

goroutine 630 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0006eca78, 0x1c)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000b8a000?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0006eca50, 0xc000ccf880)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000df0140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc00004b710}, 0x1, 0xc00118a480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000df01b8?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000df0140, 0xc00118a480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/identitybackend.(*crdBackend).ListAndWatch(0xc00004b230, {0x443345?, 0xc000dfe480?}, {0x3bb59e8?, 0xc000a44598}, 0xc00118a480)
	/go/src/github.com/cilium/cilium/pkg/k8s/identitybackend/identity.go:396 +0x53d
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:204 +0x4d
created by github.com/cilium/cilium/pkg/allocator.(*cache).start
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:203 +0x118

goroutine 480 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 2930 [select]:
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0028ed380?, {0x3b87900, 0xc00176c5d0}, 0x1, 0xc0028ed380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:238 +0x135
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001c98e60?, 0x77359400, 0x0, 0x40?, 0x20?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/leaderelection.(*LeaderElector).renew(0xc0014b06c0, {0x3bb56d8?, 0xc001c98e10?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/leaderelection/leaderelection.go:266 +0x125
k8s.io/client-go/tools/leaderelection.(*LeaderElector).Run(0xc0014b06c0, {0x3bb56d8, 0xc001b60640})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/leaderelection/leaderelection.go:209 +0x119
k8s.io/client-go/tools/leaderelection.RunOrDie({0x3bb56d8, 0xc001b60640}, {{0x3bc0b48, 0xc0013bfe60}, 0x37e11d600, 0x12a05f200, 0x77359400, {0xc000aabdd0, 0xc000aabde0, 0x0}, ...})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/leaderelection/leaderelection.go:223 +0x94
github.com/cilium/cilium/pkg/l2announcer.(*selectedService).serviceLeaderElection(0xc00012b340, {0x3bb5780?, 0xc001170d50?})
	/go/src/github.com/cilium/cilium/pkg/l2announcer/l2announcer.go:1061 +0x218
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc001e2f040, {0x3bb5780, 0xc001170d50}, 0xc0013dad80?, {{{0xc000fc44e0, 0x1, 0x1}}, {0x3be6410, 0xc0015ccd20}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:267 +0x530
created by github.com/cilium/cilium/pkg/hive/job.(*group).Add.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:181 +0x158

goroutine 545 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc001759080}, {0x7fdee7ab0f60, 0xc0006ec8f0}, {0x3be8e60?, 0x358fc00}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001456c40, {0x0?, 0x0?}, 0xc000f60180, 0xc0011b4700?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001456c40, 0xc000f60180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00081d680?, {0x3b878e0, 0xc0004ffef0}, 0x1, 0xc000f60180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001456c40, 0xc000f60180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 516 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001456c40, 0xc000f60180, 0xc0000d09c0, 0x203a226570797422?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 625 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 624 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc00096ef00, 0xc00096df00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0x6520736968742072?, 0x1746e696f70646e?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 463 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc00096f0c8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000976b98?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc00096f0b0, {0xc000868e00, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc000868e00?, 0xffffffffffffffff?, 0xffffffffffffffff?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc0001f5680)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0001f5680)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc0001f5680, {0x30221e0, 0xc0008bc7b0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc001735860, {0xc0009fa000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0000ce690, 0xc00016ade0?, {0x3b9d990, 0xc00143dd00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001031ca0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00143dcc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 517 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000ae2000, 0xc000ade300)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa01165401?, 0xc001bd2fa0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 626 [select, 3 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc0011100c0}, {0x7fdee7ab0f60, 0xc0014f0580}, {0x3be8e60?, 0x358d020}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0017e2000, {0x0?, 0x0?}, 0xc001afcd80, 0xc000b23060?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0017e2000, 0xc001afcd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000f4a280?, {0x3b878e0, 0xc000b21680}, 0x1, 0xc001afcd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0017e2000, 0xc001afcd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 303 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0004f2480, {0xc000a80690, 0x0, 0x3805780, 0x0, 0xdf8475800, 0x0, 0x0, {0x3bb56d8, 0xc0006de280}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 582 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00096e4c8, 0x3)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000acdd68?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc00096e4b0, {0xc0012a6620, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0xc0012a6620?}, {0xc0012a6620?, 0xc000acdd08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7fdee7aafda0, 0xc00096e480}, {0xc0012a6620, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc000816de0, {0xc00094ac00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc00014d680, 0xc003cf0200?, {0x3b9d990, 0xc003cf21c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc00014f200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0013d7d80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 581 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000aa8000, 0xc000940300)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0x202020202020200a?, 0xc0003e1380?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 633 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 459 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc000aa8048, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc001b92c08?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000aa8030, {0xc00163cdb8, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0xc000803860?}, {0xc00163cdb8?, 0xc001b92d08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7fdee7aafda0, 0xc000aa8000}, {0xc00163cdb8, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc0008bc5a0, {0xc001ec1800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0006dba40, 0xc0011188f0?, {0x3b9d990, 0xc00143d880})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001031bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00143d840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 460 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000dfe1c8, 0x3)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc00213dd68?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000dfe1b0, {0xc000aa3e54, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc000aa3e54?, 0xc00213dd08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7fdee7aafda0, 0xc000dfe180}, {0xc000aa3e54, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc0008bc5d0, {0xc001ec1c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0006dbae0, 0xc003cb46f0?, {0x3b9d990, 0xc003a69bc0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001031be0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00143d8c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 496 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000ae2048, 0x6)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc001de6810?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000ae2030, {0xc001d8c001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc001d8c001?, 0x2?, 0x3613591?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc000bbd400)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc000bbd400)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc000bbd400, {0x30221e0, 0xc0003d8690})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0002562a0, {0xc00108b800, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0005c9180, 0xc003f2ac00?, {0x3b9d990, 0xc003c109c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0002fefc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001759080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 593 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00096e648, 0x80)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000de8d68?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc00096e630, {0xc0033fb16c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc0033fb16c?, 0xc000de8d08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7fdee7aafda0, 0xc00096e600}, {0xc0033fb16c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc000b16e70, {0xc002daa000, 0x8000, 0xa000})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0005c9220, 0xc0047cfb00?, {0x3b9d990, 0xc0042d6fc0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0002fefe0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001759180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 3014 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00133e900, {0xc0023fc380, 0x0, 0xc002dcda10, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0023fa2d0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 668 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000aa8648, 0x1f)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc00280dd70?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000aa8630, {0xc0029fe001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc0029fe001?, 0x2?, 0x3613591?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc0002e7680)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0002e7680)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc0002e7680, {0x30221e0, 0xc000452af8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc00032dec0, {0xc001eb8000, 0x1000, 0x1500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc00014dea0, 0xc002b59ec0?, {0x3b9d990, 0xc003cf2cc0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000602c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000c4ed40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 613 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc0014f05a8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x505167?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0014f0580, 0xc0017595c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000978460)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc00004acc0}, 0x1, 0xc001afcd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0009784d8?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000978460, 0xc001afcd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumClusterwideEnvoyConfigInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_clusterwide_envoy_config.go:79 +0x330

goroutine 3075 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc00285c140)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 615 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc0014f0658, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc001028020?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0014f0630, 0xc0017596c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000978500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc000257f50}, 0x1, 0xc001afcd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000978578?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000978500, 0xc001afcd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEnvoyConfigInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_envoy_config.go:84 +0x338

goroutine 616 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 617 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc0010c8dc0}, {0x7fdee7ab0f60, 0xc0014f0630}, {0x3be8e60?, 0x358d860}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0017a3340, {0x0?, 0x0?}, 0xc001afcd80, 0xc0002ff3a0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0017a3340, 0xc001afcd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0000779f0?, {0x3b878e0, 0xc000634aa0}, 0x1, 0xc001afcd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0017a3340, 0xc001afcd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 691 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0017a3340, 0xc001afcd80, 0xc000a3aa80, 0x6d756e4504010008?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 3078 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0011ec5c0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 464 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0017e2000, 0xc001afcd80, 0xc000a3a5a0, 0x4c1ff1d000000b2?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 3187 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc0003d9ae8?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 3691 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0026885a0, {0xc0007aa018, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001f06dc0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3618 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001ac7320, {0xc001446310, 0x0, 0xc0009ffd70, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00324d0e0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 744 [chan receive]:
github.com/cilium/cilium/pkg/hubble/observer.(*LocalObserverServer).Start(0xc00067e000)
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/local_observer.go:121 +0xa9
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:187 +0x1645

goroutine 3478 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0017d9e60, {0xc0001e87e0, 0x0, 0xc00357bad0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00240ed70}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 367 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0000cfae0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0008b0900, {0xc00015b0b0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0000cfae0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1285 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000466f00)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 692 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0009be900, 0xc000865c00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa002ce801?, 0xc001f47fa0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 1295 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7fdee7e08768, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc00253ef00?, 0xc00158d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00253ef00, {0xc00158d000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc00253ef00, {0xc00158d000?, 0x4e7b66?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc0005c60e0, {0xc00158d000?, 0x0?, 0xc00107a0f8?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*connReader).Read(0xc00107a0f0, {0xc00158d000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:782 +0x171
bufio.(*Reader).fill(0xc0008d6a20)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc0008d6a20, 0x4)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*conn).serve(0xc002570c60, {0x3bb5780, 0xc00032ce70})
	/usr/local/go/src/net/http/server.go:2030 +0x77c
created by net/http.(*Server).Serve
	/usr/local/go/src/net/http/server.go:3089 +0x5ed

goroutine 1570 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0011d0aa0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 746 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7fdee7ecb008, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001fd2100?, 0xc000072420?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001fd2100)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc001fd2100)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*UnixListener).accept(0xc000460168?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x1c
net.(*UnixListener).Accept(0xc00107a600)
	/usr/local/go/src/net/unixsock.go:260 +0x3d
google.golang.org/grpc.(*Server).Serve(0xc001ffc000, {0x3bb3670?, 0xc00107a600})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:821 +0x475
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func2()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:231 +0x59
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:230 +0x230f

goroutine 745 [runnable]:
syscall.Syscall(0xc001bcd670?, 0x7fdee7e38ed8?, 0x7fdee7e54780?, 0x10?)
	/usr/local/go/src/syscall/syscall_linux.go:69 +0x27
internal/syscall/unix.GetRandom({0xc004526000?, 0x0?, 0x1004291a0?}, 0x0?)
	/usr/local/go/src/internal/syscall/unix/getrandom.go:28 +0x45
crypto/rand.getRandom({0xc004526000?, 0x10, 0x5?})
	/usr/local/go/src/crypto/rand/rand_getrandom.go:40 +0x25
crypto/rand.batched.func1({0xc004526000?, 0x40d59e?, 0x7fdee7e54780?})
	/usr/local/go/src/crypto/rand/rand.go:37 +0x91
crypto/rand.(*reader).Read(0xc0000720e0, {0xc004526000, 0x10, 0x10})
	/usr/local/go/src/crypto/rand/rand_unix.go:56 +0x114
io.ReadAtLeast({0x3b72040, 0xc0000720e0}, {0xc004526000, 0x10, 0x10}, 0x10)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
github.com/google/uuid.NewRandomFromReader({0x3b72040, 0xc0000720e0})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/uuid/version4.go:49 +0x57
github.com/google/uuid.NewRandom()
	/go/src/github.com/cilium/cilium/vendor/github.com/google/uuid/version4.go:41 +0x58
github.com/google/uuid.New(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/google/uuid/version4.go:14
github.com/cilium/cilium/pkg/hubble/monitor.(*consumer).NotifyPerfEvent(0x22ce880?, {0xc004522180, 0x2c, 0x2c}, 0x0)
	/go/src/github.com/cilium/cilium/pkg/hubble/monitor/consumer.go:123 +0x53
github.com/cilium/cilium/pkg/monitor/agent.(*agent).notifyPerfEventLocked(...)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:418
github.com/cilium/cilium/pkg/monitor/agent.(*agent).processPerfRecord(0xc0015ccc40, 0xc001de9a40?, {0x0, {0xc004522180, 0x2c, 0x2c}, 0x0})
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:378 +0x1ca
github.com/cilium/cilium/pkg/monitor/agent.(*agent).handleEvents(0xc0015ccc40, {0x3bb56d8, 0xc0006da780})
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:358 +0x728
created by github.com/cilium/cilium/pkg/monitor/agent.(*agent).startPerfReaderLocked
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:209 +0xe5

goroutine 742 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001fcc120, {0x38057e0, 0x0, 0x3805780, 0x37e11d600, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0006da4b0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 685 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:246 +0x116
created by github.com/cilium/cilium/pkg/stream.Multicast[...].func3
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:239 +0x3aa

goroutine 1415 [IO wait]:
internal/poll.runtime_pollWait(0x7fdee7e08c18, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc00284b400?, 0xc002d50000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00284b400, {0xc002d50000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc00284b400, {0xc002d50000?, 0x4e7b66?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000a82138, {0xc002d50000?, 0x0?, 0xc000bd9bc8?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*connReader).Read(0xc000bd9bc0, {0xc002d50000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:782 +0x171
bufio.(*Reader).fill(0xc0028412c0)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc0028412c0, 0x4)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*conn).serve(0xc002c84a20, {0x3bb5780, 0xc002eee480})
	/usr/local/go/src/net/http/server.go:2030 +0x77c
created by net/http.(*Server).Serve
	/usr/local/go/src/net/http/server.go:3089 +0x5ed

goroutine 667 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000aa8600, 0xc000941100)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0x3690894?, 0x61566e6f6d6d6f43?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 1914 [select, 2 minutes]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0xc003ae9360, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x115
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0xc00024c620)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x91
google.golang.org/grpc/internal/transport.NewServerTransport.func2()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:341 +0xda
created by google.golang.org/grpc/internal/transport.NewServerTransport
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:338 +0x1bb3

goroutine 682 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc0009be948, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0029dd590?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc0009be930, {0xc002120001, 0x1dff, 0x1dff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc002120001?, 0x2?, 0x3613591?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc0012632c0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0012632c0)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc0012632c0, {0x30221e0, 0xc0017bc600})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc000f34150, {0xc002168000, 0x2000, 0x2500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000384c80, 0xc00065f800?, {0x3b9d990, 0xc002335bc0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000072960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0010c8dc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 673 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00096ef48, 0x2b)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc004868540?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc00096ef30, {0xc002f98001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc002f98001?, 0x2?, 0x3613591?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc001262780)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc001262780)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc001262780, {0x30221e0, 0xc004856510})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc000b90300, {0xc0014eca00, 0x1000, 0x1500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000635540, 0xc002de9500?, {0x3b9d990, 0xc004853480})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0002ffd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0010c81c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 675 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc00096f080, 0xc001314300)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xc0011751a0?, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 678 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc00096f248, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc00096f238?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc00096f230, {0xc0013a9600, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc0013a9600?, 0x3?, 0x3b72300?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc001262b40)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc001262b40)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc001262b40, {0x30221e0, 0xc0005fd9c8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc000ebab40, {0xc001326c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000635a90, 0xc001c91fd0?, {0x3b9d990, 0xc0010c8880})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0000725e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0010c8840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 681 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc00096f3c8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc00096f3b8?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc00096f3b0, {0xc0013a9a00, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc0013a9a00?, 0x3?, 0x3b72300?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc001262f00)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc001262f00)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc001262f00, {0x30221e0, 0xc0005fdea8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc000ebbc80, {0xc001327800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000384b90, 0xc001c91fd0?, {0x3b9d990, 0xc0010c8c40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000072940)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0010c8c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 689 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0009be780, 0xc000865800)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0x365e6e3?, 0x20173776f6c6c41?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 690 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc0009be7c8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0009be7b8?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc0009be7b0, {0xc000869200, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc000869200?, 0x3?, 0x6465726975716500?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc0001f5900)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0001f5900)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc0001f5900, {0x30221e0, 0xc0008bcb88})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc000ef8450, {0xc0009fa800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0000cec80, 0x0?, {0x3b9d990, 0xc001110100})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0002d4060)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0011100c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 1289 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00256f7a0, {0xc0001e8d20, 0x0, 0xc002fc0d20, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002522820}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1389 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00137d320, {0xc00163a670, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002d1fa40}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1333 [semacquire, 3 minutes]:
sync.runtime_Semacquire(0x3124be0?)
	/usr/local/go/src/runtime/sema.go:62 +0x27
sync.(*WaitGroup).Wait(0xc000b46a00?)
	/usr/local/go/src/sync/waitgroup.go:116 +0x4b
github.com/cilium/cilium/api/v1/health/server.(*Server).Serve(0xc000b46a00)
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:278 +0x6b
github.com/cilium/cilium/pkg/health/server.(*Server).runActiveServices(0xc000b46a00)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:351 +0x113
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func2()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:369 +0x26
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:368 +0xd9

goroutine 1652 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001300240, {0xc001178018, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0030559a0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2934 [select]:
reflect.rselect({0xc0012b0120, 0x9, 0xc001e76798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc001e24400?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001410570, {0x3bb5780, 0xc0017db9e0}, 0xc001e5c700, {0x7fdee7ae8e50, 0xc000175540}, 0xc002ccab40, {0x36f79e0?, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001410570, {0x3bb5780, 0xc0017db9e0}, {0x7fdee7ae8e50?, 0xc000175540?}, {0x36f79e0, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamEndpoints(0xc0009f6b30?, {0x3bc6d60, 0xc000175540})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:121 +0x70
github.com/cilium/proxy/go/envoy/service/endpoint/v3._EndpointDiscoveryService_StreamEndpoints_Handler({0x34ffc60?, 0xc001410570}, {0x3bc0368?, 0xc0026ce4b0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:338 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001e1c000, {0x3bcc8e0, 0xc001c04b60}, 0xc001480ea0, 0xc00143be30, 0x58808a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001e1c000, {0x3bcc8e0, 0xc001c04b60}, 0xc001480ea0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 3253 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc003341906, 0x10, 0x1a}, {0xc002480810, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1226 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000822c06, 0x10, 0x1a}, {0xc00081f710, 0x24}, 0xc0009d9fb8?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1052 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0018f80a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 3274 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001280c60, {0xc000d9b870, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001c53d10}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1230 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00251aea0, {0xc0011a7a10, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0025225a0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1377 [select, 3 minutes]:
net/http.(*persistConn).writeLoop(0xc002efec60)
	/usr/local/go/src/net/http/transport.go:2410 +0xf2
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1766 +0x173d

goroutine 3270 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0035b22c6, 0x10, 0x1a}, {0xc00247e270, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 3079 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002abe360, {0xc002a82fc0, 0x0, 0xc001a61860, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0023fb720}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1429 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0013a6120, {0xc0011187b0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0004ff5e0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1246 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001fcc360, {0xc00177e1f8, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0004fe0f0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1337 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00129be60, {0xc000ef6b70, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0002643c0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2933 [select]:
reflect.rselect({0xc000a7d0e0, 0x9, 0xc0029ae798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc0033bec00?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001410570, {0x3bb5780, 0xc0049da390}, 0xc002928150, {0x7fdee7ae8e50, 0xc000ab94d0}, 0xc002bbe900, {0x36f79e0?, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001410570, {0x3bb5780, 0xc0049da390}, {0x7fdee7ae8e50?, 0xc000ab94d0?}, {0x36f79e0, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamEndpoints(0xc001cb7b30?, {0x3bc6d60, 0xc000ab94d0})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:121 +0x70
github.com/cilium/proxy/go/envoy/service/endpoint/v3._EndpointDiscoveryService_StreamEndpoints_Handler({0x34ffc60?, 0xc001410570}, {0x3bc0368?, 0xc001bf42d0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:338 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001e1c000, {0x3bcc8e0, 0xc001c04b60}, 0xc001480d80, 0xc00143be30, 0x58808a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001e1c000, {0x3bcc8e0, 0xc001c04b60}, 0xc001480d80, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 1221 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000822be6, 0x10, 0x1a}, {0xc00081f650, 0x24}, 0xc0018a6fc0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1574 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0013eb9e0, {0xc0001f95e0, 0x0, 0xc0018647b0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0004ff130}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1168 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7fdee7e08a38, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc002f14e00?, 0xc0012de000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002f14e00, {0xc0012de000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc002f14e00, {0xc0012de000?, 0x43c147?, 0xc00164fc30?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000b8e0c0, {0xc0012de000?, 0x0?, 0xc0016664e0?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*persistConn).Read(0xc002efec60, {0xc0012de000?, 0xc002f233e0?, 0xc00164fd30?})
	/usr/local/go/src/net/http/transport.go:1943 +0x4e
bufio.(*Reader).fill(0xc002f4ac00)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc002f4ac00, 0x1)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*persistConn).readLoop(0xc002efec60)
	/usr/local/go/src/net/http/transport.go:2107 +0x1ac
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1765 +0x16ea

goroutine 1008 [syscall, 3 minutes]:
os/signal.signal_recv()
	/usr/local/go/src/runtime/sigqueue.go:152 +0x2f
os/signal.loop()
	/usr/local/go/src/os/signal/signal_unix.go:23 +0x19
created by os/signal.Notify.func1.1
	/usr/local/go/src/os/signal/signal.go:151 +0x2a

goroutine 3077 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0023fb680})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002d57e60, {0xc0010775d0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0023fb680}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1003 [select, 3 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobTimer).start(0xc0000cf360, {0x3bb5780, 0xc0006ee6f0}, 0xc0008b6600?, {{{0xc000fc59e0, 0x1, 0x1}}, {0x3be6410, 0xc0015ccfc0}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:384 +0x3c5
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 1930 [select, 2 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func2()
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:73 +0x117
golang.org/x/sync/errgroup.(*Group).Go.func1()
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:75 +0x64
created by golang.org/x/sync/errgroup.(*Group).Go
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:72 +0xa5

goroutine 3013 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x24bfe20?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00032ce70?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1004 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001e22d80, {0xc001077a70, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001f64000}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1005 [select]:
github.com/cilium/cilium/pkg/hive/job.(*jobTimer).start(0xc0000cf4a0, {0x3bb5780, 0xc0006eeae0}, 0xc0007f23c0?, {{{0x0, 0x0, 0x0}}, {0x3be6500, 0xc001ab0480}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:384 +0x3c5
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 2988 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc00143c590, 0x1)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000340e00?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc00143c540, {0x3bb56d8, 0xc0023827d0}, {0xc001261700, 0x35}, 0x2, {0xc000454205, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 1354 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002ea0aa0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1425 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00136cb40, {0xc001489bf0, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002c827d0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3012 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0023fa230})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00133e360, {0xc0013323d0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0023fa230}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1006 [select, 1 minutes]:
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).cycle(0xc0015cdc00, {0x3bb5780, 0xc0006eed80}, 0x413bb7?, 0xc002148300)
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:115 +0x1cb
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).run(0xc0015cdc00, {0x3bb5780, 0xc0006eed80})
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:93 +0xd1
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc0000cf630, {0x3bb5780, 0xc0006eed80}, 0xc00083e840?, {{{0xc001006560, 0x1, 0x1}}, {0x3be6410, 0xc0015cdb20}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:267 +0x530
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 3010 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc00237de00)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2905 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001252e26, 0x10, 0x1a}, {0xc001c62030, 0x24}, 0xc00072c940?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1403 [IO wait]:
internal/poll.runtime_pollWait(0x7fdee7a5e680, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc000b39c00?, 0xc0043e7600?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadFrom(0xc000b39c00, {0xc0043e7600, 0x200, 0x200})
	/usr/local/go/src/internal/poll/fd_unix.go:223 +0x2ab
net.(*netFD).readFrom(0xc000b39c00, {0xc0043e7600?, 0x50?, 0x72?})
	/usr/local/go/src/net/fd_posix.go:61 +0x29
net.(*IPConn).readFrom(0xc00288ae68?, {0xc0043e7600, 0x200, 0x200})
	/usr/local/go/src/net/iprawsock_posix.go:49 +0x32
net.(*IPConn).ReadFrom(0xc000722110, {0xc0043e7600?, 0xc00082b018?, 0xc00288aea8?})
	/usr/local/go/src/net/iprawsock.go:129 +0x31
golang.org/x/net/icmp.(*PacketConn).ReadFrom(0xc1360900a9388710?, {0xc0043e7600?, 0x58c5060?, 0x58c5060?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/icmp/endpoint.go:58 +0x30
github.com/servak/go-fastping.(*Pinger).recvICMP(0xc00082afc0, 0xc000072f40, 0xc00087fe60, 0xc000072f60, 0xc001ba6f60?)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:570 +0x145
created by github.com/servak/go-fastping.(*Pinger).run
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:425 +0x398

goroutine 3107 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0012667e0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1919 [select, 2 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0xc00264c340)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1155 +0x233
created by google.golang.org/grpc/internal/transport.NewServerTransport
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:344 +0x1bf8

goroutine 1002 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobObserver[...]).start(0x3ba05e0, {0x3bb5780, 0xc0006ee690?}, 0x90000000008ca, {{{0xc000fc59e0, 0x1, 0x1}}, {0x3be6410, 0xc0015ccfc0}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:480 +0x409
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 1001 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobObserver[...]).start(0x3ba0560, {0x3bb5780, 0xc0006ee600?}, 0x0, {{{0xc000fc59e0, 0x1, 0x1}}, {0x3be6410, 0xc0015ccfc0}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:480 +0x409
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 998 [syscall, 3 minutes]:
syscall.Syscall6(0x20?, 0x80000000000?, 0xc001efb958?, 0x4eaee6?, 0xc000082180?, 0xc001efba08?, 0x4eae23?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x36
golang.org/x/sys/unix.EpollWait(0x0?, {0xc001172900?, 0xc000082180?, 0xc001efb9f0?}, 0xc001efba70?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:56 +0x58
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:125
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0xc0010c3420, {0xc001172900?, 0x20, 0x20}, {0x0?, 0xc001efbac0?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x2b4
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0xc002132480, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:345 +0x2d6
github.com/cilium/ebpf/perf.(*Reader).Read(0xc0002202a0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:319 +0x46
github.com/cilium/cilium/pkg/signal.(*signalManager).start.func1()
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:266 +0x8d
created by github.com/cilium/cilium/pkg/signal.(*signalManager).start
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:263 +0x12c

goroutine 997 [semacquire, 3 minutes]:
sync.runtime_Semacquire(0x3124be0?)
	/usr/local/go/src/runtime/sema.go:62 +0x27
sync.(*WaitGroup).Wait(0xc000aa8480?)
	/usr/local/go/src/sync/waitgroup.go:116 +0x4b
github.com/cilium/cilium/api/v1/server.(*Server).Serve(0xc000aa8480)
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:385 +0x6b
github.com/cilium/cilium/daemon/cmd.runDaemon(_, _, _, {{{}}, {0x3b77d80, 0xc000db7d70}, {0x3bf05a0, 0xc000b976b0}, {0x3bdc150, 0xc001176b00}, ...})
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:1876 +0x15f3
github.com/cilium/cilium/daemon/cmd.newDaemonPromise.func1.1()
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:1657 +0x78
created by github.com/cilium/cilium/daemon/cmd.newDaemonPromise.func1
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:1656 +0x198

goroutine 996 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1.1()
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:417 +0xcd
created by github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:413 +0x9b

goroutine 2825 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029d8120, {0xc000816c00, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00359d090}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3108 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029e7440, {0xc001df8a10, 0x0, 0xc003994f30, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001dac910}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3106 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001dac870})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029e6fc0, {0xc001693310, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001dac870}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3029 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00143c390, 0x27)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000fcc7a0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc00143c340, {0x3bb56d8, 0xc0032b9360}, {0xc0028df8b0, 0x42}, 0x8, {0xc001dc1705, 0x9}, {0xc000fcc7a0, 0x1, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 1067 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000454b86, 0x10, 0x1a}, {0xc00045fbf0, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 912 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00020f440, {0xc000453518, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0006df810}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2969 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002c5f320, {0xc0010327e0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001c521e0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3119 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000ad4500)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 988 [syscall, 3 minutes]:
syscall.Syscall6(0x451705?, 0xc000f2ff48?, 0xc002065ce0?, 0x443fd1?, 0xc000f2ff70?, 0xc002065d10?, 0xc000a44ea0?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x36
os.(*Process).blockUntilWaitable(0xc000ca1620)
	/usr/local/go/src/os/wait_waitid.go:32 +0x87
os.(*Process).wait(0xc000ca1620)
	/usr/local/go/src/os/exec_unix.go:22 +0x28
os.(*Process).Wait(...)
	/usr/local/go/src/os/exec.go:132
os/exec.(*Cmd).Wait(0xc001336dc0)
	/usr/local/go/src/os/exec/exec.go:890 +0x45
github.com/cilium/cilium/pkg/launcher.(*Launcher).Run.func1()
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:48 +0x45
created by github.com/cilium/cilium/pkg/launcher.(*Launcher).Run
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:47 +0x4db

goroutine 1920 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7fdee7a5e770, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc00376dc80?, 0xc003bd4580?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00376dc80, {0xc003bd4580, 0x580, 0x580})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc00376dc80, {0xc003bd4580?, 0xc003bd4585?, 0x1a?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc0008983f8, {0xc003bd4580?, 0x40dd2a?, 0xc001aeb330?})
	/usr/local/go/src/net/net.go:183 +0x45
crypto/tls.(*atLeastReader).Read(0xc00138c4e0, {0xc003bd4580?, 0xc00138c4e0?, 0x0?})
	/usr/local/go/src/crypto/tls/conn.go:788 +0x3d
bytes.(*Buffer).ReadFrom(0xc001aeb410, {0x3b720a0, 0xc00138c4e0})
	/usr/local/go/src/bytes/buffer.go:202 +0x98
crypto/tls.(*Conn).readFromUntil(0xc001aeb180, {0x3b88060?, 0xc0008983f8}, 0x580?)
	/usr/local/go/src/crypto/tls/conn.go:810 +0xe5
crypto/tls.(*Conn).readRecordOrCCS(0xc001aeb180, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:617 +0x116
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:583
crypto/tls.(*Conn).Read(0xc001aeb180, {0xc003bf4000, 0x8000, 0x0?})
	/usr/local/go/src/crypto/tls/conn.go:1316 +0x16f
bufio.(*Reader).Read(0xc0007cbc20, {0xc000518660, 0x9, 0x30?})
	/usr/local/go/src/bufio/bufio.go:237 +0x1bb
io.ReadAtLeast({0x3b71ea0, 0xc0007cbc20}, {0xc000518660, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
golang.org/x/net/http2.readFrameHeader({0xc000518660?, 0x9?, 0xc003bc6f00?}, {0x3b71ea0?, 0xc0007cbc20?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x6e
golang.org/x/net/http2.(*Framer).ReadFrame(0xc000518620)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x95
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0xc00264c340, 0x0?, 0x46c985?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:642 +0x167
google.golang.org/grpc.(*Server).serveStreams(0xc002a8e000, {0x3bcc8e0?, 0xc00264c340})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:946 +0x162
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:889 +0x46
created by google.golang.org/grpc.(*Server).handleRawConn
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:888 +0x185

goroutine 2963 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc002382280, {0xc0017e5ea0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc002382280, {0xc0017e5ea0?, 0xc002fdef48?, 0xc002d7d560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc003b18690, {0xc0017e5ea0?, 0xc002d7d5d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc003b18690}, {0xc0017e5ea0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc000a2e000, {0xc0017e5ea0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc0017e5e90, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc002d7d7a8?, 0xc000a2e000, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7fdee7ab8480, 0x5e20750}, 0xc002d7d9f8?, {0x0?, 0x0?}, {0x3472d60, 0xc0007fe640}, 0xc003532c00?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc0011af3b0, {0x3472d60?, 0xc0007fe640})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/cilium/api.(*networkPolicyDiscoveryServiceStreamNetworkPoliciesServer).Recv(0xc0012cbd00)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/cilium/api/npds.pb.go:1709 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc0029dca20?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 1206 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001414d46, 0x10, 0x1a}, {0xc00178bb30, 0x24}, 0xc002c7e6f0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 989 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000ad46e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2910 [select, 1 minutes]:
reflect.rselect({0xc0029d8480, 0x9, 0xc002ab8798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc0033bf000?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001410570, {0x3bb5780, 0xc0049da7e0}, 0xc002928690, {0x7fdee7ae8e50, 0xc000ab9ca0}, 0xc002bbeba0, {0x36f79e0?, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001410570, {0x3bb5780, 0xc0049da7e0}, {0x7fdee7ae8e50?, 0xc000ab9ca0?}, {0x36f79e0, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamEndpoints(0xc002e2ab30?, {0x3bc6d60, 0xc000ab9ca0})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:121 +0x70
github.com/cilium/proxy/go/envoy/service/endpoint/v3._EndpointDiscoveryService_StreamEndpoints_Handler({0x34ffc60?, 0xc001410570}, {0x3bc0368?, 0xc001bf43c0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:338 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001e1c000, {0x3bcc8e0, 0xc001c04b60}, 0xc002ec50e0, 0xc00143be30, 0x58808a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001e1c000, {0x3bcc8e0, 0xc001c04b60}, 0xc002ec50e0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 3273 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001280360, {0xc00102c700, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001c53a90}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1047 [select, 3 minutes]:
github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch.func2()
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:138 +0x185
created by github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:135 +0x258

goroutine 1929 [select, 2 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func1()
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:59 +0xcf
golang.org/x/sync/errgroup.(*Group).Go.func1()
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:75 +0x64
created by golang.org/x/sync/errgroup.(*Group).Go
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:72 +0xa5

goroutine 363 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0012b0360, {0xc001119560, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002c82e60}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1010 [select, 3 minutes]:
github.com/cilium/cilium/pkg/maps/ctmap/gc.Enable.func1()
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:115 +0x3a5
created by github.com/cilium/cilium/pkg/maps/ctmap/gc.Enable
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:43 +0x20a

goroutine 1358 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002eff560, {0xc001de9420, 0x0, 0xc0026af020, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0006b3720}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3279 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0035b2626, 0x10, 0x1a}, {0xc00247edb0, 0x24}, 0xc0015d2920?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 348 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001280000, {0xc00012c000, 0x0, 0x3805780, 0x0, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000384460}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1014 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000f82320)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1015 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0006b2fa0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0012bac60, {0xc000f20900, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0006b2fa0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1016 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0018a4840?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1017 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0012bb200, {0xc00019d500, 0x0, 0xc001735380, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0006b3040}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1055 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0007d70e0, {0xc00110d310, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002c821e0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1020 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0012bb680, {0xc0007eb248, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0006b33b0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 358 [select, 3 minutes]:
github.com/cilium/cilium/pkg/stream.FromChannel[...].func1.1()
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:109 +0xde
created by github.com/cilium/cilium/pkg/stream.FromChannel[...].func1
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:106 +0xea

goroutine 1023 [sleep]:
time.Sleep(0x12a05f200)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer(0xc001735bc0)
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:123 +0x54d
created by github.com/cilium/cilium/cilium-health/launch.Launch
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:68 +0x225

goroutine 1024 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000839c20, {0xc000de6ca8, 0x0, 0xc000de6cc0, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0005c8690}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1027 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1028 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1029 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1030 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1031 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1032 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1033 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1034 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1035 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1036 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1037 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1038 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1039 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1040 [IO wait]:
internal/poll.runtime_pollWait(0x7fdee7ecb1e8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc000829900?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc000829900)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc000829900)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*TCPListener).accept(0xc000de7050)
	/usr/local/go/src/net/tcpsock_posix.go:148 +0x25
net.(*TCPListener).Accept(0xc000de7050)
	/usr/local/go/src/net/tcpsock.go:297 +0x3d
net/http.(*Server).Serve(0xc001720000, {0x3bb3640, 0xc000de7050})
	/usr/local/go/src/net/http/server.go:3059 +0x385
github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService.func2({0xc000fcebb0, 0xe}, {0x3bb3640, 0xc000de7050})
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:75 +0xdb
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:70 +0x6aa

goroutine 3068 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00123b7a0, {0xc0006311f0, 0x0, 0xc00165aed0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0014acf50}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1457 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0008b0d80, {0xc0001da3f0, 0x0, 0xc001a60960, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0000cfbd0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1356 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0006b3680})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002eff0e0, {0xc000b616b0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0006b3680}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1587 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00138a6c0, {0xc0011a38c0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000246ff0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1186 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001dc0506, 0x10, 0x1a}, {0xc001b30930, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1443 [IO wait]:
internal/poll.runtime_pollWait(0x7fdee7e083a8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc004505300?, 0xc0009da000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc004505300, {0xc0009da000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc004505300, {0xc0009da000?, 0x2?, 0x588a5a0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc00064c280, {0xc0009da000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*persistConn).Read(0xc00137d7a0, {0xc0009da000?, 0x44d520?, 0xc002a99ec8?})
	/usr/local/go/src/net/http/transport.go:1943 +0x4e
bufio.(*Reader).fill(0xc0017972c0)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc0017972c0, 0x1)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*persistConn).readLoop(0xc00137d7a0)
	/usr/local/go/src/net/http/transport.go:2107 +0x1ac
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1765 +0x16ea

goroutine 749 [select, 3 minutes]:
github.com/cilium/cilium/pkg/fswatcher.(*Watcher).loop(0xc00107ac60)
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:210 +0xdd
created by github.com/cilium/cilium/pkg/fswatcher.New
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:98 +0x1ea

goroutine 1049 [chan receive, 3 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func5()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:302 +0x3e
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:301 +0x2f2c

goroutine 1048 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7fdee7a5efe0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc0010dc300?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0010dc300)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc0010dc300)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*TCPListener).accept(0xc0007eacc0)
	/usr/local/go/src/net/tcpsock_posix.go:148 +0x25
net.(*TCPListener).Accept(0xc0007eacc0)
	/usr/local/go/src/net/tcpsock.go:297 +0x3d
google.golang.org/grpc.(*Server).Serve(0xc002a8e000, {0x3bb3640?, 0xc0007eacc0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:821 +0x475
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func4()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:293 +0x65
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:292 +0x2eac

goroutine 1091 [IO wait]:
internal/poll.runtime_pollWait(0x7fdee7a5eef0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc002981780?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc002981780)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc002981780)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*UnixListener).accept(0x46e74e?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x1c
net.(*UnixListener).Accept(0xc00032cb70)
	/usr/local/go/src/net/unixsock.go:260 +0x3d
net/http.(*Server).Serve(0xc00294f770, {0x3bb3670, 0xc00032cb70})
	/usr/local/go/src/net/http/server.go:3059 +0x385
github.com/cilium/cilium/api/v1/server.(*Server).Start.func1({0x3bb3670?, 0xc00032cb70?})
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:433 +0x85
created by github.com/cilium/cilium/api/v1/server.(*Server).Start
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:431 +0x552

goroutine 365 [select]:
github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:334 +0x8a
created by github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:330 +0x65

goroutine 1175 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0014148a6, 0x10, 0x1a}, {0xc00178b860, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1210 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001414d66, 0x10, 0x1a}, {0xc00178bc20, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 3150 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000efad80, {0xc001afba40, 0x0, 0xc002a6e420, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002482b40}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1262 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0018ae5a0, {0xc000739120, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000385b30}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3023 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc001c52820, {0xc0017bdfc0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc001c52820, {0xc0017bdfc0?, 0xc002efb728?, 0xc000af5560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc000bd9380, {0xc0017bdfc0?, 0xc000af55d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc000bd9380}, {0xc0017bdfc0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc002ec5200, {0xc0017bdfc0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc0017bdfb0, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc000af57a8?, 0xc002ec5200, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7fdee7ab8480, 0x5e20750}, 0xc000af59f8?, {0x0?, 0x0?}, {0x3472d60, 0xc0007fef00}, 0xc00289baa0?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc001721d10, {0x3472d60?, 0xc0007fef00})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/endpoint/v3.(*endpointDiscoveryServiceStreamEndpointsServer).Recv(0xc0010766f0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:357 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc0033d8780?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 1573 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x284f97f?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00139a080?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2924 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7fdee7e08498, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc002050e00?, 0xc00207f000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002050e00, {0xc00207f000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc002050e00, {0xc00207f000?, 0x43c147?, 0xc00286cc30?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000a83fb8, {0xc00207f000?, 0x0?, 0xc00109bba0?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*persistConn).Read(0xc001365e60, {0xc00207f000?, 0xc0028edf20?, 0xc00286cd30?})
	/usr/local/go/src/net/http/transport.go:1943 +0x4e
bufio.(*Reader).fill(0xc0035329c0)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc0035329c0, 0x1)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*persistConn).readLoop(0xc001365e60)
	/usr/local/go/src/net/http/transport.go:2107 +0x1ac
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1765 +0x16ea

goroutine 1345 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000abdae0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 3162 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001090746, 0x10, 0x1a}, {0xc0025065d0, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2908 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc001e2f950, {0xc001410ac0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc001e2f950, {0xc001410ac0?, 0xc002fc90c8?, 0xc002c6b560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc0017db710, {0xc001410ac0?, 0xc002c6b5d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc0017db710}, {0xc001410ac0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc001480fc0, {0xc001410ac0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc001410ab0, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc002c6b7a8?, 0xc001480fc0, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7fdee7ab8480, 0x5e20750}, 0xc002c6b9f8?, {0x0?, 0x0?}, {0x3472d60, 0xc0020ae5a0}, 0xc00150bc20?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc002ec04b0, {0x3472d60?, 0xc0020ae5a0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/endpoint/v3.(*endpointDiscoveryServiceStreamEndpointsServer).Recv(0xc00072db30)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:357 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc000819170?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 1240 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002ea00a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1716 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002eff9e0, {0xc0001dbb90, 0x0, 0xc00298a750, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000a146e0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1236 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000b82e06, 0x10, 0x1a}, {0xc0028f60c0, 0x24}, 0x0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1412 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0001a7b00, {0xc0008bd548, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001f65590}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1104 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0018e5666, 0x10, 0x1a}, {0xc0029eefc0, 0x24}, 0x0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1288 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1287 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc002522730})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00256f320, {0xc0016b85a0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc002522730}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1214 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002d57560, {0xc001293098, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002d1f220}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1054 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0007d67e0, {0xc0013339d0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002c820a0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1259 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0006c8000, {0xc000de7b30, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000a14960}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2880 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0020ae780)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1714 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc000a14640})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002eff440, {0xc001640390, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc000a14640}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1280 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc002f16a50})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002f3aa20, {0xc0017374b0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc002f16a50}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1197 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0011d0d20)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1444 [select]:
net/http.(*persistConn).writeLoop(0xc00137d7a0)
	/usr/local/go/src/net/http/transport.go:2410 +0xf2
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1766 +0x173d

goroutine 1199 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc002b92fa0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002bfa360, {0xc00173e5e0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc002b92fa0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1200 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc001314400?, 0x2b60c88?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00012cbc0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1297 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002bfa7e0, {0xc0002041c0, 0x0, 0xc002bcd9b0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002b93040}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1313 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc0029fc700?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc002f223c0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1314 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002f3aea0, {0xc0001f9340, 0x0, 0xc002f46180, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002f16af0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3186 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0037337c0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0013eb8c0, {0xc0015d2360, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0037337c0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 364 [select]:
github.com/servak/go-fastping.(*Pinger).run(0xc00082afc0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:439 +0x611
created by github.com/servak/go-fastping.(*Pinger).RunLoop
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:362 +0x14a

goroutine 366 [IO wait]:
internal/poll.runtime_pollWait(0x7fdee7a5e2c0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc000f9f900?, 0x16?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc000f9f900)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc000f9f900)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*UnixListener).accept(0x46e74e?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x1c
net.(*UnixListener).Accept(0xc002c7bc20)
	/usr/local/go/src/net/unixsock.go:260 +0x3d
net/http.(*Server).Serve(0xc0026ce000, {0x3bb3670, 0xc002c7bc20})
	/usr/local/go/src/net/http/server.go:3059 +0x385
github.com/cilium/cilium/api/v1/health/server.(*Server).Start.func1({0x3bb3670?, 0xc002c7bc20?})
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:326 +0x85
created by github.com/cilium/cilium/api/v1/health/server.(*Server).Start
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:324 +0x52f

goroutine 1304 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc003034c60, {0xc00177e8a0, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002b93a40}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1308 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0011d1360)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1344 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000ad43c0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1310 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0030545f0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc003057200, {0xc000ab8910, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0030545f0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1311 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1312 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc003057680, {0xc00024a930, 0x0, 0xc0030640f0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc003054690}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1244 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001384fc0, {0xc000abfaf0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000376690}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1347 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc002d1f860})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00308f7a0, {0xc00174ab20, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc002d1f860}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1348 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0011ec5c0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1349 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00308fc20, {0xc00020d6c0, 0x0, 0xc0030a41b0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002d1f900}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1918 [select, 2 minutes]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0xc003bce230, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x115
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0xc001b3bc70)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x91
google.golang.org/grpc/internal/transport.NewServerTransport.func2()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:341 +0xda
created by google.golang.org/grpc/internal/transport.NewServerTransport
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:338 +0x1bb3

goroutine 1321 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc000376500})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002f4d0e0, {0xc0010c4320, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc000376500}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1322 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0011ec5c0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1323 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002f4d560, {0xc000470690, 0x0, 0xc00100d350, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0003765a0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1357 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x284f97f?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000ef72d0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1362 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/health/server.(*Server).Serve(0xc000b46a00)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:373 +0xee
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer.func1()
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:91 +0x77
created by github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:89 +0x1e5

goroutine 1417 [select]:
net/http.(*persistConn).writeLoop(0xc00135d440)
	/usr/local/go/src/net/http/transport.go:2410 +0xf2
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1766 +0x173d

goroutine 1370 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc002d1fd60})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001ba5200, {0xc0010c5b00, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc002d1fd60}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1371 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x2a85c9f?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0008b6de0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1372 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001ba59e0, {0xc00020ca80, 0x0, 0xc002eef7a0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002d1fe00}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4614 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001ba4b40, {0xc00019cc40, 0x0, 0xc002b37800, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002efd220}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1374 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0013fe240, {0xc0007eb6f8, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000247130}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1428 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0012e87e0, {0xc00174b4e0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0004ff310}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1430 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0009781e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1391 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00137cfc0, {0xc00177f9e0, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002d1ec30}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1915 [select, 2 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0xc00264c000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1155 +0x233
created by google.golang.org/grpc/internal/transport.NewServerTransport
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:344 +0x1bf8

goroutine 1451 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0013859e0, {0xc000174730, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0006356d0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1449 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0013ae5a0, {0xc0012937b8, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000cf3590}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1715 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1572 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0004ff040})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0013eb560, {0xc00139aea0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0004ff040}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1509 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001266ea0, {0xc00138d038, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002d1e820}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1928 [semacquire, 2 minutes]:
sync.runtime_Semacquire(0x5?)
	/usr/local/go/src/runtime/sema.go:62 +0x27
sync.(*WaitGroup).Wait(0x0?)
	/usr/local/go/src/sync/waitgroup.go:116 +0x4b
golang.org/x/sync/errgroup.(*Group).Wait(0xc00045b480)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:53 +0x27
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify(0xc00081ac40, 0x32b8e80?, {0x3bc2a20?, 0xc00073f510})
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:107 +0x43b
github.com/cilium/cilium/api/v1/peer._Peer_Notify_Handler({0x3027f60?, 0xc00081ac40}, {0x3bc0368, 0xc002f3e0f0})
	/go/src/github.com/cilium/cilium/api/v1/peer/peer_grpc.pb.go:114 +0xd0
google.golang.org/grpc.(*Server).processStreamingRPC(0xc002a8e000, {0x3bcc8e0, 0xc00264c000}, 0xc0012ba6c0, 0xc00100ce40, 0x5876aa0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc002a8e000, {0x3bcc8e0, 0xc00264c000}, 0xc0012ba6c0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 3528 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0014ade00})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0012bb440, {0xc0012a1250, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0014ade00}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3464 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001a9eb40, {0xc000739a70, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0034f8410}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1931 [select, 2 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*buffer).Pop(0xc00045b4c0)
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/buffer.go:80 +0x11e
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func3()
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:91 +0x3f
golang.org/x/sync/errgroup.(*Group).Go.func1()
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:75 +0x64
created by golang.org/x/sync/errgroup.(*Group).Go
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:72 +0xa5

goroutine 1916 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7fdee7a5e950, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc002f14380?, 0xc003bd4000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002f14380, {0xc003bd4000, 0x580, 0x580})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc002f14380, {0xc003bd4000?, 0xc003bd4005?, 0x2f?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000a823b0, {0xc003bd4000?, 0x4291a0?, 0xc001aea1b0?})
	/usr/local/go/src/net/net.go:183 +0x45
crypto/tls.(*atLeastReader).Read(0xc001489a88, {0xc003bd4000?, 0xc001489a88?, 0x0?})
	/usr/local/go/src/crypto/tls/conn.go:788 +0x3d
bytes.(*Buffer).ReadFrom(0xc001aea290, {0x3b720a0, 0xc001489a88})
	/usr/local/go/src/bytes/buffer.go:202 +0x98
crypto/tls.(*Conn).readFromUntil(0xc001aea000, {0x3b88060?, 0xc000a823b0}, 0x580?)
	/usr/local/go/src/crypto/tls/conn.go:810 +0xe5
crypto/tls.(*Conn).readRecordOrCCS(0xc001aea000, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:617 +0x116
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:583
crypto/tls.(*Conn).Read(0xc001aea000, {0xc003bdc000, 0x8000, 0xc002309cc8?})
	/usr/local/go/src/crypto/tls/conn.go:1316 +0x16f
bufio.(*Reader).Read(0xc0007cb320, {0xc0005184a0, 0x9, 0xc002309cf0?})
	/usr/local/go/src/bufio/bufio.go:237 +0x1bb
io.ReadAtLeast({0x3b71ea0, 0xc0007cb320}, {0xc0005184a0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
golang.org/x/net/http2.readFrameHeader({0xc0005184a0?, 0x9?, 0x3b86be0?}, {0x3b71ea0?, 0xc0007cb320?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x6e
golang.org/x/net/http2.(*Framer).ReadFrame(0xc000518460)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x95
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0xc00264c000, 0xc0037f7738?, 0x2df30e0?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:642 +0x167
google.golang.org/grpc.(*Server).serveStreams(0xc002a8e000, {0x3bcc8e0?, 0xc00264c000})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:946 +0x162
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:889 +0x46
created by google.golang.org/grpc.(*Server).handleRawConn
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:888 +0x185

goroutine 3062 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001251c20, {0xc00091c138, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0036e6b40}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2936 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc00143c610, 0x1)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000340e00?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc00143c5c0, {0x3bb56d8, 0xc001e2f9a0}, {0xc000a29580, 0x3c}, 0x2, {0xc0018e5445, 0x9}, {0xc000175400, 0x1, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 2937 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc001e2f860, {0xc0012f25f8, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc001e2f860, {0xc0012f25f8?, 0xc002fc90b0?, 0xc001e4f560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc0017db5c0, {0xc0012f25f8?, 0xc001e4f5d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc0017db5c0}, {0xc0012f25f8, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc001480ea0, {0xc0012f25f8, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc0012f25e8, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc001e4f7a8?, 0xc001480ea0, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7fdee7ab8480, 0x5e20750}, 0xc001e4f9f8?, {0x0?, 0x0?}, {0x3472d60, 0xc000467a40}, 0xc00333be60?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc0026ce4b0, {0x3472d60?, 0xc000467a40})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/endpoint/v3.(*endpointDiscoveryServiceStreamEndpointsServer).Recv(0xc000175540)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:357 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc0013dad80?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 3188 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0008b0000, {0xc000604850, 0x0, 0xc00300f950, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc003733860}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3477 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0xff8800010a7b?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 3266 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0035b22a6, 0x10, 0x1a}, {0xc00247e1e0, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2977 [select]:
reflect.rselect({0xc004699e60, 0x9, 0xc001d40798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc002400000?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001410570, {0x3bb5780, 0xc000818450}, 0xc0001d30a0, {0x7fdee7eabd48, 0xc0012cbd00}, 0xc0014e7920, {0x3696c3c?, 0x28})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001410570, {0x3bb5780, 0xc000818450}, {0x7fdee7eabd48?, 0xc0012cbd00?}, {0x3696c3c, 0x28})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamNetworkPolicies(0xc002e26b30?, {0x3bc6ba8, 0xc0012cbd00})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:145 +0x70
github.com/cilium/proxy/go/cilium/api._NetworkPolicyDiscoveryService_StreamNetworkPolicies_Handler({0x34ffc60?, 0xc001410570}, {0x3bc0368?, 0xc0011af3b0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/cilium/api/npds.pb.go:1690 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001e1c000, {0x3bcc8e0, 0xc001c04b60}, 0xc000a2e000, 0xc001e1e090, 0x5876d00, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001e1c000, {0x3bcc8e0, 0xc001c04b60}, 0xc000a2e000, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 3529 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc0031c8901?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001400eb0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 3364 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0035ae546, 0x10, 0x1a}, {0xc001df4f60, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 4314 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc00324c701?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00304a180?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 3485 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00179d7a0, {0xc000ef7360, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000265e50}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3067 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc000a32a50?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 3158 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0010906e6, 0x10, 0x1a}, {0xc002506540, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 3026 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc001c52730, {0xc00177fe70, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc001c52730, {0xc00177fe70?, 0xc002efb710?, 0xc000965560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc000bd9230, {0xc00177fe70?, 0xc0009655d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc000bd9230}, {0xc00177fe70, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc002ec50e0, {0xc00177fe70, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc00177fe60, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc0009657a8?, 0xc002ec50e0, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7fdee7ab8480, 0x5e20750}, 0xc0009659f8?, {0x0?, 0x0?}, {0x3472d60, 0xc000df0d20}, 0xc000951ce0?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc001bf43c0, {0x3472d60?, 0xc000df0d20})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/endpoint/v3.(*endpointDiscoveryServiceStreamEndpointsServer).Recv(0xc000ab9ca0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:357 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc0031a3980?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 3144 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0018ae240, {0xc001871740, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0024825a0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3206 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0013cafc0, {0xc00110dc80, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002c879f0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3148 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc002482aa0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000efa120, {0xc001013370, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc002482aa0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3474 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0027b4000)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 3149 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc001caafd0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00102cb70?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 3211 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0035ae3c6, 0x10, 0x1a}, {0xc001df4d80, 0x24}, 0xc000fcd7a0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2925 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0xc001365e60)
	/usr/local/go/src/net/http/transport.go:2410 +0xf2
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1766 +0x173d

goroutine 4699 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc00012f166, 0x10, 0x1a}, {0xc003e3c6f0, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 3137 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001daddb0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001ab6120, {0xc001012850, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001daddb0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3146 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000ad4780)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 3563 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00143c390, 0x29)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc001400f60?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc00143c340, {0x3bb56d8, 0xc00359c820}, {0xc0008fd860, 0x42}, 0xe, {0xc001414ee5, 0x9}, {0xc001400f60, 0x1, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 3525 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00143c390, 0x28)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0012a09d0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc00143c340, {0x3bb56d8, 0xc003054c80}, {0xc002bb0640, 0x42}, 0xd, {0xc0012531a5, 0x9}, {0xc0012a09d0, 0x1, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 2942 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00143c390, 0x26)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000ee2390?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc00143c340, {0x3bb56d8, 0xc001e2fe00}, {0xc00315b8b0, 0x42}, 0x7, {0xc001a5f2c5, 0x9}, {0xc000ee2390, 0x1, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 2928 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000943d66, 0x10, 0x1a}, {0xc00333eae0, 0x24}, 0xc000313a90?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2926 [select, 1 minutes]:
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:103 +0x71
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:102 +0x10a

goroutine 2848 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc001e2f770, {0xc00177fdb0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc001e2f770, {0xc00177fdb0?, 0xc002fc9098?, 0xc00374f560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc0017db470, {0xc00177fdb0?, 0xc00374f5d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc0017db470}, {0xc00177fdb0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc001480d80, {0xc00177fdb0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc00177fda0, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc00374f7a8?, 0xc001480d80, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7fdee7ab8480, 0x5e20750}, 0x5?, {0x0?, 0x0?}, {0x3472d60, 0xc0027b40a0}, 0xc00289a000?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc001bf42d0, {0x3472d60?, 0xc0027b40a0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/endpoint/v3.(*endpointDiscoveryServiceStreamEndpointsServer).Recv(0xc000ab94d0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:357 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc00296b9e0?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 3138 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc002785401?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc003377260?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 3139 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001ab66c0, {0xc001afa2a0, 0x0, 0xc002a4c930, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001dade50}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3040 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000ad40a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2912 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc00143c310, 0x1)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000340e00?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc00143c2c0, {0x3bb56d8, 0xc001c52870}, {0xc001c7e300, 0x33}, 0x6, {0xc001a5f505, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 3066 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0014acdc0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00123b200, {0xc0004ccb70, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0014acdc0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3031 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029505a0, {0xc000924120, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0032b9770}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2978 [select, 1 minutes]:
reflect.rselect({0xc001481440, 0x9, 0xc002416798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc002400400?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001410570, {0x3bb5780, 0xc000818b40}, 0xc0001d3730, {0x7fdee7eabea0, 0xc001736630}, 0xc0014e7bc0, {0x36e8b90?, 0x3c})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001410570, {0x3bb5780, 0xc000818b40}, {0x7fdee7eabea0?, 0xc001736630?}, {0x36e8b90, 0x3c})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamRoutes(0xc0034eeb30?, {0x3bc6ec0, 0xc001736630})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:93 +0x70
github.com/cilium/proxy/go/envoy/service/route/v3._RouteDiscoveryService_StreamRoutes_Handler({0x34ffc60?, 0xc001410570}, {0x3bc0368?, 0xc0011af4a0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/route/v3/rds.pb.go:346 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001e1c000, {0x3bcc8e0, 0xc001c04b60}, 0xc000a2e360, 0xc00143bf50, 0x5880920, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001e1c000, {0x3bcc8e0, 0xc001c04b60}, 0xc000a2e360, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 2911 [select, 1 minutes]:
reflect.rselect({0xc003035320, 0x9, 0xc001e72798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc002355a00?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001410570, {0x3bb5780, 0xc001a603c0}, 0xc0023fdc70, {0x7fdee7ae8e50, 0xc0010766f0}, 0xc002875740, {0x36f79e0?, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001410570, {0x3bb5780, 0xc001a603c0}, {0x7fdee7ae8e50?, 0xc0010766f0?}, {0x36f79e0, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamEndpoints(0xc002069b30?, {0x3bc6d60, 0xc0010766f0})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:121 +0x70
github.com/cilium/proxy/go/envoy/service/endpoint/v3._EndpointDiscoveryService_StreamEndpoints_Handler({0x34ffc60?, 0xc001410570}, {0x3bc0368?, 0xc001721d10})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:338 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001e1c000, {0x3bcc8e0, 0xc001c04b60}, 0xc002ec5200, 0xc00143be30, 0x58808a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001e1c000, {0x3bcc8e0, 0xc001c04b60}, 0xc002ec5200, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 2965 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc002382370, {0xc0017e5f48, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc002382370, {0xc0017e5f48?, 0xc002fdef60?, 0xc001c87560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc003b187e0, {0xc0017e5f48?, 0xc001c875d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc003b187e0}, {0xc0017e5f48, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc000a2e360, {0xc0017e5f48, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc0017e5f38, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc001c877a8?, 0xc000a2e360, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7fdee7ab8480, 0x5e20750}, 0xc001c879f8?, {0x0?, 0x0?}, {0x3472d60, 0xc000df0960}, 0xc003533140?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc0011af4a0, {0x3472d60?, 0xc000df0960})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/route/v3.(*routeDiscoveryServiceStreamRoutesServer).Recv(0xc001736630)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/route/v3/rds.pb.go:365 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc003532fc0?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 3168 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001267680, {0xc001033600, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001c53db0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3486 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0020ae000)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2944 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029d8b40, {0xc0012f27e0, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0029da190}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3050 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000e801e6, 0x10, 0x1a}, {0xc001c63fb0, 0x24}, 0xc003369a40?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 3131 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002869d40, {0xc000738780, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00240f540}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3128 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000454346, 0x10, 0x1a}, {0xc0020ec300, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 3000 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0035b20e6, 0x10, 0x1a}, {0xc00247f170, 0x24}, 0xc002e12360?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 3239 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0030e82e6, 0x10, 0x1a}, {0xc003038210, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 3282 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001552446, 0x10, 0x1a}, {0xc000e7a8d0, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 3313 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001552866, 0x10, 0x1a}, {0xc000e7b260, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 3317 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0004670e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 3319 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc002517a40})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00292f320, {0xc000f10a60, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc002517a40}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3320 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc002921101?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00303b740?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 3321 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00292f7a0, {0xc001aca0e0, 0x0, 0xc003009440, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002517ae0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3325 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000467180)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 3327 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001d56050})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0013ae6c0, {0xc000f10f30, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001d56050}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3328 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc00240e320?, 0xc002409580?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc003533500?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 3329 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0013aeb40, {0xc001acabd0, 0x0, 0xc0015b4720, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001d561e0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3526 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0020ae640)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 3335 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001552b26, 0x10, 0x1a}, {0xc0035b8600, 0x24}, 0xc0011ec5c0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 4612 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc002efd180})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001ba46c0, {0xc0018b00e0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc002efd180}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3576 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0018dd440, {0xc001870f90, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0006dfd10}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3616 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00308f320, {0xc00088c588, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0032fee60}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3064 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0027b4140)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 3056 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000efb0e0, {0xc0012f2c78, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0029db900}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3476 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc00240ecd0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0017d99e0, {0xc00116f8f0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc00240ecd0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3248 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0013da900, {0xc000abe6c0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002c67f40}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3435 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0014b1e60, {0xc0013bd170, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002522e10}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4690 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002f3a6c0, {0xc00463f0e0, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002fdcfa0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4299 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000b83c46, 0x10, 0x1a}, {0xc0040e9980, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 3530 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00179c120, {0xc00052a540, 0x0, 0xc0049f2390, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000264140}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3617 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x45d964b800?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00296a7e0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 3488 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc00324d040})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001ac6ea0, {0xc0012a14c0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc00324d040}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3227 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc00184c906, 0x10, 0x1a}, {0xc00045fec0, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 3668 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc00285d220)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 4606 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0044fcd20})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029510e0, {0xc000ab9c70, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0044fcd20}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3693 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002689680, {0xc0007aa120, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001f07130}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3520 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001dccea0, {0xc001afb500, 0x0, 0xc0018a5c80, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001dad1d0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3519 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x284f97f?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0011ec5c0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 3518 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001dad130})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001dcc7e0, {0xc0018b0520, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001dad130}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4591 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0032428c6, 0x10, 0x1a}, {0xc003d24ae0, 0x24}, 0xc001191f10?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 5174 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00143c490, 0x18)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000340e00?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc00143c440, {0x3bb56d8, 0xc0046d4370}, {0xc0046d2300, 0x28}, 0x2a, {0xc000943dc5, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 4311 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc00285cbe0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 4610 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000f83180)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 4315 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00403d440, {0xc0040400e0, 0x0, 0xc0040313b0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00402b540}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4613 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc002f12f90?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 3858 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002bb2d80, {0xc0013f6820, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001564e10}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3844 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00148d560, {0xc001332a10, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00184e230}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3926 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0028699e0, {0xc001333240, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001ed5f40}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4608 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002951560, {0xc003e6f0a0, 0x0, 0xc002ad1a10, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0044fcdc0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4604 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0011d0b40)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 3937 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002c5e000, {0xc000d9b090, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00217c780}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3919 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00143c390, 0x2a)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000340e00?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc00143c340, {0x3bb56d8, 0xc001f061e0}, {0xc004092140, 0x42}, 0xf, {0xc0001659c5, 0x9}, {0xc0005b47c0, 0x1, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 3785 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0018dd7a0, {0xc0012f2660, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001582b90}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4313 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc00402b4a0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00403cfc0, {0xc001756380, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc00402b4a0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4361 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001dd67e0, {0xc00163b070, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0030d20a0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4899 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0012b1680, {0xc0012b7900, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002c2a280}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4357 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00148c360, {0xc00159b278, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc004321630}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4373 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0035ae026, 0x10, 0x1a}, {0xc003d48420, 0x24}, 0xc0014f5800?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 4127 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001ae97a0, {0xc003266e70, 0x0, 0xc0027d65d0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc004063e50}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4422 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001fcc900, {0xc00073e0f0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc004207f90}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4126 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc003ae0fd0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00173e730?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 3933 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0012519e0, {0xc00174bd70, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0032fe3c0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4123 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002035180)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 4087 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004297560, {0xc001a64198, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc004286690}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4607 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc0012923c0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00032ce70?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 4682 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0013cb7a0, {0xc001770480, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0029d4910}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2
