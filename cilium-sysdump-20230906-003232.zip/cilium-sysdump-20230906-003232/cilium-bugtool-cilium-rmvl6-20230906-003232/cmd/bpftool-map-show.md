11: hash_of_maps  name cgroup_hash  flags 0x0
	key 8B  value 4B  max_entries 2048  memlock 168000B
12: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
13: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
14: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
15: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
16: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
17: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
18: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
19: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
20: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
21: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
22: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
23: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
24: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
25: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
26: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
27: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
28: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
29: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
30: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
31: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
32: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
33: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
34: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
35: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
36: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
37: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
38: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
39: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
40: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
41: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
42: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
43: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
44: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
45: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
46: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
47: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
48: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
49: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
50: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
51: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
52: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
53: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
54: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
55: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
56: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
57: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
58: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
59: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
60: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
61: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
62: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
63: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
64: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
65: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
66: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
67: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
68: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
69: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
70: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
71: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
72: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
73: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
74: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
75: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
76: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
77: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
78: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
79: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
80: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
81: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
82: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
83: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
84: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
85: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
86: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
87: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
88: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
89: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
90: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
91: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
92: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
93: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
94: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
95: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
96: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
97: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
98: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
99: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
100: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
101: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
102: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
103: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
104: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
105: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
106: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
107: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
108: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
109: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
110: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
111: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
112: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
113: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
114: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
115: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
118: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
119: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
120: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
121: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
122: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
123: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
124: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
125: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
126: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
127: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
128: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
129: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
130: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
131: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
132: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
133: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
134: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
135: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
136: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
137: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
138: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
139: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
140: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
141: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
142: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
143: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
144: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
145: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
146: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
147: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
148: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
149: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
150: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
151: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
152: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
153: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
156: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
157: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
160: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
161: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
162: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
163: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
164: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
165: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
166: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
167: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
170: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
171: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
219: hash  name cilium_auth_map  flags 0x1
	key 12B  value 8B  max_entries 524288  memlock 8390464B
220: array  name cilium_runtime_  flags 0x0
	key 4B  value 8B  max_entries 256  memlock 2368B
221: perf_event_array  name cilium_signals  flags 0x0
	key 4B  value 4B  max_entries 32  memlock 576B
222: hash  name cilium_node_map  flags 0x1
	key 20B  value 2B  max_entries 16384  memlock 264176B
223: perf_event_array  name cilium_events  flags 0x0
	key 4B  value 4B  max_entries 32  memlock 576B
224: hash  name cilium_lxc  flags 0x1
	key 20B  value 48B  max_entries 65535  memlock 1054400B
225: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 2376B
226: percpu_hash  name cilium_metrics  flags 0x1
	key 8B  value 16B  max_entries 1024  memlock 20640B
227: hash  name cilium_tunnel_m  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 1050432B
228: lru_hash  name cilium_lb4_reve  flags 0x0
	key 16B  value 8B  max_entries 73193  memlock 7368904B
229: hash  name cilium_lb4_serv  flags 0x1
	key 12B  value 12B  max_entries 65536  memlock 1054304B
230: hash  name cilium_lb4_back  flags 0x1
	key 4B  value 12B  max_entries 65536  memlock 1052032B
231: hash  name cilium_lb4_reve  flags 0x1
	key 2B  value 6B  max_entries 65536  memlock 1052160B
232: prog_array  name cilium_call_pol  flags 0x0
	key 4B  value 4B  max_entries 65535  memlock 524600B
	owner_prog_type sched_cls  owner jited
233: prog_array  name cilium_egressca  flags 0x0
	key 4B  value 4B  max_entries 65535  memlock 524600B
	owner_prog_type sched_cls  owner jited
234: lru_hash  name cilium_ct4_glob  flags 0x0
	key 14B  value 56B  max_entries 146386  memlock 21762480B
235: lru_hash  name cilium_ct_any4_  flags 0x0
	key 14B  value 56B  max_entries 73193  memlock 10882168B
236: lru_hash  name cilium_snat_v4_  flags 0x0
	key 14B  value 40B  max_entries 146386  memlock 19420304B
237: lru_hash  name cilium_nodeport  flags 0x0
	key 4B  value 8B  max_entries 146386  memlock 13564864B
238: lru_hash  name cilium_ipv4_fra  flags 0x0
	key 12B  value 4B  max_entries 8192  memlock 722752B
239: hash  name cilium_lb_affin  flags 0x1
	key 8B  value 1B  max_entries 65536  memlock 1050432B
240: lru_hash  name cilium_lb4_affi  flags 0x0
	key 16B  value 16B  max_entries 65536  memlock 6293312B
241: lpm_trie  name cilium_lb4_sour  flags 0x1
	key 12B  value 1B  max_entries 65536  memlock 0B
245: hash  name cilium_l2_respo  flags 0x1
	key 8B  value 8B  max_entries 4096  memlock 67464B
	btf_id 224
246: array  name cilium_encrypt_  flags 0x0
	key 4B  value 1B  max_entries 1  memlock 328B
	btf_id 225
247: prog_array  name cilium_calls_ov  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
248: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 144B
249: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
251: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
252: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
253: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
255: prog_array  name cilium_calls_ho  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
258: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
259: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
261: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 295
262: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
263: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
264: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 302
265: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 303
266: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
267: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
268: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 305
276: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
277: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
278: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
279: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
280: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 380
281: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 381
282: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
283: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 384
284: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
285: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
286: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
287: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 410
292: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
293: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
294: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 436
296: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
297: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
298: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 450
301: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
302: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
303: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 464
305: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
306: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
307: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 478
327: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
328: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
329: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
330: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 552
331: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
332: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 556
333: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
334: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
335: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 571
336: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
337: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
340: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
341: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 594
342: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
343: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 601
344: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
345: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 606
346: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
353: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
354: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 636
355: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
357: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
358: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 650
359: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
373: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
374: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
375: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 692
389: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
390: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
391: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 748
394: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
395: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
396: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
397: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 762
398: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
399: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 764
400: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
401: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
402: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 775
409: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
410: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
411: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 804
413: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
414: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
415: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 818
421: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
422: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 832
423: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
429: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
430: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 846
431: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
