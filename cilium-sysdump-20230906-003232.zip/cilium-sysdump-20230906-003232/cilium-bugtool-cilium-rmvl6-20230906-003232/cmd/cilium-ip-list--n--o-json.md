[
  {
    "cidr": "0.0.0.0/0",
    "identity": 2
  },
  {
    "cidr": "10.244.0.8/32",
    "hostIP": "172.17.0.2",
    "identity": 17496,
    "metadata": {
      "name": "frontend-58b6bf847f-mvjq9",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.9/32",
    "hostIP": "172.17.0.2",
    "identity": 45914,
    "metadata": {
      "name": "hubble-ui-6b468cff75-nxd77",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.12/32",
    "hostIP": "172.17.0.2",
    "identity": 17496,
    "metadata": {
      "name": "frontend-58b6bf847f-mxkjg",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.23/32",
    "hostIP": "172.17.0.2",
    "identity": 55452,
    "metadata": {
      "name": "hubble-relay-777496bf44-dqbz5",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.37/32",
    "hostIP": "172.17.0.2",
    "identity": 6361,
    "metadata": {
      "name": "postgres-migrations-tzn7j",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.42/32",
    "hostIP": "172.17.0.2",
    "identity": 34488,
    "metadata": {
      "name": "uninstall-agents-r95rd",
      "namespace": "ambassador",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.54/32",
    "hostIP": "172.17.0.2",
    "identity": 12645,
    "metadata": {
      "name": "openebs-ndm-cluster-exporter-589554f487-vj6lq",
      "namespace": "openebs",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.59/32",
    "hostIP": "172.17.0.2",
    "identity": 1
  },
  {
    "cidr": "10.244.0.75/32",
    "hostIP": "172.17.0.2",
    "identity": 22396,
    "metadata": {
      "name": "kratos-77cbf98c8f-ds6vd",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.80/32",
    "hostIP": "172.17.0.2",
    "identity": 27280,
    "metadata": {
      "name": "streamchat-79dfbb9bb4-2dtq5",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.90/32",
    "hostIP": "172.17.0.2",
    "identity": 37048,
    "metadata": {
      "name": "cert-manager-webhook-879c48cd4-r5snx",
      "namespace": "cert-manager",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.98/32",
    "hostIP": "172.17.0.2",
    "identity": 20605,
    "metadata": {
      "name": "create-minio-buckets-8m6q5",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.101/32",
    "hostIP": "172.17.0.2",
    "identity": 17496,
    "metadata": {
      "name": "frontend-58b6bf847f-m8jq6",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.118/32",
    "hostIP": "172.17.0.2",
    "identity": 37704,
    "metadata": {
      "name": "backend-855f6c7b4-ljz8j",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.126/32",
    "hostIP": "172.17.0.2",
    "identity": 15689,
    "metadata": {
      "name": "openebs-ndm-operator-7c667b76f8-5v8jv",
      "namespace": "openebs",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.132/32",
    "hostIP": "172.17.0.2",
    "identity": 4
  },
  {
    "cidr": "10.244.0.133/32",
    "hostIP": "172.17.0.2",
    "identity": 32231,
    "metadata": {
      "name": "traffic-manager-55d995585d-brtlj",
      "namespace": "ambassador",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.135/32",
    "hostIP": "172.17.0.2",
    "identity": 4302,
    "metadata": {
      "name": "cert-manager-78ddc5db85-5w8zx",
      "namespace": "cert-manager",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.148/32",
    "hostIP": "172.17.0.2",
    "identity": 32223,
    "metadata": {
      "name": "minio-d496dbccf-8lwv6",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.157/32",
    "hostIP": "172.17.0.2",
    "identity": 16036,
    "metadata": {
      "name": "openebs-ndm-node-exporter-xwb7s",
      "namespace": "openebs",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.159/32",
    "hostIP": "172.17.0.2",
    "identity": 49098,
    "metadata": {
      "name": "cert-manager-cainjector-6774f986b-q46zg",
      "namespace": "cert-manager",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.167/32",
    "hostIP": "172.17.0.2",
    "identity": 53642,
    "metadata": {
      "name": "postgres-7c845b6448-rs4t6",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.180/32",
    "hostIP": "172.17.0.2",
    "identity": 37704,
    "metadata": {
      "name": "backend-855f6c7b4-p8vjz",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.194/32",
    "hostIP": "172.17.0.2",
    "identity": 20017,
    "metadata": {
      "name": "openebs-localpv-provisioner-7d6ccb7795-czbsm",
      "namespace": "openebs",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.202/32",
    "hostIP": "172.17.0.2",
    "identity": 1728,
    "metadata": {
      "name": "redis-68c95977f4-jf9bx",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.220/32",
    "hostIP": "172.17.0.2",
    "identity": 17496,
    "metadata": {
      "name": "frontend-58b6bf847f-br98b",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.222/32",
    "hostIP": "172.17.0.2",
    "identity": 20924,
    "metadata": {
      "name": "pgweb-b74849bb6-757xs",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.223/32",
    "hostIP": "172.17.0.2",
    "identity": 5031,
    "metadata": {
      "name": "coredns-878bb57ff-r6bcw",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.228/32",
    "hostIP": "172.17.0.2",
    "identity": 31997,
    "metadata": {
      "name": "metrics-server-7f86dff975-6286h",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.230/32",
    "hostIP": "172.17.0.2",
    "identity": 8
  },
  {
    "cidr": "10.244.0.242/32",
    "hostIP": "172.17.0.2",
    "identity": 2536,
    "metadata": {
      "name": "livestreamdb-6877b6fc75-qmm5g",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "172.17.0.2/32",
    "identity": 1
  }
]

