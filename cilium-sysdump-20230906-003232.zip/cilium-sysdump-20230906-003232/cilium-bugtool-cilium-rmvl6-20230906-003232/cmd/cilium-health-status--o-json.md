{
  "local": {
    "name": "k0s"
  },
  "nodes": [
    {
      "endpoint": {
        "http": {
          "latency": 151059
        },
        "icmp": {
          "latency": 89613
        },
        "ip": "10.244.0.132"
      },
      "health-endpoint": {
        "primary-address": {
          "http": {
            "latency": 151059
          },
          "icmp": {
            "latency": 89613
          },
          "ip": "10.244.0.132"
        },
        "secondary-addresses": []
      },
      "host": {
        "primary-address": {
          "http": {
            "latency": 141940
          },
          "icmp": {
            "latency": 73404
          },
          "ip": "172.17.0.2"
        },
        "secondary-addresses": []
      },
      "name": "k0s"
    }
  ],
  "timestamp": "2023-09-05T22:32:20Z"
}

