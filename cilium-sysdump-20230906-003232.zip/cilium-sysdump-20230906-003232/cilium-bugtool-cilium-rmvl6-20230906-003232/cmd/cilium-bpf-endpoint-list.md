IP ADDRESS       LOCAL ENDPOINT INFO
10.244.0.202:0   id=3475  sec_id=1728  flags=0x0000 ifindex=63  mac=3A:36:37:42:87:11 nodemac=3A:5C:E0:E1:7C:4F   
10.244.0.135:0   id=441   sec_id=4302  flags=0x0000 ifindex=29  mac=D6:D6:AA:16:B0:8E nodemac=16:36:68:00:C9:7A   
10.244.0.8:0     id=3130  sec_id=17496 flags=0x0000 ifindex=37  mac=02:D2:7B:9C:53:13 nodemac=22:9F:12:96:40:88   
10.244.0.101:0   id=2422  sec_id=17496 flags=0x0000 ifindex=43  mac=BA:E5:1E:D4:E6:B8 nodemac=F2:CB:09:1D:6C:0F   
10.244.0.180:0   id=688   sec_id=37704 flags=0x0000 ifindex=35  mac=4A:53:50:F4:58:5A nodemac=22:B8:46:8F:47:D8   
10.244.0.75:0    id=546   sec_id=22396 flags=0x0000 ifindex=45  mac=32:14:8F:C6:23:F1 nodemac=12:C0:FF:CD:B8:C2   
172.17.0.2:0     (localhost)                                                                                      
10.244.0.80:0    id=3692  sec_id=27280 flags=0x0000 ifindex=65  mac=EA:F0:05:F0:34:EE nodemac=3E:CA:91:1E:97:A8   
10.244.0.133:0   id=889   sec_id=32231 flags=0x0000 ifindex=67  mac=76:69:DF:92:D5:F8 nodemac=22:40:09:0D:1F:D1   
10.244.0.90:0    id=1785  sec_id=37048 flags=0x0000 ifindex=15  mac=FA:C1:4D:F6:E6:20 nodemac=62:DD:3A:27:65:B4   
10.244.0.59:0    (localhost)                                                                                      
10.244.0.54:0    id=516   sec_id=12645 flags=0x0000 ifindex=17  mac=06:79:DC:82:B2:75 nodemac=FE:A9:C4:07:57:E2   
10.244.0.242:0   id=133   sec_id=2536  flags=0x0000 ifindex=71  mac=B2:70:1F:E7:23:6A nodemac=16:71:E1:94:80:51   
10.244.0.194:0   id=895   sec_id=20017 flags=0x0000 ifindex=25  mac=22:87:9B:CC:B1:B2 nodemac=EA:64:6A:77:DD:E8   
10.244.0.148:0   id=210   sec_id=32223 flags=0x0000 ifindex=73  mac=C6:DB:B8:08:23:3E nodemac=5E:1F:19:56:B9:5D   
10.244.0.9:0     id=142   sec_id=45914 flags=0x0000 ifindex=21  mac=5E:F7:8A:65:DE:CE nodemac=86:AB:C1:4A:36:E4   
10.244.0.167:0   id=1187  sec_id=53642 flags=0x0000 ifindex=69  mac=EA:47:F9:8C:D8:EB nodemac=1E:9F:A5:91:F9:99   
10.244.0.222:0   id=3122  sec_id=20924 flags=0x0000 ifindex=59  mac=BE:FE:16:9A:CA:FB nodemac=5E:5A:0F:EC:8D:EE   
10.244.0.223:0   id=353   sec_id=5031  flags=0x0000 ifindex=19  mac=DE:E7:F6:BE:E0:BC nodemac=EE:D1:BA:89:C0:1D   
10.244.0.42:0    id=281   sec_id=34488 flags=0x0000 ifindex=75  mac=F6:AE:47:AA:2C:62 nodemac=5E:52:C6:1A:AC:89   
10.244.0.118:0   id=2870  sec_id=37704 flags=0x0000 ifindex=33  mac=F2:90:77:72:49:3F nodemac=A2:E5:9B:6F:1A:C1   
10.244.0.132:0   id=913   sec_id=4     flags=0x0000 ifindex=6   mac=36:1F:36:03:34:FF nodemac=2A:44:F8:9E:32:A0   
10.244.0.220:0   id=401   sec_id=17496 flags=0x0000 ifindex=39  mac=5E:D8:40:F2:1F:DB nodemac=02:46:51:46:A9:DD   
10.244.0.23:0    id=1055  sec_id=55452 flags=0x0000 ifindex=23  mac=AE:12:F7:AE:27:82 nodemac=A2:EA:D1:A6:14:9A   
10.244.0.98:0    id=1018  sec_id=20605 flags=0x0000 ifindex=55  mac=C6:49:39:CB:E2:DD nodemac=8A:73:1E:76:C5:8F   
10.244.0.228:0   id=2550  sec_id=31997 flags=0x0000 ifindex=9   mac=8E:2D:49:6E:FA:FF nodemac=B2:17:91:38:41:61   
10.244.0.12:0    id=1784  sec_id=17496 flags=0x0000 ifindex=41  mac=AA:52:0F:0E:0B:DA nodemac=FA:58:B1:0E:2B:19   
10.244.0.126:0   id=2675  sec_id=15689 flags=0x0000 ifindex=27  mac=1A:2B:D9:BB:36:A0 nodemac=7E:D3:C9:FA:4B:77   
10.244.0.157:0   id=104   sec_id=16036 flags=0x0000 ifindex=13  mac=5E:B2:A1:6E:61:C5 nodemac=7E:5C:19:11:58:5F   
10.244.0.159:0   id=235   sec_id=49098 flags=0x0000 ifindex=31  mac=5A:EE:B1:7F:7C:F5 nodemac=F6:97:A7:99:8D:68   
10.244.0.37:0    id=243   sec_id=6361  flags=0x0000 ifindex=49  mac=86:E1:6A:AE:07:14 nodemac=56:7D:67:49:1A:95   
