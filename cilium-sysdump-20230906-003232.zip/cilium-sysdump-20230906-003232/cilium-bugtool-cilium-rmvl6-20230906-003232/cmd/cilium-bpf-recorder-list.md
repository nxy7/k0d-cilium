Error: Unable to open /sys/fs/bpf/tc/globals/cilium_capture4_rules: loading pinned map /sys/fs/bpf/tc/globals/cilium_capture4_rules: no such file or directory
> Error while running 'cilium bpf recorder list':  exit status 1

