alloc: 62.87MB (65920768 bytes)
total-alloc: 607.98MB (637513568 bytes)
sys: 98.85MB (103653475 bytes)
lookups: 0
mallocs: 7860213
frees: 7234510
heap-alloc: 62.87MB (65920768 bytes)
heap-sys: 75.28MB (78938112 bytes)
heap-idle: 7.85MB (8232960 bytes)
heap-in-use: 67.43MB (70705152 bytes)
heap-released: 3.96MB (4153344 bytes)
heap-objects: 625703
stack-in-use: 8.72MB (9142272 bytes)
stack-sys: 8.72MB (9142272 bytes)
stack-mspan-inuse: 1.04MB (1095200 bytes)
stack-mspan-sys: 1.06MB (1109760 bytes)
stack-mcache-inuse: 14.06KB (14400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.75MB (1834627 bytes)
gc-sys: 10.38MB (10883128 bytes)
next-gc: when heap-alloc >= 68.89MB (72239424 bytes)
last-gc: 2023-09-05 22:31:59.431420487 +0000 UTC
gc-pause-total: 1.443382ms
gc-pause: 30048
gc-pause-end: 1693953119431420487
num-gc: 27
num-forced-gc: 0
gc-cpu-fraction: 0.00010237170162538686
enable-gc: true
debug-gc: false
