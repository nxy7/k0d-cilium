KVStore:                Ok   Disabled
Kubernetes:             Ok   1.27 (v1.27.4+k0s) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideEnvoyConfig", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumEnvoyConfig", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Secrets", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   True   [eth0 172.17.0.2]
Host firewall:          Disabled
CNI Chaining:           none
Cilium:                 Ok   1.14.1 (v1.14.1-c191ef6f)
NodeMonitor:            Listening for events on 32 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 31/254 allocated from 10.244.0.0/24, 
Allocated addresses:
  10.244.0.101 (streampai/frontend-58b6bf847f-m8jq6)
  10.244.0.118 (streampai/backend-855f6c7b4-ljz8j)
  10.244.0.12 (streampai/frontend-58b6bf847f-mxkjg)
  10.244.0.126 (openebs/openebs-ndm-operator-7c667b76f8-5v8jv)
  10.244.0.132 (health)
  10.244.0.133 (ambassador/traffic-manager-55d995585d-brtlj)
  10.244.0.135 (cert-manager/cert-manager-78ddc5db85-5w8zx)
  10.244.0.148 (streampai/minio-d496dbccf-8lwv6)
  10.244.0.157 (openebs/openebs-ndm-node-exporter-xwb7s)
  10.244.0.159 (cert-manager/cert-manager-cainjector-6774f986b-q46zg)
  10.244.0.167 (streampai/postgres-7c845b6448-rs4t6)
  10.244.0.180 (streampai/backend-855f6c7b4-p8vjz)
  10.244.0.194 (openebs/openebs-localpv-provisioner-7d6ccb7795-czbsm)
  10.244.0.202 (streampai/redis-68c95977f4-jf9bx)
  10.244.0.220 (streampai/frontend-58b6bf847f-br98b)
  10.244.0.222 (streampai/pgweb-b74849bb6-757xs)
  10.244.0.223 (kube-system/coredns-878bb57ff-r6bcw)
  10.244.0.228 (kube-system/metrics-server-7f86dff975-6286h)
  10.244.0.23 (kube-system/hubble-relay-777496bf44-dqbz5)
  10.244.0.230 (ingress)
  10.244.0.242 (streampai/livestreamdb-6877b6fc75-qmm5g)
  10.244.0.37 (streampai/postgres-migrations-tzn7j)
  10.244.0.42 (ambassador/uninstall-agents-r95rd)
  10.244.0.54 (openebs/openebs-ndm-cluster-exporter-589554f487-vj6lq)
  10.244.0.59 (router)
  10.244.0.75 (streampai/kratos-77cbf98c8f-ds6vd)
  10.244.0.8 (streampai/frontend-58b6bf847f-mvjq9)
  10.244.0.80 (streampai/streamchat-79dfbb9bb4-2dtq5)
  10.244.0.9 (kube-system/hubble-ui-6b468cff75-nxd77)
  10.244.0.90 (cert-manager/cert-manager-webhook-879c48cd4-r5snx)
  10.244.0.98 (streampai/create-minio-buckets-8m6q5)
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Host Routing:           Legacy
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      132/132 healthy
  Name                                  Last success   Last error   Count   Message
  cilium-health-ep                      15s ago        never        0       no error   
  dns-garbage-collector-job             23s ago        never        0       no error   
  endpoint-1018-regeneration-recovery   never          never        0       no error   
  endpoint-104-regeneration-recovery    never          never        0       no error   
  endpoint-1055-regeneration-recovery   never          never        0       no error   
  endpoint-1187-regeneration-recovery   never          never        0       no error   
  endpoint-133-regeneration-recovery    never          never        0       no error   
  endpoint-142-regeneration-recovery    never          never        0       no error   
  endpoint-1784-regeneration-recovery   never          never        0       no error   
  endpoint-1785-regeneration-recovery   never          never        0       no error   
  endpoint-210-regeneration-recovery    never          never        0       no error   
  endpoint-235-regeneration-recovery    never          never        0       no error   
  endpoint-2422-regeneration-recovery   never          never        0       no error   
  endpoint-243-regeneration-recovery    never          never        0       no error   
  endpoint-2550-regeneration-recovery   never          never        0       no error   
  endpoint-2675-regeneration-recovery   never          never        0       no error   
  endpoint-281-regeneration-recovery    never          never        0       no error   
  endpoint-2870-regeneration-recovery   never          never        0       no error   
  endpoint-3122-regeneration-recovery   never          never        0       no error   
  endpoint-3130-regeneration-recovery   never          never        0       no error   
  endpoint-3475-regeneration-recovery   never          never        0       no error   
  endpoint-353-regeneration-recovery    never          never        0       no error   
  endpoint-3656-regeneration-recovery   never          never        0       no error   
  endpoint-3692-regeneration-recovery   never          never        0       no error   
  endpoint-401-regeneration-recovery    never          never        0       no error   
  endpoint-441-regeneration-recovery    never          never        0       no error   
  endpoint-516-regeneration-recovery    never          never        0       no error   
  endpoint-546-regeneration-recovery    never          never        0       no error   
  endpoint-688-regeneration-recovery    never          never        0       no error   
  endpoint-889-regeneration-recovery    never          never        0       no error   
  endpoint-895-regeneration-recovery    never          never        0       no error   
  endpoint-913-regeneration-recovery    never          never        0       no error   
  endpoint-gc                           3m23s ago      never        0       no error   
  ipcache-inject-labels                 16s ago        3m18s ago    0       no error   
  k8s-heartbeat                         23s ago        never        0       no error   
  link-cache                            16s ago        never        0       no error   
  metricsmap-bpf-prom-sync              3s ago         never        0       no error   
  resolve-identity-1018                 55s ago        never        0       no error   
  resolve-identity-104                  3m16s ago      never        0       no error   
  resolve-identity-1055                 3m13s ago      never        0       no error   
  resolve-identity-1187                 42s ago        never        0       no error   
  resolve-identity-133                  41s ago        never        0       no error   
  resolve-identity-142                  3m14s ago      never        0       no error   
  resolve-identity-1784                 57s ago        never        0       no error   
  resolve-identity-1785                 3m14s ago      never        0       no error   
  resolve-identity-210                  35s ago        never        0       no error   
  resolve-identity-235                  3m11s ago      never        0       no error   
  resolve-identity-2422                 57s ago        never        0       no error   
  resolve-identity-243                  56s ago        never        0       no error   
  resolve-identity-2550                 3m16s ago      never        0       no error   
  resolve-identity-2675                 3m9s ago       never        0       no error   
  resolve-identity-281                  25s ago        never        0       no error   
  resolve-identity-2870                 57s ago        never        0       no error   
  resolve-identity-3122                 52s ago        never        0       no error   
  resolve-identity-3130                 57s ago        never        0       no error   
  resolve-identity-3475                 51s ago        never        0       no error   
  resolve-identity-353                  3m16s ago      never        0       no error   
  resolve-identity-3656                 2m56s ago      never        0       no error   
  resolve-identity-3692                 51s ago        never        0       no error   
  resolve-identity-401                  57s ago        never        0       no error   
  resolve-identity-441                  3m14s ago      never        0       no error   
  resolve-identity-516                  3m14s ago      never        0       no error   
  resolve-identity-546                  56s ago        never        0       no error   
  resolve-identity-688                  57s ago        never        0       no error   
  resolve-identity-889                  51s ago        never        0       no error   
  resolve-identity-895                  3m12s ago      never        0       no error   
  resolve-identity-913                  3m15s ago      never        0       no error   
  sync-host-ips                         16s ago        never        0       no error   
  sync-lb-maps-with-k8s-services        3m16s ago      never        0       no error   
  sync-policymap-1018                   25s ago        never        0       no error   
  sync-policymap-104                    25s ago        never        0       no error   
  sync-policymap-1055                   25s ago        never        0       no error   
  sync-policymap-1187                   25s ago        never        0       no error   
  sync-policymap-133                    25s ago        never        0       no error   
  sync-policymap-142                    25s ago        never        0       no error   
  sync-policymap-1784                   25s ago        never        0       no error   
  sync-policymap-1785                   25s ago        never        0       no error   
  sync-policymap-210                    25s ago        never        0       no error   
  sync-policymap-235                    25s ago        never        0       no error   
  sync-policymap-2422                   25s ago        never        0       no error   
  sync-policymap-243                    25s ago        never        0       no error   
  sync-policymap-2550                   25s ago        never        0       no error   
  sync-policymap-2675                   25s ago        never        0       no error   
  sync-policymap-281                    25s ago        never        0       no error   
  sync-policymap-2870                   25s ago        never        0       no error   
  sync-policymap-3122                   25s ago        never        0       no error   
  sync-policymap-3130                   25s ago        never        0       no error   
  sync-policymap-3475                   25s ago        never        0       no error   
  sync-policymap-353                    25s ago        never        0       no error   
  sync-policymap-3656                   25s ago        never        0       no error   
  sync-policymap-3692                   25s ago        never        0       no error   
  sync-policymap-401                    25s ago        never        0       no error   
  sync-policymap-441                    25s ago        never        0       no error   
  sync-policymap-516                    25s ago        never        0       no error   
  sync-policymap-546                    25s ago        never        0       no error   
  sync-policymap-688                    25s ago        never        0       no error   
  sync-policymap-889                    25s ago        never        0       no error   
  sync-policymap-895                    25s ago        never        0       no error   
  sync-policymap-913                    25s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1018)     3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (104)      5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1055)     2s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1187)     2s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (133)      1s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (142)      3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1784)     7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1785)     3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (210)      5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (235)      11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2422)     7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (243)      4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2550)     6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2675)     9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (281)      5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2870)     7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3122)     10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3130)     7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3475)     10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (353)      5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3656)     6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3692)     10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (401)      7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (441)      2s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (516)      3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (546)      5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (688)      7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (889)      10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (895)      1s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (913)      5s ago         never        0       no error   
  sync-utime                            16s ago        never        0       no error   
  template-dir-watcher                  never          never        0       no error   
  write-cni-file                        3m23s ago      never        0       no error   
Proxy Status:            OK, ip 10.244.0.59, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 256, max 65535
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 25.92   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 True
  Socket LB:              Enabled
  Socket LB Tracing:      Enabled
  Socket LB Coverage:     Full
  Devices:                eth0 172.17.0.2
  Mode:                   SNAT
  Backend Selection:      Random
  Session Affinity:       Enabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  XDP Acceleration:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Enabled (Range: 30000-32767) 
  - LoadBalancer:   Enabled 
  - externalIPs:    Enabled 
  - HostPort:       Enabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   73193
  TCP connection tracking       146386
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           146386
  Neighbor table                146386
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              73193
  Tunnel                        65536
Encryption:         Disabled        
Cluster health:     1/1 reachable   (2023-09-05T22:32:20Z)
  Name              IP              Node        Endpoints
  k0s (localhost)   172.17.0.2      reachable   reachable
