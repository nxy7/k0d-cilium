xdp:

tc:
cilium_net(2) clsact/ingress cil_to_host-cilium_net id 879
cilium_host(3) clsact/ingress cil_to_host-cilium_host id 864
cilium_host(3) clsact/egress cil_from_host-cilium_host id 868
cilium_vxlan(4) clsact/ingress cil_from_overlay-cilium_vxlan id 574
cilium_vxlan(4) clsact/egress cil_to_overlay-cilium_vxlan id 575
lxc_health(6) clsact/ingress cil_from_container-lxc_health id 638
eth0(7) clsact/ingress cil_from_netdev-eth0 id 900
eth0(7) clsact/egress cil_to_netdev-eth0 id 907
lxcd9fdefc20bbb(9) clsact/ingress cil_from_container-lxcd9fdefc20bbb id 674
lxc119ad3dfee62(13) clsact/ingress cil_from_container-lxc119ad3dfee62 id 698
lxc4848deb1985a(15) clsact/ingress cil_from_container-lxc4848deb1985a id 718
lxc8a558cabb5a1(17) clsact/ingress cil_from_container-lxc8a558cabb5a1 id 740
lxccedcb6c151a5(19) clsact/ingress cil_from_container-lxccedcb6c151a5 id 630
lxc346fa36d29b0(21) clsact/ingress cil_from_container-lxc346fa36d29b0 id 725
lxcfe16b37f78d3(23) clsact/ingress cil_from_container-lxcfe16b37f78d3 id 783
lxc37782ef37adb(25) clsact/ingress cil_from_container-lxc37782ef37adb id 802
lxc7bc95390c700(27) clsact/ingress cil_from_container-lxc7bc95390c700 id 836
lxcf3d11662b2bf(29) clsact/ingress cil_from_container-lxcf3d11662b2bf id 756
lxca6c1d0c986ff(31) clsact/ingress cil_from_container-lxca6c1d0c986ff id 815
lxcf7c2ea09d41d(33) clsact/ingress cil_from_container-lxcf7c2ea09d41d id 968
lxca94861d8ed77(35) clsact/ingress cil_from_container-lxca94861d8ed77 id 945
lxcc21955409817(37) clsact/ingress cil_from_container-lxcc21955409817 id 955
lxcf9603e308e74(39) clsact/ingress cil_from_container-lxcf9603e308e74 id 986
lxc4d1095406f91(41) clsact/ingress cil_from_container-lxc4d1095406f91 id 1021
lxc983f3c9d1402(43) clsact/ingress cil_from_container-lxc983f3c9d1402 id 1005
lxc0ef1ae825717(45) clsact/ingress cil_from_container-lxc0ef1ae825717 id 1042
lxca9dd546d2ddb(49) clsact/ingress cil_from_container-lxca9dd546d2ddb id 1065
lxc6ad0c51d5075(55) clsact/ingress cil_from_container-lxc6ad0c51d5075 id 1129
lxcc5cc5cdac255(59) clsact/ingress cil_from_container-lxcc5cc5cdac255 id 1182
lxc9ad5d7a32906(63) clsact/ingress cil_from_container-lxc9ad5d7a32906 id 1200
lxc81cfe30fa5c2(65) clsact/ingress cil_from_container-lxc81cfe30fa5c2 id 1226
lxc59e096dd7e22(67) clsact/ingress cil_from_container-lxc59e096dd7e22 id 1234
lxc12be36577ae9(69) clsact/ingress cil_from_container-lxc12be36577ae9 id 1260
lxc8b90fe1d5b0f(71) clsact/ingress cil_from_container-lxc8b90fe1d5b0f id 1281
lxc655b8d0b3ee4(73) clsact/ingress cil_from_container-lxc655b8d0b3ee4 id 1310
lxcba34e313be1c(75) clsact/ingress cil_from_container-lxcba34e313be1c id 1336

flow_dissector:

