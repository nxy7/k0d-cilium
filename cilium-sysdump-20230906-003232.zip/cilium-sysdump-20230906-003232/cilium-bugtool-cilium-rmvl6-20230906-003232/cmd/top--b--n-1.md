top - 22:32:34 up 33 min,  0 users,  load average: 1.66, 0.77, 0.40
Tasks:  18 total,  10 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 40.1 us, 53.8 sy,  0.0 ni,  4.9 id,  0.5 wa,  0.0 hi,  0.5 si,  0.0 st
MiB Mem :  15915.0 total,   1770.7 free,   4738.6 used,   9405.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.  10574.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    514 root      20   0    2928   1280   1280 R  66.7   0.0   0:00.10 cat
      1 root      20   0  879940 162504  68224 S  33.3   1.0   0:05.31 cilium-+
    522 root      20   0  786680  63340  41600 S  26.7   0.4   0:00.04 cilium
    372 root      20   0  725920  16896  10240 S  20.0   0.1   0:00.04 cilium-+
    523 root      20   0  786168  60160  41728 S  20.0   0.4   0:00.03 cilium
    557 root      20   0  785336  55424  39168 R  20.0   0.3   0:00.03 cilium
    588 root      20   0  785656  58112  40576 R  20.0   0.4   0:00.03 cilium
    562 root      20   0  785336  47872  38656 R  13.3   0.3   0:00.02 cilium
    573 root      20   0    3540   2176   2048 R  13.3   0.0   0:00.02 bpftool
    579 root      20   0  785592  50688  38528 R  13.3   0.3   0:00.02 cilium
    586 root      20   0  784568  33024  25856 R   6.7   0.2   0:00.01 cilium
    600 root      20   0  786616  39296  31104 R   6.7   0.2   0:00.01 cilium
    613 root      20   0  784312  30336  24064 R   6.7   0.2   0:00.01 cilium
    202 root      20   0  713924   4608   3712 S   0.0   0.0   0:00.00 cilium-+
    410 root      20   0    7180   3200   2816 R   0.0   0.0   0:00.00 top
    630 root      20   0  718940   7424   6144 S   0.0   0.0   0:00.00 runc:[2+
    638 root      20   0  783992  20736  17408 S   0.0   0.1   0:00.00 cilium
    639 root      20   0  783736   8704   8064 S   0.0   0.1   0:00.00 cilium
