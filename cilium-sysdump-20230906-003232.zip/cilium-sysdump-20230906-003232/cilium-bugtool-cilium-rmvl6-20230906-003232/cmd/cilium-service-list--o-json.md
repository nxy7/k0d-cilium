[
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.223",
          "nodeName": "k0s",
          "port": 53,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kube-dns",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.96.0.10",
        "port": 53,
        "scope": "external"
      },
      "id": 8
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.223",
            "nodeName": "k0s",
            "port": 53,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kube-dns",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.96.0.10",
          "port": 53,
          "scope": "external"
        },
        "id": 8
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.223",
          "nodeName": "k0s",
          "port": 9153,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kube-dns",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.96.0.10",
        "port": 9153,
        "scope": "external"
      },
      "id": 9
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.223",
            "nodeName": "k0s",
            "port": 9153,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kube-dns",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.96.0.10",
          "port": 9153,
          "scope": "external"
        },
        "id": 9
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "minio",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.104.163.144",
        "port": 9000,
        "scope": "external"
      },
      "id": 15
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "minio",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.104.163.144",
          "port": 9000,
          "scope": "external"
        },
        "id": 15
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cilium-gateway-sgtw",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.106.139.3",
        "port": 80,
        "scope": "external"
      },
      "id": 20
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cilium-gateway-sgtw",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.106.139.3",
          "port": 80,
          "scope": "external"
        },
        "id": 20
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.135",
          "nodeName": "k0s",
          "port": 9402,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cert-manager",
        "namespace": "cert-manager",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.110.36.32",
        "port": 9402,
        "scope": "external"
      },
      "id": 2
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.135",
            "nodeName": "k0s",
            "port": 9402,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cert-manager",
          "namespace": "cert-manager",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.110.36.32",
          "port": 9402,
          "scope": "external"
        },
        "id": 2
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.23",
          "nodeName": "k0s",
          "port": 4245,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "hubble-relay",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.226.243",
        "port": 80,
        "scope": "external"
      },
      "id": 6
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.23",
            "nodeName": "k0s",
            "port": 4245,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "hubble-relay",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.226.243",
          "port": 80,
          "scope": "external"
        },
        "id": 6
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "coqui",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.107.249.151",
        "port": 7000,
        "scope": "external"
      },
      "id": 11
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "coqui",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.107.249.151",
          "port": 7000,
          "scope": "external"
        },
        "id": 11
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.75",
          "nodeName": "k0s",
          "port": 4433,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kratos",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.98.191.110",
        "port": 4433,
        "scope": "external"
      },
      "id": 13
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.75",
            "nodeName": "k0s",
            "port": 4433,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kratos",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.98.191.110",
          "port": 4433,
          "scope": "external"
        },
        "id": 13
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.242",
          "nodeName": "k0s",
          "port": 5432,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "livestreamdb",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.110.82.62",
        "port": 5432,
        "scope": "external"
      },
      "id": 14
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.242",
            "nodeName": "k0s",
            "port": 5432,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "livestreamdb",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.110.82.62",
          "port": 5432,
          "scope": "external"
        },
        "id": 14
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.133",
          "nodeName": "k0s",
          "port": 443,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "agent-injector",
        "namespace": "ambassador",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.109.73.183",
        "port": 443,
        "scope": "external"
      },
      "id": 24
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.133",
            "nodeName": "k0s",
            "port": 443,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "agent-injector",
          "namespace": "ambassador",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.109.73.183",
          "port": 443,
          "scope": "external"
        },
        "id": 24
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.228",
          "nodeName": "k0s",
          "port": 10250,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "metrics-server",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.108.118.97",
        "port": 443,
        "scope": "external"
      },
      "id": 1
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.228",
            "nodeName": "k0s",
            "port": 10250,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "metrics-server",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.108.118.97",
          "port": 443,
          "scope": "external"
        },
        "id": 1
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.90",
          "nodeName": "k0s",
          "port": 10250,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cert-manager-webhook",
        "namespace": "cert-manager",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.96.9.116",
        "port": 443,
        "scope": "external"
      },
      "id": 3
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.90",
            "nodeName": "k0s",
            "port": 10250,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cert-manager-webhook",
          "namespace": "cert-manager",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.96.9.116",
          "port": 443,
          "scope": "external"
        },
        "id": 3
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "172.17.0.2",
          "nodeName": "k0s",
          "port": 4244,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Local",
        "name": "hubble-peer",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.194.198",
        "port": 443,
        "scope": "external"
      },
      "id": 5
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "172.17.0.2",
            "nodeName": "k0s",
            "port": 4244,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Local",
          "name": "hubble-peer",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.194.198",
          "port": 443,
          "scope": "external"
        },
        "id": 5
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "minio",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.104.163.144",
        "port": 9001,
        "scope": "external"
      },
      "id": 16
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "minio",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.104.163.144",
          "port": 9001,
          "scope": "external"
        },
        "id": 16
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.167",
          "nodeName": "k0s",
          "port": 5432,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "postgres",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.102.212.184",
        "port": 5432,
        "scope": "external"
      },
      "id": 18
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.167",
            "nodeName": "k0s",
            "port": 5432,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "postgres",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.102.212.184",
          "port": 5432,
          "scope": "external"
        },
        "id": 18
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cilium-gateway-sgtw",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "LoadBalancer"
      },
      "frontend-address": {
        "ip": "172.17.39.148",
        "port": 80,
        "scope": "external"
      },
      "id": 21
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cilium-gateway-sgtw",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "LoadBalancer"
        },
        "frontend-address": {
          "ip": "172.17.39.148",
          "port": 80,
          "scope": "external"
        },
        "id": 21
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cilium-gateway-sgtw",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "NodePort"
      },
      "frontend-address": {
        "ip": "172.17.0.2",
        "port": 31956,
        "scope": "external"
      },
      "id": 22
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cilium-gateway-sgtw",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "NodePort"
        },
        "frontend-address": {
          "ip": "172.17.0.2",
          "port": 31956,
          "scope": "external"
        },
        "id": 22
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "172.17.0.2",
          "port": 6443,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kubernetes",
        "namespace": "default",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.96.0.1",
        "port": 443,
        "scope": "external"
      },
      "id": 4
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "172.17.0.2",
            "port": 6443,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kubernetes",
          "namespace": "default",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.96.0.1",
          "port": 443,
          "scope": "external"
        },
        "id": 4
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.9",
          "nodeName": "k0s",
          "port": 8081,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "hubble-ui",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.101.180.15",
        "port": 80,
        "scope": "external"
      },
      "id": 7
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.9",
            "nodeName": "k0s",
            "port": 8081,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "hubble-ui",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.101.180.15",
          "port": 80,
          "scope": "external"
        },
        "id": 7
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.180",
          "nodeName": "k0s",
          "port": 7000,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.244.0.118",
          "nodeName": "k0s",
          "port": 7000,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "backend",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.101.253.206",
        "port": 7000,
        "scope": "external"
      },
      "id": 10
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.180",
            "nodeName": "k0s",
            "port": 7000,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.244.0.118",
            "nodeName": "k0s",
            "port": 7000,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "backend",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.101.253.206",
          "port": 7000,
          "scope": "external"
        },
        "id": 10
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.8",
          "nodeName": "k0s",
          "port": 3000,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.244.0.12",
          "nodeName": "k0s",
          "port": 3000,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.244.0.220",
          "nodeName": "k0s",
          "port": 3000,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.244.0.101",
          "nodeName": "k0s",
          "port": 3000,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "frontend",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.104.78.187",
        "port": 3000,
        "scope": "external"
      },
      "id": 12
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.8",
            "nodeName": "k0s",
            "port": 3000,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.244.0.12",
            "nodeName": "k0s",
            "port": 3000,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.244.0.220",
            "nodeName": "k0s",
            "port": 3000,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.244.0.101",
            "nodeName": "k0s",
            "port": 3000,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "frontend",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.104.78.187",
          "port": 3000,
          "scope": "external"
        },
        "id": 12
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "pgweb",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.102.204.154",
        "port": 8081,
        "scope": "external"
      },
      "id": 17
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "pgweb",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.102.204.154",
          "port": 8081,
          "scope": "external"
        },
        "id": 17
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.202",
          "nodeName": "k0s",
          "port": 6379,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "redis",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.102.231.26",
        "port": 6379,
        "scope": "external"
      },
      "id": 19
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.202",
            "nodeName": "k0s",
            "port": 6379,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "redis",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.102.231.26",
          "port": 6379,
          "scope": "external"
        },
        "id": 19
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cilium-gateway-sgtw",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "NodePort"
      },
      "frontend-address": {
        "ip": "0.0.0.0",
        "port": 31956,
        "scope": "external"
      },
      "id": 23
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cilium-gateway-sgtw",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "NodePort"
        },
        "frontend-address": {
          "ip": "0.0.0.0",
          "port": 31956,
          "scope": "external"
        },
        "id": 23
      }
    }
  }
]

