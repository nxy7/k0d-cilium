filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcba34e313be1c direct-action not_in_hw id 1336 tag d983c6ecb806dc00 jited 
