key: 01 00 00 00  value: 1d 3b 00 00
key: 07 00 00 00  value: 1c 3b 00 00
key: 0f 00 00 00  value: 17 3b 00 00
key: 11 00 00 00  value: 1a 3b 00 00
key: 24 00 00 00  value: 16 3b 00 00
key: 26 00 00 00  value: 1b 3b 00 00
Found 6 elements
