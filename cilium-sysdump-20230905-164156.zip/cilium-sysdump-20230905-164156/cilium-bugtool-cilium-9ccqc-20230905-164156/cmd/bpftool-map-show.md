11: hash_of_maps  name cgroup_hash  flags 0x0
	key 8B  value 4B  max_entries 2048  memlock 168000B
12: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
13: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
14: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
15: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
16: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
17: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
18: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
19: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
20: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
21: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
22: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
23: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
24: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
25: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
26: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
27: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
28: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
29: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
30: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
31: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
32: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
33: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
34: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
35: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
36: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
37: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
38: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
39: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
40: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
41: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
42: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
43: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
44: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
45: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
46: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
47: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
48: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
49: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
50: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
51: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
52: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
53: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
54: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
55: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
56: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
57: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
58: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
59: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
60: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
61: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
62: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
63: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
64: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
65: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
66: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
67: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
68: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
69: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
70: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
71: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
72: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
73: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
74: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
75: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
76: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
77: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
78: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
79: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
80: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
81: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
82: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
83: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
84: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
85: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
86: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
87: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
88: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
89: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
90: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
91: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
92: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
93: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
94: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
95: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
96: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
97: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
98: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
99: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
100: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
101: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
102: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
103: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
104: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
105: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
106: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
107: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
108: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
109: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
110: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
111: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
112: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
113: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
114: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
115: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
116: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
117: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
120: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
121: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
122: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
123: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
124: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
125: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
126: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
127: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
128: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
129: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
130: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
131: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
132: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
133: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
134: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
135: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
136: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
137: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
138: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
139: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
140: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
141: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
142: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
143: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
144: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
145: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
146: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
147: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
148: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
149: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
150: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
151: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
152: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
153: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
156: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
157: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
160: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
161: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
162: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
163: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
216: hash  name cilium_auth_map  flags 0x1
	key 12B  value 8B  max_entries 524288  memlock 8390464B
217: array  name cilium_runtime_  flags 0x0
	key 4B  value 8B  max_entries 256  memlock 2368B
218: perf_event_array  name cilium_signals  flags 0x0
	key 4B  value 4B  max_entries 32  memlock 576B
219: hash  name cilium_node_map  flags 0x1
	key 20B  value 2B  max_entries 16384  memlock 264968B
220: perf_event_array  name cilium_events  flags 0x0
	key 4B  value 4B  max_entries 32  memlock 576B
221: hash  name cilium_lxc  flags 0x1
	key 20B  value 48B  max_entries 65535  memlock 1054016B
222: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 1584B
223: percpu_hash  name cilium_metrics  flags 0x1
	key 8B  value 16B  max_entries 1024  memlock 21840B
224: hash  name cilium_tunnel_m  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 1050432B
225: lru_hash  name cilium_lb4_reve  flags 0x0
	key 16B  value 8B  max_entries 73193  memlock 7368904B
226: hash  name cilium_lb4_serv  flags 0x1
	key 12B  value 12B  max_entries 65536  memlock 1054568B
227: hash  name cilium_lb4_back  flags 0x1
	key 4B  value 12B  max_entries 65536  memlock 1052272B
228: hash  name cilium_lb4_reve  flags 0x1
	key 2B  value 6B  max_entries 65536  memlock 1052160B
229: prog_array  name cilium_call_pol  flags 0x0
	key 4B  value 4B  max_entries 65535  memlock 524600B
	owner_prog_type sched_cls  owner jited
230: prog_array  name cilium_egressca  flags 0x0
	key 4B  value 4B  max_entries 65535  memlock 524600B
	owner_prog_type sched_cls  owner jited
231: lru_hash  name cilium_ct4_glob  flags 0x0
	key 14B  value 56B  max_entries 146386  memlock 21762480B
232: lru_hash  name cilium_ct_any4_  flags 0x0
	key 14B  value 56B  max_entries 73193  memlock 10882168B
233: lru_hash  name cilium_snat_v4_  flags 0x0
	key 14B  value 40B  max_entries 146386  memlock 19420304B
234: lru_hash  name cilium_nodeport  flags 0x0
	key 4B  value 8B  max_entries 146386  memlock 13564864B
235: lru_hash  name cilium_ipv4_fra  flags 0x0
	key 12B  value 4B  max_entries 8192  memlock 722752B
236: hash  name cilium_lb_affin  flags 0x1
	key 8B  value 1B  max_entries 65536  memlock 1050432B
237: lru_hash  name cilium_lb4_affi  flags 0x0
	key 16B  value 16B  max_entries 65536  memlock 6293312B
238: lpm_trie  name cilium_lb4_sour  flags 0x1
	key 12B  value 1B  max_entries 65536  memlock 0B
240: array  name cilium_encrypt_  flags 0x0
	key 4B  value 1B  max_entries 1  memlock 328B
	btf_id 212
241: hash  name cilium_l2_respo  flags 0x1
	key 8B  value 8B  max_entries 4096  memlock 67464B
	btf_id 213
242: prog_array  name cilium_calls_ov  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
245: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
246: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
258: prog_array  name cilium_calls_ho  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
283: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
288: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
395: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 2592B
396: hash  name cilium_tunnel_m  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 1050432B
401: prog_array  name cilium_calls_ho  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
405: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
582: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
583: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
664: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 2592B
665: hash  name cilium_tunnel_m  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 1050432B
671: prog_array  name cilium_calls_ho  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
678: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
932: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 2232B
933: hash  name cilium_tunnel_m  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 1050432B
937: prog_array  name cilium_calls_ho  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
941: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
1678: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
1679: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
1898: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 2520B
1899: hash  name cilium_tunnel_m  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 1050432B
1909: prog_array  name cilium_calls_ho  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
1931: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
2658: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 1152B
2659: hash  name cilium_tunnel_m  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 1050432B
2672: prog_array  name cilium_calls_ho  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
2677: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
2789: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 648B
2790: hash  name cilium_tunnel_m  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 1050432B
2800: prog_array  name cilium_calls_ho  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
2804: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
2893: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 648B
2894: hash  name cilium_tunnel_m  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 1050432B
2899: prog_array  name cilium_calls_ho  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
2902: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
2984: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 2232B
2985: hash  name cilium_tunnel_m  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 1050432B
2989: prog_array  name cilium_calls_ho  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
2994: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3200: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
3201: array  flags 0x0
	key 4B  value 8B  max_entries 2  memlock 336B
3249: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 2160B
3250: hash  name cilium_tunnel_m  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 1050432B
3254: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 144B
3255: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3256: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3257: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3259: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3260: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3261: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3262: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3263: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3264: prog_array  name cilium_calls_ho  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3269: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3271: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 4897
3272: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3273: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 4899
3274: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3275: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3276: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 4900
3277: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3278: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3279: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 4903
3280: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 4904
3281: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3282: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3284: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 4909
3285: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3286: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 4910
3288: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 4911
3297: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3298: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 5023
3299: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3301: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3302: prog_array  name cilium_calls_04  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3303: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 5037
3306: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3307: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3308: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 5051
3310: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3311: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3312: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 5065
3328: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3329: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3330: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3331: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 5139
3332: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 5144
3333: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3334: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3335: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3336: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3337: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 5167
3338: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3340: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3341: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 5180
3342: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3343: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 5184
3352: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3354: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3355: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 5223
3357: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3358: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3359: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 5237
3383: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3384: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 5321
3385: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3388: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3390: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3391: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3392: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 5335
3393: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3394: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3395: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 5341
3398: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 5361
3399: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3413: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3414: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3415: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 5391
3417: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3418: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 5405
3419: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
3424: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 216B
3425: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 48B  max_entries 1  memlock 1864B
	btf_id 5419
3426: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 696B
	owner_prog_type sched_cls  owner jited
