markdown output at /tmp/cilium-bugtool-20230905-144157.809+0000-UTC-2859100440/cmd/cilium-debuginfo-20230905-144157.929+0000-UTC.md
json output at /tmp/cilium-bugtool-20230905-144157.809+0000-UTC-2859100440/cmd/cilium-debuginfo-20230905-144157.929+0000-UTC.json
