{
  "l2-announce-entries": [
    {"IP":"172.17.8.187","NetworkInterface":"eth0","Origins":[{"Name":"cilium-gateway-sgtw","Namespace":"streampai"}],"Deleted":false,"Revision":2}
  ]
}
