KVStore:                Ok   Disabled
Kubernetes:             Ok   1.27 (v1.27.4+k0s) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideEnvoyConfig", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumEnvoyConfig", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Secrets", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   True   [eth0 172.17.0.2]
Host firewall:          Disabled
CNI Chaining:           none
Cilium:                 Ok   1.14.1 (v1.14.1-c191ef6f)
NodeMonitor:            Listening for events on 32 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 28/254 allocated from 10.244.0.0/24, 
Allocated addresses:
  10.244.0.106 (cert-manager/cert-manager-78ddc5db85-nbbjs)
  10.244.0.112 (kube-system/metrics-server-7f86dff975-tb5rv)
  10.244.0.123 (openebs/openebs-ndm-cluster-exporter-589554f487-g4gzj)
  10.244.0.124 (streampai/redis-68c95977f4-5ldmf)
  10.244.0.129 (openebs/openebs-ndm-operator-7c667b76f8-8bkbl)
  10.244.0.130 (router)
  10.244.0.132 (streampai/postgres-7c845b6448-hmx74)
  10.244.0.137 (streampai/backend-855f6c7b4-2lvs2)
  10.244.0.143 (openebs/openebs-ndm-node-exporter-bg5c6)
  10.244.0.149 (openebs/openebs-localpv-provisioner-7d6ccb7795-pnpxg)
  10.244.0.159 (streampai/frontend-58b6bf847f-nzgv5)
  10.244.0.160 (streampai/frontend-58b6bf847f-sxngk)
  10.244.0.177 (streampai/streamchat-79dfbb9bb4-5bt4p)
  10.244.0.178 (streampai/pgweb-b74849bb6-rd2fs)
  10.244.0.222 (streampai/backend-855f6c7b4-j4k6m)
  10.244.0.231 (streampai/frontend-58b6bf847f-rm7qs)
  10.244.0.243 (ingress)
  10.244.0.26 (streampai/livestreamdb-6877b6fc75-7w45t)
  10.244.0.29 (health)
  10.244.0.40 (cert-manager/cert-manager-webhook-879c48cd4-qp49t)
  10.244.0.41 (streampai/frontend-58b6bf847f-xgnzm)
  10.244.0.46 (kube-system/hubble-ui-6b468cff75-zwm9s)
  10.244.0.47 (streampai/kratos-77cbf98c8f-k2l6k)
  10.244.0.49 (kube-system/coredns-878bb57ff-lgfbn)
  10.244.0.52 (cert-manager/cert-manager-cainjector-6774f986b-jw7hp)
  10.244.0.62 (streampai/minio-d496dbccf-8rsnz)
  10.244.0.81 (ambassador/traffic-manager-55d995585d-xn8tw)
  10.244.0.86 (kube-system/hubble-relay-777496bf44-h6sbk)
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Host Routing:           Legacy
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      120/120 healthy
  Name                                  Last success   Last error   Count   Message
  cilium-health-ep                      1m1s ago       never        0       no error   
  dns-garbage-collector-job             9s ago         never        0       no error   
  endpoint-105-regeneration-recovery    never          never        0       no error   
  endpoint-1111-regeneration-recovery   never          never        0       no error   
  endpoint-119-regeneration-recovery    never          never        0       no error   
  endpoint-1288-regeneration-recovery   never          never        0       no error   
  endpoint-1493-regeneration-recovery   never          never        0       no error   
  endpoint-160-regeneration-recovery    never          never        0       no error   
  endpoint-198-regeneration-recovery    never          never        0       no error   
  endpoint-208-regeneration-recovery    never          never        0       no error   
  endpoint-2128-regeneration-recovery   never          never        0       no error   
  endpoint-215-regeneration-recovery    never          never        0       no error   
  endpoint-2207-regeneration-recovery   never          never        0       no error   
  endpoint-2326-regeneration-recovery   never          never        0       no error   
  endpoint-2497-regeneration-recovery   never          never        0       no error   
  endpoint-257-regeneration-recovery    never          never        0       no error   
  endpoint-2747-regeneration-recovery   never          never        0       no error   
  endpoint-2856-regeneration-recovery   never          never        0       no error   
  endpoint-3903-regeneration-recovery   never          never        0       no error   
  endpoint-3933-regeneration-recovery   never          never        0       no error   
  endpoint-4067-regeneration-recovery   never          never        0       no error   
  endpoint-455-regeneration-recovery    never          never        0       no error   
  endpoint-471-regeneration-recovery    never          never        0       no error   
  endpoint-606-regeneration-recovery    never          never        0       no error   
  endpoint-626-regeneration-recovery    never          never        0       no error   
  endpoint-633-regeneration-recovery    never          never        0       no error   
  endpoint-645-regeneration-recovery    never          never        0       no error   
  endpoint-702-regeneration-recovery    never          never        0       no error   
  endpoint-82-regeneration-recovery     never          never        0       no error   
  endpoint-gc                           3m9s ago       never        0       no error   
  ipcache-inject-labels                 2s ago         3m4s ago     0       no error   
  k8s-heartbeat                         9s ago         never        0       no error   
  link-cache                            17s ago        never        0       no error   
  metricsmap-bpf-prom-sync              4s ago         never        0       no error   
  resolve-identity-105                  2m30s ago      never        0       no error   
  resolve-identity-1111                 2m48s ago      never        0       no error   
  resolve-identity-119                  3m2s ago       never        0       no error   
  resolve-identity-1288                 2m24s ago      never        0       no error   
  resolve-identity-1493                 2m29s ago      never        0       no error   
  resolve-identity-160                  3m1s ago       never        0       no error   
  resolve-identity-198                  3m2s ago       never        0       no error   
  resolve-identity-208                  2m56s ago      never        0       no error   
  resolve-identity-2128                 2m30s ago      never        0       no error   
  resolve-identity-215                  2m24s ago      never        0       no error   
  resolve-identity-2207                 3m2s ago       never        0       no error   
  resolve-identity-2326                 3m2s ago       never        0       no error   
  resolve-identity-2497                 2m25s ago      never        0       no error   
  resolve-identity-257                  2m30s ago      never        0       no error   
  resolve-identity-2747                 3m2s ago       never        0       no error   
  resolve-identity-2856                 2m30s ago      never        0       no error   
  resolve-identity-3903                 2m29s ago      never        0       no error   
  resolve-identity-3933                 2m57s ago      never        0       no error   
  resolve-identity-4067                 2m58s ago      never        0       no error   
  resolve-identity-455                  2m5s ago       never        0       no error   
  resolve-identity-471                  2m30s ago      never        0       no error   
  resolve-identity-606                  1m59s ago      never        0       no error   
  resolve-identity-626                  3m2s ago       never        0       no error   
  resolve-identity-633                  2m59s ago      never        0       no error   
  resolve-identity-645                  2m24s ago      never        0       no error   
  resolve-identity-702                  2m6s ago       never        0       no error   
  resolve-identity-82                   3m2s ago       never        0       no error   
  sync-host-ips                         2s ago         never        0       no error   
  sync-lb-maps-with-k8s-services        3m2s ago       never        0       no error   
  sync-policymap-105                    58s ago        never        0       no error   
  sync-policymap-1111                   58s ago        never        0       no error   
  sync-policymap-119                    58s ago        never        0       no error   
  sync-policymap-1288                   58s ago        never        0       no error   
  sync-policymap-1493                   58s ago        never        0       no error   
  sync-policymap-160                    58s ago        never        0       no error   
  sync-policymap-198                    58s ago        never        0       no error   
  sync-policymap-208                    58s ago        never        0       no error   
  sync-policymap-2128                   58s ago        never        0       no error   
  sync-policymap-215                    58s ago        never        0       no error   
  sync-policymap-2207                   58s ago        never        0       no error   
  sync-policymap-2326                   58s ago        never        0       no error   
  sync-policymap-2497                   58s ago        never        0       no error   
  sync-policymap-257                    58s ago        never        0       no error   
  sync-policymap-2747                   58s ago        never        0       no error   
  sync-policymap-2856                   58s ago        never        0       no error   
  sync-policymap-3903                   58s ago        never        0       no error   
  sync-policymap-3933                   58s ago        never        0       no error   
  sync-policymap-4067                   58s ago        never        0       no error   
  sync-policymap-455                    58s ago        never        0       no error   
  sync-policymap-471                    58s ago        never        0       no error   
  sync-policymap-606                    58s ago        never        0       no error   
  sync-policymap-626                    58s ago        never        0       no error   
  sync-policymap-633                    58s ago        never        0       no error   
  sync-policymap-645                    58s ago        never        0       no error   
  sync-policymap-702                    58s ago        never        0       no error   
  sync-policymap-82                     58s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (105)      10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1111)     8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (119)      9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1288)     3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1493)     8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (160)      11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (198)      10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (208)      5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2128)     9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (215)      2s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2207)     9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2326)     10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2497)     4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (257)      10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2747)     9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2856)     10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3903)     7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3933)     7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (4067)     8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (455)      5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (471)      10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (606)      9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (626)      10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (633)      8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (645)      3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (702)      6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (82)       12s ago        never        0       no error   
  sync-utime                            2s ago         never        0       no error   
  template-dir-watcher                  never          never        0       no error   
  write-cni-file                        3m9s ago       never        0       no error   
Proxy Status:            OK, ip 10.244.0.130, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 256, max 65535
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 29.48   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 True
  Socket LB:              Enabled
  Socket LB Tracing:      Enabled
  Socket LB Coverage:     Full
  Devices:                eth0 172.17.0.2
  Mode:                   SNAT
  Backend Selection:      Random
  Session Affinity:       Enabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  XDP Acceleration:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Enabled (Range: 30000-32767) 
  - LoadBalancer:   Enabled 
  - externalIPs:    Enabled 
  - HostPort:       Enabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   73193
  TCP connection tracking       146386
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           146386
  Neighbor table                146386
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              73193
  Tunnel                        65536
Encryption:         Disabled        
Cluster health:     1/1 reachable   (2023-09-05T14:41:57Z)
  Name              IP              Node        Endpoints
  k0s (localhost)   172.17.0.2      reachable   reachable
