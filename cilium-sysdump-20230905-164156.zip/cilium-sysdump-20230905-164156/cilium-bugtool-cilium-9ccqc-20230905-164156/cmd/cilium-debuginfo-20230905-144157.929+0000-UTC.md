# Cilium debug information

#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.27 (v1.27.4+k0s) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideEnvoyConfig", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumEnvoyConfig", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Secrets", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   True   [eth0 172.17.0.2]
Host firewall:          Disabled
CNI Chaining:           none
Cilium:                 Ok   1.14.1 (v1.14.1-c191ef6f)
NodeMonitor:            Listening for events on 32 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 28/254 allocated from 10.244.0.0/24, 
Allocated addresses:
  10.244.0.106 (cert-manager/cert-manager-78ddc5db85-nbbjs)
  10.244.0.112 (kube-system/metrics-server-7f86dff975-tb5rv)
  10.244.0.123 (openebs/openebs-ndm-cluster-exporter-589554f487-g4gzj)
  10.244.0.124 (streampai/redis-68c95977f4-5ldmf)
  10.244.0.129 (openebs/openebs-ndm-operator-7c667b76f8-8bkbl)
  10.244.0.130 (router)
  10.244.0.132 (streampai/postgres-7c845b6448-hmx74)
  10.244.0.137 (streampai/backend-855f6c7b4-2lvs2)
  10.244.0.143 (openebs/openebs-ndm-node-exporter-bg5c6)
  10.244.0.149 (openebs/openebs-localpv-provisioner-7d6ccb7795-pnpxg)
  10.244.0.159 (streampai/frontend-58b6bf847f-nzgv5)
  10.244.0.160 (streampai/frontend-58b6bf847f-sxngk)
  10.244.0.177 (streampai/streamchat-79dfbb9bb4-5bt4p)
  10.244.0.178 (streampai/pgweb-b74849bb6-rd2fs)
  10.244.0.222 (streampai/backend-855f6c7b4-j4k6m)
  10.244.0.231 (streampai/frontend-58b6bf847f-rm7qs)
  10.244.0.243 (ingress)
  10.244.0.26 (streampai/livestreamdb-6877b6fc75-7w45t)
  10.244.0.29 (health)
  10.244.0.40 (cert-manager/cert-manager-webhook-879c48cd4-qp49t)
  10.244.0.41 (streampai/frontend-58b6bf847f-xgnzm)
  10.244.0.46 (kube-system/hubble-ui-6b468cff75-zwm9s)
  10.244.0.47 (streampai/kratos-77cbf98c8f-k2l6k)
  10.244.0.49 (kube-system/coredns-878bb57ff-lgfbn)
  10.244.0.52 (cert-manager/cert-manager-cainjector-6774f986b-jw7hp)
  10.244.0.62 (streampai/minio-d496dbccf-8rsnz)
  10.244.0.81 (ambassador/traffic-manager-55d995585d-xn8tw)
  10.244.0.86 (kube-system/hubble-relay-777496bf44-h6sbk)
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Host Routing:           Legacy
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      120/120 healthy
  Name                                  Last success   Last error   Count   Message
  cilium-health-ep                      1m1s ago       never        0       no error   
  dns-garbage-collector-job             9s ago         never        0       no error   
  endpoint-105-regeneration-recovery    never          never        0       no error   
  endpoint-1111-regeneration-recovery   never          never        0       no error   
  endpoint-119-regeneration-recovery    never          never        0       no error   
  endpoint-1288-regeneration-recovery   never          never        0       no error   
  endpoint-1493-regeneration-recovery   never          never        0       no error   
  endpoint-160-regeneration-recovery    never          never        0       no error   
  endpoint-198-regeneration-recovery    never          never        0       no error   
  endpoint-208-regeneration-recovery    never          never        0       no error   
  endpoint-2128-regeneration-recovery   never          never        0       no error   
  endpoint-215-regeneration-recovery    never          never        0       no error   
  endpoint-2207-regeneration-recovery   never          never        0       no error   
  endpoint-2326-regeneration-recovery   never          never        0       no error   
  endpoint-2497-regeneration-recovery   never          never        0       no error   
  endpoint-257-regeneration-recovery    never          never        0       no error   
  endpoint-2747-regeneration-recovery   never          never        0       no error   
  endpoint-2856-regeneration-recovery   never          never        0       no error   
  endpoint-3903-regeneration-recovery   never          never        0       no error   
  endpoint-3933-regeneration-recovery   never          never        0       no error   
  endpoint-4067-regeneration-recovery   never          never        0       no error   
  endpoint-455-regeneration-recovery    never          never        0       no error   
  endpoint-471-regeneration-recovery    never          never        0       no error   
  endpoint-606-regeneration-recovery    never          never        0       no error   
  endpoint-626-regeneration-recovery    never          never        0       no error   
  endpoint-633-regeneration-recovery    never          never        0       no error   
  endpoint-645-regeneration-recovery    never          never        0       no error   
  endpoint-702-regeneration-recovery    never          never        0       no error   
  endpoint-82-regeneration-recovery     never          never        0       no error   
  endpoint-gc                           3m9s ago       never        0       no error   
  ipcache-inject-labels                 2s ago         3m4s ago     0       no error   
  k8s-heartbeat                         9s ago         never        0       no error   
  link-cache                            17s ago        never        0       no error   
  metricsmap-bpf-prom-sync              4s ago         never        0       no error   
  resolve-identity-105                  2m30s ago      never        0       no error   
  resolve-identity-1111                 2m48s ago      never        0       no error   
  resolve-identity-119                  3m2s ago       never        0       no error   
  resolve-identity-1288                 2m24s ago      never        0       no error   
  resolve-identity-1493                 2m29s ago      never        0       no error   
  resolve-identity-160                  3m1s ago       never        0       no error   
  resolve-identity-198                  3m2s ago       never        0       no error   
  resolve-identity-208                  2m55s ago      never        0       no error   
  resolve-identity-2128                 2m30s ago      never        0       no error   
  resolve-identity-215                  2m24s ago      never        0       no error   
  resolve-identity-2207                 3m2s ago       never        0       no error   
  resolve-identity-2326                 3m2s ago       never        0       no error   
  resolve-identity-2497                 2m25s ago      never        0       no error   
  resolve-identity-257                  2m30s ago      never        0       no error   
  resolve-identity-2747                 3m2s ago       never        0       no error   
  resolve-identity-2856                 2m30s ago      never        0       no error   
  resolve-identity-3903                 2m28s ago      never        0       no error   
  resolve-identity-3933                 2m57s ago      never        0       no error   
  resolve-identity-4067                 2m58s ago      never        0       no error   
  resolve-identity-455                  2m5s ago       never        0       no error   
  resolve-identity-471                  2m30s ago      never        0       no error   
  resolve-identity-606                  1m59s ago      never        0       no error   
  resolve-identity-626                  3m2s ago       never        0       no error   
  resolve-identity-633                  2m59s ago      never        0       no error   
  resolve-identity-645                  2m24s ago      never        0       no error   
  resolve-identity-702                  2m6s ago       never        0       no error   
  resolve-identity-82                   3m2s ago       never        0       no error   
  sync-host-ips                         2s ago         never        0       no error   
  sync-lb-maps-with-k8s-services        3m2s ago       never        0       no error   
  sync-policymap-105                    58s ago        never        0       no error   
  sync-policymap-1111                   58s ago        never        0       no error   
  sync-policymap-119                    58s ago        never        0       no error   
  sync-policymap-1288                   58s ago        never        0       no error   
  sync-policymap-1493                   58s ago        never        0       no error   
  sync-policymap-160                    58s ago        never        0       no error   
  sync-policymap-198                    58s ago        never        0       no error   
  sync-policymap-208                    58s ago        never        0       no error   
  sync-policymap-2128                   58s ago        never        0       no error   
  sync-policymap-215                    58s ago        never        0       no error   
  sync-policymap-2207                   58s ago        never        0       no error   
  sync-policymap-2326                   58s ago        never        0       no error   
  sync-policymap-2497                   58s ago        never        0       no error   
  sync-policymap-257                    58s ago        never        0       no error   
  sync-policymap-2747                   58s ago        never        0       no error   
  sync-policymap-2856                   58s ago        never        0       no error   
  sync-policymap-3903                   58s ago        never        0       no error   
  sync-policymap-3933                   58s ago        never        0       no error   
  sync-policymap-4067                   58s ago        never        0       no error   
  sync-policymap-455                    58s ago        never        0       no error   
  sync-policymap-471                    58s ago        never        0       no error   
  sync-policymap-606                    58s ago        never        0       no error   
  sync-policymap-626                    58s ago        never        0       no error   
  sync-policymap-633                    58s ago        never        0       no error   
  sync-policymap-645                    58s ago        never        0       no error   
  sync-policymap-702                    58s ago        never        0       no error   
  sync-policymap-82                     58s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (105)      10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1111)     8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (119)      9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1288)     3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1493)     8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (160)      11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (198)      10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (208)      5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2128)     9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (215)      2s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2207)     9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2326)     9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2497)     4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (257)      10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2747)     9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2856)     10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3903)     7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3933)     7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (4067)     8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (455)      5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (471)      10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (606)      9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (626)      10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (633)      8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (645)      2s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (702)      6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (82)       12s ago        never        0       no error   
  sync-utime                            2s ago         never        0       no error   
  template-dir-watcher                  never          never        0       no error   
  write-cni-file                        3m9s ago       never        0       no error   
Proxy Status:            OK, ip 10.244.0.130, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 256, max 65535
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 29.48   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 True
  Socket LB:              Enabled
  Socket LB Tracing:      Enabled
  Socket LB Coverage:     Full
  Devices:                eth0 172.17.0.2
  Mode:                   SNAT
  Backend Selection:      Random
  Session Affinity:       Enabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  XDP Acceleration:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Enabled (Range: 30000-32767) 
  - LoadBalancer:   Enabled 
  - externalIPs:    Enabled 
  - HostPort:       Enabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   73193
  TCP connection tracking       146386
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           146386
  Neighbor table                146386
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              73193
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
enable-l7-proxy:true
enable-host-firewall:false
clustermesh-config:/var/lib/cilium/clustermesh/
tofqdns-max-deferred-connection-deletes:10000
tofqdns-proxy-port:0
enable-cilium-health-api-server-access:
node-port-bind-protection:true
ip-masq-agent-config-path:/etc/config/ip-masq-agent
k8s-service-proxy-name:
l2-announcements-renew-deadline:5s
bpf-ct-timeout-regular-tcp:6h0m0s
bpf-ct-timeout-service-tcp-grace:1m0s
iptables-lock-timeout:5s
bgp-announce-pod-cidr:false
agent-labels:
enable-ipv4-big-tcp:false
cni-log-file:/var/run/cilium/cilium-cni.log
egress-multi-home-ip-rule-compat:false
enable-high-scale-ipcache:false
config-dir:/tmp/cilium/config-map
bpf-lb-maglev-table-size:16381
bpf-lb-dsr-l4-xlate:frontend
kvstore:
tofqdns-min-ttl:0
bpf-lb-dev-ip-addr-inherit:
enable-l2-neigh-discovery:true
vtep-mask:
vtep-endpoint:
procfs:/host/proc
bpf-ct-global-any-max:262144
single-cluster-route:false
ipv6-native-routing-cidr:
devices:eth0
auto-create-cilium-node-resource:true
arping-refresh-period:30s
enable-endpoint-routes:false
enable-envoy-config:true
bpf-filter-priority:1
endpoint-gc-interval:5m0s
dnsproxy-concurrency-processing-grace-period:0s
node-port-mode:snat
bpf-lb-rss-ipv6-src-cidr:
dnsproxy-concurrency-limit:0
monitor-aggregation-interval:5s
log-system-load:false
ipv4-node:auto
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
hubble-skip-unknown-cgroup-ids:true
proxy-connect-timeout:2
envoy-log:
cluster-id:0
hubble-recorder-storage-path:/var/run/cilium/pcaps
enable-bpf-clock-probe:false
enable-ipv4-egress-gateway:false
pprof-port:6060
exclude-local-address:
enable-nat46x64-gateway:false
bpf-lb-maglev-map-max:0
max-controller-interval:0
node-port-algorithm:random
l2-pod-announcements-interface:
http-403-msg:
enable-endpoint-health-checking:true
bpf-lb-map-max:65536
prepend-iptables-chains:true
bpf-ct-timeout-regular-any:1m0s
install-iptables-rules:true
kube-proxy-replacement:true
enable-ipv6:false
cnp-node-status-gc-interval:0s
enable-identity-mark:true
hubble-listen-address::4244
mesh-auth-spire-admin-socket:
enable-ipsec-key-watcher:true
policy-queue-size:100
vtep-mac:
bpf-sock-rev-map-max:262144
ipv6-cluster-alloc-cidr:f00d::/64
state-dir:/var/run/cilium
hubble-event-queue-size:0
auto-direct-node-routes:false
debug:false
enable-bbr:false
bpf-lb-affinity-map-max:0
routing-mode:tunnel
kvstore-periodic-sync:5m0s
enable-service-topology:false
gateway-api-secrets-namespace:cilium-secrets
enable-ipv4-fragment-tracking:true
identity-allocation-mode:crd
l2-announcements-lease-duration:15s
cluster-name:default
monitor-aggregation:medium
use-cilium-internal-ip-for-ipsec:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
allow-icmp-frag-needed:true
enable-ipsec:false
bpf-nat-global-max:524288
nodes-gc-interval:5m0s
enable-k8s-event-handover:false
identity-change-grace-period:5s
enable-xt-socket-fallback:true
enable-session-affinity:false
tofqdns-idle-connection-grace-period:0s
dns-max-ips-per-restored-rule:1000
ipam-cilium-node-update-rate:15s
enable-ip-masq-agent:false
k8s-client-qps:5
tofqdns-endpoint-max-ip-per-hostname:50
enable-l2-announcements:true
enable-remote-node-identity:true
tofqdns-enable-dns-compression:true
enable-node-port:false
derive-masquerade-ip-addr-from-device:
log-driver:
k8s-api-server:
bpf-lb-algorithm:random
join-cluster:false
mesh-auth-rotated-identities-queue-size:1024
enable-local-redirect-policy:false
enable-ipv6-ndp:false
enable-external-ips:false
disable-cnp-status-updates:true
skip-cnp-status-startup-clean:false
remove-cilium-node-taints:true
enable-ipv6-big-tcp:false
bpf-lb-sock-hostns-only:false
tunnel-protocol:vxlan
egress-gateway-reconciliation-trigger-interval:1s
ipv6-mcast-device:
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
config-sources:config-map:kube-system/cilium-config
enable-well-known-identities:false
unmanaged-pod-watcher-interval:15
enable-k8s-terminating-endpoint:true
proxy-max-connection-duration-seconds:0
log-opt:
enable-hubble:true
keep-config:false
cni-exclusive:true
proxy-idle-timeout-seconds:60
bgp-config-path:/var/lib/cilium/bgp/config.yaml
custom-cni-conf:false
enable-k8s:true
synchronize-k8s-nodes:true
mesh-auth-enabled:true
dns-policy-unload-on-shutdown:false
proxy-prometheus-port:0
monitor-queue-size:0
hubble-prefer-ipv6:false
ipsec-key-rotation-duration:5m0s
enable-srv6:false
lib-dir:/var/lib/cilium
enable-monitor:true
encrypt-interface:
cmdref:
enable-cilium-api-server-access:
hubble-export-file-path:
enable-vtep:false
external-envoy-proxy:true
k8s-kubeconfig-path:
proxy-max-requests-per-connection:0
tofqdns-pre-cache:
agent-liveness-update-interval:1s
enable-k8s-networkpolicy:true
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
bpf-lb-external-clusterip:false
fixed-identity-mapping:
k8s-require-ipv4-pod-cidr:false
bpf-root:/sys/fs/bpf
ipv4-native-routing-cidr:
monitor-aggregation-flags:all
local-max-addr-scope:252
tofqdns-proxy-response-max-delay:100ms
enable-bpf-tproxy:false
ipsec-key-file:
operator-api-serve-addr:127.0.0.1:9234
kvstore-connectivity-timeout:2m0s
envoy-config-timeout:2m0s
identity-heartbeat-timeout:30m0s
agent-health-port:9879
egress-gateway-policy-map-max:16384
hubble-export-file-max-size-mb:10
hubble-recorder-sink-queue-size:1024
disable-iptables-feeder-rules:
ipv6-range:auto
route-metric:0
ip-allocation-timeout:2m0s
enable-auto-protect-node-port-range:true
trace-sock:true
install-egress-gateway-routes:false
bpf-fragments-map-max:8192
enable-health-check-nodeport:true
ipv4-service-loopback-address:169.254.42.1
mesh-auth-mutual-listener-port:0
set-cilium-is-up-condition:true
l2-announcements-retry-period:2s
bpf-auth-map-max:524288
bpf-ct-timeout-service-tcp:6h0m0s
set-cilium-node-taints:true
preallocate-bpf-maps:false
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
prometheus-serve-addr::9962
disable-envoy-version-check:false
cni-chaining-target:
http-request-timeout:3600
enable-hubble-recorder-api:true
bpf-ct-timeout-regular-tcp-syn:1m0s
cgroup-root:/run/cilium/cgroupv2
srv6-encap-mode:reduced
enable-l2-pod-announcements:false
bpf-map-event-buffers:
bpf-lb-service-map-max:0
bpf-lb-dsr-dispatch:opt
enable-mke:false
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
local-router-ipv4:
enable-gateway-api:true
bpf-ct-timeout-regular-tcp-fin:10s
conntrack-gc-interval:0s
bgp-announce-lb-ip:false
certificates-directory:/var/run/cilium/certs
bpf-policy-map-max:16384
proxy-gid:1337
vtep-cidr:
enable-k8s-endpoint-slice:true
cilium-endpoint-gc-interval:5m0s
bpf-lb-mode:snat
disable-endpoint-crd:false
enable-local-node-route:true
local-router-ipv6:
bpf-lb-rss-ipv4-src-cidr:
cni-chaining-mode:none
hubble-metrics:
hubble-export-file-max-backups:5
bpf-lb-source-range-map-max:0
enable-host-legacy-routing:false
encrypt-node:false
k8s-client-burst:10
http-idle-timeout:0
config:
hubble-socket-path:/var/run/cilium/hubble.sock
http-retry-timeout:0
mesh-auth-gc-interval:5m0s
enable-wireguard-userspace-fallback:false
hubble-metrics-server:
ipv6-pod-subnets:
bpf-ct-timeout-service-any:1m0s
enable-custom-calls:false
node-port-acceleration:disabled
debug-verbose:envoy
read-cni-conf:
ipam-multi-pool-pre-allocation:default=8
enable-pmtu-discovery:false
identity-restore-grace-period:10m0s
ipv4-pod-subnets:
pprof:false
hubble-monitor-events:
endpoint-status:
enable-runtime-device-detection:false
ipv4-service-range:auto
trace-payloadlen:128
enable-policy:default
bpf-lb-acceleration:disabled
http-normalize-path:true
bpf-ct-global-tcp-max:524288
hubble-event-buffer-capacity:4095
enable-bandwidth-manager:false
mke-cgroup-mount:
enable-wireguard:false
kvstore-opt:
k8s-namespace:kube-system
ipv6-node:auto
datapath-mode:veth
enable-svc-source-range-check:true
cflags:
socket-path:/var/run/cilium/cilium.sock
enable-xdp-prefilter:false
kube-proxy-replacement-healthz-bind-address:
endpoint-queue-size:25
http-retry-count:3
enable-ipv4-masquerade:true
enable-health-checking:true
labels:
enable-tracing:false
dnsproxy-lock-timeout:500ms
bpf-lb-service-backend-map-max:0
enable-host-port:false
egress-masquerade-interfaces:
bpf-lb-sock:false
crd-wait-timeout:5m0s
bpf-lb-rev-nat-map-max:0
hubble-disable-tls:false
tunnel:
kvstore-max-consecutive-quorum-errors:2
node-port-range:
enable-ipv4:true
vlan-bpf-bypass:
ipv4-range:auto
bpf-map-dynamic-size-ratio:0.0025
mesh-auth-queue-size:1024
label-prefix-file:
enable-stale-cilium-endpoint-cleanup:true
enable-sctp:false
identity-gc-interval:15m0s
fqdn-regex-compile-lru-size:1024
enable-gateway-api-secrets-sync:true
mesh-auth-spiffe-trust-domain:spiffe.cilium
sidecar-istio-proxy-image:cilium/istio_proxy
enable-icmp-rules:true
k8s-heartbeat-timeout:30s
enable-bpf-masquerade:false
http-max-grpc-timeout:0
tunnel-port:0
ipv6-service-range:auto
mtu:0
ipam:kubernetes
dnsproxy-lock-count:128
policy-trigger-interval:1s
gops-port:9890
k8s-sync-timeout:3m0s
enable-unreachable-routes:false
annotate-k8s-node:false
kvstore-lease-ttl:15m0s
allow-localhost:auto
restore:true
tofqdns-dns-reject-response-code:refused
iptables-random-fully:false
direct-routing-device:
metrics:
api-rate-limit:
enable-cilium-endpoint-slice:false
hubble-export-file-compress:false
enable-ipv6-masquerade:true
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
cluster-health-port:4240
pprof-address:localhost
enable-recorder:false
bpf-neigh-global-max:524288
allocator-list-timeout:3m0s
enable-k8s-api-discovery:false
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
enable-bgp-control-plane:false
k8s-require-ipv6-pod-cidr:false
bypass-ip-availability-upon-restore:false
version:false
k8s-service-cache-size:128
policy-audit-mode:false
install-no-conntrack-iptables-rules:false
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                   IPv6   IPv4           STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                      
82         Disabled           Disabled          40792      k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs               10.244.0.143   ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator                                               
                                                           k8s:io.kubernetes.pod.namespace=openebs                                                                     
                                                           k8s:name=openebs-ndm-node-exporter                                                                          
                                                           k8s:openebs.io/component-name=ndm-node-exporter                                                             
                                                           k8s:openebs.io/version=3.4.0                                                                                
105        Disabled           Disabled          29809      k8s:app=frontend                                                                     10.244.0.231   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
119        Disabled           Disabled          5710       k8s:app.kubernetes.io/component=cainjector                                           10.244.0.52    ready   
                                                           k8s:app.kubernetes.io/instance=cert-manager                                                                 
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                       
                                                           k8s:app.kubernetes.io/name=cainjector                                                                       
                                                           k8s:app.kubernetes.io/version=v1.10.0                                                                       
                                                           k8s:app=cainjector                                                                                          
                                                           k8s:helm.sh/chart=cert-manager-v1.10.0                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager                                 
                                                           k8s:io.cilium.k8s.namespace.labels.name=cert-manager                                                        
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-cainjector                                             
                                                           k8s:io.kubernetes.pod.namespace=cert-manager                                                                
160        Disabled           Disabled          4          reserved:health                                                                      10.244.0.29    ready   
198        Disabled           Disabled          17675      k8s:app.kubernetes.io/component=webhook                                              10.244.0.40    ready   
                                                           k8s:app.kubernetes.io/instance=cert-manager                                                                 
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                       
                                                           k8s:app.kubernetes.io/name=webhook                                                                          
                                                           k8s:app.kubernetes.io/version=v1.10.0                                                                       
                                                           k8s:app=webhook                                                                                             
                                                           k8s:helm.sh/chart=cert-manager-v1.10.0                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager                                 
                                                           k8s:io.cilium.k8s.namespace.labels.name=cert-manager                                                        
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-webhook                                                
                                                           k8s:io.kubernetes.pod.namespace=cert-manager                                                                
208        Disabled           Disabled          44885      k8s:app.kubernetes.io/name=hubble-relay                                              10.244.0.86    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                        
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay                                                        
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=hubble-relay                                                                                    
215        Disabled           Disabled          43844      k8s:app=pgweb                                                                        10.244.0.178   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
257        Disabled           Disabled          22996      k8s:app=backend                                                                      10.244.0.137   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
455        Disabled           Disabled          12060      k8s:app=minio                                                                        10.244.0.62    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
471        Disabled           Disabled          29809      k8s:app=frontend                                                                     10.244.0.41    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
606        Disabled           Disabled          5148       k8s:app=postgres                                                                     10.244.0.132   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
626        Disabled           Disabled          6602       k8s:app.kubernetes.io/component=controller                                           10.244.0.106   ready   
                                                           k8s:app.kubernetes.io/instance=cert-manager                                                                 
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                       
                                                           k8s:app.kubernetes.io/name=cert-manager                                                                     
                                                           k8s:app.kubernetes.io/version=v1.10.0                                                                       
                                                           k8s:app=cert-manager                                                                                        
                                                           k8s:helm.sh/chart=cert-manager-v1.10.0                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager                                 
                                                           k8s:io.cilium.k8s.namespace.labels.name=cert-manager                                                        
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=cert-manager                                                        
                                                           k8s:io.kubernetes.pod.namespace=cert-manager                                                                
633        Disabled           Disabled          31330      k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system           10.244.0.49    ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=kube-dns                                                                                        
645        Disabled           Disabled          20103      k8s:app=redis                                                                        10.244.0.124   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
702        Disabled           Disabled          12173      k8s:app=livestreamdb                                                                 10.244.0.26    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
1111       Disabled           Disabled          1          k8s:node-role.kubernetes.io/control-plane=true                                                      ready   
                                                           k8s:node.k0sproject.io/role=control-plane                                                                   
                                                           reserved:host                                                                                               
1288       Disabled           Disabled          10456      k8s:app=streamchat                                                                   10.244.0.177   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
1493       Disabled           Disabled          29809      k8s:app=frontend                                                                     10.244.0.159   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
2128       Disabled           Disabled          36400      k8s:app=kratos                                                                       10.244.0.47    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
2207       Disabled           Disabled          63175      k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs               10.244.0.149   ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator                                               
                                                           k8s:io.kubernetes.pod.namespace=openebs                                                                     
                                                           k8s:name=openebs-localpv-provisioner                                                                        
                                                           k8s:openebs.io/component-name=openebs-localpv-provisioner                                                   
                                                           k8s:openebs.io/version=3.4.0                                                                                
2326       Disabled           Disabled          19125      k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs               10.244.0.129   ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator                                               
                                                           k8s:io.kubernetes.pod.namespace=openebs                                                                     
                                                           k8s:name=openebs-ndm-operator                                                                               
                                                           k8s:openebs.io/component-name=ndm-operator                                                                  
                                                           k8s:openebs.io/version=3.4.0                                                                                
2497       Disabled           Disabled          4626       k8s:app=traffic-manager                                                              10.244.0.81    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=ambassador                                   
                                                           k8s:io.cilium.k8s.namespace.labels.name=ambassador                                                          
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=traffic-manager                                                     
                                                           k8s:io.kubernetes.pod.namespace=ambassador                                                                  
                                                           k8s:telepresence=manager                                                                                    
2747       Disabled           Disabled          10281      k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system           10.244.0.112   ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=metrics-server                                                      
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=metrics-server                                                                                  
2856       Disabled           Disabled          22996      k8s:app=backend                                                                      10.244.0.222   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
3903       Disabled           Disabled          29809      k8s:app=frontend                                                                     10.244.0.160   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
3933       Disabled           Disabled          290        k8s:app.kubernetes.io/name=hubble-ui                                                 10.244.0.46    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                        
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=hubble-ui                                                                                       
4067       Disabled           Disabled          62607      k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs               10.244.0.123   ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator                                               
                                                           k8s:io.kubernetes.pod.namespace=openebs                                                                     
                                                           k8s:name=openebs-ndm-cluster-exporter                                                                       
                                                           k8s:openebs.io/component-name=ndm-cluster-exporter                                                          
                                                           k8s:openebs.io/version=3.4.0                                                                                
```

#### BPF Policy Get 82

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    27672   298       0        

```


#### BPF CT List 82

```
Invalid argument: unknown type 82
```


#### Endpoint Get 82

```
[
  {
    "id": 82,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-82-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "9eb1b8b7-6cae-4e9c-b5fd-696ef87a203b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-82",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:38:55.893Z",
            "success-count": 1
          },
          "uuid": "62893a29-7a3a-4d8f-8c91-a38e899f0a02"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-82",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:40:59.799Z",
            "success-count": 21
          },
          "uuid": "0384d7f7-6a48-4989-bc90-ca443f8ec44f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (82)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:55.908Z",
            "success-count": 20
          },
          "uuid": "435d0801-7bc8-4b58-8d13-722029d7fa9c"
        }
      ],
      "external-identifiers": {
        "container-id": "6ca953f974aa020416ea54dab4ebd97c6f12b0519337d529b4d152be715be274",
        "k8s-namespace": "openebs",
        "k8s-pod-name": "openebs-ndm-node-exporter-bg5c6",
        "pod-name": "openebs/openebs-ndm-node-exporter-bg5c6"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 40792,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:openebs.io/version=3.4.0",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:name=openebs-ndm-node-exporter",
          "k8s:openebs.io/component-name=ndm-node-exporter"
        ]
      },
      "labels": {
        "derived": [
          "k8s:controller-revision-hash=65597f5db8",
          "k8s:pod-template-generation=1"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:name=openebs-ndm-node-exporter",
          "k8s:openebs.io/component-name=ndm-node-exporter",
          "k8s:openebs.io/version=3.4.0"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "namedPorts": [
        {
          "name": "metrics",
          "port": 9101,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.143",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "aa:29:0a:cd:a9:c7",
        "interface-index": 12,
        "interface-name": "lxcd5f50712b795",
        "mac": "f2:0f:57:b3:6c:28"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 40792,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 40792,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 82

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 82

```
Timestamp              Status    State                   Message
2023-09-05T14:39:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:28Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:28Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:28Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:28Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:27Z   OK        ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T14:39:27Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:27Z   OK        regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T14:39:27Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T14:39:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:02Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:38:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:57Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T14:38:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:38:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:57Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:38:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:55Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:38:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:38:55Z   OK        ready                   Set identity for this endpoint
2023-09-05T14:38:55Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:55Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 40792

```
ID      LABELS
40792   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator
        k8s:io.kubernetes.pod.namespace=openebs
        k8s:name=openebs-ndm-node-exporter
        k8s:openebs.io/component-name=ndm-node-exporter
        k8s:openebs.io/version=3.4.0

```


#### BPF Policy Get 105

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4949    32        0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 105

```
Invalid argument: unknown type 105
```


#### Endpoint Get 105

```
[
  {
    "id": 105,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-105-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "144e2b6b-54c3-4355-bd05-e25a636599b6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-105",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:39:27.831Z",
            "success-count": 1
          },
          "uuid": "3ee847b0-cc0b-4c47-a2ad-d0198d4b1923"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-105",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:40:59.800Z",
            "success-count": 14
          },
          "uuid": "64c1ce17-eb0d-447d-918c-7baf11a19cb1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (105)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:57.857Z",
            "success-count": 17
          },
          "uuid": "72e2c36b-2bee-4a7d-83b4-f7756a3b817d"
        }
      ],
      "external-identifiers": {
        "container-id": "256095e2394a7c59e331e4689f9da81be2de5b97786cd03961d365e086eb2237",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "frontend-58b6bf847f-rm7qs",
        "pod-name": "streampai/frontend-58b6bf847f-rm7qs"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 29809,
        "labels": [
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=58b6bf847f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.231",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "9e:8b:cf:03:5f:32",
        "interface-index": 36,
        "interface-name": "lxca3bc785de088",
        "mac": "ea:46:93:6d:e7:e6"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 29809,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 29809,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 105

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 105

```
Timestamp              Status   State                   Message
2023-09-05T14:39:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:39:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:27Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:39:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:39:27Z   OK       ready                   Set identity for this endpoint
2023-09-05T14:39:27Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 29809

```
ID      LABELS
29809   k8s:app=frontend
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 119

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    96858   877       0        

```


#### BPF CT List 119

```
Invalid argument: unknown type 119
```


#### Endpoint Get 119

```
[
  {
    "id": 119,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-119-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c29c4482-7cde-44c2-b7a5-a4b48c9dc976"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-119",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:38:55.912Z",
            "success-count": 1
          },
          "uuid": "4cb4b3de-7079-4264-a725-872816b81b9c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-119",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:40:59.800Z",
            "success-count": 21
          },
          "uuid": "ded2a74e-719d-4690-aab0-530dd7430e1f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (119)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:48.667Z",
            "success-count": 19
          },
          "uuid": "e57b3276-85b9-4b52-a024-d94d94fe9d53"
        }
      ],
      "external-identifiers": {
        "container-id": "54f4b829a13411e875774e2f9e706feb989ebf219ad738a2b5bdabdfad993ebe",
        "k8s-namespace": "cert-manager",
        "k8s-pod-name": "cert-manager-cainjector-6774f986b-jw7hp",
        "pod-name": "cert-manager/cert-manager-cainjector-6774f986b-jw7hp"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5710,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/component=cainjector",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:app.kubernetes.io/name=cainjector",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-cainjector",
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:helm.sh/chart=cert-manager-v1.10.0",
          "k8s:io.kubernetes.pod.namespace=cert-manager",
          "k8s:app.kubernetes.io/version=v1.10.0",
          "k8s:app=cainjector"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6774f986b"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/component=cainjector",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=cainjector",
          "k8s:app.kubernetes.io/version=v1.10.0",
          "k8s:app=cainjector",
          "k8s:helm.sh/chart=cert-manager-v1.10.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-cainjector",
          "k8s:io.kubernetes.pod.namespace=cert-manager"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.52",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "62:da:ec:6b:90:90",
        "interface-index": 26,
        "interface-name": "lxcc4f2ad3599a9",
        "mac": "7a:b6:ad:7c:ca:04"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5710,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5710,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 119

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 119

```
Timestamp              Status   State                   Message
2023-09-05T14:39:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T14:39:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:27Z   OK       regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T14:39:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T14:39:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:38:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:57Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:38:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:38:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:57Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:38:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:55Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:38:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:38:55Z   OK       ready                   Set identity for this endpoint
2023-09-05T14:38:55Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 5710

```
ID     LABELS
5710   k8s:app.kubernetes.io/component=cainjector
       k8s:app.kubernetes.io/instance=cert-manager
       k8s:app.kubernetes.io/managed-by=Helm
       k8s:app.kubernetes.io/name=cainjector
       k8s:app.kubernetes.io/version=v1.10.0
       k8s:app=cainjector
       k8s:helm.sh/chart=cert-manager-v1.10.0
       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager
       k8s:io.cilium.k8s.namespace.labels.name=cert-manager
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-cainjector
       k8s:io.kubernetes.pod.namespace=cert-manager

```


#### BPF Policy Get 160

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    2802    32        0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 160

```
Invalid argument: unknown type 160
```


#### Endpoint Get 160

```
[
  {
    "id": 160,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-160-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "fe4c54d1-179d-471c-a170-53d7712d1234"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-160",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:38:56.413Z",
            "success-count": 1
          },
          "uuid": "d2bbf976-ddd9-4d91-a0b7-ab378b095d52"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-160",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:40:59.799Z",
            "success-count": 21
          },
          "uuid": "716a5fe8-b623-4977-b566-c6b0e0c1d382"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (160)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:56.421Z",
            "success-count": 20
          },
          "uuid": "5fc24f67-f6e7-44d5-b318-7cea53400719"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.29",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "d2:69:21:fd:bb:63",
        "interface-index": 6,
        "interface-name": "lxc_health",
        "mac": "62:3b:02:92:50:78"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 160

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 160

```
Timestamp              Status   State                   Message
2023-09-05T14:39:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T14:39:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:27Z   OK       regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T14:39:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T14:39:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:38:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:57Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:38:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:38:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:57Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:38:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:56Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:38:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:38:56Z   OK       ready                   Set identity for this endpoint
2023-09-05T14:38:55Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 198

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    42928   308       0        
Allow    Egress      0          ANY          NONE         disabled    6747    33        0        

```


#### BPF CT List 198

```
Invalid argument: unknown type 198
```


#### Endpoint Get 198

```
[
  {
    "id": 198,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-198-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "0401a28b-5082-4c51-9876-4204d79fdd04"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-198",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:38:55.902Z",
            "success-count": 1
          },
          "uuid": "c56aa17e-6201-4c80-a919-7673eb2eaf94"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-198",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:40:59.800Z",
            "success-count": 21
          },
          "uuid": "590c91cd-8819-4395-bd64-4bb53d268d8a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (198)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:57.666Z",
            "success-count": 20
          },
          "uuid": "53c89e6c-9dc8-44a6-9f60-536234a148db"
        }
      ],
      "external-identifiers": {
        "container-id": "df9757790004eb9c93ed75616aac1414c5c518094e1b11070ec968b56b46ae89",
        "k8s-namespace": "cert-manager",
        "k8s-pod-name": "cert-manager-webhook-879c48cd4-qp49t",
        "pod-name": "cert-manager/cert-manager-webhook-879c48cd4-qp49t"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 17675,
        "labels": [
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-webhook",
          "k8s:app.kubernetes.io/component=webhook",
          "k8s:app.kubernetes.io/version=v1.10.0",
          "k8s:helm.sh/chart=cert-manager-v1.10.0",
          "k8s:app.kubernetes.io/name=webhook",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:app=webhook",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.kubernetes.pod.namespace=cert-manager"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=879c48cd4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/component=webhook",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=webhook",
          "k8s:app.kubernetes.io/version=v1.10.0",
          "k8s:app=webhook",
          "k8s:helm.sh/chart=cert-manager-v1.10.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-webhook",
          "k8s:io.kubernetes.pod.namespace=cert-manager"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "namedPorts": [
        {
          "name": "healthcheck",
          "port": 6080,
          "protocol": "TCP"
        },
        {
          "name": "https",
          "port": 10250,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.40",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "56:d6:36:07:e9:45",
        "interface-index": 28,
        "interface-name": "lxca6e942e43be4",
        "mac": "ae:bf:fe:6b:ba:0d"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 17675,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 17675,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 198

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 198

```
Timestamp              Status   State                   Message
2023-09-05T14:39:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T14:39:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:27Z   OK       regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T14:39:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T14:39:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:38:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:57Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:38:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:38:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:57Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:38:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:55Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:38:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:38:55Z   OK       ready                   Set identity for this endpoint
2023-09-05T14:38:55Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 17675

```
ID      LABELS
17675   k8s:app.kubernetes.io/component=webhook
        k8s:app.kubernetes.io/instance=cert-manager
        k8s:app.kubernetes.io/managed-by=Helm
        k8s:app.kubernetes.io/name=webhook
        k8s:app.kubernetes.io/version=v1.10.0
        k8s:app=webhook
        k8s:helm.sh/chart=cert-manager-v1.10.0
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager
        k8s:io.cilium.k8s.namespace.labels.name=cert-manager
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-webhook
        k8s:io.kubernetes.pod.namespace=cert-manager

```


#### BPF Policy Get 208

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    7540    116       0        
Allow    Egress      0          ANY          NONE         disabled    8277    65        0        

```


#### BPF CT List 208

```
Invalid argument: unknown type 208
```


#### Endpoint Get 208

```
[
  {
    "id": 208,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-208-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "40969c36-f446-4734-b8e0-0683167e8a8c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-208",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:39:02.154Z",
            "success-count": 1
          },
          "uuid": "a2992935-1da9-4836-b8d9-ecb0ee546450"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-208",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:40:59.799Z",
            "success-count": 15
          },
          "uuid": "4c1bcd52-69ab-406c-be8d-4933385a60fd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (208)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:52.172Z",
            "success-count": 19
          },
          "uuid": "61c93a63-5682-4f7a-aed5-1047da4608b8"
        }
      ],
      "external-identifiers": {
        "container-id": "e0d48a21c88ad3f49000e4eade8d9f8ac3d347e2e0ac35648b27bed7878f55c9",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "hubble-relay-777496bf44-h6sbk",
        "pod-name": "kube-system/hubble-relay-777496bf44-h6sbk"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 44885,
        "labels": [
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:k8s-app=hubble-relay",
          "k8s:app.kubernetes.io/name=hubble-relay",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=777496bf44"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=hubble-relay",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=hubble-relay"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "namedPorts": [
        {
          "name": "grpc",
          "port": 4245,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.86",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "ae:85:3f:ed:55:fa",
        "interface-index": 16,
        "interface-name": "lxc8f4963f4d794",
        "mac": "4e:f0:2d:ca:14:ad"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 44885,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 44885,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 208

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 208

```
Timestamp              Status    State                   Message
2023-09-05T14:39:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:28Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:28Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:28Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:28Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:27Z   OK        ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T14:39:27Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:27Z   OK        regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T14:39:27Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T14:39:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:39:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:02Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:39:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:39:02Z   OK        ready                   Set identity for this endpoint
2023-09-05T14:39:02Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:02Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 44885

```
ID      LABELS
44885   k8s:app.kubernetes.io/name=hubble-relay
        k8s:app.kubernetes.io/part-of=cilium
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=hubble-relay

```


#### BPF Policy Get 215

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    3167    26        0        

```


#### BPF CT List 215

```
Invalid argument: unknown type 215
```


#### Endpoint Get 215

```
[
  {
    "id": 215,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-215-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "4e0d3d41-1853-4a9d-844a-8e5be816e195"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-215",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:39:33.467Z",
            "success-count": 1
          },
          "uuid": "7948d237-3f65-4b95-a451-7d6565354534"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-215",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:40:59.799Z",
            "success-count": 8
          },
          "uuid": "319f37fe-0dbf-4b06-ab80-5a197e760249"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (215)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:55.235Z",
            "success-count": 16
          },
          "uuid": "9d18bc83-6a62-4ae1-a90e-30905bac4d54"
        }
      ],
      "external-identifiers": {
        "container-id": "5054acf2cf7818c85d996a1fdc0aff265b95a4e92d3c37b6a959cb5194cf33b0",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "pgweb-b74849bb6-rd2fs",
        "pod-name": "streampai/pgweb-b74849bb6-rd2fs"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 43844,
        "labels": [
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=pgweb",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=b74849bb6"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=pgweb",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.178",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "e6:02:e8:77:37:28",
        "interface-index": 58,
        "interface-name": "lxcf80faf7bf140",
        "mac": "2e:aa:55:f4:55:5d"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 43844,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 43844,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 215

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 215

```
Timestamp              Status    State                   Message
2023-09-05T14:39:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:39:33Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:39:33Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:39:33Z   OK        ready                   Set identity for this endpoint
2023-09-05T14:39:33Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 43844

```
ID      LABELS
43844   k8s:app=pgweb
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 257

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1267    6         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 257

```
Invalid argument: unknown type 257
```


#### Endpoint Get 257

```
[
  {
    "id": 257,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-257-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "852889e6-c040-4140-b96c-44be3ab94151"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-257",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:39:27.667Z",
            "success-count": 1
          },
          "uuid": "9574b615-83d9-433d-81bb-abd529af23af"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-257",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:40:59.800Z",
            "success-count": 14
          },
          "uuid": "fbfeffe9-26ac-4dd5-bb8c-841c9b637de0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (257)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:57.689Z",
            "success-count": 17
          },
          "uuid": "397754dd-d416-42fa-9bea-c703986e11ed"
        }
      ],
      "external-identifiers": {
        "container-id": "8d19df63511ab0d49a9719b078dadf169461d0b0adb8e920c6c1a73643d52aad",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "backend-855f6c7b4-2lvs2",
        "pod-name": "streampai/backend-855f6c7b4-2lvs2"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 22996,
        "labels": [
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=backend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=855f6c7b4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=backend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.137",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "de:fb:8f:a5:eb:ca",
        "interface-index": 32,
        "interface-name": "lxc99e06d89f0fa",
        "mac": "76:ea:fd:64:aa:73"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 22996,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 22996,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 257

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 257

```
Timestamp              Status   State                   Message
2023-09-05T14:39:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:39:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:27Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:39:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:39:27Z   OK       ready                   Set identity for this endpoint
2023-09-05T14:39:27Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 22996

```
ID      LABELS
22996   k8s:app=backend
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 455

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    8065    36        0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    4872    47        0        

```


#### BPF CT List 455

```
Invalid argument: unknown type 455
```


#### Endpoint Get 455

```
[
  {
    "id": 455,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-455-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "8b23c64c-99c0-46b8-85e6-96f90606adde"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-455",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:39:52.422Z",
            "success-count": 1
          },
          "uuid": "05ce4807-7c2f-42fc-b3a8-e9ecbac531c4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-455",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:40:59.798Z",
            "success-count": 4
          },
          "uuid": "3f4ce108-c2c7-4dd7-b5f1-cc01d844fc14"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (455)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:52.437Z",
            "success-count": 14
          },
          "uuid": "356e6cbc-0947-47d0-9b4f-b623cffcd054"
        }
      ],
      "external-identifiers": {
        "container-id": "7476cb2824b94ca1f9d7c75eefdeb82529918eaa1d2b2072688282345eeb7480",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "minio-d496dbccf-8rsnz",
        "pod-name": "streampai/minio-d496dbccf-8rsnz"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 12060,
        "labels": [
          "k8s:app=minio",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=d496dbccf"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=minio",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.62",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "42:8a:b8:70:f8:45",
        "interface-index": 71,
        "interface-name": "lxc14e2da0d3f54",
        "mac": "a6:ee:91:65:9a:32"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 12060,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 12060,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 455

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 455

```
Timestamp              Status    State                   Message
2023-09-05T14:39:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:39:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:39:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:39:52Z   OK        ready                   Set identity for this endpoint
2023-09-05T14:39:52Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 12060

```
ID      LABELS
12060   k8s:app=minio
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 471

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4315    28        0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 471

```
Invalid argument: unknown type 471
```


#### Endpoint Get 471

```
[
  {
    "id": 471,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-471-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "53d0dc96-540b-45c5-8519-06ab665de042"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-471",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:39:27.875Z",
            "success-count": 1
          },
          "uuid": "67edf278-9853-445f-9a14-07e22cb7f536"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-471",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:40:59.799Z",
            "success-count": 14
          },
          "uuid": "c0a83103-1368-4915-9f9c-80fee16ca3bd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (471)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:57.898Z",
            "success-count": 17
          },
          "uuid": "bb655987-f15e-40cd-b403-cca66bc85ca8"
        }
      ],
      "external-identifiers": {
        "container-id": "28c45285a69dd33c7d6eb5facaf0a6ad533aeee0627a77b5bf33d53b5cf9e8b8",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "frontend-58b6bf847f-xgnzm",
        "pod-name": "streampai/frontend-58b6bf847f-xgnzm"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 29809,
        "labels": [
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=58b6bf847f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.41",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "2e:9c:eb:75:07:90",
        "interface-index": 40,
        "interface-name": "lxc7e22bb71519c",
        "mac": "6a:0f:f8:ee:78:20"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 29809,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 29809,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 471

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 471

```
Timestamp              Status   State                   Message
2023-09-05T14:39:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:39:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:27Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:39:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:39:27Z   OK       ready                   Set identity for this endpoint
2023-09-05T14:39:27Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 29809

```
ID      LABELS
29809   k8s:app=frontend
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 606

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    265534   1924      0        
Allow    Ingress     1          ANY          NONE         disabled    0        0         0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 606

```
Invalid argument: unknown type 606
```


#### Endpoint Get 606

```
[
  {
    "id": 606,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-606-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7cd0bc1c-b823-47f5-9ad1-dfe601b74caf"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-606",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:39:58.835Z",
            "success-count": 1
          },
          "uuid": "dfb3901e-f270-4600-ac6d-ecf3e75c76c9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-606",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:40:59.800Z",
            "success-count": 3
          },
          "uuid": "e5f73344-89e8-4231-abab-e545fb25b3d0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (606)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:58.849Z",
            "success-count": 14
          },
          "uuid": "9e0f36c1-cb35-40f3-a118-6871d45f7784"
        }
      ],
      "external-identifiers": {
        "container-id": "5bac844af1051a34909dc3e13d7027ef733b1316326314a5735d892ee8723303",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "postgres-7c845b6448-hmx74",
        "pod-name": "streampai/postgres-7c845b6448-hmx74"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5148,
        "labels": [
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=postgres",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7c845b6448"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=postgres",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.132",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "72:c9:e8:7a:6a:98",
        "interface-index": 73,
        "interface-name": "lxc155b3629c0eb",
        "mac": "fe:76:8c:09:97:60"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5148,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5148,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 606

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 606

```
Timestamp              Status    State                   Message
2023-09-05T14:39:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:39:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:39:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:39:58Z   OK        ready                   Set identity for this endpoint
2023-09-05T14:39:58Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 5148

```
ID     LABELS
5148   k8s:app=postgres
       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
       k8s:io.cilium.k8s.namespace.labels.name=streampai
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=default
       k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 626

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    0        0         0        
Allow    Egress      0          ANY          NONE         disabled    104973   1001      0        

```


#### BPF CT List 626

```
Invalid argument: unknown type 626
```


#### Endpoint Get 626

```
[
  {
    "id": 626,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-626-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "300769b0-8899-4dcc-890c-4f9369637722"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-626",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:38:55.895Z",
            "success-count": 1
          },
          "uuid": "8e63afcc-4f1e-41ac-877d-2c05c08eb15d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-626",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:40:59.800Z",
            "success-count": 21
          },
          "uuid": "836ff81c-7ae7-4e09-8a46-ddbe27824f89"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (626)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:57.467Z",
            "success-count": 20
          },
          "uuid": "3470619d-d5de-430c-b6c1-3cac32954479"
        }
      ],
      "external-identifiers": {
        "container-id": "00af56099af799154b2566f9aa3a622f9f0f94e45a3713d4a89ad558a14536a2",
        "k8s-namespace": "cert-manager",
        "k8s-pod-name": "cert-manager-78ddc5db85-nbbjs",
        "pod-name": "cert-manager/cert-manager-78ddc5db85-nbbjs"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6602,
        "labels": [
          "k8s:io.kubernetes.pod.namespace=cert-manager",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager",
          "k8s:app.kubernetes.io/name=cert-manager",
          "k8s:helm.sh/chart=cert-manager-v1.10.0",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app=cert-manager",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:app.kubernetes.io/version=v1.10.0",
          "k8s:app.kubernetes.io/component=controller"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=78ddc5db85"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/component=controller",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=cert-manager",
          "k8s:app.kubernetes.io/version=v1.10.0",
          "k8s:app=cert-manager",
          "k8s:helm.sh/chart=cert-manager-v1.10.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager",
          "k8s:io.kubernetes.pod.namespace=cert-manager"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "namedPorts": [
        {
          "name": "http-metrics",
          "port": 9402,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.106",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "3e:6f:6a:ae:ce:4c",
        "interface-index": 30,
        "interface-name": "lxc74e3fcbb5020",
        "mac": "86:da:b5:28:cc:22"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6602,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6602,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 626

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 626

```
Timestamp              Status    State                   Message
2023-09-05T14:39:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:28Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:28Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:28Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:28Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:27Z   OK        ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T14:39:27Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:27Z   OK        regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T14:39:27Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T14:39:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:02Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:38:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:57Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T14:38:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:38:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:57Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:38:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:55Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:38:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:38:55Z   OK        ready                   Set identity for this endpoint
2023-09-05T14:38:55Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:55Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 6602

```
ID     LABELS
6602   k8s:app.kubernetes.io/component=controller
       k8s:app.kubernetes.io/instance=cert-manager
       k8s:app.kubernetes.io/managed-by=Helm
       k8s:app.kubernetes.io/name=cert-manager
       k8s:app.kubernetes.io/version=v1.10.0
       k8s:app=cert-manager
       k8s:helm.sh/chart=cert-manager-v1.10.0
       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager
       k8s:io.cilium.k8s.namespace.labels.name=cert-manager
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=cert-manager
       k8s:io.kubernetes.pod.namespace=cert-manager

```


#### BPF Policy Get 633

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    35328   327       0        
Allow    Ingress     1          ANY          NONE         disabled    41948   479       0        
Allow    Egress      0          ANY          NONE         disabled    13962   156       0        

```


#### BPF CT List 633

```
Invalid argument: unknown type 633
```


#### Endpoint Get 633

```
[
  {
    "id": 633,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-633-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "ae92e999-0dcd-4314-8ecf-43fa9a051568"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-633",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:38:58.897Z",
            "success-count": 1
          },
          "uuid": "794233c8-5578-47e6-a879-3ab2b6c80146"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-633",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:40:59.801Z",
            "success-count": 18
          },
          "uuid": "b4dc9496-ff4d-4ad1-8405-d5559d03e051"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (633)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:59.267Z",
            "success-count": 20
          },
          "uuid": "dbc066ef-6d1c-4e91-be5c-13fd117a8602"
        }
      ],
      "external-identifiers": {
        "container-id": "942ad978de370916d091d112a88cf9cee9f716a5a4a0dbe28acde61376fe6148",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-878bb57ff-lgfbn",
        "pod-name": "kube-system/coredns-878bb57ff-lgfbn"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 31330,
        "labels": [
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:k8s-app=kube-dns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.kubernetes.pod.namespace=kube-system"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=878bb57ff"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.49",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "0a:c0:f0:54:67:48",
        "interface-index": 24,
        "interface-name": "lxc5aa26ecaf428",
        "mac": "4a:c9:92:bd:4d:ee"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 31330,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 31330,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 633

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 633

```
Timestamp              Status    State                   Message
2023-09-05T14:39:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:28Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:28Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:28Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:28Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:27Z   OK        ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T14:39:27Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:27Z   OK        regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T14:39:27Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T14:39:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:02Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:38:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:58Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:38:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:38:58Z   OK        ready                   Set identity for this endpoint
2023-09-05T14:38:58Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:57Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to 
2023-09-05T14:38:57Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 31330

```
ID      LABELS
31330   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=coredns
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=kube-dns

```


#### BPF Policy Get 645

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1676    12        0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 645

```
Invalid argument: unknown type 645
```


#### Endpoint Get 645

```
[
  {
    "id": 645,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-645-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "4cf3d35f-e15f-42e3-a453-83eef39a2761"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-645",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:39:33.427Z",
            "success-count": 1
          },
          "uuid": "0df67c45-fe4f-4526-be9d-845aa5b464d2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-645",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:59.801Z",
            "success-count": 9
          },
          "uuid": "a002a6f0-49d1-4c20-bb17-f73bbf996acc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (645)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:55.036Z",
            "success-count": 16
          },
          "uuid": "925c043d-f515-4780-818c-0f6892db375e"
        }
      ],
      "external-identifiers": {
        "container-id": "8103d27e0622ccdea67d45171fd8e11d482d3a8068d96e8111659906a7817319",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "redis-68c95977f4-5ldmf",
        "pod-name": "streampai/redis-68c95977f4-5ldmf"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 20103,
        "labels": [
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=redis",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=68c95977f4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=redis",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.124",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "52:3b:a8:33:de:89",
        "interface-index": 60,
        "interface-name": "lxc4889aef29f33",
        "mac": "42:1d:71:d0:63:fc"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 20103,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 20103,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 645

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 645

```
Timestamp              Status    State                   Message
2023-09-05T14:39:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:39:33Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:39:33Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:39:33Z   OK        ready                   Set identity for this endpoint
2023-09-05T14:39:33Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 20103

```
ID      LABELS
20103   k8s:app=redis
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 702

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6770    42        0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    7498    21        0        

```


#### BPF CT List 702

```
Invalid argument: unknown type 702
```


#### Endpoint Get 702

```
[
  {
    "id": 702,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-702-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "85aba1eb-3e5c-4149-9dd9-d484597ba0cc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-702",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:39:51.418Z",
            "success-count": 1
          },
          "uuid": "4a292a61-2192-406e-be94-5eee46e97755"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-702",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:59.799Z",
            "success-count": 6
          },
          "uuid": "be98ec71-26cb-4eb6-8988-21112d0a2469"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (702)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:51.436Z",
            "success-count": 14
          },
          "uuid": "ec870bfa-2e59-40a9-8ee0-4e5cdda3c7c1"
        }
      ],
      "external-identifiers": {
        "container-id": "0dd6f650e52fc8872438556cf3b4b639ee03fa3d9d4fc7385cf0390c65ea5174",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "livestreamdb-6877b6fc75-7w45t",
        "pod-name": "streampai/livestreamdb-6877b6fc75-7w45t"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 12173,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=livestreamdb"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6877b6fc75"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=livestreamdb",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.26",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "f2:f7:49:10:e6:ad",
        "interface-index": 69,
        "interface-name": "lxcf0882de5a2d1",
        "mac": "d2:77:d5:fc:41:bc"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 12173,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 12173,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 702

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 702

```
Timestamp              Status    State                   Message
2023-09-05T14:39:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:39:51Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:39:51Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:39:51Z   OK        ready                   Set identity for this endpoint
2023-09-05T14:39:51Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 12173

```
ID      LABELS
12173   k8s:app=livestreamdb
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 1111

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1111

```
Invalid argument: unknown type 1111
```


#### Endpoint Get 1111

```
[
  {
    "id": 1111,
    "spec": {
      "label-configuration": {
        "user": [
          "k8s:node-role.kubernetes.io/control-plane=true"
        ]
      },
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1111-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5c6a006e-148d-4c36-93ee-3eb2ed973c7b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1111",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:39:09.679Z",
            "success-count": 2
          },
          "uuid": "501278fe-446e-4f30-9891-adc551879c65"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-1111",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:59.801Z",
            "success-count": 23
          },
          "uuid": "31fda442-2cbe-452f-8055-95d04651f8e9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1111)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:59.689Z",
            "success-count": 21
          },
          "uuid": "3eb8e073-b439-47c5-a413-77ed5fcfdea8"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "k8s:node-role.kubernetes.io/control-plane=true",
          "reserved:host",
          "k8s:node.k0sproject.io/role=control-plane"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.k0sproject.io/role=control-plane",
          "reserved:host"
        ],
        "realized": {
          "user": [
            "k8s:node-role.kubernetes.io/control-plane=true"
          ]
        },
        "security-relevant": [
          "k8s:node-role.kubernetes.io/control-plane=true",
          "k8s:node.k0sproject.io/role=control-plane",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "06:e2:fc:10:79:52",
        "interface-name": "cilium_host",
        "mac": "06:e2:fc:10:79:52"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {
          "user": [
            "k8s:node-role.kubernetes.io/control-plane=true"
          ]
        },
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1111

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1111

```
Timestamp              Status   State                   Message
2023-09-05T14:39:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T14:39:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:27Z   OK       regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T14:39:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T14:39:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:39:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:09Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:39:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:39:09Z   OK       ready                   Set identity for this endpoint
2023-09-05T14:39:09Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2023-09-05T14:39:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:38:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:57Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:38:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:38:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:57Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:38:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2023-09-05T14:38:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:55Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:38:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:38:55Z   OK       ready                   Set identity for this endpoint
2023-09-05T14:38:55Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host
     reserved:kube-apiserver

```


#### BPF Policy Get 1288

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    7651    71        0        

```


#### BPF CT List 1288

```
Invalid argument: unknown type 1288
```


#### Endpoint Get 1288

```
[
  {
    "id": 1288,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1288-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b9f2e9e9-f12d-4551-ba75-fb51806281af"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1288",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:39:33.427Z",
            "success-count": 1
          },
          "uuid": "36cea724-b059-47ff-8b72-1641fbcca013"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-1288",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:59.801Z",
            "success-count": 9
          },
          "uuid": "8cc214bf-7794-4a1c-83e6-772862c618e2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1288)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:54.650Z",
            "success-count": 16
          },
          "uuid": "279134e5-97d7-4e80-b11e-6924223a0004"
        }
      ],
      "external-identifiers": {
        "container-id": "9b6d9c3d70cf6bfe9e4e0ee1830aa11fccbba5b90c4e6e8956054ed6e04b5885",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "streamchat-79dfbb9bb4-5bt4p",
        "pod-name": "streampai/streamchat-79dfbb9bb4-5bt4p"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 10456,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=streamchat"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=79dfbb9bb4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=streamchat",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.177",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "26:63:ac:d3:10:0f",
        "interface-index": 65,
        "interface-name": "lxc7f62068e89e0",
        "mac": "ca:87:cb:2d:c5:29"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 10456,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 10456,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1288

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1288

```
Timestamp              Status    State                   Message
2023-09-05T14:39:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:39:33Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:39:33Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:39:33Z   OK        ready                   Set identity for this endpoint
2023-09-05T14:39:33Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 10456

```
ID      LABELS
10456   k8s:app=streamchat
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 1493

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4375    29        0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1493

```
Invalid argument: unknown type 1493
```


#### Endpoint Get 1493

```
[
  {
    "id": 1493,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1493-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f5ed4233-146f-4f4e-9f48-25a5a9111906"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1493",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:39:28.387Z",
            "success-count": 1
          },
          "uuid": "6062065d-ceb9-47a6-ab60-6cc803b0091f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-1493",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:59.799Z",
            "success-count": 14
          },
          "uuid": "952cbbc6-9306-489e-bd06-63dd24ccd8ae"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1493)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:59.437Z",
            "success-count": 17
          },
          "uuid": "17024d85-15d7-42ed-9bc2-fc32e9089012"
        }
      ],
      "external-identifiers": {
        "container-id": "3aa76d2e40568b710d8e8328f5fb784b4896d9be23fd8073e544b990277d5ae8",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "frontend-58b6bf847f-nzgv5",
        "pod-name": "streampai/frontend-58b6bf847f-nzgv5"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 29809,
        "labels": [
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=58b6bf847f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.159",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "ba:5e:3c:1c:65:9b",
        "interface-index": 44,
        "interface-name": "lxcdc89b647f006",
        "mac": "ca:77:cb:4e:1c:80"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 29809,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 29809,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1493

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1493

```
Timestamp              Status   State                   Message
2023-09-05T14:39:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:39:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:28Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:39:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:39:28Z   OK       ready                   Set identity for this endpoint
2023-09-05T14:39:28Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 29809

```
ID      LABELS
29809   k8s:app=frontend
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 2128

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    12767   116       0        

```


#### BPF CT List 2128

```
Invalid argument: unknown type 2128
```


#### Endpoint Get 2128

```
[
  {
    "id": 2128,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2128-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7b2b5462-d30b-4c22-815d-14aa37186b01"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2128",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:39:27.886Z",
            "success-count": 1
          },
          "uuid": "16d9aaf2-5b44-4ba4-8ede-ea293cedca18"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-2128",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:59.801Z",
            "success-count": 15
          },
          "uuid": "d0a9b81d-54f1-41a4-8fcc-78c1e59cd2f3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2128)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:58.435Z",
            "success-count": 17
          },
          "uuid": "106ef11b-d722-432b-a4d2-edcd4619f681"
        }
      ],
      "external-identifiers": {
        "container-id": "a038bc390c1c6cb49b5646c1633294f7616d87c61bd806ffa62abafae9a14797",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "kratos-77cbf98c8f-k2l6k",
        "pod-name": "streampai/kratos-77cbf98c8f-k2l6k"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 36400,
        "labels": [
          "k8s:app=kratos",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=77cbf98c8f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=kratos",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.47",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "d6:fc:9b:b6:91:9f",
        "interface-index": 38,
        "interface-name": "lxc7cd25424e3c0",
        "mac": "5a:c9:e6:ab:85:d9"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 36400,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 36400,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2128

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2128

```
Timestamp              Status   State                   Message
2023-09-05T14:39:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:39:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:27Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:39:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:39:27Z   OK       ready                   Set identity for this endpoint
2023-09-05T14:39:27Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 36400

```
ID      LABELS
36400   k8s:app=kratos
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 2207

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    0        0         0        
Allow    Egress      0          ANY          NONE         disabled    161472   972       0        

```


#### BPF CT List 2207

```
Invalid argument: unknown type 2207
```


#### Endpoint Get 2207

```
[
  {
    "id": 2207,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2207-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "28592d57-56f9-40be-99d6-dbcbc667effb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2207",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:38:55.909Z",
            "success-count": 1
          },
          "uuid": "ce7d9476-6e75-4e76-a670-ec7527d12efd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-2207",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:59.799Z",
            "success-count": 22
          },
          "uuid": "e5657aa4-7290-45da-87a4-e70118df4c45"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2207)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:58.268Z",
            "success-count": 20
          },
          "uuid": "5e9597ce-bf20-429b-9432-e3dfbb8650cf"
        }
      ],
      "external-identifiers": {
        "container-id": "ec535af9ad510280608bf4224d80c8daf6dfbef3d9859d74d969cceda312715c",
        "k8s-namespace": "openebs",
        "k8s-pod-name": "openebs-localpv-provisioner-7d6ccb7795-pnpxg",
        "pod-name": "openebs/openebs-localpv-provisioner-7d6ccb7795-pnpxg"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 63175,
        "labels": [
          "k8s:openebs.io/version=3.4.0",
          "k8s:name=openebs-localpv-provisioner",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:openebs.io/component-name=openebs-localpv-provisioner"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7d6ccb7795"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:name=openebs-localpv-provisioner",
          "k8s:openebs.io/component-name=openebs-localpv-provisioner",
          "k8s:openebs.io/version=3.4.0"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.149",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "56:1c:8b:59:c2:f3",
        "interface-index": 14,
        "interface-name": "lxc3ad9da7138e0",
        "mac": "fa:8e:c3:46:e1:72"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 63175,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 63175,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2207

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2207

```
Timestamp              Status   State                   Message
2023-09-05T14:39:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T14:39:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:27Z   OK       regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T14:39:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T14:39:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:38:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:57Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:38:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:38:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:57Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:38:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:55Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:38:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:38:55Z   OK       ready                   Set identity for this endpoint
2023-09-05T14:38:55Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 63175

```
ID      LABELS
63175   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator
        k8s:io.kubernetes.pod.namespace=openebs
        k8s:name=openebs-localpv-provisioner
        k8s:openebs.io/component-name=openebs-localpv-provisioner
        k8s:openebs.io/version=3.4.0

```


#### BPF Policy Get 2326

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    12778   147       0        
Allow    Egress      0          ANY          NONE         disabled    16862   153       0        

```


#### BPF CT List 2326

```
Invalid argument: unknown type 2326
```


#### Endpoint Get 2326

```
[
  {
    "id": 2326,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2326-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "fe4b1829-10b5-4d61-8a14-ed714389faaa"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2326",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:38:55.906Z",
            "success-count": 1
          },
          "uuid": "485c4b20-9e5c-4d49-bc69-d33930a8ca56"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-2326",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:59.799Z",
            "success-count": 22
          },
          "uuid": "f1398ef4-12af-4f63-bddb-34cfae4304f5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2326)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:58.067Z",
            "success-count": 20
          },
          "uuid": "2e1a46bc-c3da-4b73-a892-32d6a788008a"
        }
      ],
      "external-identifiers": {
        "container-id": "2fe35873da099fbf47ce91e841d43ef34116605bffc4b992b95f56e9819f0ccc",
        "k8s-namespace": "openebs",
        "k8s-pod-name": "openebs-ndm-operator-7c667b76f8-8bkbl",
        "pod-name": "openebs/openebs-ndm-operator-7c667b76f8-8bkbl"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 19125,
        "labels": [
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:openebs.io/component-name=ndm-operator",
          "k8s:openebs.io/version=3.4.0",
          "k8s:name=openebs-ndm-operator",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7c667b76f8"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:name=openebs-ndm-operator",
          "k8s:openebs.io/component-name=ndm-operator",
          "k8s:openebs.io/version=3.4.0"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.129",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "96:f2:93:19:ee:19",
        "interface-index": 10,
        "interface-name": "lxc4731b84c7f23",
        "mac": "2e:7d:11:22:a4:40"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 19125,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 19125,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2326

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2326

```
Timestamp              Status   State                   Message
2023-09-05T14:39:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T14:39:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:27Z   OK       regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T14:39:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T14:39:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:38:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:57Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:38:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:38:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:57Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:38:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:55Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:38:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:38:55Z   OK       ready                   Set identity for this endpoint
2023-09-05T14:38:55Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 19125

```
ID      LABELS
19125   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator
        k8s:io.kubernetes.pod.namespace=openebs
        k8s:name=openebs-ndm-operator
        k8s:openebs.io/component-name=ndm-operator
        k8s:openebs.io/version=3.4.0

```


#### BPF Policy Get 2497

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1507    11        0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    40114   296       0        

```


#### BPF CT List 2497

```
Invalid argument: unknown type 2497
```


#### Endpoint Get 2497

```
[
  {
    "id": 2497,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2497-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "05794f15-33d1-42ab-809d-ae6e0da41cff"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2497",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:39:32.827Z",
            "success-count": 1
          },
          "uuid": "16094813-aa46-48b1-9df5-ed56297d9587"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-2497",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:59.801Z",
            "success-count": 10
          },
          "uuid": "0b8b4e9e-3bf0-42a7-9b67-4ed1f0191a3c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2497)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:53.640Z",
            "success-count": 16
          },
          "uuid": "0429cd40-2af6-4fa1-8c3c-975f42fd8e78"
        }
      ],
      "external-identifiers": {
        "container-id": "e168e8852c21772a25793515dc6522aa960f49e6b8f4cbc31f943cc5f8478217",
        "k8s-namespace": "ambassador",
        "k8s-pod-name": "traffic-manager-55d995585d-xn8tw",
        "pod-name": "ambassador/traffic-manager-55d995585d-xn8tw"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4626,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.name=ambassador",
          "k8s:io.kubernetes.pod.namespace=ambassador",
          "k8s:io.cilium.k8s.policy.serviceaccount=traffic-manager",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:telepresence=manager",
          "k8s:app=traffic-manager",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=ambassador"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=55d995585d"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=traffic-manager",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=ambassador",
          "k8s:io.cilium.k8s.namespace.labels.name=ambassador",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=traffic-manager",
          "k8s:io.kubernetes.pod.namespace=ambassador",
          "k8s:telepresence=manager"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "namedPorts": [
        {
          "name": "api",
          "port": 8081,
          "protocol": "TCP"
        },
        {
          "name": "grpc-trace",
          "port": 15766,
          "protocol": "TCP"
        },
        {
          "name": "https",
          "port": 443,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.81",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "1a:aa:9c:85:68:59",
        "interface-index": 67,
        "interface-name": "lxcc57ce94121eb",
        "mac": "32:b7:61:05:6b:b1"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4626,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4626,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2497

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2497

```
Timestamp              Status    State                   Message
2023-09-05T14:39:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK        regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:39:32Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:39:32Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:39:32Z   OK        ready                   Set identity for this endpoint
2023-09-05T14:39:32Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 4626

```
ID     LABELS
4626   k8s:app=traffic-manager
       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=ambassador
       k8s:io.cilium.k8s.namespace.labels.name=ambassador
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=traffic-manager
       k8s:io.kubernetes.pod.namespace=ambassador
       k8s:telepresence=manager

```


#### BPF Policy Get 2747

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    71233   628       0        
Allow    Egress      0          ANY          NONE         disabled    21169   193       0        

```


#### BPF CT List 2747

```
Invalid argument: unknown type 2747
```


#### Endpoint Get 2747

```
[
  {
    "id": 2747,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2747-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "14b0ad7f-b56a-4dcc-97ea-301bd4ffe5e7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2747",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:38:55.909Z",
            "success-count": 1
          },
          "uuid": "3b27c0e8-75ee-4af3-8cc7-19fdf678e802"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-2747",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:59.799Z",
            "success-count": 22
          },
          "uuid": "fc9806c0-4b9c-4d60-92de-fb4eb7843edd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2747)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:58.469Z",
            "success-count": 20
          },
          "uuid": "021ad40b-6c99-46b8-a381-5fa55e2c78a2"
        }
      ],
      "external-identifiers": {
        "container-id": "61294bfeb9bab421b3fd30eb07bc5b1e99f478d0234fd3dea0143cc6ffab7a26",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "metrics-server-7f86dff975-tb5rv",
        "pod-name": "kube-system/metrics-server-7f86dff975-tb5rv"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 10281,
        "labels": [
          "k8s:k8s-app=metrics-server",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:io.cilium.k8s.policy.serviceaccount=metrics-server",
          "k8s:io.cilium.k8s.policy.cluster=default"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7f86dff975"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=metrics-server",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=metrics-server"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "namedPorts": [
        {
          "name": "https",
          "port": 10250,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.112",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "2e:62:28:11:42:11",
        "interface-index": 22,
        "interface-name": "lxc85e32e5f3830",
        "mac": "66:05:5c:95:ed:56"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 10281,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 10281,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2747

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2747

```
Timestamp              Status   State                   Message
2023-09-05T14:39:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T14:39:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:27Z   OK       regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T14:39:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T14:39:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:38:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:57Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:38:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:38:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:57Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:38:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:55Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:38:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:38:55Z   OK       ready                   Set identity for this endpoint
2023-09-05T14:38:55Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 10281

```
ID      LABELS
10281   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=metrics-server
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=metrics-server

```


#### BPF Policy Get 2856

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    857     6         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2856

```
Invalid argument: unknown type 2856
```


#### Endpoint Get 2856

```
[
  {
    "id": 2856,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2856-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "57b24587-84f5-47ea-9559-7a6f16cdc8f6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2856",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:39:27.652Z",
            "success-count": 1
          },
          "uuid": "22b30bd6-752a-4e47-a77a-94b7da48dcba"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-2856",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:59.801Z",
            "success-count": 15
          },
          "uuid": "fd52062b-aa18-4a1f-86df-baa99db45dcb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2856)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:57.673Z",
            "success-count": 17
          },
          "uuid": "b85308c7-beb6-414f-addc-9e88b8a09665"
        }
      ],
      "external-identifiers": {
        "container-id": "68ca637dcd2d136ef756aae37df6750149931c80fa9f7df41e04214b18c7e84b",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "backend-855f6c7b4-j4k6m",
        "pod-name": "streampai/backend-855f6c7b4-j4k6m"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 22996,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=backend"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=855f6c7b4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=backend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.222",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "6e:fd:8e:af:03:32",
        "interface-index": 34,
        "interface-name": "lxcd4296424070a",
        "mac": "f2:aa:ec:70:ba:10"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 22996,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 22996,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2856

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2856

```
Timestamp              Status   State                   Message
2023-09-05T14:39:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:39:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:27Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:39:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:39:27Z   OK       ready                   Set identity for this endpoint
2023-09-05T14:39:27Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 22996

```
ID      LABELS
22996   k8s:app=backend
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 3903

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3756    26        0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3903

```
Invalid argument: unknown type 3903
```


#### Endpoint Get 3903

```
[
  {
    "id": 3903,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3903-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f5dd9871-625a-4c0d-946b-1d6a172ecaf6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3903",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:39:29.050Z",
            "success-count": 1
          },
          "uuid": "ca4bc036-f548-48e3-8fbf-f32665080592"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-3903",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:59.801Z",
            "success-count": 14
          },
          "uuid": "1baea0b3-0c92-47fc-9c9f-6b4b7fb9b8c8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3903)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:42:00.237Z",
            "success-count": 17
          },
          "uuid": "2156f28c-aa59-4a07-8804-439ce3be3e0b"
        }
      ],
      "external-identifiers": {
        "container-id": "e2432f9b67206bd3fe1782ed853c17ad2388fa781ef5a9f96cc8db9e32a7122a",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "frontend-58b6bf847f-sxngk",
        "pod-name": "streampai/frontend-58b6bf847f-sxngk"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 29809,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=58b6bf847f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.160",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "96:02:0a:e8:cd:1f",
        "interface-index": 48,
        "interface-name": "lxc2d7efae318fd",
        "mac": "4a:d8:6e:bc:92:e7"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 29809,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 29809,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3903

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3903

```
Timestamp              Status   State                   Message
2023-09-05T14:39:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:39:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:39:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:39:29Z   OK       ready                   Set identity for this endpoint
2023-09-05T14:39:29Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 29809

```
ID      LABELS
29809   k8s:app=frontend
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 3933

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3933

```
Invalid argument: unknown type 3933
```


#### Endpoint Get 3933

```
[
  {
    "id": 3933,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3933-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "a75f1da1-0adc-426f-ace8-d370061d7c39"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3933",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:39:00.674Z",
            "success-count": 1
          },
          "uuid": "a07c2b50-cdb3-4065-a707-c6e7e9612a31"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-3933",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:59.802Z",
            "success-count": 18
          },
          "uuid": "8f4bdd90-3a2a-431d-aabf-3fa397ea28af"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3933)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:42:00.692Z",
            "success-count": 20
          },
          "uuid": "6419acd0-4021-4ed6-b5b3-41a75fe26047"
        }
      ],
      "external-identifiers": {
        "container-id": "c91c81f3261d7411efb70ba81f8e9117e1e45ad3b32ae6b72da97c967915b14c",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "hubble-ui-6b468cff75-zwm9s",
        "pod-name": "kube-system/hubble-ui-6b468cff75-zwm9s"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 290,
        "labels": [
          "k8s:k8s-app=hubble-ui",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app.kubernetes.io/name=hubble-ui",
          "k8s:app.kubernetes.io/part-of=cilium"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6b468cff75"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=hubble-ui",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=hubble-ui"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "namedPorts": [
        {
          "name": "grpc",
          "port": 8090,
          "protocol": "TCP"
        },
        {
          "name": "http",
          "port": 8081,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.46",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "92:61:43:a6:2b:2d",
        "interface-index": 20,
        "interface-name": "lxce015178ea3e5",
        "mac": "16:b6:3c:f9:ff:c8"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 290,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 290,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3933

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3933

```
Timestamp              Status   State                   Message
2023-09-05T14:39:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T14:39:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:27Z   OK       regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T14:39:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T14:39:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:39:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:00Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:39:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:39:00Z   OK       ready                   Set identity for this endpoint
2023-09-05T14:39:00Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 290

```
ID    LABELS
290   k8s:app.kubernetes.io/name=hubble-ui
      k8s:app.kubernetes.io/part-of=cilium
      k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
      k8s:io.cilium.k8s.policy.cluster=default
      k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui
      k8s:io.kubernetes.pod.namespace=kube-system
      k8s:k8s-app=hubble-ui

```


#### BPF Policy Get 4067

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    25833   270       0        

```


#### BPF CT List 4067

```
Invalid argument: unknown type 4067
```


#### Endpoint Get 4067

```
[
  {
    "id": 4067,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-4067-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7c30ecec-5aca-41a4-93c6-c1ec947a2ad8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-4067",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:38:59.497Z",
            "success-count": 1
          },
          "uuid": "d4b9619c-8c5d-4a7f-936f-72b119612924"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-4067",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:59.801Z",
            "success-count": 19
          },
          "uuid": "f8d96cbd-2180-44d5-91bf-566233a44c1e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (4067)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-05T14:41:59.868Z",
            "success-count": 20
          },
          "uuid": "b8a3c25a-2006-416a-b11a-c1658f64c525"
        }
      ],
      "external-identifiers": {
        "container-id": "466d11cd15f1579e8ecfbb1ea6e424f6ec5a8e0b3f698da856abf2d63b506c70",
        "k8s-namespace": "openebs",
        "k8s-pod-name": "openebs-ndm-cluster-exporter-589554f487-g4gzj",
        "pod-name": "openebs/openebs-ndm-cluster-exporter-589554f487-g4gzj"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 62607,
        "labels": [
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:name=openebs-ndm-cluster-exporter",
          "k8s:openebs.io/component-name=ndm-cluster-exporter",
          "k8s:openebs.io/version=3.4.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.kubernetes.pod.namespace=openebs"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=589554f487"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:name=openebs-ndm-cluster-exporter",
          "k8s:openebs.io/component-name=ndm-cluster-exporter",
          "k8s:openebs.io/version=3.4.0"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: one or more identities created or deleted)",
          "state": "ready",
          "timestamp": "2023-09-05T14:39:59Z"
        }
      ],
      "namedPorts": [
        {
          "name": "metrics",
          "port": 9100,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.123",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "42:ca:ed:d2:b3:59",
        "interface-index": 18,
        "interface-name": "lxc2553a1209f7b",
        "mac": "96:d2:f4:a7:bb:c0"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 62607,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 62607,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 4067

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 4067

```
Timestamp              Status   State                   Message
2023-09-05T14:39:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-05T14:39:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:35Z   OK       regenerating            Regenerating endpoint: 
2023-09-05T14:39:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-05T14:39:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:33Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:29Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: Envoy Listeners added)
2023-09-05T14:39:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:27Z   OK       regenerating            Regenerating endpoint: Envoy Listeners added
2023-09-05T14:39:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to Envoy Listeners added
2023-09-05T14:39:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:02Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:39:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:39:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:39:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:39:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-05T14:38:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-05T14:38:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-05T14:38:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-05T14:38:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-05T14:38:59Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-05T14:38:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-05T14:38:59Z   OK       ready                   Set identity for this endpoint
2023-09-05T14:38:59Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 62607

```
ID      LABELS
62607   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator
        k8s:io.kubernetes.pod.namespace=openebs
        k8s:name=openebs-ndm-cluster-exporter
        k8s:openebs.io/component-name=ndm-cluster-exporter
        k8s:openebs.io/version=3.4.0

```


#### Service list

```
ID    Frontend              Service Type   Backend                            
92    10.96.0.1:443         ClusterIP      1 => 172.17.0.2:6443 (active)      
96    10.96.0.10:53         ClusterIP      1 => 10.244.0.49:53 (active)       
97    10.96.0.10:9153       ClusterIP      1 => 10.244.0.49:9153 (active)     
181   10.110.101.73:443     ClusterIP      1 => 10.244.0.40:10250 (active)    
182   10.97.217.47:80       ClusterIP      1 => 10.244.0.86:4245 (active)     
183   10.104.81.197:9402    ClusterIP      1 => 10.244.0.106:9402 (active)    
184   10.104.68.211:80      ClusterIP      1 => 10.244.0.46:8081 (active)     
185   10.110.16.102:443     ClusterIP      1 => 172.17.0.2:4244 (active)      
186   10.100.176.195:443    ClusterIP      1 => 10.244.0.112:10250 (active)   
187   10.99.236.194:7000    ClusterIP      1 => 10.244.0.137:7000 (active)    
                                           2 => 10.244.0.222:7000 (active)    
188   10.108.174.65:7000    ClusterIP                                         
189   10.102.58.195:3000    ClusterIP      1 => 10.244.0.41:3000 (active)     
                                           2 => 10.244.0.231:3000 (active)    
                                           3 => 10.244.0.159:3000 (active)    
                                           4 => 10.244.0.160:3000 (active)    
190   10.101.105.189:4433   ClusterIP      1 => 10.244.0.47:4433 (active)     
191   10.105.1.38:5432      ClusterIP      1 => 10.244.0.26:5432 (active)     
192   10.97.110.167:9000    ClusterIP      1 => 10.244.0.62:9000 (active)     
193   10.97.110.167:9001    ClusterIP      1 => 10.244.0.62:9001 (active)     
194   10.109.161.190:8081   ClusterIP      1 => 10.244.0.178:8081 (active)    
195   10.103.2.13:5432      ClusterIP      1 => 10.244.0.132:5432 (active)    
196   10.98.188.83:6379     ClusterIP      1 => 10.244.0.124:6379 (active)    
197   10.97.78.2:80         ClusterIP                                         
198   172.17.8.187:80       LoadBalancer                                      
199   172.17.0.2:30888      NodePort                                          
200   0.0.0.0:30888         NodePort                                          
201   10.109.194.147:443    ClusterIP      1 => 10.244.0.81:443 (active)      
```

#### Policy get

```
:
 []
Revision: 2

```


#### ipam

```
<nil>
```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0xc0016d21c0)({
 Events: (chan k8s.ServiceEvent) (cap=128) 0xc00072c420,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=23) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0xc001032160)(frontends:[10.96.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0xc001032420)(frontends:[10.96.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) openebs/openebs-ndm-cluster-exporter-service: (*k8s.Service)(0xc0010324d0)(frontends:[]/ports=[metrics]/selector=map[name:openebs-ndm-cluster-exporter]),
  (k8s.ServiceID) kube-system/metrics-server: (*k8s.Service)(0xc001032790)(frontends:[10.100.176.195]/ports=[https]/selector=map[k8s-app:metrics-server]),
  (k8s.ServiceID) streampai/backend: (*k8s.Service)(0xc0015fe4d0)(frontends:[10.99.236.194]/ports=[http]/selector=map[app:backend]),
  (k8s.ServiceID) streampai/minio: (*k8s.Service)(0xc0009f0790)(frontends:[10.97.110.167]/ports=[main console]/selector=map[app:minio]),
  (k8s.ServiceID) ambassador/traffic-manager: (*k8s.Service)(0xc0017c6000)(frontends:[]/ports=[api grpc-trace]/selector=map[app:traffic-manager telepresence:manager]),
  (k8s.ServiceID) cert-manager/cert-manager-webhook: (*k8s.Service)(0xc0010320b0)(frontends:[10.110.101.73]/ports=[https]/selector=map[app.kubernetes.io/component:webhook app.kubernetes.io/instance:cert-manager app.kubernetes.io/name:webhook]),
  (k8s.ServiceID) cert-manager/cert-manager: (*k8s.Service)(0xc001032630)(frontends:[10.104.81.197]/ports=[tcp-prometheus-servicemonitor]/selector=map[app.kubernetes.io/component:controller app.kubernetes.io/instance:cert-manager app.kubernetes.io/name:cert-manager]),
  (k8s.ServiceID) streampai/frontend: (*k8s.Service)(0xc001f402c0)(frontends:[10.102.58.195]/ports=[http]/selector=map[app:frontend]),
  (k8s.ServiceID) streampai/pgweb: (*k8s.Service)(0xc0015fe630)(frontends:[10.109.161.190]/ports=[http]/selector=map[app:pgweb]),
  (k8s.ServiceID) ambassador/agent-injector: (*k8s.Service)(0xc0017c60b0)(frontends:[10.109.194.147]/ports=[https]/selector=map[app:traffic-manager telepresence:manager]),
  (k8s.ServiceID) kube-system/hubble-relay: (*k8s.Service)(0xc0010322c0)(frontends:[10.97.217.47]/ports=[]/selector=map[k8s-app:hubble-relay]),
  (k8s.ServiceID) openebs/openebs-ndm-node-exporter-service: (*k8s.Service)(0xc001032840)(frontends:[]/ports=[metrics]/selector=map[name:openebs-ndm-node-exporter]),
  (k8s.ServiceID) streampai/coqui: (*k8s.Service)(0xc0009f0580)(frontends:[10.108.174.65]/ports=[http]/selector=map[app:coqui]),
  (k8s.ServiceID) streampai/livestreamdb: (*k8s.Service)(0xc001f404d0)(frontends:[10.105.1.38]/ports=[]/selector=map[app:livestreamdb]),
  (k8s.ServiceID) streampai/redis: (*k8s.Service)(0xc001f40840)(frontends:[10.98.188.83]/ports=[http]/selector=map[app:redis]),
  (k8s.ServiceID) kube-system/cilium-envoy: (*k8s.Service)(0xc001032210)(frontends:[]/ports=[envoy-metrics]/selector=map[k8s-app:cilium-envoy]),
  (k8s.ServiceID) kube-system/hubble-ui: (*k8s.Service)(0xc001032370)(frontends:[10.104.68.211]/ports=[http]/selector=map[k8s-app:hubble-ui]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0xc0010326e0)(frontends:[10.110.16.102]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) streampai/kratos: (*k8s.Service)(0xc001f40420)(frontends:[10.101.105.189]/ports=[http]/selector=map[app:kratos]),
  (k8s.ServiceID) streampai/postgres: (*k8s.Service)(0xc0009f0840)(frontends:[10.103.2.13]/ports=[]/selector=map[app:postgres]),
  (k8s.ServiceID) streampai/cilium-gateway-sgtw: (*k8s.Service)(0xc001f409a0)(frontends:[10.97.78.2]/ports=[port-80]/selector=map[])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=19) {
  (k8s.ServiceID) kube-system/metrics-server: (*k8s.EndpointSlices)(0xc000e4e020)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "metrics-server-n47tc": (*k8s.Endpoints)(0xc0014c9520)(10.244.0.112:10250/TCP)
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0xc000e4e038)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0xc001d44a90)(172.17.0.2:6443/TCP)
   }
  }),
  (k8s.ServiceID) streampai/livestreamdb: (*k8s.EndpointSlices)(0xc000ae8730)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=18) "livestreamdb-n86qc": (*k8s.Endpoints)(0xc0041775f0)(10.244.0.26:5432/TCP)
   }
  }),
  (k8s.ServiceID) streampai/minio: (*k8s.EndpointSlices)(0xc000e4e400)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=11) "minio-47d9s": (*k8s.Endpoints)(0xc003374270)(10.244.0.62:9000/TCP,10.244.0.62:9001/TCP)
   }
  }),
  (k8s.ServiceID) streampai/pgweb: (*k8s.EndpointSlices)(0xc000e4e418)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=11) "pgweb-jbsmq": (*k8s.Endpoints)(0xc003d12750)(10.244.0.178:8081/TCP)
   }
  }),
  (k8s.ServiceID) ambassador/agent-injector: (*k8s.EndpointSlices)(0xc000d84660)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "agent-injector-n94z7": (*k8s.Endpoints)(0xc000f48ea0)(10.244.0.81:443/TCP)
   }
  }),
  (k8s.ServiceID) cert-manager/cert-manager: (*k8s.EndpointSlices)(0xc000e4e028)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=18) "cert-manager-dt5sp": (*k8s.Endpoints)(0xc0016a6c30)(10.244.0.106:9402/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-ui: (*k8s.EndpointSlices)(0xc0009e4110)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=15) "hubble-ui-kkt6z": (*k8s.Endpoints)(0xc002b184e0)(10.244.0.46:8081/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0xc0009e4118)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-fgsq4": (*k8s.Endpoints)(0xc005268270)(10.244.0.49:53/TCP,10.244.0.49:53/UDP,10.244.0.49:9153/TCP)
   }
  }),
  (k8s.ServiceID) streampai/frontend: (*k8s.EndpointSlices)(0xc001444948)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "frontend-c2w4h": (*k8s.Endpoints)(0xc002ba20d0)(10.244.0.159:3000/TCP,10.244.0.160:3000/TCP,10.244.0.231:3000/TCP,10.244.0.41:3000/TCP)
   }
  }),
  (k8s.ServiceID) streampai/postgres: (*k8s.EndpointSlices)(0xc000e4e438)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "postgres-cw965": (*k8s.Endpoints)(0xc0033741a0)(10.244.0.132:5432/TCP)
   }
  }),
  (k8s.ServiceID) cert-manager/cert-manager-webhook: (*k8s.EndpointSlices)(0xc000e4e030)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=26) "cert-manager-webhook-vzzdm": (*k8s.Endpoints)(0xc001343ad0)(10.244.0.40:10250/TCP)
   }
  }),
  (k8s.ServiceID) streampai/backend: (*k8s.EndpointSlices)(0xc001444940)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=13) "backend-s6nm9": (*k8s.Endpoints)(0xc001589e10)(10.244.0.137:7000/TCP,10.244.0.222:7000/TCP)
   }
  }),
  (k8s.ServiceID) streampai/coqui: (*k8s.EndpointSlices)(0xc000e4e3f0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=11) "coqui-gs7xn": (*k8s.Endpoints)(0xc0016a7860)()
   }
  }),
  (k8s.ServiceID) streampai/kratos: (*k8s.EndpointSlices)(0xc000ae8720)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=12) "kratos-tr46j": (*k8s.Endpoints)(0xc003a981a0)(10.244.0.47:4433/TCP)
   }
  }),
  (k8s.ServiceID) streampai/redis: (*k8s.EndpointSlices)(0xc000ae8740)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=11) "redis-sv6bn": (*k8s.Endpoints)(0xc0016a6b60)(10.244.0.124:6379/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0xc0009e4100)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-tsk6t": (*k8s.Endpoints)(0xc001044680)(172.17.0.2:4244/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-relay: (*k8s.EndpointSlices)(0xc0009e4108)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=18) "hubble-relay-pbfp2": (*k8s.Endpoints)(0xc003a98d00)(10.244.0.86:4245/TCP)
   }
  }),
  (k8s.ServiceID) streampai/cilium-gateway-sgtw: (*k8s.EndpointSlices)(0xc000e4e548)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=25) "cilium-gateway-sgtw-z95gc": (*k8s.Endpoints)(0xc001044000)(192.192.192.192:9999/TCP)
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 nodeAddressing: (*linux.linuxNodeAddressing)(0x5e20750)({
  ipv6: (linux.addressFamilyIPv6) {
  },
  ipv4: (linux.addressFamilyIPv4) {
  }
 }),
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption



#### Cilium version

```
1.14.1 c191ef6f 2023-08-10T18:54:57+02:00 go version go1.20.7 linux/amd64
```


#### Cilium memory map


```
00400000-02bf5000 r-xp 00000000 08:02 42239478                           /usr/bin/cilium-agent
02bf5000-0577f000 r--p 027f5000 08:02 42239478                           /usr/bin/cilium-agent
0577f000-058a3000 rw-p 0537f000 08:02 42239478                           /usr/bin/cilium-agent
058a3000-06036000 rw-p 00000000 00:00 0 
c000000000-c002e00000 rw-p 00000000 00:00 0 
c002e00000-c003600000 rw-p 00000000 00:00 0 
c003600000-c003800000 rw-p 00000000 00:00 0 
c003800000-c005400000 rw-p 00000000 00:00 0 
c005400000-c008000000 ---p 00000000 00:00 0 
7ffa493c4000-7ffa49529000 rw-p 00000000 00:00 0 
7ffa49529000-7ffa4956a000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa4956a000-7ffa495ab000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa495ab000-7ffa495ec000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa495ec000-7ffa4962d000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa4962d000-7ffa4966e000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa4966e000-7ffa496af000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa496af000-7ffa496f0000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa496f0000-7ffa49731000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa49731000-7ffa49772000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa49772000-7ffa497b3000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa497b3000-7ffa497f4000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa497f4000-7ffa49835000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa49835000-7ffa49837000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa49837000-7ffa49839000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa49839000-7ffa4983b000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa4983b000-7ffa4983d000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa4983d000-7ffa4983f000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa4983f000-7ffa49841000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa49841000-7ffa49843000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa49843000-7ffa49845000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa49845000-7ffa49847000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa49847000-7ffa49849000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa49849000-7ffa4984b000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa4984b000-7ffa4984d000 rw-s 00000000 00:0e 2069                       anon_inode:[perf_event]
7ffa4984d000-7ffa4c200000 rw-p 00000000 00:00 0 
7ffa4c200000-7ffa4c400000 rw-p 00000000 00:00 0 
7ffa4c400000-7ffa4c5df000 rw-p 00000000 00:00 0 
7ffa4c5df000-7ffa5cb58000 ---p 00000000 00:00 0 
7ffa5cb58000-7ffa5cb59000 rw-p 00000000 00:00 0 
7ffa5cb59000-7ffa6ea08000 ---p 00000000 00:00 0 
7ffa6ea08000-7ffa6ea09000 rw-p 00000000 00:00 0 
7ffa6ea09000-7ffa70dde000 ---p 00000000 00:00 0 
7ffa70dde000-7ffa70ddf000 rw-p 00000000 00:00 0 
7ffa70ddf000-7ffa71258000 ---p 00000000 00:00 0 
7ffa71258000-7ffa71259000 rw-p 00000000 00:00 0 
7ffa71259000-7ffa712d8000 ---p 00000000 00:00 0 
7ffa712d8000-7ffa71338000 rw-p 00000000 00:00 0 
7fff8935e000-7fff8937f000 rw-p 00000000 00:00 0                          [stack]
7fff893ec000-7fff893f0000 r--p 00000000 00:00 0                          [vvar]
7fff893f0000-7fff893f2000 r-xp 00000000 00:00 0                          [vdso]
ffffffffff600000-ffffffffff601000 --xp 00000000 00:00 0                  [vsyscall]

```


#### Kernel version

```
6.5.0
```

