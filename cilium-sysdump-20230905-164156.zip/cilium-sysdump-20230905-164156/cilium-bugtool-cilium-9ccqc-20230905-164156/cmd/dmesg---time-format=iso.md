2023-09-05T13:06:40,000000+00:00 Linux version 6.5.0 (nixbld@localhost) (gcc (GCC) 12.3.0, GNU ld (GNU Binutils) 2.40) #1-NixOS SMP PREEMPT_DYNAMIC Sun Aug 27 21:49:51 UTC 2023
2023-09-05T13:06:40,000000+00:00 Command line: initrd=\efi\nixos\7iziifwb9in6d9y2z16m10z4avbz8sxz-initrd-linux-6.5-initrd.efi init=/nix/store/6zhcn3ndafmmnvx6ka1axfgv546ggfsd-nixos-system-nixos-23.05.20230902.9075cba/init cgroup_no_v1=all cgroup_enable=memory cgroup_enable=cpuset systemd.unified_cgroup_hierarchy=1 loglevel=4 nvidia-drm.modeset=1
2023-09-05T13:06:40,000000+00:00 BIOS-provided physical RAM map:
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x0000000000000000-0x000000000009ffff] usable
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000000a0000-0x00000000000fffff] reserved
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x0000000000100000-0x0000000009bfefff] usable
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x0000000009bff000-0x0000000009ffffff] reserved
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x000000000a000000-0x000000000a1fffff] usable
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x000000000a200000-0x000000000a20dfff] ACPI NVS
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x000000000a20e000-0x000000000affffff] usable
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x000000000b000000-0x000000000b01ffff] reserved
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x000000000b020000-0x00000000ba9bbfff] usable
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000ba9bc000-0x00000000bc0fefff] reserved
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000bc0ff000-0x00000000bc135fff] ACPI data
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000bc136000-0x00000000bc810fff] ACPI NVS
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000bc811000-0x00000000bdbfefff] reserved
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000bdbff000-0x00000000beffffff] usable
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000bf000000-0x00000000bfffffff] reserved
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000f0000000-0x00000000f7ffffff] reserved
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000fd200000-0x00000000fd2fffff] reserved
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000fd600000-0x00000000fd7fffff] reserved
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000fea00000-0x00000000fea0ffff] reserved
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000feb80000-0x00000000fec01fff] reserved
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000fec10000-0x00000000fec10fff] reserved
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000fec30000-0x00000000fec30fff] reserved
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000fed00000-0x00000000fed00fff] reserved
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000fed40000-0x00000000fed44fff] reserved
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000fed80000-0x00000000fed8ffff] reserved
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000fedc2000-0x00000000fedcffff] reserved
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000fedd4000-0x00000000fedd5fff] reserved
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x00000000ff000000-0x00000000ffffffff] reserved
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x0000000100000000-0x000000043f37ffff] usable
2023-09-05T13:06:40,000000+00:00 BIOS-e820: [mem 0x000000043f380000-0x000000043fffffff] reserved
2023-09-05T13:06:40,000000+00:00 NX (Execute Disable) protection: active
2023-09-05T13:06:40,000000+00:00 e820: update [mem 0xb5374018-0xb5393e57] usable ==> usable
2023-09-05T13:06:40,000000+00:00 e820: update [mem 0xb5374018-0xb5393e57] usable ==> usable
2023-09-05T13:06:40,000000+00:00 extended physical RAM map:
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x0000000000000000-0x000000000009ffff] usable
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000000a0000-0x00000000000fffff] reserved
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x0000000000100000-0x0000000009bfefff] usable
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x0000000009bff000-0x0000000009ffffff] reserved
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x000000000a000000-0x000000000a1fffff] usable
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x000000000a200000-0x000000000a20dfff] ACPI NVS
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x000000000a20e000-0x000000000affffff] usable
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x000000000b000000-0x000000000b01ffff] reserved
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x000000000b020000-0x00000000b5374017] usable
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000b5374018-0x00000000b5393e57] usable
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000b5393e58-0x00000000ba9bbfff] usable
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000ba9bc000-0x00000000bc0fefff] reserved
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000bc0ff000-0x00000000bc135fff] ACPI data
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000bc136000-0x00000000bc810fff] ACPI NVS
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000bc811000-0x00000000bdbfefff] reserved
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000bdbff000-0x00000000beffffff] usable
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000bf000000-0x00000000bfffffff] reserved
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000f0000000-0x00000000f7ffffff] reserved
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000fd200000-0x00000000fd2fffff] reserved
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000fd600000-0x00000000fd7fffff] reserved
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000fea00000-0x00000000fea0ffff] reserved
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000feb80000-0x00000000fec01fff] reserved
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000fec10000-0x00000000fec10fff] reserved
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000fec30000-0x00000000fec30fff] reserved
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000fed00000-0x00000000fed00fff] reserved
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000fed40000-0x00000000fed44fff] reserved
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000fed80000-0x00000000fed8ffff] reserved
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000fedc2000-0x00000000fedcffff] reserved
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000fedd4000-0x00000000fedd5fff] reserved
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x00000000ff000000-0x00000000ffffffff] reserved
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x0000000100000000-0x000000043f37ffff] usable
2023-09-05T13:06:40,000000+00:00 reserve setup_data: [mem 0x000000043f380000-0x000000043fffffff] reserved
2023-09-05T13:06:40,000000+00:00 efi: EFI v2.7 by American Megatrends
2023-09-05T13:06:40,000000+00:00 efi: ACPI=0xbc7fa000 ACPI 2.0=0xbc7fa014 TPMFinalLog=0xbc7c4000 SMBIOS=0xbda22000 SMBIOS 3.0=0xbda21000 MEMATTR=0xb7020298 ESRT=0xb914bb98 RNG=0xbc10af18 INITRD=0xb5f10a98 TPMEventLog=0xb5394018 
2023-09-05T13:06:40,000000+00:00 random: crng init done
2023-09-05T13:06:40,000000+00:00 efi: Remove mem334: MMIO range=[0xf0000000-0xf7ffffff] (128MB) from e820 map
2023-09-05T13:06:40,000000+00:00 e820: remove [mem 0xf0000000-0xf7ffffff] reserved
2023-09-05T13:06:40,000000+00:00 efi: Remove mem335: MMIO range=[0xfd200000-0xfd2fffff] (1MB) from e820 map
2023-09-05T13:06:40,000000+00:00 e820: remove [mem 0xfd200000-0xfd2fffff] reserved
2023-09-05T13:06:40,000000+00:00 efi: Remove mem336: MMIO range=[0xfd600000-0xfd7fffff] (2MB) from e820 map
2023-09-05T13:06:40,000000+00:00 e820: remove [mem 0xfd600000-0xfd7fffff] reserved
2023-09-05T13:06:40,000000+00:00 efi: Not removing mem337: MMIO range=[0xfea00000-0xfea0ffff] (64KB) from e820 map
2023-09-05T13:06:40,000000+00:00 efi: Remove mem338: MMIO range=[0xfeb80000-0xfec01fff] (0MB) from e820 map
2023-09-05T13:06:40,000000+00:00 e820: remove [mem 0xfeb80000-0xfec01fff] reserved
2023-09-05T13:06:40,000000+00:00 efi: Not removing mem339: MMIO range=[0xfec10000-0xfec10fff] (4KB) from e820 map
2023-09-05T13:06:40,000000+00:00 efi: Not removing mem340: MMIO range=[0xfec30000-0xfec30fff] (4KB) from e820 map
2023-09-05T13:06:40,000000+00:00 efi: Not removing mem341: MMIO range=[0xfed00000-0xfed00fff] (4KB) from e820 map
2023-09-05T13:06:40,000000+00:00 efi: Not removing mem342: MMIO range=[0xfed40000-0xfed44fff] (20KB) from e820 map
2023-09-05T13:06:40,000000+00:00 efi: Not removing mem343: MMIO range=[0xfed80000-0xfed8ffff] (64KB) from e820 map
2023-09-05T13:06:40,000000+00:00 efi: Not removing mem344: MMIO range=[0xfedc2000-0xfedcffff] (56KB) from e820 map
2023-09-05T13:06:40,000000+00:00 efi: Not removing mem345: MMIO range=[0xfedd4000-0xfedd5fff] (8KB) from e820 map
2023-09-05T13:06:40,000000+00:00 efi: Remove mem346: MMIO range=[0xff000000-0xffffffff] (16MB) from e820 map
2023-09-05T13:06:40,000000+00:00 e820: remove [mem 0xff000000-0xffffffff] reserved
2023-09-05T13:06:40,000000+00:00 SMBIOS 3.3.0 present.
2023-09-05T13:06:40,000000+00:00 DMI: To Be Filled By O.E.M. To Be Filled By O.E.M./X470 Taichi, BIOS P10.01 04/17/2023
2023-09-05T13:06:40,000000+00:00 tsc: Fast TSC calibration using PIT
2023-09-05T13:06:40,000000+00:00 tsc: Detected 3500.252 MHz processor
2023-09-05T13:06:40,000357+00:00 e820: update [mem 0x00000000-0x00000fff] usable ==> reserved
2023-09-05T13:06:40,000359+00:00 e820: remove [mem 0x000a0000-0x000fffff] usable
2023-09-05T13:06:40,000364+00:00 last_pfn = 0x43f380 max_arch_pfn = 0x400000000
2023-09-05T13:06:40,000367+00:00 MTRR map: 7 entries (3 fixed + 4 variable; max 20), built from 9 variable MTRRs
2023-09-05T13:06:40,000368+00:00 x86/PAT: Configuration [0-7]: WB  WC  UC- UC  WB  WP  UC- WT  
2023-09-05T13:06:40,001099+00:00 e820: update [mem 0xbc2a0000-0xbc2affff] usable ==> reserved
2023-09-05T13:06:40,001104+00:00 e820: update [mem 0xc0000000-0xffffffff] usable ==> reserved
2023-09-05T13:06:40,001106+00:00 last_pfn = 0xbf000 max_arch_pfn = 0x400000000
2023-09-05T13:06:40,003766+00:00 esrt: Reserving ESRT space from 0x00000000b914bb98 to 0x00000000b914bbd0.
2023-09-05T13:06:40,003772+00:00 e820: update [mem 0xb914b000-0xb914bfff] usable ==> reserved
2023-09-05T13:06:40,003802+00:00 Using GB pages for direct mapping
2023-09-05T13:06:40,004012+00:00 Secure boot disabled
2023-09-05T13:06:40,004013+00:00 RAMDISK: [mem 0xb0af0000-0xb1665fff]
2023-09-05T13:06:40,004016+00:00 ACPI: Early table checksum verification disabled
2023-09-05T13:06:40,004018+00:00 ACPI: RSDP 0x00000000BC7FA014 000024 (v02 ALASKA)
2023-09-05T13:06:40,004020+00:00 ACPI: XSDT 0x00000000BC7F9728 0000BC (v01 ALASKA A M I    01072009 AMI  01000013)
2023-09-05T13:06:40,004023+00:00 ACPI: FACP 0x00000000BC127000 000114 (v06 ALASKA A M I    01072009 AMI  00010013)
2023-09-05T13:06:40,004026+00:00 ACPI: DSDT 0x00000000BC120000 0065BE (v02 ALASKA A M I    01072009 INTL 20120913)
2023-09-05T13:06:40,004028+00:00 ACPI: FACS 0x00000000BC7F4000 000040
2023-09-05T13:06:40,004029+00:00 ACPI: SSDT 0x00000000BC12D000 008CE9 (v02 AMD    AmdTable 00000002 MSFT 04000000)
2023-09-05T13:06:40,004031+00:00 ACPI: SSDT 0x00000000BC129000 003CB6 (v02 AMD    AMD AOD  00000001 INTL 20120913)
2023-09-05T13:06:40,004032+00:00 ACPI: SSDT 0x00000000BC128000 0000C8 (v02 ALASKA CPUSSDT  01072009 AMI  01072009)
2023-09-05T13:06:40,004034+00:00 ACPI: FIDT 0x00000000BC11F000 00009C (v01 ALASKA A M I    01072009 AMI  00010013)
2023-09-05T13:06:40,004035+00:00 ACPI: MCFG 0x00000000BC11E000 00003C (v01 ALASKA A M I    01072009 MSFT 00010013)
2023-09-05T13:06:40,004036+00:00 ACPI: AAFT 0x00000000BC11D000 0000F1 (v01 ALASKA OEMAAFT  01072009 MSFT 00000097)
2023-09-05T13:06:40,004038+00:00 ACPI: HPET 0x00000000BC11C000 000038 (v01 ALASKA A M I    01072009 AMI  00000005)
2023-09-05T13:06:40,004039+00:00 ACPI: TPM2 0x00000000BC11B000 00004C (v04 ALASKA A M I    00000001 AMI  00000000)
2023-09-05T13:06:40,004041+00:00 ACPI: PCCT 0x00000000BC11A000 00006E (v02 AMD    AmdTable 00000001 AMD  00000001)
2023-09-05T13:06:40,004042+00:00 ACPI: SSDT 0x00000000BC117000 002AEF (v02 AMD    AmdTable 00000001 AMD  00000001)
2023-09-05T13:06:40,004043+00:00 ACPI: CRAT 0x00000000BC116000 000B90 (v01 AMD    AmdTable 00000001 AMD  00000001)
2023-09-05T13:06:40,004045+00:00 ACPI: CDIT 0x00000000BC115000 000029 (v01 AMD    AmdTable 00000001 AMD  00000001)
2023-09-05T13:06:40,004046+00:00 ACPI: SSDT 0x00000000BC111000 0037C4 (v02 AMD    MYRTLE   00000001 INTL 20120913)
2023-09-05T13:06:40,004048+00:00 ACPI: SSDT 0x00000000BC110000 0000BF (v01 AMD    AmdTable 00001000 INTL 20120913)
2023-09-05T13:06:40,004049+00:00 ACPI: WSMT 0x00000000BC10F000 000028 (v01 ALASKA A M I    01072009 AMI  00010013)
2023-09-05T13:06:40,004050+00:00 ACPI: APIC 0x00000000BC10E000 00015E (v03 ALASKA A M I    01072009 AMI  00010013)
2023-09-05T13:06:40,004052+00:00 ACPI: SSDT 0x00000000BC10C000 0010AF (v02 AMD    MYRTLE   00000001 INTL 20120913)
2023-09-05T13:06:40,004053+00:00 ACPI: FPDT 0x00000000BC10B000 000044 (v01 ALASKA A M I    01072009 AMI  01000013)
2023-09-05T13:06:40,004054+00:00 ACPI: Reserving FACP table memory at [mem 0xbc127000-0xbc127113]
2023-09-05T13:06:40,004055+00:00 ACPI: Reserving DSDT table memory at [mem 0xbc120000-0xbc1265bd]
2023-09-05T13:06:40,004055+00:00 ACPI: Reserving FACS table memory at [mem 0xbc7f4000-0xbc7f403f]
2023-09-05T13:06:40,004056+00:00 ACPI: Reserving SSDT table memory at [mem 0xbc12d000-0xbc135ce8]
2023-09-05T13:06:40,004056+00:00 ACPI: Reserving SSDT table memory at [mem 0xbc129000-0xbc12ccb5]
2023-09-05T13:06:40,004057+00:00 ACPI: Reserving SSDT table memory at [mem 0xbc128000-0xbc1280c7]
2023-09-05T13:06:40,004057+00:00 ACPI: Reserving FIDT table memory at [mem 0xbc11f000-0xbc11f09b]
2023-09-05T13:06:40,004057+00:00 ACPI: Reserving MCFG table memory at [mem 0xbc11e000-0xbc11e03b]
2023-09-05T13:06:40,004058+00:00 ACPI: Reserving AAFT table memory at [mem 0xbc11d000-0xbc11d0f0]
2023-09-05T13:06:40,004058+00:00 ACPI: Reserving HPET table memory at [mem 0xbc11c000-0xbc11c037]
2023-09-05T13:06:40,004059+00:00 ACPI: Reserving TPM2 table memory at [mem 0xbc11b000-0xbc11b04b]
2023-09-05T13:06:40,004059+00:00 ACPI: Reserving PCCT table memory at [mem 0xbc11a000-0xbc11a06d]
2023-09-05T13:06:40,004059+00:00 ACPI: Reserving SSDT table memory at [mem 0xbc117000-0xbc119aee]
2023-09-05T13:06:40,004060+00:00 ACPI: Reserving CRAT table memory at [mem 0xbc116000-0xbc116b8f]
2023-09-05T13:06:40,004060+00:00 ACPI: Reserving CDIT table memory at [mem 0xbc115000-0xbc115028]
2023-09-05T13:06:40,004061+00:00 ACPI: Reserving SSDT table memory at [mem 0xbc111000-0xbc1147c3]
2023-09-05T13:06:40,004061+00:00 ACPI: Reserving SSDT table memory at [mem 0xbc110000-0xbc1100be]
2023-09-05T13:06:40,004061+00:00 ACPI: Reserving WSMT table memory at [mem 0xbc10f000-0xbc10f027]
2023-09-05T13:06:40,004062+00:00 ACPI: Reserving APIC table memory at [mem 0xbc10e000-0xbc10e15d]
2023-09-05T13:06:40,004062+00:00 ACPI: Reserving SSDT table memory at [mem 0xbc10c000-0xbc10d0ae]
2023-09-05T13:06:40,004062+00:00 ACPI: Reserving FPDT table memory at [mem 0xbc10b000-0xbc10b043]
2023-09-05T13:06:40,004106+00:00 No NUMA configuration found
2023-09-05T13:06:40,004106+00:00 Faking a node at [mem 0x0000000000000000-0x000000043f37ffff]
2023-09-05T13:06:40,004108+00:00 NODE_DATA(0) allocated [mem 0x43f37a000-0x43f37ffff]
2023-09-05T13:06:40,004125+00:00 Zone ranges:
2023-09-05T13:06:40,004126+00:00   DMA      [mem 0x0000000000001000-0x0000000000ffffff]
2023-09-05T13:06:40,004127+00:00   DMA32    [mem 0x0000000001000000-0x00000000ffffffff]
2023-09-05T13:06:40,004127+00:00   Normal   [mem 0x0000000100000000-0x000000043f37ffff]
2023-09-05T13:06:40,004128+00:00   Device   empty
2023-09-05T13:06:40,004129+00:00 Movable zone start for each node
2023-09-05T13:06:40,004129+00:00 Early memory node ranges
2023-09-05T13:06:40,004129+00:00   node   0: [mem 0x0000000000001000-0x000000000009ffff]
2023-09-05T13:06:40,004130+00:00   node   0: [mem 0x0000000000100000-0x0000000009bfefff]
2023-09-05T13:06:40,004131+00:00   node   0: [mem 0x000000000a000000-0x000000000a1fffff]
2023-09-05T13:06:40,004131+00:00   node   0: [mem 0x000000000a20e000-0x000000000affffff]
2023-09-05T13:06:40,004132+00:00   node   0: [mem 0x000000000b020000-0x00000000ba9bbfff]
2023-09-05T13:06:40,004132+00:00   node   0: [mem 0x00000000bdbff000-0x00000000beffffff]
2023-09-05T13:06:40,004133+00:00   node   0: [mem 0x0000000100000000-0x000000043f37ffff]
2023-09-05T13:06:40,004134+00:00 Initmem setup node 0 [mem 0x0000000000001000-0x000000043f37ffff]
2023-09-05T13:06:40,004137+00:00 On node 0, zone DMA: 1 pages in unavailable ranges
2023-09-05T13:06:40,004148+00:00 On node 0, zone DMA: 96 pages in unavailable ranges
2023-09-05T13:06:40,004243+00:00 On node 0, zone DMA32: 1025 pages in unavailable ranges
2023-09-05T13:06:40,004252+00:00 On node 0, zone DMA32: 14 pages in unavailable ranges
2023-09-05T13:06:40,006805+00:00 On node 0, zone DMA32: 32 pages in unavailable ranges
2023-09-05T13:06:40,006907+00:00 On node 0, zone DMA32: 12867 pages in unavailable ranges
2023-09-05T13:06:40,026450+00:00 On node 0, zone Normal: 4096 pages in unavailable ranges
2023-09-05T13:06:40,026471+00:00 On node 0, zone Normal: 3200 pages in unavailable ranges
2023-09-05T13:06:40,026698+00:00 ACPI: PM-Timer IO Port: 0x808
2023-09-05T13:06:40,026704+00:00 ACPI: LAPIC_NMI (acpi_id[0xff] high edge lint[0x1])
2023-09-05T13:06:40,026715+00:00 IOAPIC[0]: apic_id 13, version 33, address 0xfec00000, GSI 0-23
2023-09-05T13:06:40,026720+00:00 IOAPIC[1]: apic_id 14, version 33, address 0xfec01000, GSI 24-55
2023-09-05T13:06:40,026721+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 0 global_irq 2 dfl dfl)
2023-09-05T13:06:40,026723+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 9 global_irq 9 low level)
2023-09-05T13:06:40,026725+00:00 ACPI: Using ACPI (MADT) for SMP configuration information
2023-09-05T13:06:40,026726+00:00 ACPI: HPET id: 0x10228201 base: 0xfed00000
2023-09-05T13:06:40,026729+00:00 smpboot: Allowing 32 CPUs, 20 hotplug CPUs
2023-09-05T13:06:40,026744+00:00 PM: hibernation: Registered nosave memory: [mem 0x00000000-0x00000fff]
2023-09-05T13:06:40,026746+00:00 PM: hibernation: Registered nosave memory: [mem 0x000a0000-0x000fffff]
2023-09-05T13:06:40,026747+00:00 PM: hibernation: Registered nosave memory: [mem 0x09bff000-0x09ffffff]
2023-09-05T13:06:40,026748+00:00 PM: hibernation: Registered nosave memory: [mem 0x0a200000-0x0a20dfff]
2023-09-05T13:06:40,026749+00:00 PM: hibernation: Registered nosave memory: [mem 0x0b000000-0x0b01ffff]
2023-09-05T13:06:40,026750+00:00 PM: hibernation: Registered nosave memory: [mem 0xb5374000-0xb5374fff]
2023-09-05T13:06:40,026751+00:00 PM: hibernation: Registered nosave memory: [mem 0xb5393000-0xb5393fff]
2023-09-05T13:06:40,026752+00:00 PM: hibernation: Registered nosave memory: [mem 0xb914b000-0xb914bfff]
2023-09-05T13:06:40,026752+00:00 PM: hibernation: Registered nosave memory: [mem 0xba9bc000-0xbc0fefff]
2023-09-05T13:06:40,026753+00:00 PM: hibernation: Registered nosave memory: [mem 0xbc0ff000-0xbc135fff]
2023-09-05T13:06:40,026753+00:00 PM: hibernation: Registered nosave memory: [mem 0xbc136000-0xbc810fff]
2023-09-05T13:06:40,026753+00:00 PM: hibernation: Registered nosave memory: [mem 0xbc811000-0xbdbfefff]
2023-09-05T13:06:40,026754+00:00 PM: hibernation: Registered nosave memory: [mem 0xbf000000-0xbfffffff]
2023-09-05T13:06:40,026755+00:00 PM: hibernation: Registered nosave memory: [mem 0xc0000000-0xfe9fffff]
2023-09-05T13:06:40,026755+00:00 PM: hibernation: Registered nosave memory: [mem 0xfea00000-0xfea0ffff]
2023-09-05T13:06:40,026755+00:00 PM: hibernation: Registered nosave memory: [mem 0xfea10000-0xfec0ffff]
2023-09-05T13:06:40,026756+00:00 PM: hibernation: Registered nosave memory: [mem 0xfec10000-0xfec10fff]
2023-09-05T13:06:40,026756+00:00 PM: hibernation: Registered nosave memory: [mem 0xfec11000-0xfec2ffff]
2023-09-05T13:06:40,026756+00:00 PM: hibernation: Registered nosave memory: [mem 0xfec30000-0xfec30fff]
2023-09-05T13:06:40,026757+00:00 PM: hibernation: Registered nosave memory: [mem 0xfec31000-0xfecfffff]
2023-09-05T13:06:40,026757+00:00 PM: hibernation: Registered nosave memory: [mem 0xfed00000-0xfed00fff]
2023-09-05T13:06:40,026757+00:00 PM: hibernation: Registered nosave memory: [mem 0xfed01000-0xfed3ffff]
2023-09-05T13:06:40,026758+00:00 PM: hibernation: Registered nosave memory: [mem 0xfed40000-0xfed44fff]
2023-09-05T13:06:40,026758+00:00 PM: hibernation: Registered nosave memory: [mem 0xfed45000-0xfed7ffff]
2023-09-05T13:06:40,026758+00:00 PM: hibernation: Registered nosave memory: [mem 0xfed80000-0xfed8ffff]
2023-09-05T13:06:40,026758+00:00 PM: hibernation: Registered nosave memory: [mem 0xfed90000-0xfedc1fff]
2023-09-05T13:06:40,026759+00:00 PM: hibernation: Registered nosave memory: [mem 0xfedc2000-0xfedcffff]
2023-09-05T13:06:40,026759+00:00 PM: hibernation: Registered nosave memory: [mem 0xfedd0000-0xfedd3fff]
2023-09-05T13:06:40,026759+00:00 PM: hibernation: Registered nosave memory: [mem 0xfedd4000-0xfedd5fff]
2023-09-05T13:06:40,026760+00:00 PM: hibernation: Registered nosave memory: [mem 0xfedd6000-0xffffffff]
2023-09-05T13:06:40,026761+00:00 [mem 0xc0000000-0xfe9fffff] available for PCI devices
2023-09-05T13:06:40,026763+00:00 Booting paravirtualized kernel on bare hardware
2023-09-05T13:06:40,026765+00:00 clocksource: refined-jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 1910969940391419 ns
2023-09-05T13:06:40,029421+00:00 setup_percpu: NR_CPUS:384 nr_cpumask_bits:32 nr_cpu_ids:32 nr_node_ids:1
2023-09-05T13:06:40,030388+00:00 percpu: Embedded 62 pages/cpu s217088 r8192 d28672 u262144
2023-09-05T13:06:40,030393+00:00 pcpu-alloc: s217088 r8192 d28672 u262144 alloc=1*2097152
2023-09-05T13:06:40,030394+00:00 pcpu-alloc: [0] 00 01 02 03 04 05 06 07 [0] 08 09 10 11 12 13 14 15 
2023-09-05T13:06:40,030399+00:00 pcpu-alloc: [0] 16 17 18 19 20 21 22 23 [0] 24 25 26 27 28 29 30 31 
2023-09-05T13:06:40,030413+00:00 Kernel command line: initrd=\efi\nixos\7iziifwb9in6d9y2z16m10z4avbz8sxz-initrd-linux-6.5-initrd.efi init=/nix/store/6zhcn3ndafmmnvx6ka1axfgv546ggfsd-nixos-system-nixos-23.05.20230902.9075cba/init cgroup_no_v1=all cgroup_enable=memory cgroup_enable=cpuset systemd.unified_cgroup_hierarchy=1 loglevel=4 nvidia-drm.modeset=1
2023-09-05T13:06:40,030464+00:00 Unknown kernel command line parameters "cgroup_enable=cpuset", will be passed to user space.
2023-09-05T13:06:40,031952+00:00 Dentry cache hash table entries: 2097152 (order: 12, 16777216 bytes, linear)
2023-09-05T13:06:40,032614+00:00 Inode-cache hash table entries: 1048576 (order: 11, 8388608 bytes, linear)
2023-09-05T13:06:40,032743+00:00 Fallback order for Node 0: 0 
2023-09-05T13:06:40,032746+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 4107609
2023-09-05T13:06:40,032747+00:00 Policy zone: Normal
2023-09-05T13:06:40,032748+00:00 mem auto-init: stack:all(zero), heap alloc:off, heap free:off
2023-09-05T13:06:40,032752+00:00 software IO TLB: area num 32.
2023-09-05T13:06:40,069748+00:00 Memory: 16184604K/16691892K available (14336K kernel code, 2305K rwdata, 9160K rodata, 2932K init, 5104K bss, 507028K reserved, 0K cma-reserved)
2023-09-05T13:06:40,069891+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=32, Nodes=1
2023-09-05T13:06:40,069910+00:00 ftrace: allocating 39493 entries in 155 pages
2023-09-05T13:06:40,075647+00:00 ftrace: allocated 155 pages with 5 groups
2023-09-05T13:06:40,076112+00:00 Dynamic Preempt: voluntary
2023-09-05T13:06:40,076161+00:00 rcu: Preemptible hierarchical RCU implementation.
2023-09-05T13:06:40,076161+00:00 rcu: 	RCU event tracing is enabled.
2023-09-05T13:06:40,076162+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=384 to nr_cpu_ids=32.
2023-09-05T13:06:40,076162+00:00 	Trampoline variant of Tasks RCU enabled.
2023-09-05T13:06:40,076163+00:00 	Rude variant of Tasks RCU enabled.
2023-09-05T13:06:40,076163+00:00 	Tracing variant of Tasks RCU enabled.
2023-09-05T13:06:40,076163+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 100 jiffies.
2023-09-05T13:06:40,076164+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=32
2023-09-05T13:06:40,077755+00:00 NR_IRQS: 24832, nr_irqs: 1224, preallocated irqs: 16
2023-09-05T13:06:40,077928+00:00 rcu: srcu_init: Setting srcu_struct sizes based on contention.
2023-09-05T13:06:40,077995+00:00 Console: colour dummy device 80x25
2023-09-05T13:06:40,077997+00:00 printk: console [tty0] enabled
2023-09-05T13:06:40,078027+00:00 ACPI: Core revision 20230331
2023-09-05T13:06:40,078103+00:00 clocksource: hpet: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 133484873504 ns
2023-09-05T13:06:40,078119+00:00 APIC: Switch to symmetric I/O mode setup
2023-09-05T13:06:40,078250+00:00 x2apic: IRQ remapping doesn't support X2APIC mode
2023-09-05T13:06:40,078311+00:00 Switched APIC routing to physical flat.
2023-09-05T13:06:40,078912+00:00 ..TIMER: vector=0x30 apic1=0 pin1=2 apic2=-1 pin2=-1
2023-09-05T13:06:40,083119+00:00 clocksource: tsc-early: mask: 0xffffffffffffffff max_cycles: 0x32743f7d696, max_idle_ns: 440795378997 ns
2023-09-05T13:06:40,083123+00:00 Calibrating delay loop (skipped), value calculated using timer frequency.. 7000.50 BogoMIPS (lpj=3500252)
2023-09-05T13:06:40,083133+00:00 x86/cpu: User Mode Instruction Prevention (UMIP) activated
2023-09-05T13:06:40,083176+00:00 LVT offset 1 assigned for vector 0xf9
2023-09-05T13:06:40,083287+00:00 LVT offset 2 assigned for vector 0xf4
2023-09-05T13:06:40,083321+00:00 process: using mwait in idle threads
2023-09-05T13:06:40,083322+00:00 Last level iTLB entries: 4KB 512, 2MB 512, 4MB 256
2023-09-05T13:06:40,083323+00:00 Last level dTLB entries: 4KB 2048, 2MB 2048, 4MB 1024, 1GB 0
2023-09-05T13:06:40,083325+00:00 Spectre V1 : Mitigation: usercopy/swapgs barriers and __user pointer sanitization
2023-09-05T13:06:40,083327+00:00 Spectre V2 : Mitigation: Retpolines
2023-09-05T13:06:40,083327+00:00 Spectre V2 : Spectre v2 / SpectreRSB mitigation: Filling RSB on context switch
2023-09-05T13:06:40,083327+00:00 Spectre V2 : Spectre v2 / SpectreRSB : Filling RSB on VMEXIT
2023-09-05T13:06:40,083328+00:00 Spectre V2 : Enabling Restricted Speculation for firmware calls
2023-09-05T13:06:40,083329+00:00 Spectre V2 : mitigation: Enabling conditional Indirect Branch Prediction Barrier
2023-09-05T13:06:40,083329+00:00 Spectre V2 : User space: Mitigation: STIBP always-on protection
2023-09-05T13:06:40,083330+00:00 Speculative Store Bypass: Mitigation: Speculative Store Bypass disabled via prctl
2023-09-05T13:06:40,083333+00:00 Speculative Return Stack Overflow: IBPB-extending microcode not applied!
2023-09-05T13:06:40,083333+00:00 Speculative Return Stack Overflow: WARNING: See https://kernel.org/doc/html/latest/admin-guide/hw-vuln/srso.html for mitigation options.
2023-09-05T13:06:40,083334+00:00 Speculative Return Stack Overflow: Mitigation: safe RET, no microcode
2023-09-05T13:06:40,083336+00:00 x86/fpu: Supporting XSAVE feature 0x001: 'x87 floating point registers'
2023-09-05T13:06:40,083337+00:00 x86/fpu: Supporting XSAVE feature 0x002: 'SSE registers'
2023-09-05T13:06:40,083338+00:00 x86/fpu: Supporting XSAVE feature 0x004: 'AVX registers'
2023-09-05T13:06:40,083338+00:00 x86/fpu: Supporting XSAVE feature 0x200: 'Protection Keys User registers'
2023-09-05T13:06:40,083339+00:00 x86/fpu: xstate_offset[2]:  576, xstate_sizes[2]:  256
2023-09-05T13:06:40,083340+00:00 x86/fpu: xstate_offset[9]:  832, xstate_sizes[9]:    8
2023-09-05T13:06:40,083340+00:00 x86/fpu: Enabled xstate features 0x207, context size is 840 bytes, using 'compacted' format.
2023-09-05T13:06:40,096723+00:00 Freeing SMP alternatives memory: 32K
2023-09-05T13:06:40,096725+00:00 pid_max: default: 32768 minimum: 301
2023-09-05T13:06:40,099916+00:00 LSM: initializing lsm=capability,landlock,yama,selinux,bpf,integrity
2023-09-05T13:06:40,099930+00:00 landlock: Up and running.
2023-09-05T13:06:40,099931+00:00 Yama: becoming mindful.
2023-09-05T13:06:40,099933+00:00 SELinux:  Initializing.
2023-09-05T13:06:40,099948+00:00 LSM support for eBPF active
2023-09-05T13:06:40,099991+00:00 Mount-cache hash table entries: 32768 (order: 6, 262144 bytes, linear)
2023-09-05T13:06:40,100010+00:00 Mountpoint-cache hash table entries: 32768 (order: 6, 262144 bytes, linear)
2023-09-05T13:06:40,100144+00:00 Disabling cpuset control group subsystem in v1 mounts
2023-09-05T13:06:40,100149+00:00 Disabling cpu control group subsystem in v1 mounts
2023-09-05T13:06:40,100151+00:00 Disabling cpuacct control group subsystem in v1 mounts
2023-09-05T13:06:40,100155+00:00 Disabling io control group subsystem in v1 mounts
2023-09-05T13:06:40,100171+00:00 Disabling memory control group subsystem in v1 mounts
2023-09-05T13:06:40,100176+00:00 Disabling devices control group subsystem in v1 mounts
2023-09-05T13:06:40,100181+00:00 Disabling freezer control group subsystem in v1 mounts
2023-09-05T13:06:40,100183+00:00 Disabling net_cls control group subsystem in v1 mounts
2023-09-05T13:06:40,100186+00:00 Disabling perf_event control group subsystem in v1 mounts
2023-09-05T13:06:40,100187+00:00 Disabling net_prio control group subsystem in v1 mounts
2023-09-05T13:06:40,100189+00:00 Disabling hugetlb control group subsystem in v1 mounts
2023-09-05T13:06:40,100190+00:00 Disabling pids control group subsystem in v1 mounts
2023-09-05T13:06:40,100192+00:00 Disabling rdma control group subsystem in v1 mounts
2023-09-05T13:06:40,100193+00:00 Disabling misc control group subsystem in v1 mounts
2023-09-05T13:06:40,100196+00:00 Disabling debug control group subsystem in v1 mounts
2023-09-05T13:06:40,203813+00:00 smpboot: CPU0: AMD Ryzen 5 5600 6-Core Processor (family: 0x19, model: 0x21, stepping: 0x2)
2023-09-05T13:06:40,203931+00:00 RCU Tasks: Setting shift to 5 and lim to 1 rcu_task_cb_adjust=1.
2023-09-05T13:06:40,203945+00:00 RCU Tasks Rude: Setting shift to 5 and lim to 1 rcu_task_cb_adjust=1.
2023-09-05T13:06:40,203959+00:00 RCU Tasks Trace: Setting shift to 5 and lim to 1 rcu_task_cb_adjust=1.
2023-09-05T13:06:40,203971+00:00 Performance Events: Fam17h+ core perfctr, AMD PMU driver.
2023-09-05T13:06:40,203976+00:00 ... version:                0
2023-09-05T13:06:40,203976+00:00 ... bit width:              48
2023-09-05T13:06:40,203977+00:00 ... generic registers:      6
2023-09-05T13:06:40,203978+00:00 ... value mask:             0000ffffffffffff
2023-09-05T13:06:40,203979+00:00 ... max period:             00007fffffffffff
2023-09-05T13:06:40,203979+00:00 ... fixed-purpose events:   0
2023-09-05T13:06:40,203980+00:00 ... event mask:             000000000000003f
2023-09-05T13:06:40,204049+00:00 signal: max sigframe size: 3376
2023-09-05T13:06:40,204071+00:00 rcu: Hierarchical SRCU implementation.
2023-09-05T13:06:40,204072+00:00 rcu: 	Max phase no-delay instances is 400.
2023-09-05T13:06:40,204120+00:00 smp: Bringing up secondary CPUs ...
2023-09-05T13:06:40,204120+00:00 smpboot: x86: Booting SMP configuration:
2023-09-05T13:06:40,204120+00:00 .... node  #0, CPUs:        #1  #2  #3  #4  #5  #6  #7  #8  #9 #10 #11
2023-09-05T13:06:40,212175+00:00 Spectre V2 : Update user space SMT mitigation: STIBP always-on
2023-09-05T13:06:40,217134+00:00 smp: Brought up 1 node, 12 CPUs
2023-09-05T13:06:40,217134+00:00 smpboot: Max logical packages: 3
2023-09-05T13:06:40,217134+00:00 smpboot: Total of 12 processors activated (84006.04 BogoMIPS)
2023-09-05T13:06:40,219462+00:00 devtmpfs: initialized
2023-09-05T13:06:40,219462+00:00 x86/mm: Memory block size: 128MB
2023-09-05T13:06:40,221331+00:00 ACPI: PM: Registering ACPI NVS region [mem 0x0a200000-0x0a20dfff] (57344 bytes)
2023-09-05T13:06:40,221331+00:00 ACPI: PM: Registering ACPI NVS region [mem 0xbc136000-0xbc810fff] (7188480 bytes)
2023-09-05T13:06:40,221338+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 1911260446275000 ns
2023-09-05T13:06:40,221341+00:00 futex hash table entries: 8192 (order: 7, 524288 bytes, linear)
2023-09-05T13:06:40,221406+00:00 pinctrl core: initialized pinctrl subsystem
2023-09-05T13:06:40,221757+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2023-09-05T13:06:40,221891+00:00 DMA: preallocated 2048 KiB GFP_KERNEL pool for atomic allocations
2023-09-05T13:06:40,221894+00:00 DMA: preallocated 2048 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2023-09-05T13:06:40,222122+00:00 DMA: preallocated 2048 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2023-09-05T13:06:40,222130+00:00 audit: initializing netlink subsys (disabled)
2023-09-05T13:06:40,222135+00:00 audit: type=2000 audit(1693926399.144:1): state=initialized audit_enabled=0 res=1
2023-09-05T13:06:40,222209+00:00 thermal_sys: Registered thermal governor 'bang_bang'
2023-09-05T13:06:40,222210+00:00 thermal_sys: Registered thermal governor 'step_wise'
2023-09-05T13:06:40,222211+00:00 thermal_sys: Registered thermal governor 'user_space'
2023-09-05T13:06:40,222226+00:00 cpuidle: using governor menu
2023-09-05T13:06:40,222226+00:00 Detected 1 PCC Subspaces
2023-09-05T13:06:40,222226+00:00 Registering PCC driver as Mailbox controller
2023-09-05T13:06:40,222226+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2023-09-05T13:06:40,222251+00:00 PCI: MMCONFIG for domain 0000 [bus 00-7f] at [mem 0xf0000000-0xf7ffffff] (base 0xf0000000)
2023-09-05T13:06:40,222255+00:00 PCI: not using MMCONFIG
2023-09-05T13:06:40,222255+00:00 PCI: Using configuration type 1 for base access
2023-09-05T13:06:40,222256+00:00 PCI: Using configuration type 1 for extended access
2023-09-05T13:06:40,222847+00:00 kprobes: kprobe jump-optimization is enabled. All kprobes are optimized if possible.
2023-09-05T13:06:40,223154+00:00 HugeTLB: registered 1.00 GiB page size, pre-allocated 0 pages
2023-09-05T13:06:40,223154+00:00 HugeTLB: 16380 KiB vmemmap can be freed for a 1.00 GiB page
2023-09-05T13:06:40,223154+00:00 HugeTLB: registered 2.00 MiB page size, pre-allocated 0 pages
2023-09-05T13:06:40,223154+00:00 HugeTLB: 28 KiB vmemmap can be freed for a 2.00 MiB page
2023-09-05T13:06:40,223196+00:00 ACPI: Added _OSI(Module Device)
2023-09-05T13:06:40,223197+00:00 ACPI: Added _OSI(Processor Device)
2023-09-05T13:06:40,223199+00:00 ACPI: Added _OSI(3.0 _SCP Extensions)
2023-09-05T13:06:40,223200+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2023-09-05T13:06:40,235025+00:00 ACPI: 8 ACPI AML tables successfully acquired and loaded
2023-09-05T13:06:40,236584+00:00 ACPI: [Firmware Bug]: BIOS _OSI(Linux) query ignored
2023-09-05T13:06:40,240467+00:00 ACPI: Interpreter enabled
2023-09-05T13:06:40,240480+00:00 ACPI: PM: (supports S0 S3 S4 S5)
2023-09-05T13:06:40,240482+00:00 ACPI: Using IOAPIC for interrupt routing
2023-09-05T13:06:40,240798+00:00 PCI: MMCONFIG for domain 0000 [bus 00-7f] at [mem 0xf0000000-0xf7ffffff] (base 0xf0000000)
2023-09-05T13:06:40,240831+00:00 PCI: MMCONFIG at [mem 0xf0000000-0xf7ffffff] reserved as ACPI motherboard resource
2023-09-05T13:06:40,240840+00:00 PCI: Using host bridge windows from ACPI; if necessary, use "pci=nocrs" and report a bug
2023-09-05T13:06:40,240841+00:00 PCI: Ignoring E820 reservations for host bridge windows
2023-09-05T13:06:40,241191+00:00 ACPI: Enabled 3 GPEs in block 00 to 1F
2023-09-05T13:06:40,251573+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-ff])
2023-09-05T13:06:40,251578+00:00 acpi PNP0A08:00: _OSC: OS supports [ExtendedConfig ASPM ClockPM Segments MSI HPX-Type3]
2023-09-05T13:06:40,251653+00:00 acpi PNP0A08:00: _OSC: platform does not support [LTR]
2023-09-05T13:06:40,251787+00:00 acpi PNP0A08:00: _OSC: OS now controls [PCIeHotplug PME PCIeCapability]
2023-09-05T13:06:40,251796+00:00 acpi PNP0A08:00: [Firmware Info]: MMCONFIG for domain 0000 [bus 00-7f] only partially covers this bridge
2023-09-05T13:06:40,252177+00:00 PCI host bridge to bus 0000:00
2023-09-05T13:06:40,252178+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0x03af window]
2023-09-05T13:06:40,252180+00:00 pci_bus 0000:00: root bus resource [io  0x03e0-0x0cf7 window]
2023-09-05T13:06:40,252181+00:00 pci_bus 0000:00: root bus resource [io  0x03b0-0x03df window]
2023-09-05T13:06:40,252183+00:00 pci_bus 0000:00: root bus resource [io  0x0d00-0xffff window]
2023-09-05T13:06:40,252184+00:00 pci_bus 0000:00: root bus resource [mem 0x000a0000-0x000dffff window]
2023-09-05T13:06:40,252185+00:00 pci_bus 0000:00: root bus resource [mem 0xc0000000-0xfec2ffff window]
2023-09-05T13:06:40,252187+00:00 pci_bus 0000:00: root bus resource [mem 0xfee00000-0xffffffff window]
2023-09-05T13:06:40,252188+00:00 pci_bus 0000:00: root bus resource [bus 00-ff]
2023-09-05T13:06:40,252203+00:00 pci 0000:00:00.0: [1022:1480] type 00 class 0x060000
2023-09-05T13:06:40,252303+00:00 pci 0000:00:01.0: [1022:1482] type 00 class 0x060000
2023-09-05T13:06:40,252371+00:00 pci 0000:00:01.3: [1022:1483] type 01 class 0x060400
2023-09-05T13:06:40,252401+00:00 pci 0000:00:01.3: enabling Extended Tags
2023-09-05T13:06:40,252455+00:00 pci 0000:00:01.3: PME# supported from D0 D3hot D3cold
2023-09-05T13:06:40,252630+00:00 pci 0000:00:02.0: [1022:1482] type 00 class 0x060000
2023-09-05T13:06:40,252697+00:00 pci 0000:00:03.0: [1022:1482] type 00 class 0x060000
2023-09-05T13:06:40,252760+00:00 pci 0000:00:03.1: [1022:1483] type 01 class 0x060400
2023-09-05T13:06:40,252830+00:00 pci 0000:00:03.1: PME# supported from D0 D3hot D3cold
2023-09-05T13:06:40,252951+00:00 pci 0000:00:03.2: [1022:1483] type 01 class 0x060400
2023-09-05T13:06:40,253021+00:00 pci 0000:00:03.2: PME# supported from D0 D3hot D3cold
2023-09-05T13:06:40,253145+00:00 pci 0000:00:04.0: [1022:1482] type 00 class 0x060000
2023-09-05T13:06:40,253211+00:00 pci 0000:00:05.0: [1022:1482] type 00 class 0x060000
2023-09-05T13:06:40,253277+00:00 pci 0000:00:07.0: [1022:1482] type 00 class 0x060000
2023-09-05T13:06:40,253339+00:00 pci 0000:00:07.1: [1022:1484] type 01 class 0x060400
2023-09-05T13:06:40,253363+00:00 pci 0000:00:07.1: enabling Extended Tags
2023-09-05T13:06:40,253404+00:00 pci 0000:00:07.1: PME# supported from D0 D3hot D3cold
2023-09-05T13:06:40,253516+00:00 pci 0000:00:08.0: [1022:1482] type 00 class 0x060000
2023-09-05T13:06:40,253581+00:00 pci 0000:00:08.1: [1022:1484] type 01 class 0x060400
2023-09-05T13:06:40,253607+00:00 pci 0000:00:08.1: enabling Extended Tags
2023-09-05T13:06:40,253651+00:00 pci 0000:00:08.1: PME# supported from D0 D3hot D3cold
2023-09-05T13:06:40,253767+00:00 pci 0000:00:08.3: [1022:1484] type 01 class 0x060400
2023-09-05T13:06:40,253793+00:00 pci 0000:00:08.3: enabling Extended Tags
2023-09-05T13:06:40,253837+00:00 pci 0000:00:08.3: PME# supported from D0 D3hot D3cold
2023-09-05T13:06:40,253966+00:00 pci 0000:00:14.0: [1022:790b] type 00 class 0x0c0500
2023-09-05T13:06:40,254087+00:00 pci 0000:00:14.3: [1022:790e] type 00 class 0x060100
2023-09-05T13:06:40,254221+00:00 pci 0000:00:18.0: [1022:1440] type 00 class 0x060000
2023-09-05T13:06:40,254258+00:00 pci 0000:00:18.1: [1022:1441] type 00 class 0x060000
2023-09-05T13:06:40,254293+00:00 pci 0000:00:18.2: [1022:1442] type 00 class 0x060000
2023-09-05T13:06:40,254329+00:00 pci 0000:00:18.3: [1022:1443] type 00 class 0x060000
2023-09-05T13:06:40,254365+00:00 pci 0000:00:18.4: [1022:1444] type 00 class 0x060000
2023-09-05T13:06:40,254401+00:00 pci 0000:00:18.5: [1022:1445] type 00 class 0x060000
2023-09-05T13:06:40,254437+00:00 pci 0000:00:18.6: [1022:1446] type 00 class 0x060000
2023-09-05T13:06:40,254474+00:00 pci 0000:00:18.7: [1022:1447] type 00 class 0x060000
2023-09-05T13:06:40,254577+00:00 pci 0000:01:00.0: [1022:43d0] type 00 class 0x0c0330
2023-09-05T13:06:40,254597+00:00 pci 0000:01:00.0: reg 0x10: [mem 0xfc7a0000-0xfc7a7fff 64bit]
2023-09-05T13:06:40,254643+00:00 pci 0000:01:00.0: enabling Extended Tags
2023-09-05T13:06:40,254709+00:00 pci 0000:01:00.0: PME# supported from D3hot D3cold
2023-09-05T13:06:40,254872+00:00 pci 0000:01:00.1: [1022:43c8] type 00 class 0x010601
2023-09-05T13:06:40,254926+00:00 pci 0000:01:00.1: reg 0x24: [mem 0xfc780000-0xfc79ffff]
2023-09-05T13:06:40,254935+00:00 pci 0000:01:00.1: reg 0x30: [mem 0xfc700000-0xfc77ffff pref]
2023-09-05T13:06:40,254942+00:00 pci 0000:01:00.1: enabling Extended Tags
2023-09-05T13:06:40,254989+00:00 pci 0000:01:00.1: PME# supported from D3hot D3cold
2023-09-05T13:06:40,255078+00:00 pci 0000:01:00.2: [1022:43c6] type 01 class 0x060400
2023-09-05T13:06:40,255129+00:00 pci 0000:01:00.2: enabling Extended Tags
2023-09-05T13:06:40,255181+00:00 pci 0000:01:00.2: PME# supported from D3hot D3cold
2023-09-05T13:06:40,255300+00:00 pci 0000:00:01.3: PCI bridge to [bus 01-0c]
2023-09-05T13:06:40,255304+00:00 pci 0000:00:01.3:   bridge window [io  0xd000-0xefff]
2023-09-05T13:06:40,255307+00:00 pci 0000:00:01.3:   bridge window [mem 0xfc200000-0xfc7fffff]
2023-09-05T13:06:40,255401+00:00 pci 0000:02:00.0: [1022:43c7] type 01 class 0x060400
2023-09-05T13:06:40,255455+00:00 pci 0000:02:00.0: enabling Extended Tags
2023-09-05T13:06:40,255525+00:00 pci 0000:02:00.0: PME# supported from D3hot D3cold
2023-09-05T13:06:40,255769+00:00 pci 0000:02:02.0: [1022:43c7] type 01 class 0x060400
2023-09-05T13:06:40,255823+00:00 pci 0000:02:02.0: enabling Extended Tags
2023-09-05T13:06:40,255891+00:00 pci 0000:02:02.0: PME# supported from D3hot D3cold
2023-09-05T13:06:40,256011+00:00 pci 0000:02:03.0: [1022:43c7] type 01 class 0x060400
2023-09-05T13:06:40,256065+00:00 pci 0000:02:03.0: enabling Extended Tags
2023-09-05T13:06:40,256135+00:00 pci 0000:02:03.0: PME# supported from D3hot D3cold
2023-09-05T13:06:40,256256+00:00 pci 0000:02:04.0: [1022:43c7] type 01 class 0x060400
2023-09-05T13:06:40,256310+00:00 pci 0000:02:04.0: enabling Extended Tags
2023-09-05T13:06:40,256379+00:00 pci 0000:02:04.0: PME# supported from D3hot D3cold
2023-09-05T13:06:40,256506+00:00 pci 0000:02:09.0: [1022:43c7] type 01 class 0x060400
2023-09-05T13:06:40,256561+00:00 pci 0000:02:09.0: enabling Extended Tags
2023-09-05T13:06:40,256629+00:00 pci 0000:02:09.0: PME# supported from D3hot D3cold
2023-09-05T13:06:40,256741+00:00 pci 0000:01:00.2: PCI bridge to [bus 02-0c]
2023-09-05T13:06:40,256747+00:00 pci 0000:01:00.2:   bridge window [io  0xd000-0xefff]
2023-09-05T13:06:40,256750+00:00 pci 0000:01:00.2:   bridge window [mem 0xfc200000-0xfc6fffff]
2023-09-05T13:06:40,256828+00:00 pci 0000:03:00.0: [1b21:2142] type 00 class 0x0c0330
2023-09-05T13:06:40,256861+00:00 pci 0000:03:00.0: reg 0x10: [mem 0xfc600000-0xfc607fff 64bit]
2023-09-05T13:06:40,256936+00:00 pci 0000:03:00.0: enabling Extended Tags
2023-09-05T13:06:40,257039+00:00 pci 0000:03:00.0: PME# supported from D0
2023-09-05T13:06:40,257098+00:00 pci 0000:03:00.0: 8.000 Gb/s available PCIe bandwidth, limited by 5.0 GT/s PCIe x2 link at 0000:02:00.0 (capable of 15.752 Gb/s with 8.0 GT/s PCIe x2 link)
2023-09-05T13:06:40,257217+00:00 pci 0000:02:00.0: PCI bridge to [bus 03]
2023-09-05T13:06:40,257225+00:00 pci 0000:02:00.0:   bridge window [mem 0xfc600000-0xfc6fffff]
2023-09-05T13:06:40,257303+00:00 pci 0000:04:00.0: [1b21:0612] type 00 class 0x010601
2023-09-05T13:06:40,257328+00:00 pci 0000:04:00.0: reg 0x10: [io  0xe050-0xe057]
2023-09-05T13:06:40,257343+00:00 pci 0000:04:00.0: reg 0x14: [io  0xe040-0xe043]
2023-09-05T13:06:40,257357+00:00 pci 0000:04:00.0: reg 0x18: [io  0xe030-0xe037]
2023-09-05T13:06:40,257371+00:00 pci 0000:04:00.0: reg 0x1c: [io  0xe020-0xe023]
2023-09-05T13:06:40,257385+00:00 pci 0000:04:00.0: reg 0x20: [io  0xe000-0xe01f]
2023-09-05T13:06:40,257399+00:00 pci 0000:04:00.0: reg 0x24: [mem 0xfc500000-0xfc5001ff]
2023-09-05T13:06:40,257599+00:00 pci 0000:02:02.0: PCI bridge to [bus 04]
2023-09-05T13:06:40,257605+00:00 pci 0000:02:02.0:   bridge window [io  0xe000-0xefff]
2023-09-05T13:06:40,257608+00:00 pci 0000:02:02.0:   bridge window [mem 0xfc500000-0xfc5fffff]
2023-09-05T13:06:40,257683+00:00 pci 0000:05:00.0: [1b21:1184] type 01 class 0x060400
2023-09-05T13:06:40,257761+00:00 pci 0000:05:00.0: enabling Extended Tags
2023-09-05T13:06:40,257860+00:00 pci 0000:05:00.0: PME# supported from D0 D3hot D3cold
2023-09-05T13:06:40,258003+00:00 pci 0000:02:03.0: PCI bridge to [bus 05-0a]
2023-09-05T13:06:40,258009+00:00 pci 0000:02:03.0:   bridge window [io  0xd000-0xdfff]
2023-09-05T13:06:40,258012+00:00 pci 0000:02:03.0:   bridge window [mem 0xfc200000-0xfc3fffff]
2023-09-05T13:06:40,258094+00:00 pci 0000:06:01.0: [1b21:1184] type 01 class 0x060400
2023-09-05T13:06:40,258178+00:00 pci 0000:06:01.0: enabling Extended Tags
2023-09-05T13:06:40,258281+00:00 pci 0000:06:01.0: PME# supported from D0 D3hot D3cold
2023-09-05T13:06:40,258404+00:00 pci 0000:06:03.0: [1b21:1184] type 01 class 0x060400
2023-09-05T13:06:40,258485+00:00 pci 0000:06:03.0: enabling Extended Tags
2023-09-05T13:06:40,258582+00:00 pci 0000:06:03.0: PME# supported from D0 D3hot D3cold
2023-09-05T13:06:40,258704+00:00 pci 0000:06:05.0: [1b21:1184] type 01 class 0x060400
2023-09-05T13:06:40,258785+00:00 pci 0000:06:05.0: enabling Extended Tags
2023-09-05T13:06:40,258881+00:00 pci 0000:06:05.0: PME# supported from D0 D3hot D3cold
2023-09-05T13:06:40,259005+00:00 pci 0000:06:07.0: [1b21:1184] type 01 class 0x060400
2023-09-05T13:06:40,259086+00:00 pci 0000:06:07.0: enabling Extended Tags
2023-09-05T13:06:40,259184+00:00 pci 0000:06:07.0: PME# supported from D0 D3hot D3cold
2023-09-05T13:06:40,259326+00:00 pci 0000:05:00.0: PCI bridge to [bus 06-0a]
2023-09-05T13:06:40,259334+00:00 pci 0000:05:00.0:   bridge window [io  0xd000-0xdfff]
2023-09-05T13:06:40,259339+00:00 pci 0000:05:00.0:   bridge window [mem 0xfc200000-0xfc3fffff]
2023-09-05T13:06:40,259461+00:00 pci 0000:07:00.0: [8086:24fb] type 00 class 0x028000
2023-09-05T13:06:40,259513+00:00 pci 0000:07:00.0: reg 0x10: [mem 0xfc300000-0xfc301fff 64bit]
2023-09-05T13:06:40,259792+00:00 pci 0000:07:00.0: PME# supported from D0 D3hot D3cold
2023-09-05T13:06:40,260089+00:00 pci 0000:06:01.0: PCI bridge to [bus 07]
2023-09-05T13:06:40,260101+00:00 pci 0000:06:01.0:   bridge window [mem 0xfc300000-0xfc3fffff]
2023-09-05T13:06:40,260166+00:00 pci 0000:06:03.0: PCI bridge to [bus 08]
2023-09-05T13:06:40,260289+00:00 pci 0000:09:00.0: [8086:1539] type 00 class 0x020000
2023-09-05T13:06:40,260329+00:00 pci 0000:09:00.0: reg 0x10: [mem 0xfc200000-0xfc21ffff]
2023-09-05T13:06:40,260371+00:00 pci 0000:09:00.0: reg 0x18: [io  0xd000-0xd01f]
2023-09-05T13:06:40,260392+00:00 pci 0000:09:00.0: reg 0x1c: [mem 0xfc220000-0xfc223fff]
2023-09-05T13:06:40,260620+00:00 pci 0000:09:00.0: PME# supported from D0 D3hot D3cold
2023-09-05T13:06:40,260853+00:00 pci 0000:06:05.0: PCI bridge to [bus 09]
2023-09-05T13:06:40,260861+00:00 pci 0000:06:05.0:   bridge window [io  0xd000-0xdfff]
2023-09-05T13:06:40,260866+00:00 pci 0000:06:05.0:   bridge window [mem 0xfc200000-0xfc2fffff]
2023-09-05T13:06:40,260929+00:00 pci 0000:06:07.0: PCI bridge to [bus 0a]
2023-09-05T13:06:40,261055+00:00 pci 0000:0b:00.0: [144d:a808] type 00 class 0x010802
2023-09-05T13:06:40,261086+00:00 pci 0000:0b:00.0: reg 0x10: [mem 0xfc400000-0xfc403fff 64bit]
2023-09-05T13:06:40,261345+00:00 pci 0000:0b:00.0: 16.000 Gb/s available PCIe bandwidth, limited by 5.0 GT/s PCIe x4 link at 0000:02:04.0 (capable of 31.504 Gb/s with 8.0 GT/s PCIe x4 link)
2023-09-05T13:06:40,261486+00:00 pci 0000:02:04.0: PCI bridge to [bus 0b]
2023-09-05T13:06:40,261495+00:00 pci 0000:02:04.0:   bridge window [mem 0xfc400000-0xfc4fffff]
2023-09-05T13:06:40,261540+00:00 pci 0000:02:09.0: PCI bridge to [bus 0c]
2023-09-05T13:06:40,261631+00:00 pci 0000:0d:00.0: [10de:1f02] type 00 class 0x030000
2023-09-05T13:06:40,261646+00:00 pci 0000:0d:00.0: reg 0x10: [mem 0xfb000000-0xfbffffff]
2023-09-05T13:06:40,261658+00:00 pci 0000:0d:00.0: reg 0x14: [mem 0xd0000000-0xdfffffff 64bit pref]
2023-09-05T13:06:40,261671+00:00 pci 0000:0d:00.0: reg 0x1c: [mem 0xe0000000-0xe1ffffff 64bit pref]
2023-09-05T13:06:40,261679+00:00 pci 0000:0d:00.0: reg 0x24: [io  0xf000-0xf07f]
2023-09-05T13:06:40,261687+00:00 pci 0000:0d:00.0: reg 0x30: [mem 0xfc000000-0xfc07ffff pref]
2023-09-05T13:06:40,261707+00:00 pci 0000:0d:00.0: BAR 3: assigned to efifb
2023-09-05T13:06:40,261712+00:00 pci 0000:0d:00.0: Video device with shadowed ROM at [mem 0x000c0000-0x000dffff]
2023-09-05T13:06:40,261762+00:00 pci 0000:0d:00.0: PME# supported from D0 D3hot
2023-09-05T13:06:40,261818+00:00 pci 0000:0d:00.0: 16.000 Gb/s available PCIe bandwidth, limited by 2.5 GT/s PCIe x8 link at 0000:00:03.1 (capable of 126.016 Gb/s with 8.0 GT/s PCIe x16 link)
2023-09-05T13:06:40,261932+00:00 pci 0000:0d:00.1: [10de:10f9] type 00 class 0x040300
2023-09-05T13:06:40,261947+00:00 pci 0000:0d:00.1: reg 0x10: [mem 0xfc080000-0xfc083fff]
2023-09-05T13:06:40,262094+00:00 pci 0000:0d:00.2: [10de:1ada] type 00 class 0x0c0330
2023-09-05T13:06:40,262113+00:00 pci 0000:0d:00.2: reg 0x10: [mem 0xe2000000-0xe203ffff 64bit pref]
2023-09-05T13:06:40,262135+00:00 pci 0000:0d:00.2: reg 0x1c: [mem 0xe2040000-0xe204ffff 64bit pref]
2023-09-05T13:06:40,262197+00:00 pci 0000:0d:00.2: PME# supported from D0 D3hot
2023-09-05T13:06:40,262260+00:00 pci 0000:0d:00.3: [10de:1adb] type 00 class 0x0c8000
2023-09-05T13:06:40,262275+00:00 pci 0000:0d:00.3: reg 0x10: [mem 0xfc084000-0xfc084fff]
2023-09-05T13:06:40,262365+00:00 pci 0000:0d:00.3: PME# supported from D0 D3hot
2023-09-05T13:06:40,262459+00:00 pci 0000:00:03.1: PCI bridge to [bus 0d]
2023-09-05T13:06:40,262463+00:00 pci 0000:00:03.1:   bridge window [io  0xf000-0xffff]
2023-09-05T13:06:40,262465+00:00 pci 0000:00:03.1:   bridge window [mem 0xfb000000-0xfc0fffff]
2023-09-05T13:06:40,262469+00:00 pci 0000:00:03.1:   bridge window [mem 0xd0000000-0xe20fffff 64bit pref]
2023-09-05T13:06:40,262521+00:00 pci 0000:0e:00.0: [12ab:0710] type 00 class 0x048000
2023-09-05T13:06:40,262534+00:00 pci 0000:0e:00.0: reg 0x10: [mem 0xfcb00000-0xfcbfffff]
2023-09-05T13:06:40,262541+00:00 pci 0000:0e:00.0: reg 0x14: [mem 0xfcc00000-0xfcc0ffff]
2023-09-05T13:06:40,262616+00:00 pci 0000:0e:00.0: PME# supported from D0 D1 D2 D3hot
2023-09-05T13:06:40,262679+00:00 pci 0000:00:03.2: PCI bridge to [bus 0e]
2023-09-05T13:06:40,262684+00:00 pci 0000:00:03.2:   bridge window [mem 0xfcb00000-0xfccfffff]
2023-09-05T13:06:40,262729+00:00 pci 0000:0f:00.0: [1022:148a] type 00 class 0x130000
2023-09-05T13:06:40,262758+00:00 pci 0000:0f:00.0: enabling Extended Tags
2023-09-05T13:06:40,262901+00:00 pci 0000:00:07.1: PCI bridge to [bus 0f]
2023-09-05T13:06:40,262958+00:00 pci 0000:10:00.0: [1022:1485] type 00 class 0x130000
2023-09-05T13:06:40,262992+00:00 pci 0000:10:00.0: enabling Extended Tags
2023-09-05T13:06:40,263135+00:00 pci 0000:10:00.1: [1022:1486] type 00 class 0x108000
2023-09-05T13:06:40,263152+00:00 pci 0000:10:00.1: reg 0x18: [mem 0xfc900000-0xfc9fffff]
2023-09-05T13:06:40,263164+00:00 pci 0000:10:00.1: reg 0x24: [mem 0xfca08000-0xfca09fff]
2023-09-05T13:06:40,263173+00:00 pci 0000:10:00.1: enabling Extended Tags
2023-09-05T13:06:40,263292+00:00 pci 0000:10:00.3: [1022:149c] type 00 class 0x0c0330
2023-09-05T13:06:40,263306+00:00 pci 0000:10:00.3: reg 0x10: [mem 0xfc800000-0xfc8fffff 64bit]
2023-09-05T13:06:40,263337+00:00 pci 0000:10:00.3: enabling Extended Tags
2023-09-05T13:06:40,263384+00:00 pci 0000:10:00.3: PME# supported from D0 D3hot D3cold
2023-09-05T13:06:40,263483+00:00 pci 0000:10:00.4: [1022:1487] type 00 class 0x040300
2023-09-05T13:06:40,263492+00:00 pci 0000:10:00.4: reg 0x10: [mem 0xfca00000-0xfca07fff]
2023-09-05T13:06:40,263519+00:00 pci 0000:10:00.4: enabling Extended Tags
2023-09-05T13:06:40,263563+00:00 pci 0000:10:00.4: PME# supported from D0 D3hot D3cold
2023-09-05T13:06:40,263670+00:00 pci 0000:00:08.1: PCI bridge to [bus 10]
2023-09-05T13:06:40,263675+00:00 pci 0000:00:08.1:   bridge window [mem 0xfc800000-0xfcafffff]
2023-09-05T13:06:40,263724+00:00 pci 0000:11:00.0: [1022:7901] type 00 class 0x010601
2023-09-05T13:06:40,263760+00:00 pci 0000:11:00.0: reg 0x24: [mem 0xfcd00000-0xfcd007ff]
2023-09-05T13:06:40,263770+00:00 pci 0000:11:00.0: enabling Extended Tags
2023-09-05T13:06:40,263829+00:00 pci 0000:11:00.0: PME# supported from D3hot D3cold
2023-09-05T13:06:40,263955+00:00 pci 0000:00:08.3: PCI bridge to [bus 11]
2023-09-05T13:06:40,263959+00:00 pci 0000:00:08.3:   bridge window [mem 0xfcd00000-0xfcdfffff]
2023-09-05T13:06:40,264299+00:00 ACPI: PCI: Interrupt link LNKA configured for IRQ 0
2023-09-05T13:06:40,264345+00:00 ACPI: PCI: Interrupt link LNKB configured for IRQ 0
2023-09-05T13:06:40,264385+00:00 ACPI: PCI: Interrupt link LNKC configured for IRQ 0
2023-09-05T13:06:40,264432+00:00 ACPI: PCI: Interrupt link LNKD configured for IRQ 0
2023-09-05T13:06:40,264476+00:00 ACPI: PCI: Interrupt link LNKE configured for IRQ 0
2023-09-05T13:06:40,264513+00:00 ACPI: PCI: Interrupt link LNKF configured for IRQ 0
2023-09-05T13:06:40,264548+00:00 ACPI: PCI: Interrupt link LNKG configured for IRQ 0
2023-09-05T13:06:40,264585+00:00 ACPI: PCI: Interrupt link LNKH configured for IRQ 0
2023-09-05T13:06:40,265263+00:00 iommu: Default domain type: Translated
2023-09-05T13:06:40,265264+00:00 iommu: DMA domain TLB invalidation policy: lazy mode
2023-09-05T13:06:40,265324+00:00 efivars: Registered efivars operations
2023-09-05T13:06:40,265338+00:00 NetLabel: Initializing
2023-09-05T13:06:40,265339+00:00 NetLabel:  domain hash size = 128
2023-09-05T13:06:40,265340+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2023-09-05T13:06:40,265356+00:00 NetLabel:  unlabeled traffic allowed by default
2023-09-05T13:06:40,265357+00:00 PCI: Using ACPI for IRQ routing
2023-09-05T13:06:40,269249+00:00 PCI: pci_cache_line_size set to 64 bytes
2023-09-05T13:06:40,269360+00:00 e820: reserve RAM buffer [mem 0x09bff000-0x0bffffff]
2023-09-05T13:06:40,269362+00:00 e820: reserve RAM buffer [mem 0x0a200000-0x0bffffff]
2023-09-05T13:06:40,269363+00:00 e820: reserve RAM buffer [mem 0x0b000000-0x0bffffff]
2023-09-05T13:06:40,269364+00:00 e820: reserve RAM buffer [mem 0xb5374018-0xb7ffffff]
2023-09-05T13:06:40,269365+00:00 e820: reserve RAM buffer [mem 0xb914b000-0xbbffffff]
2023-09-05T13:06:40,269366+00:00 e820: reserve RAM buffer [mem 0xba9bc000-0xbbffffff]
2023-09-05T13:06:40,269367+00:00 e820: reserve RAM buffer [mem 0xbf000000-0xbfffffff]
2023-09-05T13:06:40,269367+00:00 e820: reserve RAM buffer [mem 0x43f380000-0x43fffffff]
2023-09-05T13:06:40,269439+00:00 pci 0000:0d:00.0: vgaarb: setting as boot VGA device
2023-09-05T13:06:40,269439+00:00 pci 0000:0d:00.0: vgaarb: bridge control possible
2023-09-05T13:06:40,269439+00:00 pci 0000:0d:00.0: vgaarb: VGA device added: decodes=io+mem,owns=io+mem,locks=none
2023-09-05T13:06:40,269439+00:00 vgaarb: loaded
2023-09-05T13:06:40,269439+00:00 hpet0: at MMIO 0xfed00000, IRQs 2, 8, 0
2023-09-05T13:06:40,269439+00:00 hpet0: 3 comparators, 32-bit 14.318180 MHz counter
2023-09-05T13:06:40,271169+00:00 clocksource: Switched to clocksource tsc-early
2023-09-05T13:06:40,271255+00:00 VFS: Disk quotas dquot_6.6.0
2023-09-05T13:06:40,271269+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2023-09-05T13:06:40,271331+00:00 pnp: PnP ACPI init
2023-09-05T13:06:40,271407+00:00 system 00:00: [mem 0xf0000000-0xf7ffffff] has been reserved
2023-09-05T13:06:40,271448+00:00 system 00:01: [mem 0xfeb80000-0xfebfffff] has been reserved
2023-09-05T13:06:40,271534+00:00 system 00:02: [mem 0xfd200000-0xfd2fffff] has been reserved
2023-09-05T13:06:40,271817+00:00 system 00:04: [io  0x0280-0x028f] has been reserved
2023-09-05T13:06:40,271819+00:00 system 00:04: [io  0x0290-0x029f] has been reserved
2023-09-05T13:06:40,271820+00:00 system 00:04: [io  0x02a0-0x02af] has been reserved
2023-09-05T13:06:40,271822+00:00 system 00:04: [io  0x02b0-0x02bf] has been reserved
2023-09-05T13:06:40,272038+00:00 system 00:05: [io  0x04d0-0x04d1] has been reserved
2023-09-05T13:06:40,272039+00:00 system 00:05: [io  0x040b] has been reserved
2023-09-05T13:06:40,272041+00:00 system 00:05: [io  0x04d6] has been reserved
2023-09-05T13:06:40,272042+00:00 system 00:05: [io  0x0c00-0x0c01] has been reserved
2023-09-05T13:06:40,272044+00:00 system 00:05: [io  0x0c14] has been reserved
2023-09-05T13:06:40,272045+00:00 system 00:05: [io  0x0c50-0x0c51] has been reserved
2023-09-05T13:06:40,272046+00:00 system 00:05: [io  0x0c52] has been reserved
2023-09-05T13:06:40,272048+00:00 system 00:05: [io  0x0c6c] has been reserved
2023-09-05T13:06:40,272049+00:00 system 00:05: [io  0x0c6f] has been reserved
2023-09-05T13:06:40,272050+00:00 system 00:05: [io  0x0cd8-0x0cdf] has been reserved
2023-09-05T13:06:40,272052+00:00 system 00:05: [io  0x0800-0x089f] has been reserved
2023-09-05T13:06:40,272053+00:00 system 00:05: [io  0x0b00-0x0b0f] has been reserved
2023-09-05T13:06:40,272055+00:00 system 00:05: [io  0x0b20-0x0b3f] has been reserved
2023-09-05T13:06:40,272056+00:00 system 00:05: [io  0x0900-0x090f] has been reserved
2023-09-05T13:06:40,272057+00:00 system 00:05: [io  0x0910-0x091f] has been reserved
2023-09-05T13:06:40,272059+00:00 system 00:05: [mem 0xfec00000-0xfec00fff] could not be reserved
2023-09-05T13:06:40,272061+00:00 system 00:05: [mem 0xfec01000-0xfec01fff] could not be reserved
2023-09-05T13:06:40,272062+00:00 system 00:05: [mem 0xfedc0000-0xfedc0fff] has been reserved
2023-09-05T13:06:40,272064+00:00 system 00:05: [mem 0xfee00000-0xfee00fff] has been reserved
2023-09-05T13:06:40,272066+00:00 system 00:05: [mem 0xfed80000-0xfed8ffff] could not be reserved
2023-09-05T13:06:40,272068+00:00 system 00:05: [mem 0xfec10000-0xfec10fff] has been reserved
2023-09-05T13:06:40,272069+00:00 system 00:05: [mem 0xff000000-0xffffffff] has been reserved
2023-09-05T13:06:40,272532+00:00 pnp: PnP ACPI: found 6 devices
2023-09-05T13:06:40,278394+00:00 clocksource: acpi_pm: mask: 0xffffff max_cycles: 0xffffff, max_idle_ns: 2085701024 ns
2023-09-05T13:06:40,278461+00:00 NET: Registered PF_INET protocol family
2023-09-05T13:06:40,278578+00:00 IP idents hash table entries: 262144 (order: 9, 2097152 bytes, linear)
2023-09-05T13:06:40,280317+00:00 tcp_listen_portaddr_hash hash table entries: 8192 (order: 5, 131072 bytes, linear)
2023-09-05T13:06:40,280326+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2023-09-05T13:06:40,280329+00:00 TCP established hash table entries: 131072 (order: 8, 1048576 bytes, linear)
2023-09-05T13:06:40,280396+00:00 TCP bind hash table entries: 65536 (order: 9, 2097152 bytes, linear)
2023-09-05T13:06:40,280509+00:00 TCP: Hash tables configured (established 131072 bind 65536)
2023-09-05T13:06:40,280608+00:00 MPTCP token hash table entries: 16384 (order: 6, 393216 bytes, linear)
2023-09-05T13:06:40,280629+00:00 UDP hash table entries: 8192 (order: 6, 262144 bytes, linear)
2023-09-05T13:06:40,280660+00:00 UDP-Lite hash table entries: 8192 (order: 6, 262144 bytes, linear)
2023-09-05T13:06:40,280739+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2023-09-05T13:06:40,280745+00:00 NET: Registered PF_XDP protocol family
2023-09-05T13:06:40,280755+00:00 pci 0000:02:00.0: PCI bridge to [bus 03]
2023-09-05T13:06:40,280761+00:00 pci 0000:02:00.0:   bridge window [mem 0xfc600000-0xfc6fffff]
2023-09-05T13:06:40,280769+00:00 pci 0000:02:02.0: PCI bridge to [bus 04]
2023-09-05T13:06:40,280772+00:00 pci 0000:02:02.0:   bridge window [io  0xe000-0xefff]
2023-09-05T13:06:40,280777+00:00 pci 0000:02:02.0:   bridge window [mem 0xfc500000-0xfc5fffff]
2023-09-05T13:06:40,280785+00:00 pci 0000:06:01.0: PCI bridge to [bus 07]
2023-09-05T13:06:40,280791+00:00 pci 0000:06:01.0:   bridge window [mem 0xfc300000-0xfc3fffff]
2023-09-05T13:06:40,280803+00:00 pci 0000:06:03.0: PCI bridge to [bus 08]
2023-09-05T13:06:40,280820+00:00 pci 0000:06:05.0: PCI bridge to [bus 09]
2023-09-05T13:06:40,280823+00:00 pci 0000:06:05.0:   bridge window [io  0xd000-0xdfff]
2023-09-05T13:06:40,280829+00:00 pci 0000:06:05.0:   bridge window [mem 0xfc200000-0xfc2fffff]
2023-09-05T13:06:40,280841+00:00 pci 0000:06:07.0: PCI bridge to [bus 0a]
2023-09-05T13:06:40,280858+00:00 pci 0000:05:00.0: PCI bridge to [bus 06-0a]
2023-09-05T13:06:40,280860+00:00 pci 0000:05:00.0:   bridge window [io  0xd000-0xdfff]
2023-09-05T13:06:40,280867+00:00 pci 0000:05:00.0:   bridge window [mem 0xfc200000-0xfc3fffff]
2023-09-05T13:06:40,280878+00:00 pci 0000:02:03.0: PCI bridge to [bus 05-0a]
2023-09-05T13:06:40,280880+00:00 pci 0000:02:03.0:   bridge window [io  0xd000-0xdfff]
2023-09-05T13:06:40,280885+00:00 pci 0000:02:03.0:   bridge window [mem 0xfc200000-0xfc3fffff]
2023-09-05T13:06:40,280893+00:00 pci 0000:02:04.0: PCI bridge to [bus 0b]
2023-09-05T13:06:40,280898+00:00 pci 0000:02:04.0:   bridge window [mem 0xfc400000-0xfc4fffff]
2023-09-05T13:06:40,280906+00:00 pci 0000:02:09.0: PCI bridge to [bus 0c]
2023-09-05T13:06:40,280917+00:00 pci 0000:01:00.2: PCI bridge to [bus 02-0c]
2023-09-05T13:06:40,280920+00:00 pci 0000:01:00.2:   bridge window [io  0xd000-0xefff]
2023-09-05T13:06:40,280924+00:00 pci 0000:01:00.2:   bridge window [mem 0xfc200000-0xfc6fffff]
2023-09-05T13:06:40,280932+00:00 pci 0000:00:01.3: PCI bridge to [bus 01-0c]
2023-09-05T13:06:40,280934+00:00 pci 0000:00:01.3:   bridge window [io  0xd000-0xefff]
2023-09-05T13:06:40,280937+00:00 pci 0000:00:01.3:   bridge window [mem 0xfc200000-0xfc7fffff]
2023-09-05T13:06:40,280943+00:00 pci 0000:00:03.1: PCI bridge to [bus 0d]
2023-09-05T13:06:40,280944+00:00 pci 0000:00:03.1:   bridge window [io  0xf000-0xffff]
2023-09-05T13:06:40,280947+00:00 pci 0000:00:03.1:   bridge window [mem 0xfb000000-0xfc0fffff]
2023-09-05T13:06:40,280950+00:00 pci 0000:00:03.1:   bridge window [mem 0xd0000000-0xe20fffff 64bit pref]
2023-09-05T13:06:40,280953+00:00 pci 0000:00:03.2: PCI bridge to [bus 0e]
2023-09-05T13:06:40,280956+00:00 pci 0000:00:03.2:   bridge window [mem 0xfcb00000-0xfccfffff]
2023-09-05T13:06:40,280961+00:00 pci 0000:00:07.1: PCI bridge to [bus 0f]
2023-09-05T13:06:40,280968+00:00 pci 0000:00:08.1: PCI bridge to [bus 10]
2023-09-05T13:06:40,280971+00:00 pci 0000:00:08.1:   bridge window [mem 0xfc800000-0xfcafffff]
2023-09-05T13:06:40,280975+00:00 pci 0000:00:08.3: PCI bridge to [bus 11]
2023-09-05T13:06:40,280978+00:00 pci 0000:00:08.3:   bridge window [mem 0xfcd00000-0xfcdfffff]
2023-09-05T13:06:40,280983+00:00 pci_bus 0000:00: resource 4 [io  0x0000-0x03af window]
2023-09-05T13:06:40,280985+00:00 pci_bus 0000:00: resource 5 [io  0x03e0-0x0cf7 window]
2023-09-05T13:06:40,280986+00:00 pci_bus 0000:00: resource 6 [io  0x03b0-0x03df window]
2023-09-05T13:06:40,280988+00:00 pci_bus 0000:00: resource 7 [io  0x0d00-0xffff window]
2023-09-05T13:06:40,280989+00:00 pci_bus 0000:00: resource 8 [mem 0x000a0000-0x000dffff window]
2023-09-05T13:06:40,280990+00:00 pci_bus 0000:00: resource 9 [mem 0xc0000000-0xfec2ffff window]
2023-09-05T13:06:40,280991+00:00 pci_bus 0000:00: resource 10 [mem 0xfee00000-0xffffffff window]
2023-09-05T13:06:40,280993+00:00 pci_bus 0000:01: resource 0 [io  0xd000-0xefff]
2023-09-05T13:06:40,280994+00:00 pci_bus 0000:01: resource 1 [mem 0xfc200000-0xfc7fffff]
2023-09-05T13:06:40,280996+00:00 pci_bus 0000:02: resource 0 [io  0xd000-0xefff]
2023-09-05T13:06:40,280998+00:00 pci_bus 0000:02: resource 1 [mem 0xfc200000-0xfc6fffff]
2023-09-05T13:06:40,280999+00:00 pci_bus 0000:03: resource 1 [mem 0xfc600000-0xfc6fffff]
2023-09-05T13:06:40,281000+00:00 pci_bus 0000:04: resource 0 [io  0xe000-0xefff]
2023-09-05T13:06:40,281001+00:00 pci_bus 0000:04: resource 1 [mem 0xfc500000-0xfc5fffff]
2023-09-05T13:06:40,281003+00:00 pci_bus 0000:05: resource 0 [io  0xd000-0xdfff]
2023-09-05T13:06:40,281004+00:00 pci_bus 0000:05: resource 1 [mem 0xfc200000-0xfc3fffff]
2023-09-05T13:06:40,281005+00:00 pci_bus 0000:06: resource 0 [io  0xd000-0xdfff]
2023-09-05T13:06:40,281006+00:00 pci_bus 0000:06: resource 1 [mem 0xfc200000-0xfc3fffff]
2023-09-05T13:06:40,281008+00:00 pci_bus 0000:07: resource 1 [mem 0xfc300000-0xfc3fffff]
2023-09-05T13:06:40,281009+00:00 pci_bus 0000:09: resource 0 [io  0xd000-0xdfff]
2023-09-05T13:06:40,281010+00:00 pci_bus 0000:09: resource 1 [mem 0xfc200000-0xfc2fffff]
2023-09-05T13:06:40,281011+00:00 pci_bus 0000:0b: resource 1 [mem 0xfc400000-0xfc4fffff]
2023-09-05T13:06:40,281013+00:00 pci_bus 0000:0d: resource 0 [io  0xf000-0xffff]
2023-09-05T13:06:40,281014+00:00 pci_bus 0000:0d: resource 1 [mem 0xfb000000-0xfc0fffff]
2023-09-05T13:06:40,281015+00:00 pci_bus 0000:0d: resource 2 [mem 0xd0000000-0xe20fffff 64bit pref]
2023-09-05T13:06:40,281017+00:00 pci_bus 0000:0e: resource 1 [mem 0xfcb00000-0xfccfffff]
2023-09-05T13:06:40,281018+00:00 pci_bus 0000:10: resource 1 [mem 0xfc800000-0xfcafffff]
2023-09-05T13:06:40,281019+00:00 pci_bus 0000:11: resource 1 [mem 0xfcd00000-0xfcdfffff]
2023-09-05T13:06:40,281184+00:00 pci 0000:03:00.0: PME# does not work under D0, disabling it
2023-09-05T13:06:40,281335+00:00 pci 0000:0d:00.1: extending delay after power-on from D3hot to 20 msec
2023-09-05T13:06:40,281360+00:00 pci 0000:0d:00.1: D0 power state depends on 0000:0d:00.0
2023-09-05T13:06:40,281417+00:00 pci 0000:0d:00.2: D0 power state depends on 0000:0d:00.0
2023-09-05T13:06:40,281546+00:00 pci 0000:0d:00.3: D0 power state depends on 0000:0d:00.0
2023-09-05T13:06:40,281694+00:00 PCI: CLS 64 bytes, default 64
2023-09-05T13:06:40,281698+00:00 PCI-DMA: Using software bounce buffering for IO (SWIOTLB)
2023-09-05T13:06:40,281699+00:00 software IO TLB: mapped [mem 0x00000000acaf0000-0x00000000b0af0000] (64MB)
2023-09-05T13:06:40,281732+00:00 Trying to unpack rootfs image as initramfs...
2023-09-05T13:06:40,281735+00:00 LVT offset 0 assigned for vector 0x400
2023-09-05T13:06:40,281795+00:00 perf: AMD IBS detected (0x000003ff)
2023-09-05T13:06:40,282325+00:00 Initialise system trusted keyrings
2023-09-05T13:06:40,282351+00:00 workingset: timestamp_bits=40 max_order=22 bucket_order=0
2023-09-05T13:06:40,282362+00:00 zbud: loaded
2023-09-05T13:06:40,282582+00:00 NET: Registered PF_ALG protocol family
2023-09-05T13:06:40,282585+00:00 Key type asymmetric registered
2023-09-05T13:06:40,282586+00:00 Asymmetric key parser 'x509' registered
2023-09-05T13:06:40,282594+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 252)
2023-09-05T13:06:40,282623+00:00 io scheduler mq-deadline registered
2023-09-05T13:06:40,282624+00:00 io scheduler kyber registered
2023-09-05T13:06:40,283410+00:00 amd_gpio AMDI0030:00: Invalid config param 0014
2023-09-05T13:06:40,283414+00:00 fbcon: Taking over console
2023-09-05T13:06:40,283547+00:00 pcieport 0000:00:01.3: PME: Signaling with IRQ 28
2023-09-05T13:06:40,283678+00:00 pcieport 0000:00:03.1: PME: Signaling with IRQ 29
2023-09-05T13:06:40,283787+00:00 pcieport 0000:00:03.2: PME: Signaling with IRQ 30
2023-09-05T13:06:40,283923+00:00 pcieport 0000:00:07.1: PME: Signaling with IRQ 31
2023-09-05T13:06:40,284026+00:00 pcieport 0000:00:08.1: PME: Signaling with IRQ 32
2023-09-05T13:06:40,284180+00:00 pcieport 0000:00:08.3: PME: Signaling with IRQ 33
2023-09-05T13:06:40,285645+00:00 efifb: probing for efifb
2023-09-05T13:06:40,285654+00:00 efifb: No BGRT, not showing boot graphics
2023-09-05T13:06:40,285655+00:00 efifb: framebuffer at 0xe1000000, using 2400k, total 2400k
2023-09-05T13:06:40,285656+00:00 efifb: mode is 800x600x32, linelength=4096, pages=1
2023-09-05T13:06:40,285657+00:00 efifb: scrolling: redraw
2023-09-05T13:06:40,285658+00:00 efifb: Truecolor: size=8:8:8:8, shift=24:16:8:0
2023-09-05T13:06:40,285727+00:00 Console: switching to colour frame buffer device 100x37
2023-09-05T13:06:40,286999+00:00 fb0: EFI VGA frame buffer device
2023-09-05T13:06:40,287664+00:00 Estimated ratio of average max frequency by base frequency (times 1024): 1165
2023-09-05T13:06:40,290106+00:00 Serial: 8250/16550 driver, 4 ports, IRQ sharing enabled
2023-09-05T13:06:40,291302+00:00 amd_pstate: driver load is disabled, boot with specific mode to enable this
2023-09-05T13:06:40,291341+00:00 drop_monitor: Initializing network drop monitor service
2023-09-05T13:06:40,298791+00:00 NET: Registered PF_INET6 protocol family
2023-09-05T13:06:40,321447+00:00 Freeing initrd memory: 11736K
2023-09-05T13:06:40,321930+00:00 Segment Routing with IPv6
2023-09-05T13:06:40,321942+00:00 In-situ OAM (IOAM) with IPv6
2023-09-05T13:06:40,322843+00:00 microcode: CPU0: patch_level=0x0a20120a
2023-09-05T13:06:40,322844+00:00 microcode: CPU1: patch_level=0x0a20120a
2023-09-05T13:06:40,322844+00:00 microcode: CPU3: patch_level=0x0a20120a
2023-09-05T13:06:40,322845+00:00 microcode: CPU6: patch_level=0x0a20120a
2023-09-05T13:06:40,322845+00:00 microcode: CPU5: patch_level=0x0a20120a
2023-09-05T13:06:40,322846+00:00 microcode: CPU4: patch_level=0x0a20120a
2023-09-05T13:06:40,322846+00:00 microcode: CPU9: patch_level=0x0a20120a
2023-09-05T13:06:40,322846+00:00 microcode: CPU7: patch_level=0x0a20120a
2023-09-05T13:06:40,322847+00:00 microcode: CPU10: patch_level=0x0a20120a
2023-09-05T13:06:40,322847+00:00 microcode: CPU2: patch_level=0x0a20120a
2023-09-05T13:06:40,322847+00:00 microcode: CPU8: patch_level=0x0a20120a
2023-09-05T13:06:40,322848+00:00 microcode: CPU11: patch_level=0x0a20120a
2023-09-05T13:06:40,322867+00:00 microcode: Microcode Update Driver: v2.2.
2023-09-05T13:06:40,322870+00:00 IPI shorthand broadcast: enabled
2023-09-05T13:06:40,324274+00:00 sched_clock: Marking stable (323721176, 165948)->(678413675, -354526551)
2023-09-05T13:06:40,324374+00:00 registered taskstats version 1
2023-09-05T13:06:40,324529+00:00 Loading compiled-in X.509 certificates
2023-09-05T13:06:40,326243+00:00 Key type .fscrypt registered
2023-09-05T13:06:40,326245+00:00 Key type fscrypt-provisioning registered
2023-09-05T13:06:40,326467+00:00 clk: Disabling unused clocks
2023-09-05T13:06:40,327279+00:00 Freeing unused decrypted memory: 2036K
2023-09-05T13:06:40,327744+00:00 Freeing unused kernel image (initmem) memory: 2932K
2023-09-05T13:06:40,339656+00:00 Write protecting the kernel read-only data: 24576k
2023-09-05T13:06:40,339994+00:00 Freeing unused kernel image (rodata/data gap) memory: 1080K
2023-09-05T13:06:40,380591+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2023-09-05T13:06:40,380595+00:00 Run /init as init process
2023-09-05T13:06:40,380596+00:00   with arguments:
2023-09-05T13:06:40,380597+00:00     /init
2023-09-05T13:06:40,380598+00:00   with environment:
2023-09-05T13:06:40,380599+00:00     HOME=/
2023-09-05T13:06:40,380600+00:00     TERM=linux
2023-09-05T13:06:40,380600+00:00     cgroup_enable=cpuset
2023-09-05T13:06:40,401805+00:00 stage-1-init: [Tue Sep  5 15:06:39 UTC 2023] loading module dm_mod...
2023-09-05T13:06:40,410169+00:00 device-mapper: ioctl: 4.48.0-ioctl (2023-03-01) initialised: dm-devel@redhat.com
2023-09-05T13:06:40,411050+00:00 stage-1-init: [Tue Sep  5 15:06:39 UTC 2023] running udev...
2023-09-05T13:06:40,419076+00:00 stage-1-init: [Tue Sep  5 15:06:39 UTC 2023] Starting systemd-udevd version 253.6
2023-09-05T13:06:40,492063+00:00 rtc_cmos 00:03: RTC can wake from S4
2023-09-05T13:06:40,492324+00:00 rtc_cmos 00:03: registered as rtc0
2023-09-05T13:06:40,492354+00:00 rtc_cmos 00:03: alarms up to one month, y3k, 114 bytes nvram, hpet irqs
2023-09-05T13:06:40,504269+00:00 SCSI subsystem initialized
2023-09-05T13:06:40,508247+00:00 ACPI: bus type USB registered
2023-09-05T13:06:40,508266+00:00 usbcore: registered new interface driver usbfs
2023-09-05T13:06:40,508277+00:00 usbcore: registered new interface driver hub
2023-09-05T13:06:40,508301+00:00 usbcore: registered new device driver usb
2023-09-05T13:06:40,508347+00:00 nvme nvme0: pci function 0000:0b:00.0
2023-09-05T13:06:40,514575+00:00 nvme nvme0: missing or invalid SUBNQN field.
2023-09-05T13:06:40,514701+00:00 nvme nvme0: Shutdown timeout set to 8 seconds
2023-09-05T13:06:40,518723+00:00 libata version 3.00 loaded.
2023-09-05T13:06:40,541716+00:00 nvme nvme0: 32/0/0 default/read/poll queues
2023-09-05T13:06:40,547086+00:00  nvme0n1: p1 p2
2023-09-05T13:06:40,550685+00:00 ahci 0000:01:00.1: version 3.0
2023-09-05T13:06:40,550822+00:00 ahci 0000:01:00.1: SSS flag set, parallel bus scan disabled
2023-09-05T13:06:40,550889+00:00 ahci 0000:01:00.1: AHCI 0001.0301 32 slots 8 ports 6 Gbps 0xff impl SATA mode
2023-09-05T13:06:40,550892+00:00 ahci 0000:01:00.1: flags: 64bit ncq sntf stag pm led clo only pmp pio slum part sxs deso sadm sds apst 
2023-09-05T13:06:40,551732+00:00 scsi host0: ahci
2023-09-05T13:06:40,551873+00:00 scsi host1: ahci
2023-09-05T13:06:40,551995+00:00 scsi host2: ahci
2023-09-05T13:06:40,552115+00:00 scsi host3: ahci
2023-09-05T13:06:40,552233+00:00 scsi host4: ahci
2023-09-05T13:06:40,552342+00:00 scsi host5: ahci
2023-09-05T13:06:40,552455+00:00 scsi host6: ahci
2023-09-05T13:06:40,552567+00:00 scsi host7: ahci
2023-09-05T13:06:40,552621+00:00 ata1: SATA max UDMA/133 abar m131072@0xfc780000 port 0xfc780100 irq 77
2023-09-05T13:06:40,552623+00:00 ata2: SATA max UDMA/133 abar m131072@0xfc780000 port 0xfc780180 irq 77
2023-09-05T13:06:40,552626+00:00 ata3: SATA max UDMA/133 abar m131072@0xfc780000 port 0xfc780200 irq 77
2023-09-05T13:06:40,552628+00:00 ata4: SATA max UDMA/133 abar m131072@0xfc780000 port 0xfc780280 irq 77
2023-09-05T13:06:40,552630+00:00 ata5: SATA max UDMA/133 abar m131072@0xfc780000 port 0xfc780300 irq 77
2023-09-05T13:06:40,552632+00:00 ata6: SATA max UDMA/133 abar m131072@0xfc780000 port 0xfc780380 irq 77
2023-09-05T13:06:40,552634+00:00 ata7: SATA max UDMA/133 abar m131072@0xfc780000 port 0xfc780400 irq 77
2023-09-05T13:06:40,552636+00:00 ata8: SATA max UDMA/133 abar m131072@0xfc780000 port 0xfc780480 irq 77
2023-09-05T13:06:40,552837+00:00 ahci 0000:04:00.0: SSS flag set, parallel bus scan disabled
2023-09-05T13:06:40,552883+00:00 ahci 0000:04:00.0: AHCI 0001.0200 32 slots 2 ports 6 Gbps 0x3 impl SATA mode
2023-09-05T13:06:40,552886+00:00 ahci 0000:04:00.0: flags: 64bit ncq sntf stag led clo pmp pio slum part ccc 
2023-09-05T13:06:40,553127+00:00 scsi host8: ahci
2023-09-05T13:06:40,553221+00:00 scsi host9: ahci
2023-09-05T13:06:40,553266+00:00 ata9: SATA max UDMA/133 abar m512@0xfc500000 port 0xfc500100 irq 78
2023-09-05T13:06:40,553269+00:00 ata10: SATA max UDMA/133 abar m512@0xfc500000 port 0xfc500180 irq 78
2023-09-05T13:06:40,553413+00:00 ahci 0000:11:00.0: AHCI 0001.0301 32 slots 1 ports 6 Gbps 0x20 impl SATA mode
2023-09-05T13:06:40,553415+00:00 ahci 0000:11:00.0: flags: 64bit ncq sntf ilck pm led clo only pmp fbs pio slum part 
2023-09-05T13:06:40,554050+00:00 scsi host10: ahci
2023-09-05T13:06:40,554217+00:00 scsi host11: ahci
2023-09-05T13:06:40,554355+00:00 scsi host12: ahci
2023-09-05T13:06:40,554494+00:00 scsi host13: ahci
2023-09-05T13:06:40,554597+00:00 scsi host14: ahci
2023-09-05T13:06:40,554700+00:00 scsi host15: ahci
2023-09-05T13:06:40,554757+00:00 ata11: DUMMY
2023-09-05T13:06:40,554758+00:00 ata12: DUMMY
2023-09-05T13:06:40,554760+00:00 ata13: DUMMY
2023-09-05T13:06:40,554760+00:00 ata14: DUMMY
2023-09-05T13:06:40,554761+00:00 ata15: DUMMY
2023-09-05T13:06:40,554763+00:00 ata16: SATA max UDMA/133 abar m2048@0xfcd00000 port 0xfcd00380 irq 80
2023-09-05T13:06:40,859923+00:00 ata1: SATA link down (SStatus 0 SControl 330)
2023-09-05T13:06:40,860043+00:00 ata9: SATA link down (SStatus 0 SControl 300)
2023-09-05T13:06:41,029898+00:00 ata16: SATA link up 6.0 Gbps (SStatus 133 SControl 300)
2023-09-05T13:06:41,030202+00:00 ata16.00: supports DRM functions and may not be fully accessible
2023-09-05T13:06:41,030204+00:00 ata16.00: ATA-11: Samsung SSD 860 EVO M.2 2TB, RVT21B6Q, max UDMA/133
2023-09-05T13:06:41,030881+00:00 ata16.00: 3907029168 sectors, multi 1: LBA48 NCQ (depth 32), AA
2023-09-05T13:06:41,034061+00:00 ata16.00: Features: Trust Dev-Sleep NCQ-sndrcv
2023-09-05T13:06:41,034471+00:00 ata16.00: supports DRM functions and may not be fully accessible
2023-09-05T13:06:41,038532+00:00 ata16.00: configured for UDMA/133
2023-09-05T13:06:41,173355+00:00 ata2: SATA link down (SStatus 0 SControl 330)
2023-09-05T13:06:41,325174+00:00 tsc: Refined TSC clocksource calibration: 3500.278 MHz
2023-09-05T13:06:41,325181+00:00 clocksource: tsc: mask: 0xffffffffffffffff max_cycles: 0x3274571b4ac, max_idle_ns: 440795220744 ns
2023-09-05T13:06:41,325199+00:00 clocksource: Switched to clocksource tsc
2023-09-05T13:06:41,482293+00:00 ata3: SATA link down (SStatus 0 SControl 330)
2023-09-05T13:06:41,786268+00:00 ata4: SATA link down (SStatus 0 SControl 330)
2023-09-05T13:06:42,090274+00:00 ata5: SATA link down (SStatus 0 SControl 330)
2023-09-05T13:06:42,394284+00:00 ata6: SATA link down (SStatus 0 SControl 330)
2023-09-05T13:06:42,698281+00:00 ata7: SATA link down (SStatus 0 SControl 330)
2023-09-05T13:06:43,002281+00:00 ata8: SATA link down (SStatus 0 SControl 330)
2023-09-05T13:06:43,306415+00:00 ata10: SATA link down (SStatus 0 SControl 300)
2023-09-05T13:06:43,306518+00:00 scsi 15:0:0:0: Direct-Access     ATA      Samsung SSD 860  1B6Q PQ: 0 ANSI: 5
2023-09-05T13:06:43,310083+00:00 xhci_hcd 0000:01:00.0: xHCI Host Controller
2023-09-05T13:06:43,310089+00:00 xhci_hcd 0000:01:00.0: new USB bus registered, assigned bus number 1
2023-09-05T13:06:43,315439+00:00 ata16.00: Enabling discard_zeroes_data
2023-09-05T13:06:43,315455+00:00 sd 15:0:0:0: [sda] 3907029168 512-byte logical blocks: (2.00 TB/1.82 TiB)
2023-09-05T13:06:43,315470+00:00 sd 15:0:0:0: [sda] Write Protect is off
2023-09-05T13:06:43,315472+00:00 sd 15:0:0:0: [sda] Mode Sense: 00 3a 00 00
2023-09-05T13:06:43,315491+00:00 sd 15:0:0:0: [sda] Write cache: enabled, read cache: enabled, doesn't support DPO or FUA
2023-09-05T13:06:43,315530+00:00 sd 15:0:0:0: [sda] Preferred minimum I/O size 512 bytes
2023-09-05T13:06:43,315886+00:00 ata16.00: Enabling discard_zeroes_data
2023-09-05T13:06:43,318753+00:00  sda: sda1 sda2
2023-09-05T13:06:43,319864+00:00 sd 15:0:0:0: [sda] supports TCG Opal
2023-09-05T13:06:43,319866+00:00 sd 15:0:0:0: [sda] Attached SCSI disk
2023-09-05T13:06:43,365275+00:00 xhci_hcd 0000:01:00.0: hcc params 0x0200ef81 hci version 0x110 quirks 0x0000000000000410
2023-09-05T13:06:43,365604+00:00 xhci_hcd 0000:01:00.0: xHCI Host Controller
2023-09-05T13:06:43,365607+00:00 xhci_hcd 0000:01:00.0: new USB bus registered, assigned bus number 2
2023-09-05T13:06:43,365609+00:00 xhci_hcd 0000:01:00.0: Host supports USB 3.1 Enhanced SuperSpeed
2023-09-05T13:06:43,365671+00:00 usb usb1: New USB device found, idVendor=1d6b, idProduct=0002, bcdDevice= 6.05
2023-09-05T13:06:43,365673+00:00 usb usb1: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2023-09-05T13:06:43,365674+00:00 usb usb1: Product: xHCI Host Controller
2023-09-05T13:06:43,365675+00:00 usb usb1: Manufacturer: Linux 6.5.0 xhci-hcd
2023-09-05T13:06:43,365676+00:00 usb usb1: SerialNumber: 0000:01:00.0
2023-09-05T13:06:43,365817+00:00 hub 1-0:1.0: USB hub found
2023-09-05T13:06:43,365836+00:00 hub 1-0:1.0: 14 ports detected
2023-09-05T13:06:43,366340+00:00 usb usb2: We don't know the algorithms for LPM for this host, disabling LPM.
2023-09-05T13:06:43,366360+00:00 usb usb2: New USB device found, idVendor=1d6b, idProduct=0003, bcdDevice= 6.05
2023-09-05T13:06:43,366361+00:00 usb usb2: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2023-09-05T13:06:43,366362+00:00 usb usb2: Product: xHCI Host Controller
2023-09-05T13:06:43,366364+00:00 usb usb2: Manufacturer: Linux 6.5.0 xhci-hcd
2023-09-05T13:06:43,366365+00:00 usb usb2: SerialNumber: 0000:01:00.0
2023-09-05T13:06:43,366452+00:00 hub 2-0:1.0: USB hub found
2023-09-05T13:06:43,366465+00:00 hub 2-0:1.0: 8 ports detected
2023-09-05T13:06:43,366578+00:00 usb: port power management may be unreliable
2023-09-05T13:06:43,366834+00:00 xhci_hcd 0000:03:00.0: xHCI Host Controller
2023-09-05T13:06:43,366838+00:00 xhci_hcd 0000:03:00.0: new USB bus registered, assigned bus number 3
2023-09-05T13:06:43,421659+00:00 xhci_hcd 0000:03:00.0: hcc params 0x0200ef80 hci version 0x110 quirks 0x0000000000800010
2023-09-05T13:06:43,421981+00:00 xhci_hcd 0000:03:00.0: xHCI Host Controller
2023-09-05T13:06:43,421984+00:00 xhci_hcd 0000:03:00.0: new USB bus registered, assigned bus number 4
2023-09-05T13:06:43,421987+00:00 xhci_hcd 0000:03:00.0: Host supports USB 3.1 Enhanced SuperSpeed
2023-09-05T13:06:43,422032+00:00 usb usb3: New USB device found, idVendor=1d6b, idProduct=0002, bcdDevice= 6.05
2023-09-05T13:06:43,422034+00:00 usb usb3: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2023-09-05T13:06:43,422035+00:00 usb usb3: Product: xHCI Host Controller
2023-09-05T13:06:43,422036+00:00 usb usb3: Manufacturer: Linux 6.5.0 xhci-hcd
2023-09-05T13:06:43,422037+00:00 usb usb3: SerialNumber: 0000:03:00.0
2023-09-05T13:06:43,422122+00:00 hub 3-0:1.0: USB hub found
2023-09-05T13:06:43,422130+00:00 hub 3-0:1.0: 2 ports detected
2023-09-05T13:06:43,422228+00:00 usb usb4: We don't know the algorithms for LPM for this host, disabling LPM.
2023-09-05T13:06:43,422246+00:00 usb usb4: New USB device found, idVendor=1d6b, idProduct=0003, bcdDevice= 6.05
2023-09-05T13:06:43,422247+00:00 usb usb4: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2023-09-05T13:06:43,422249+00:00 usb usb4: Product: xHCI Host Controller
2023-09-05T13:06:43,422250+00:00 usb usb4: Manufacturer: Linux 6.5.0 xhci-hcd
2023-09-05T13:06:43,422251+00:00 usb usb4: SerialNumber: 0000:03:00.0
2023-09-05T13:06:43,422325+00:00 hub 4-0:1.0: USB hub found
2023-09-05T13:06:43,422333+00:00 hub 4-0:1.0: 2 ports detected
2023-09-05T13:06:43,422513+00:00 xhci_hcd 0000:0d:00.2: xHCI Host Controller
2023-09-05T13:06:43,422517+00:00 xhci_hcd 0000:0d:00.2: new USB bus registered, assigned bus number 5
2023-09-05T13:06:43,423106+00:00 xhci_hcd 0000:0d:00.2: hcc params 0x0180ff05 hci version 0x110 quirks 0x0000000000000010
2023-09-05T13:06:43,423245+00:00 xhci_hcd 0000:0d:00.2: xHCI Host Controller
2023-09-05T13:06:43,423247+00:00 xhci_hcd 0000:0d:00.2: new USB bus registered, assigned bus number 6
2023-09-05T13:06:43,423249+00:00 xhci_hcd 0000:0d:00.2: Host supports USB 3.1 Enhanced SuperSpeed
2023-09-05T13:06:43,423289+00:00 usb usb5: New USB device found, idVendor=1d6b, idProduct=0002, bcdDevice= 6.05
2023-09-05T13:06:43,423291+00:00 usb usb5: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2023-09-05T13:06:43,423292+00:00 usb usb5: Product: xHCI Host Controller
2023-09-05T13:06:43,423293+00:00 usb usb5: Manufacturer: Linux 6.5.0 xhci-hcd
2023-09-05T13:06:43,423294+00:00 usb usb5: SerialNumber: 0000:0d:00.2
2023-09-05T13:06:43,423370+00:00 hub 5-0:1.0: USB hub found
2023-09-05T13:06:43,423376+00:00 hub 5-0:1.0: 2 ports detected
2023-09-05T13:06:43,423473+00:00 usb usb6: We don't know the algorithms for LPM for this host, disabling LPM.
2023-09-05T13:06:43,423491+00:00 usb usb6: New USB device found, idVendor=1d6b, idProduct=0003, bcdDevice= 6.05
2023-09-05T13:06:43,423492+00:00 usb usb6: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2023-09-05T13:06:43,423493+00:00 usb usb6: Product: xHCI Host Controller
2023-09-05T13:06:43,423495+00:00 usb usb6: Manufacturer: Linux 6.5.0 xhci-hcd
2023-09-05T13:06:43,423496+00:00 usb usb6: SerialNumber: 0000:0d:00.2
2023-09-05T13:06:43,423567+00:00 hub 6-0:1.0: USB hub found
2023-09-05T13:06:43,423576+00:00 hub 6-0:1.0: 4 ports detected
2023-09-05T13:06:43,423760+00:00 xhci_hcd 0000:10:00.3: xHCI Host Controller
2023-09-05T13:06:43,423764+00:00 xhci_hcd 0000:10:00.3: new USB bus registered, assigned bus number 7
2023-09-05T13:06:43,423863+00:00 xhci_hcd 0000:10:00.3: hcc params 0x0278ffe5 hci version 0x110 quirks 0x0000000000000410
2023-09-05T13:06:43,424118+00:00 xhci_hcd 0000:10:00.3: xHCI Host Controller
2023-09-05T13:06:43,424121+00:00 xhci_hcd 0000:10:00.3: new USB bus registered, assigned bus number 8
2023-09-05T13:06:43,424123+00:00 xhci_hcd 0000:10:00.3: Host supports USB 3.1 Enhanced SuperSpeed
2023-09-05T13:06:43,424153+00:00 usb usb7: New USB device found, idVendor=1d6b, idProduct=0002, bcdDevice= 6.05
2023-09-05T13:06:43,424155+00:00 usb usb7: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2023-09-05T13:06:43,424156+00:00 usb usb7: Product: xHCI Host Controller
2023-09-05T13:06:43,424157+00:00 usb usb7: Manufacturer: Linux 6.5.0 xhci-hcd
2023-09-05T13:06:43,424158+00:00 usb usb7: SerialNumber: 0000:10:00.3
2023-09-05T13:06:43,424241+00:00 hub 7-0:1.0: USB hub found
2023-09-05T13:06:43,424248+00:00 hub 7-0:1.0: 4 ports detected
2023-09-05T13:06:43,424361+00:00 usb usb8: We don't know the algorithms for LPM for this host, disabling LPM.
2023-09-05T13:06:43,424379+00:00 usb usb8: New USB device found, idVendor=1d6b, idProduct=0003, bcdDevice= 6.05
2023-09-05T13:06:43,424381+00:00 usb usb8: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2023-09-05T13:06:43,424382+00:00 usb usb8: Product: xHCI Host Controller
2023-09-05T13:06:43,424383+00:00 usb usb8: Manufacturer: Linux 6.5.0 xhci-hcd
2023-09-05T13:06:43,424384+00:00 usb usb8: SerialNumber: 0000:10:00.3
2023-09-05T13:06:43,424462+00:00 hub 8-0:1.0: USB hub found
2023-09-05T13:06:43,424469+00:00 hub 8-0:1.0: 4 ports detected
2023-09-05T13:06:43,428654+00:00 stage-1-init: [Tue Sep  5 15:06:42 UTC 2023] starting device mapper and LVM...
2023-09-05T13:06:43,468449+00:00 stage-1-init: [Tue Sep  5 15:06:42 UTC 2023] checking /dev/disk/by-uuid/4b1cd989-5999-4d7c-8012-535963e2f7e5...
2023-09-05T13:06:43,469068+00:00 stage-1-init: [Tue Sep  5 15:06:42 UTC 2023] fsck (busybox 1.36.1)
2023-09-05T13:06:43,469712+00:00 stage-1-init: [Tue Sep  5 15:06:42 UTC 2023] [fsck.ext4 (1) -- /mnt-root/] fsck.ext4 -a /dev/disk/by-uuid/4b1cd989-5999-4d7c-8012-535963e2f7e5
2023-09-05T13:06:43,477455+00:00 stage-1-init: [Tue Sep  5 15:06:42 UTC 2023] /dev/disk/by-uuid/4b1cd989-5999-4d7c-8012-535963e2f7e5: clean, 16187263/122068992 files, 278663704/488246424 blocks
2023-09-05T13:06:43,483512+00:00 stage-1-init: [Tue Sep  5 15:06:42 UTC 2023] mounting /dev/disk/by-uuid/4b1cd989-5999-4d7c-8012-535963e2f7e5 on /...
2023-09-05T13:06:43,550368+00:00 EXT4-fs (sda2): mounted filesystem 4b1cd989-5999-4d7c-8012-535963e2f7e5 r/w with ordered data mode. Quota mode: none.
2023-09-05T13:06:43,551476+00:00 EXT4-fs (sda2): re-mounted 4b1cd989-5999-4d7c-8012-535963e2f7e5 r/w. Quota mode: none.
2023-09-05T13:06:43,663172+00:00 usb 7-1: new high-speed USB device number 2 using xhci_hcd
2023-09-05T13:06:43,701174+00:00 usb 1-9: new full-speed USB device number 2 using xhci_hcd
2023-09-05T13:06:43,730232+00:00 EXT4-fs (sda2): re-mounted 4b1cd989-5999-4d7c-8012-535963e2f7e5 r/w. Quota mode: none.
2023-09-05T13:06:43,730413+00:00 booting system configuration /nix/store/6zhcn3ndafmmnvx6ka1axfgv546ggfsd-nixos-system-nixos-23.05.20230902.9075cba
2023-09-05T13:06:43,754984+00:00 stage-2-init: running activation script...
2023-09-05T13:06:43,802516+00:00 usb 7-1: New USB device found, idVendor=0bda, idProduct=5411, bcdDevice= 1.03
2023-09-05T13:06:43,802520+00:00 usb 7-1: New USB device strings: Mfr=1, Product=2, SerialNumber=0
2023-09-05T13:06:43,802522+00:00 usb 7-1: Product: USB2.1 Hub
2023-09-05T13:06:43,802523+00:00 usb 7-1: Manufacturer: Generic
2023-09-05T13:06:43,840928+00:00 hub 7-1:1.0: USB hub found
2023-09-05T13:06:43,842141+00:00 hub 7-1:1.0: 2 ports detected
2023-09-05T13:06:43,878036+00:00 stage-2-init: setting up /etc...
2023-09-05T13:06:43,910668+00:00 usb 8-1: new SuperSpeed USB device number 2 using xhci_hcd
2023-09-05T13:06:43,931355+00:00 usb 8-1: New USB device found, idVendor=0bda, idProduct=0411, bcdDevice= 1.03
2023-09-05T13:06:43,931366+00:00 usb 8-1: New USB device strings: Mfr=1, Product=2, SerialNumber=0
2023-09-05T13:06:43,931368+00:00 usb 8-1: Product: USB3.2 Hub
2023-09-05T13:06:43,931369+00:00 usb 8-1: Manufacturer: Generic
2023-09-05T13:06:43,952976+00:00 hub 8-1:1.0: USB hub found
2023-09-05T13:06:43,954328+00:00 hub 8-1:1.0: 2 ports detected
2023-09-05T13:06:44,040182+00:00 usb 7-2: new high-speed USB device number 3 using xhci_hcd
2023-09-05T13:06:44,067767+00:00 usb 1-9: New USB device found, idVendor=8087, idProduct=0aa7, bcdDevice= 0.01
2023-09-05T13:06:44,067771+00:00 usb 1-9: New USB device strings: Mfr=0, Product=0, SerialNumber=0
2023-09-05T13:06:44,142430+00:00 systemd[1]: RTC configured in localtime, applying delta of 120 minutes to system time.
2023-09-05T13:06:44,153040+00:00 systemd[1]: Inserted module 'autofs4'
2023-09-05T13:06:44,171516+00:00 usb 7-2: New USB device found, idVendor=1220, idProduct=8fe0, bcdDevice= 1.00
2023-09-05T13:06:44,171519+00:00 usb 7-2: New USB device strings: Mfr=1, Product=2, SerialNumber=0
2023-09-05T13:06:44,171521+00:00 usb 7-2: Product: GoXLR
2023-09-05T13:06:44,171523+00:00 usb 7-2: Manufacturer: TC-Helicon
2023-09-05T13:06:44,173744+00:00 systemd[1]: systemd 253.6 running in system mode (+PAM +AUDIT -SELINUX +APPARMOR +IMA +SMACK +SECCOMP +GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN +IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 -PWQUALITY +P11KIT -QRENCODE +TPM2 +BZIP2 +LZ4 +XZ +ZLIB +ZSTD +BPF_FRAMEWORK -XKBCOMMON +UTMP -SYSVINIT default-hierarchy=unified)
2023-09-05T13:06:44,173748+00:00 systemd[1]: Detected architecture x86-64.
2023-09-05T13:06:44,244175+00:00 usb 7-1.1: new high-speed USB device number 4 using xhci_hcd
2023-09-05T13:06:44,255171+00:00 usb 1-13: new full-speed USB device number 3 using xhci_hcd
2023-09-05T13:06:44,334892+00:00 usb 7-1.1: New USB device found, idVendor=214b, idProduct=7250, bcdDevice= 1.00
2023-09-05T13:06:44,334894+00:00 usb 7-1.1: New USB device strings: Mfr=0, Product=1, SerialNumber=0
2023-09-05T13:06:44,334896+00:00 usb 7-1.1: Product: USB2.0 HUB
2023-09-05T13:06:44,384298+00:00 hub 7-1.1:1.0: USB hub found
2023-09-05T13:06:44,384642+00:00 hub 7-1.1:1.0: 4 ports detected
2023-09-05T13:06:44,481181+00:00 systemd[1]: bpf-lsm: LSM BPF program attached
2023-09-05T13:06:44,623771+00:00 usb 1-13: New USB device found, idVendor=1e71, idProduct=170e, bcdDevice= 2.00
2023-09-05T13:06:44,623775+00:00 usb 1-13: New USB device strings: Mfr=1, Product=2, SerialNumber=3
2023-09-05T13:06:44,623777+00:00 usb 1-13: Product: NZXT USB Device
2023-09-05T13:06:44,623778+00:00 usb 1-13: Manufacturer: NZXT.-Inc.
2023-09-05T13:06:44,623780+00:00 usb 1-13: SerialNumber: 6D72167E545
2023-09-05T13:06:44,636143+00:00 systemd[1]: /nix/store/k9gwy4xk7gp05hlflxgwhh94hcs3xrs9-system-units/docker.service.d/overrides.conf:18: Missing '=', ignoring line.
2023-09-05T13:06:44,638637+00:00 systemd[1]: /etc/systemd/system/cups.socket:5: ListenStream= references a path below legacy directory /var/run/, updating /var/run/cups/cups.sock \xe2\x86\x92 /run/cups/cups.sock; please update the unit file accordingly.
2023-09-05T13:06:44,652505+00:00 systemd[1]: Queued start job for default target Graphical Interface.
2023-09-05T13:06:44,661175+00:00 usb 7-1.1.1: new high-speed USB device number 5 using xhci_hcd
2023-09-05T13:06:44,664780+00:00 systemd[1]: Created slice Slice /system/modprobe.
2023-09-05T13:06:44,665285+00:00 systemd[1]: Created slice Slice /system/systemd-fsck.
2023-09-05T13:06:44,665719+00:00 systemd[1]: Created slice User and Session Slice.
2023-09-05T13:06:44,665811+00:00 systemd[1]: Started Dispatch Password Requests to Console Directory Watch.
2023-09-05T13:06:44,665899+00:00 systemd[1]: Started Forward Password Requests to Wall Directory Watch.
2023-09-05T13:06:44,666057+00:00 systemd[1]: Set up automount Arbitrary Executable File Formats File System Automount Point.
2023-09-05T13:06:44,666132+00:00 systemd[1]: Reached target Local Encrypted Volumes.
2023-09-05T13:06:44,666182+00:00 systemd[1]: Reached target Login Prompts.
2023-09-05T13:06:44,666226+00:00 systemd[1]: Reached target Containers.
2023-09-05T13:06:44,666270+00:00 systemd[1]: Reached target Path Units.
2023-09-05T13:06:44,666309+00:00 systemd[1]: Reached target Remote File Systems.
2023-09-05T13:06:44,666348+00:00 systemd[1]: Reached target Slice Units.
2023-09-05T13:06:44,666386+00:00 systemd[1]: Reached target Swaps.
2023-09-05T13:06:44,667108+00:00 systemd[1]: Listening on Process Core Dump Socket.
2023-09-05T13:06:44,667776+00:00 systemd[1]: Listening on Journal Socket (/dev/log).
2023-09-05T13:06:44,668430+00:00 systemd[1]: Listening on Journal Socket.
2023-09-05T13:06:44,669100+00:00 systemd[1]: Listening on Userspace Out-Of-Memory (OOM) Killer Socket.
2023-09-05T13:06:44,669918+00:00 systemd[1]: Listening on udev Control Socket.
2023-09-05T13:06:44,670562+00:00 systemd[1]: Listening on udev Kernel Socket.
2023-09-05T13:06:44,672104+00:00 systemd[1]: Mounting Huge Pages File System...
2023-09-05T13:06:44,673540+00:00 systemd[1]: Mounting POSIX Message Queue File System...
2023-09-05T13:06:44,674960+00:00 systemd[1]: Mounting Kernel Debug File System...
2023-09-05T13:06:44,676409+00:00 systemd[1]: Starting Create List of Static Device Nodes...
2023-09-05T13:06:44,677810+00:00 systemd[1]: Starting Load Kernel Module configfs...
2023-09-05T13:06:44,679164+00:00 systemd[1]: Starting Load Kernel Module drm...
2023-09-05T13:06:44,680466+00:00 systemd[1]: Starting Load Kernel Module efi_pstore...
2023-09-05T13:06:44,681767+00:00 systemd[1]: Starting Load Kernel Module fuse...
2023-09-05T13:06:44,683048+00:00 systemd[1]: Starting mount-pstore.service...
2023-09-05T13:06:44,683531+00:00 systemd[1]: File System Check on Root Device was skipped because of an unmet condition check (ConditionPathIsReadWrite=!/).
2023-09-05T13:06:44,684746+00:00 systemd[1]: Starting Journal Service...
2023-09-05T13:06:44,685675+00:00 pstore: Using crash dump compression: deflate
2023-09-05T13:06:44,686131+00:00 systemd[1]: Starting Load Kernel Modules...
2023-09-05T13:06:44,686892+00:00 pstore: Registered efi_pstore as persistent store backend
2023-09-05T13:06:44,687440+00:00 systemd[1]: Starting Remount Root and Kernel File Systems...
2023-09-05T13:06:44,688865+00:00 systemd[1]: Starting Coldplug All udev Devices...
2023-09-05T13:06:44,690608+00:00 fuse: init (API version 7.38)
2023-09-05T13:06:44,691425+00:00 systemd[1]: Mounted Huge Pages File System.
2023-09-05T13:06:44,691944+00:00 systemd[1]: Mounted POSIX Message Queue File System.
2023-09-05T13:06:44,692477+00:00 systemd[1]: Mounted Kernel Debug File System.
2023-09-05T13:06:44,695183+00:00 systemd-journald[710]: Collecting audit messages is disabled.
2023-09-05T13:06:44,699177+00:00 EXT4-fs (sda2): re-mounted 4b1cd989-5999-4d7c-8012-535963e2f7e5 r/w. Quota mode: none.
2023-09-05T13:06:44,709735+00:00 ACPI: bus type drm_connector registered
2023-09-05T13:06:44,715364+00:00 systemd[1]: Finished Create List of Static Device Nodes.
2023-09-05T13:06:44,716669+00:00 systemd[1]: modprobe@configfs.service: Deactivated successfully.
2023-09-05T13:06:44,726318+00:00 systemd[1]: Finished Load Kernel Module configfs.
2023-09-05T13:06:44,726998+00:00 systemd[1]: modprobe@drm.service: Deactivated successfully.
2023-09-05T13:06:44,738893+00:00 usb 7-1.1.1: New USB device found, idVendor=1a40, idProduct=0101, bcdDevice= 1.11
2023-09-05T13:06:44,738897+00:00 usb 7-1.1.1: New USB device strings: Mfr=0, Product=1, SerialNumber=0
2023-09-05T13:06:44,738899+00:00 usb 7-1.1.1: Product: USB 2.0 Hub
2023-09-05T13:06:44,756300+00:00 systemd[1]: Finished Load Kernel Module drm.
2023-09-05T13:06:44,756846+00:00 systemd[1]: Started Journal Service.
2023-09-05T13:06:44,758384+00:00 ccp 0000:10:00.1: enabling device (0000 -> 0002)
2023-09-05T13:06:44,758495+00:00 ccp 0000:10:00.1: ccp: unable to access the device: you might be running a broken BIOS.
2023-09-05T13:06:44,758508+00:00 ccp 0000:10:00.1: psp enabled
2023-09-05T13:06:44,765611+00:00 kvm_amd: TSC scaling supported
2023-09-05T13:06:44,765613+00:00 kvm_amd: Nested Virtualization enabled
2023-09-05T13:06:44,765613+00:00 kvm_amd: Nested Paging enabled
2023-09-05T13:06:44,765619+00:00 kvm_amd: Virtual VMLOAD VMSAVE supported
2023-09-05T13:06:44,765620+00:00 kvm_amd: Virtual GIF supported
2023-09-05T13:06:44,765621+00:00 kvm_amd: LBR virtualization supported
2023-09-05T13:06:44,784589+00:00 bridge: filtering via arp/ip/ip6tables is no longer available by default. Update your scripts to load br_netfilter if you need this.
2023-09-05T13:06:44,790396+00:00 tun: Universal TUN/TAP device driver, 1.6
2023-09-05T13:06:44,793045+00:00 Bridge firewalling registered
2023-09-05T13:06:44,800311+00:00 hub 7-1.1.1:1.0: USB hub found
2023-09-05T13:06:44,800641+00:00 hub 7-1.1.1:1.0: 4 ports detected
2023-09-05T13:06:44,808692+00:00 loop: module loaded
2023-09-05T13:06:44,865186+00:00 systemd-journald[710]: Received client request to flush runtime journal.
2023-09-05T13:06:44,867175+00:00 usb 7-1.1.2: new high-speed USB device number 6 using xhci_hcd
2023-09-05T13:06:44,946517+00:00 usb 7-1.1.2: New USB device found, idVendor=0fd9, idProduct=0060, bcdDevice= 1.00
2023-09-05T13:06:44,946522+00:00 usb 7-1.1.2: New USB device strings: Mfr=1, Product=2, SerialNumber=3
2023-09-05T13:06:44,946524+00:00 usb 7-1.1.2: Product: Stream Deck
2023-09-05T13:06:44,946526+00:00 usb 7-1.1.2: Manufacturer: Elgato Systems
2023-09-05T13:06:44,946527+00:00 usb 7-1.1.2: SerialNumber: AL15I1C02177
2023-09-05T13:06:45,000813+00:00 systemd-journald[710]: /var/log/journal/7db9449887224d229d073f714f3c3782/system.journal: Monotonic clock jumped backwards relative to last journal entry, rotating.
2023-09-05T13:06:45,000817+00:00 systemd-journald[710]: Rotating system journal.
2023-09-05T13:06:45,047210+00:00 nvidia: loading out-of-tree module taints kernel.
2023-09-05T13:06:45,047217+00:00 nvidia: module license 'NVIDIA' taints kernel.
2023-09-05T13:06:45,047218+00:00 Disabling lock debugging due to kernel taint
2023-09-05T13:06:45,047220+00:00 nvidia: module license taints kernel.
2023-09-05T13:06:45,089188+00:00 usb 7-1.1.3: new full-speed USB device number 7 using xhci_hcd
2023-09-05T13:06:45,209153+00:00 usb 7-1.1.3: New USB device found, idVendor=12c9, idProduct=2003, bcdDevice= 2.11
2023-09-05T13:06:45,209157+00:00 usb 7-1.1.3: New USB device strings: Mfr=1, Product=2, SerialNumber=0
2023-09-05T13:06:45,209160+00:00 usb 7-1.1.3: Product: USB Gaming Mouse
2023-09-05T13:06:45,209161+00:00 usb 7-1.1.3: Manufacturer: SOAI
2023-09-05T13:06:45,411170+00:00 usb 7-1.1.4: new high-speed USB device number 8 using xhci_hcd
2023-09-05T13:06:45,443144+00:00 RAPL PMU: API unit is 2^-32 Joules, 1 fixed counters, 163840 ms ovfl timer
2023-09-05T13:06:45,443146+00:00 RAPL PMU: hw unit of domain package 2^-16 Joules
2023-09-05T13:06:45,443215+00:00 hid: raw HID events driver (C) Jiri Kosina
2023-09-05T13:06:45,443255+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0C:00/input/input0
2023-09-05T13:06:45,443286+00:00 ACPI: button: Power Button [PWRB]
2023-09-05T13:06:45,443343+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXPWRBN:00/input/input1
2023-09-05T13:06:45,445009+00:00 piix4_smbus 0000:00:14.0: SMBus Host Controller at 0xb00, revision 0
2023-09-05T13:06:45,445013+00:00 piix4_smbus 0000:00:14.0: Using register 0x02 for SMBus port selection
2023-09-05T13:06:45,445094+00:00 piix4_smbus 0000:00:14.0: Auxiliary SMBus Host Controller at 0xb20
2023-09-05T13:06:45,445636+00:00 cryptd: max_cpu_qlen set to 1000
2023-09-05T13:06:45,448156+00:00 dca service started, version 1.12.1
2023-09-05T13:06:45,448537+00:00 nvidia-nvlink: Nvlink Core is being initialized, major device number 244

2023-09-05T13:06:45,449820+00:00 nvidia 0000:0d:00.0: vgaarb: changed VGA decodes: olddecodes=io+mem,decodes=none:owns=io+mem
2023-09-05T13:06:45,451847+00:00 AVX2 version of gcm_enc/dec engaged.
2023-09-05T13:06:45,451887+00:00 AES CTR mode by8 optimization enabled
2023-09-05T13:06:45,465790+00:00 ACPI: button: Power Button [PWRF]
2023-09-05T13:06:45,465948+00:00 pps_core: LinuxPPS API ver. 1 registered
2023-09-05T13:06:45,465950+00:00 pps_core: Software ver. 5.3.6 - Copyright 2005-2007 Rodolfo Giometti <giometti@linux.it>
2023-09-05T13:06:45,467009+00:00 sp5100_tco: SP5100/SB800 TCO WatchDog Timer Driver
2023-09-05T13:06:45,467091+00:00 sp5100-tco sp5100-tco: Using 0xfeb00000 for watchdog MMIO address
2023-09-05T13:06:45,473211+00:00 sp5100-tco sp5100-tco: initialized. heartbeat=60 sec (nowayout=0)
2023-09-05T13:06:45,484274+00:00 EDAC MC: Ver: 3.0.0
2023-09-05T13:06:45,484338+00:00 PTP clock support registered
2023-09-05T13:06:45,486399+00:00 mc: Linux media interface: v0.10
2023-09-05T13:06:45,487909+00:00 MCE: In-kernel MCE decoding enabled.
2023-09-05T13:06:45,490019+00:00 usb 7-1.1.4: New USB device found, idVendor=214b, idProduct=7250, bcdDevice= 1.00
2023-09-05T13:06:45,490023+00:00 usb 7-1.1.4: New USB device strings: Mfr=0, Product=1, SerialNumber=0
2023-09-05T13:06:45,490025+00:00 usb 7-1.1.4: Product: USB2.0 HUB
2023-09-05T13:06:45,497357+00:00 usbcore: registered new interface driver usbhid
2023-09-05T13:06:45,497360+00:00 usbhid: USB HID core driver
2023-09-05T13:06:45,520229+00:00 Bluetooth: Core ver 2.22
2023-09-05T13:06:45,520242+00:00 NET: Registered PF_BLUETOOTH protocol family
2023-09-05T13:06:45,520244+00:00 Bluetooth: HCI device and connection manager initialized
2023-09-05T13:06:45,520247+00:00 Bluetooth: HCI socket layer initialized
2023-09-05T13:06:45,520248+00:00 Bluetooth: L2CAP socket layer initialized
2023-09-05T13:06:45,520252+00:00 Bluetooth: SCO socket layer initialized
2023-09-05T13:06:45,536315+00:00 hub 7-1.1.4:1.0: USB hub found
2023-09-05T13:06:45,536641+00:00 hub 7-1.1.4:1.0: 4 ports detected
2023-09-05T13:06:45,551644+00:00 nzxt-kraken2 0003:1E71:170E.0001: hidraw0: USB HID v1.10 Device [NZXT.-Inc. NZXT USB Device] on usb-0000:01:00.0-13/input0
2023-09-05T13:06:45,560318+00:00 intel_rapl_common: Found RAPL domain package
2023-09-05T13:06:45,560320+00:00 igb: Intel(R) Gigabit Ethernet Network Driver
2023-09-05T13:06:45,560321+00:00 intel_rapl_common: Found RAPL domain core
2023-09-05T13:06:45,560322+00:00 igb: Copyright (c) 2007-2014 Intel Corporation.
2023-09-05T13:06:45,560843+00:00 cfg80211: Loading compiled-in X.509 certificates for regulatory database
2023-09-05T13:06:45,563446+00:00 Loaded X.509 cert 'sforshee: 00b28ddf47aef9cea7'
2023-09-05T13:06:45,566642+00:00 snd_hda_intel 0000:0d:00.1: Disabling MSI
2023-09-05T13:06:45,566651+00:00 snd_hda_intel 0000:0d:00.1: Handle vga_switcheroo audio client
2023-09-05T13:06:45,566721+00:00 snd_hda_intel 0000:10:00.4: enabling device (0000 -> 0002)
2023-09-05T13:06:45,570354+00:00 usbcore: registered new interface driver btusb
2023-09-05T13:06:45,585326+00:00 Intel(R) Wireless WiFi driver for Linux
2023-09-05T13:06:45,585380+00:00 iwlwifi 0000:07:00.0: enabling device (0000 -> 0002)
2023-09-05T13:06:45,585641+00:00 Bluetooth: hci0: Legacy ROM 2.x revision 5.0 build 25 week 20 2015
2023-09-05T13:06:45,585644+00:00 Bluetooth: hci0: Intel device is already patched. patch num: 3c
2023-09-05T13:06:45,585706+00:00 iwlwifi 0000:07:00.0: Detected crf-id 0x0, cnv-id 0x0 wfpm id 0x0
2023-09-05T13:06:45,585712+00:00 iwlwifi 0000:07:00.0: PCI dev 24fb/2110, rev=0x220, rfid=0xd55555d5
2023-09-05T13:06:45,589368+00:00 input: HDA NVidia HDMI/DP,pcm=3 as /devices/pci0000:00/0000:00:03.1/0000:0d:00.1/sound/card0/input2
2023-09-05T13:06:45,589439+00:00 input: HDA NVidia HDMI/DP,pcm=7 as /devices/pci0000:00/0000:00:03.1/0000:0d:00.1/sound/card0/input3
2023-09-05T13:06:45,589501+00:00 input: HDA NVidia HDMI/DP,pcm=8 as /devices/pci0000:00/0000:00:03.1/0000:0d:00.1/sound/card0/input4
2023-09-05T13:06:45,589563+00:00 input: HDA NVidia HDMI/DP,pcm=9 as /devices/pci0000:00/0000:00:03.1/0000:0d:00.1/sound/card0/input5
2023-09-05T13:06:45,589664+00:00 pps pps0: new PPS source ptp0
2023-09-05T13:06:45,590598+00:00 igb 0000:09:00.0: added PHC on eth0
2023-09-05T13:06:45,590628+00:00 igb 0000:09:00.0: Intel(R) Gigabit Ethernet Network Connection
2023-09-05T13:06:45,590630+00:00 igb 0000:09:00.0: eth0: (PCIe:2.5Gb/s:Width x1) 70:85:c2:b9:65:7d
2023-09-05T13:06:45,590632+00:00 igb 0000:09:00.0: eth0: PBA No: FFFFFF-0FF
2023-09-05T13:06:45,590634+00:00 igb 0000:09:00.0: Using MSI-X interrupts. 2 rx queue(s), 2 tx queue(s)
2023-09-05T13:06:45,591415+00:00 snd_hda_codec_realtek hdaudioC1D0: autoconfig for ALC1220: line_outs=3 (0x14/0x15/0x16/0x0/0x0) type:line
2023-09-05T13:06:45,591419+00:00 snd_hda_codec_realtek hdaudioC1D0:    speaker_outs=0 (0x0/0x0/0x0/0x0/0x0)
2023-09-05T13:06:45,591422+00:00 snd_hda_codec_realtek hdaudioC1D0:    hp_outs=1 (0x1b/0x0/0x0/0x0/0x0)
2023-09-05T13:06:45,591424+00:00 snd_hda_codec_realtek hdaudioC1D0:    mono: mono_out=0x0
2023-09-05T13:06:45,591426+00:00 snd_hda_codec_realtek hdaudioC1D0:    dig-out=0x1e/0x0
2023-09-05T13:06:45,591428+00:00 snd_hda_codec_realtek hdaudioC1D0:    inputs:
2023-09-05T13:06:45,591429+00:00 snd_hda_codec_realtek hdaudioC1D0:      Front Mic=0x19
2023-09-05T13:06:45,591431+00:00 snd_hda_codec_realtek hdaudioC1D0:      Rear Mic=0x18
2023-09-05T13:06:45,591433+00:00 snd_hda_codec_realtek hdaudioC1D0:      Line=0x1a
2023-09-05T13:06:45,595365+00:00 igb 0000:09:00.0 enp9s0: renamed from eth0
2023-09-05T13:06:45,603354+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T13:06:45,603356+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T13:06:45,603357+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T13:06:45,603358+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T13:06:45,603359+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T13:06:45,603360+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T13:06:45,603361+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T13:06:45,603362+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T13:06:45,603363+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T13:06:45,603364+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T13:06:45,603463+00:00 input: Elgato Systems Stream Deck as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.2/7-1.1.2:1.0/0003:0FD9:0060.0002/input/input9
2023-09-05T13:06:45,604265+00:00 input: HD-Audio Generic Front Mic as /devices/pci0000:00/0000:00:08.1/0000:10:00.4/sound/card1/input6
2023-09-05T13:06:45,607097+00:00 iwlwifi 0000:07:00.0: loaded firmware version 29.198743027.0 3168-29.ucode op_mode iwlmvm
2023-09-05T13:06:45,656275+00:00 hid-generic 0003:0FD9:0060.0002: input,hidraw1: USB HID v1.11 Device [Elgato Systems Stream Deck] on usb-0000:10:00.3-1.1.2/input0
2023-09-05T13:06:45,656312+00:00 input: HD-Audio Generic Rear Mic as /devices/pci0000:00/0000:00:08.1/0000:10:00.4/sound/card1/input7
2023-09-05T13:06:45,656397+00:00 input: HD-Audio Generic Line as /devices/pci0000:00/0000:00:08.1/0000:10:00.4/sound/card1/input8
2023-09-05T13:06:45,656411+00:00 input: SOAI USB Gaming Mouse as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.3/7-1.1.3:1.0/0003:12C9:2003.0003/input/input14
2023-09-05T13:06:45,656483+00:00 input: HD-Audio Generic Line Out Front as /devices/pci0000:00/0000:00:08.1/0000:10:00.4/sound/card1/input10
2023-09-05T13:06:45,656522+00:00 hid-generic 0003:12C9:2003.0003: input,hidraw2: USB HID v1.10 Mouse [SOAI USB Gaming Mouse] on usb-0000:10:00.3-1.1.3/input0
2023-09-05T13:06:45,656568+00:00 input: HD-Audio Generic Line Out Surround as /devices/pci0000:00/0000:00:08.1/0000:10:00.4/sound/card1/input11
2023-09-05T13:06:45,656640+00:00 input: HD-Audio Generic Line Out CLFE as /devices/pci0000:00/0000:00:08.1/0000:10:00.4/sound/card1/input12
2023-09-05T13:06:45,656705+00:00 input: HD-Audio Generic Front Headphone as /devices/pci0000:00/0000:00:08.1/0000:10:00.4/sound/card1/input13
2023-09-05T13:06:45,656725+00:00 input: SOAI USB Gaming Mouse Keyboard as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.3/7-1.1.3:1.1/0003:12C9:2003.0004/input/input15
2023-09-05T13:06:45,683205+00:00 NVRM: loading NVIDIA UNIX x86_64 Kernel Module  535.104.05  Sat Aug 19 01:15:15 UTC 2023
2023-09-05T13:06:45,683755+00:00 iwlwifi 0000:07:00.0: Detected Intel(R) Dual Band Wireless AC 3168, REV=0x220
2023-09-05T13:06:45,683812+00:00 thermal thermal_zone0: failed to read out thermal zone (-61)
2023-09-05T13:06:45,697350+00:00 usbcore: registered new interface driver snd-usb-audio
2023-09-05T13:06:45,707298+00:00 nvidia-modeset: Loading NVIDIA Kernel Mode Setting Driver for UNIX platforms  535.104.05  Sat Aug 19 00:59:57 UTC 2023
2023-09-05T13:06:45,707871+00:00 iwlwifi 0000:07:00.0: base HW address: fc:77:74:8c:d8:3b, OTP minor version: 0x0
2023-09-05T13:06:45,709280+00:00 input: SOAI USB Gaming Mouse as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.3/7-1.1.3:1.1/0003:12C9:2003.0004/input/input16
2023-09-05T13:06:45,709413+00:00 hid-generic 0003:12C9:2003.0004: input,hiddev96,hidraw3: USB HID v1.10 Keyboard [SOAI USB Gaming Mouse] on usb-0000:10:00.3-1.1.3/input1
2023-09-05T13:06:45,709525+00:00 hid-generic 0003:12C9:2003.0005: hiddev97,hidraw4: USB HID v1.10 Device [SOAI USB Gaming Mouse] on usb-0000:10:00.3-1.1.3/input2
2023-09-05T13:06:45,715271+00:00 mousedev: PS/2 mouse device common for all mice
2023-09-05T13:06:45,727590+00:00 [drm] [nvidia-drm] [GPU ID 0x00000d00] Loading driver
2023-09-05T13:06:45,737303+00:00 ieee80211 phy0: Selected rate control algorithm 'iwl-mvm-rs'
2023-09-05T13:06:45,740355+00:00 iwlwifi 0000:07:00.0 wlp7s0: renamed from wlan0
2023-09-05T13:06:45,793722+00:00 nvidia_uvm: module uses symbols nvUvmInterfaceDisableAccessCntr from proprietary module nvidia, inheriting taint.
2023-09-05T13:06:46,135475+00:00 nvidia-uvm: Loaded the UVM driver, major device number 238.
2023-09-05T13:06:47,564748+00:00 [drm] Initialized nvidia-drm 0.0.0 20160202 for 0000:0d:00.0 on minor 0
2023-09-05T13:06:47,767626+00:00 Bluetooth: BNEP (Ethernet Emulation) ver 1.3
2023-09-05T13:06:47,767631+00:00 Bluetooth: BNEP socket layer initialized
2023-09-05T13:06:47,768729+00:00 Bluetooth: MGMT ver 1.22
2023-09-05T13:06:48,063738+00:00 systemd-journald[710]: /var/log/journal/7db9449887224d229d073f714f3c3782/user-1000.journal: Monotonic clock jumped backwards relative to last journal entry, rotating.
2023-09-05T13:06:48,815519+00:00 memfd_create() without MFD_EXEC nor MFD_NOEXEC_SEAL, pid=1323 'X'
2023-09-05T13:06:50,897783+00:00 igb 0000:09:00.0 enp9s0: igb: enp9s0 NIC Link is Up 1000 Mbps Full Duplex, Flow Control: RX
2023-09-05T13:06:51,118806+00:00 NET: Registered PF_PACKET protocol family
2023-09-05T13:06:52,314672+00:00 Bluetooth: RFCOMM TTY layer initialized
2023-09-05T13:06:52,314680+00:00 Bluetooth: RFCOMM socket layer initialized
2023-09-05T13:06:52,314685+00:00 Bluetooth: RFCOMM ver 1.11
2023-09-05T13:06:52,786278+00:00 NET: Registered PF_QIPCRTR protocol family
2023-09-05T13:06:53,925661+00:00 Initializing XFRM netlink socket
2023-09-05T13:06:54,435770+00:00 br-e429376abcdb: port 1(vethe510e14) entered blocking state
2023-09-05T13:06:54,435775+00:00 br-e429376abcdb: port 1(vethe510e14) entered disabled state
2023-09-05T13:06:54,435785+00:00 vethe510e14: entered allmulticast mode
2023-09-05T13:06:54,435825+00:00 vethe510e14: entered promiscuous mode
2023-09-05T13:06:54,435918+00:00 br-e429376abcdb: port 1(vethe510e14) entered blocking state
2023-09-05T13:06:54,435921+00:00 br-e429376abcdb: port 1(vethe510e14) entered forwarding state
2023-09-05T13:06:54,436106+00:00 br-e429376abcdb: port 1(vethe510e14) entered disabled state
2023-09-05T13:06:54,462745+00:00 br-e429376abcdb: port 2(vethc9a7c3b) entered blocking state
2023-09-05T13:06:54,462749+00:00 br-e429376abcdb: port 2(vethc9a7c3b) entered disabled state
2023-09-05T13:06:54,462759+00:00 vethc9a7c3b: entered allmulticast mode
2023-09-05T13:06:54,462797+00:00 vethc9a7c3b: entered promiscuous mode
2023-09-05T13:06:54,462876+00:00 br-e429376abcdb: port 2(vethc9a7c3b) entered blocking state
2023-09-05T13:06:54,462880+00:00 br-e429376abcdb: port 2(vethc9a7c3b) entered forwarding state
2023-09-05T13:06:54,836412+00:00 eth0: renamed from veth3a81b1f
2023-09-05T13:06:54,858432+00:00 eth0: renamed from veth33f1b47
2023-09-05T13:06:54,874287+00:00 br-e429376abcdb: port 2(vethc9a7c3b) entered disabled state
2023-09-05T13:06:54,874362+00:00 br-e429376abcdb: port 1(vethe510e14) entered blocking state
2023-09-05T13:06:54,874365+00:00 br-e429376abcdb: port 1(vethe510e14) entered forwarding state
2023-09-05T13:06:54,874625+00:00 br-e429376abcdb: port 2(vethc9a7c3b) entered blocking state
2023-09-05T13:06:54,874629+00:00 br-e429376abcdb: port 2(vethc9a7c3b) entered forwarding state
2023-09-05T13:07:13,181175+00:00 usb 7-1.1.1.4: new full-speed USB device number 9 using xhci_hcd
2023-09-05T13:07:13,394177+00:00 usb 7-1.1.1.4: New USB device found, idVendor=258a, idProduct=0059, bcdDevice=10.21
2023-09-05T13:07:13,394181+00:00 usb 7-1.1.1.4: New USB device strings: Mfr=1, Product=2, SerialNumber=0
2023-09-05T13:07:13,394183+00:00 usb 7-1.1.1.4: Product: RK Bluetooth Keyboar
2023-09-05T13:07:13,394185+00:00 usb 7-1.1.1.4: Manufacturer: SINO WEALTH
2023-09-05T13:07:13,479374+00:00 input: SINO WEALTH RK Bluetooth Keyboar as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.1/7-1.1.1.4/7-1.1.1.4:1.0/0003:258A:0059.0006/input/input17
2023-09-05T13:07:13,531287+00:00 hid-generic 0003:258A:0059.0006: input,hidraw5: USB HID v1.11 Keyboard [SINO WEALTH RK Bluetooth Keyboar] on usb-0000:10:00.3-1.1.1.4/input0
2023-09-05T13:07:13,537378+00:00 input: SINO WEALTH RK Bluetooth Keyboar System Control as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.1/7-1.1.1.4/7-1.1.1.4:1.1/0003:258A:0059.0007/input/input18
2023-09-05T13:07:13,589324+00:00 input: SINO WEALTH RK Bluetooth Keyboar Consumer Control as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.1/7-1.1.1.4/7-1.1.1.4:1.1/0003:258A:0059.0007/input/input19
2023-09-05T13:07:13,589404+00:00 input: SINO WEALTH RK Bluetooth Keyboar Keyboard as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.1/7-1.1.1.4/7-1.1.1.4:1.1/0003:258A:0059.0007/input/input20
2023-09-05T13:07:13,589531+00:00 hid-generic 0003:258A:0059.0007: input,hiddev98,hidraw6: USB HID v1.11 Keyboard [SINO WEALTH RK Bluetooth Keyboar] on usb-0000:10:00.3-1.1.1.4/input1
2023-09-05T13:07:23,393446+00:00 eth0: renamed from tmp9b05e
2023-09-05T13:07:23,442326+00:00 eth0: renamed from tmpb3225
2023-09-05T13:07:23,456802+00:00 eth0: renamed from tmpa19aa
2023-09-05T13:07:23,525573+00:00 eth0: renamed from tmpaa5b5
2023-09-05T13:07:23,603317+00:00 eth0: renamed from tmp71a72
2023-09-05T13:07:23,617337+00:00 eth0: renamed from tmp67b62
2023-09-05T13:07:23,628396+00:00 eth0: renamed from tmpe8aff
2023-09-05T13:07:23,662298+00:00 eth0: renamed from tmp01a73
2023-09-05T13:07:23,689326+00:00 eth0: renamed from tmpa2fa5
2023-09-05T13:07:23,700539+00:00 eth0: renamed from tmp087f8
2023-09-05T13:07:23,712779+00:00 eth0: renamed from tmp70a99
2023-09-05T13:07:23,733471+00:00 eth0: renamed from tmpd9698
2023-09-05T13:07:23,741415+00:00 eth0: renamed from tmpfcd8f
2023-09-05T13:07:23,750496+00:00 eth0: renamed from tmp52235
2023-09-05T13:07:23,780849+00:00 eth0: renamed from tmp3646b
2023-09-05T13:07:23,872320+00:00 eth0: renamed from tmpac497
2023-09-05T13:07:23,882291+00:00 eth0: renamed from tmp814b7
2023-09-05T13:07:23,898830+00:00 eth0: renamed from tmp10f8e
2023-09-05T13:07:23,921380+00:00 eth0: renamed from tmpb76b5
2023-09-05T13:07:23,932258+00:00 eth0: renamed from tmpf5895
2023-09-05T13:07:24,008335+00:00 eth0: renamed from tmp07e62
2023-09-05T13:07:24,024270+00:00 eth0: renamed from tmp97417
2023-09-05T13:07:24,040282+00:00 eth0: renamed from tmp64c96
2023-09-05T13:07:24,063304+00:00 eth0: renamed from tmpcc48d
2023-09-05T13:07:24,078296+00:00 eth0: renamed from tmp965e1
2023-09-05T13:07:24,094798+00:00 eth0: renamed from tmp1f6bf
2023-09-05T13:07:25,017764+00:00 eth0: Caught tx_queue_len zero misconfig
2023-09-05T13:07:30,329347+00:00 br-e429376abcdb: port 2(vethc9a7c3b) entered disabled state
2023-09-05T13:07:30,329414+00:00 veth33f1b47: renamed from eth0
2023-09-05T13:07:30,375896+00:00 br-e429376abcdb: port 2(vethc9a7c3b) entered disabled state
2023-09-05T13:07:30,376499+00:00 vethc9a7c3b (unregistering): left allmulticast mode
2023-09-05T13:07:30,376502+00:00 vethc9a7c3b (unregistering): left promiscuous mode
2023-09-05T13:07:30,376504+00:00 br-e429376abcdb: port 2(vethc9a7c3b) entered disabled state
2023-09-05T13:07:32,066495+00:00 eth0: renamed from tmp2f203
2023-09-05T13:07:32,303491+00:00 br-e429376abcdb: port 1(vethe510e14) entered disabled state
2023-09-05T13:07:32,303559+00:00 veth3a81b1f: renamed from eth0
2023-09-05T13:07:32,342871+00:00 br-e429376abcdb: port 1(vethe510e14) entered disabled state
2023-09-05T13:07:32,343265+00:00 vethe510e14 (unregistering): left allmulticast mode
2023-09-05T13:07:32,343269+00:00 vethe510e14 (unregistering): left promiscuous mode
2023-09-05T13:07:32,343273+00:00 br-e429376abcdb: port 1(vethe510e14) entered disabled state
2023-09-05T13:07:43,335682+00:00 br-e429376abcdb: port 1(vethf7f1cf6) entered blocking state
2023-09-05T13:07:43,335687+00:00 br-e429376abcdb: port 1(vethf7f1cf6) entered disabled state
2023-09-05T13:07:43,335695+00:00 vethf7f1cf6: entered allmulticast mode
2023-09-05T13:07:43,335768+00:00 vethf7f1cf6: entered promiscuous mode
2023-09-05T13:07:43,521470+00:00 eth0: renamed from veth598efe2
2023-09-05T13:07:43,533488+00:00 br-e429376abcdb: port 1(vethf7f1cf6) entered blocking state
2023-09-05T13:07:43,533493+00:00 br-e429376abcdb: port 1(vethf7f1cf6) entered forwarding state
2023-09-05T13:07:43,623361+00:00 br-e429376abcdb: port 1(vethf7f1cf6) entered disabled state
2023-09-05T13:07:43,623415+00:00 veth598efe2: renamed from eth0
2023-09-05T13:07:43,669090+00:00 br-e429376abcdb: port 1(vethf7f1cf6) entered disabled state
2023-09-05T13:07:43,669630+00:00 vethf7f1cf6 (unregistering): left allmulticast mode
2023-09-05T13:07:43,669633+00:00 vethf7f1cf6 (unregistering): left promiscuous mode
2023-09-05T13:07:43,669636+00:00 br-e429376abcdb: port 1(vethf7f1cf6) entered disabled state
2023-09-05T13:07:43,852795+00:00 br-e429376abcdb: port 1(vethac7f714) entered blocking state
2023-09-05T13:07:43,852799+00:00 br-e429376abcdb: port 1(vethac7f714) entered disabled state
2023-09-05T13:07:43,852811+00:00 vethac7f714: entered allmulticast mode
2023-09-05T13:07:43,852861+00:00 vethac7f714: entered promiscuous mode
2023-09-05T13:07:43,852953+00:00 br-e429376abcdb: port 1(vethac7f714) entered blocking state
2023-09-05T13:07:43,852956+00:00 br-e429376abcdb: port 1(vethac7f714) entered forwarding state
2023-09-05T13:07:44,025371+00:00 eth0: renamed from veth56d4d86
2023-09-05T13:07:46,589594+00:00 br-e429376abcdb: port 2(veth57022e7) entered blocking state
2023-09-05T13:07:46,589601+00:00 br-e429376abcdb: port 2(veth57022e7) entered disabled state
2023-09-05T13:07:46,589620+00:00 veth57022e7: entered allmulticast mode
2023-09-05T13:07:46,589678+00:00 veth57022e7: entered promiscuous mode
2023-09-05T13:07:46,774388+00:00 eth0: renamed from vethcc39f77
2023-09-05T13:07:46,795467+00:00 br-e429376abcdb: port 2(veth57022e7) entered blocking state
2023-09-05T13:07:46,795471+00:00 br-e429376abcdb: port 2(veth57022e7) entered forwarding state
2023-09-05T13:08:34,186612+00:00 eth0: Caught tx_queue_len zero misconfig
2023-09-05T13:08:34,533868+00:00 eth0: renamed from tmp820ec
2023-09-05T13:08:34,574078+00:00 eth0: renamed from tmpa9bf3
2023-09-05T13:08:34,610925+00:00 eth0: renamed from tmpe3e1c
2023-09-05T13:08:34,670895+00:00 eth0: renamed from tmp346a0
2023-09-05T13:08:34,770317+00:00 eth0: renamed from tmpf47f8
2023-09-05T13:08:34,781146+00:00 eth0: renamed from tmp04435
2023-09-05T13:08:34,788449+00:00 eth0: renamed from tmp21db1
2023-09-05T13:08:34,799861+00:00 eth0: renamed from tmp8c1cd
2023-09-05T13:08:34,846716+00:00 eth0: renamed from tmpeba8b
2023-09-05T13:08:34,855590+00:00 eth0: renamed from tmp56f2e
2023-09-05T13:08:34,882693+00:00 eth0: renamed from tmp856bf
2023-09-05T13:08:34,909088+00:00 eth0: renamed from tmp8d0fa
2023-09-05T13:08:34,943784+00:00 eth0: renamed from tmp533b1
2023-09-05T13:11:38,671052+00:00 eth0: renamed from tmp949b5
2023-09-05T13:11:38,699927+00:00 eth0: renamed from tmp8b430
2023-09-05T13:11:38,962867+00:00 eth0: renamed from tmp3b553
2023-09-05T13:11:39,124087+00:00 eth0: renamed from tmp2bb73
2023-09-05T13:11:39,143977+00:00 eth0: renamed from tmp2c452
2023-09-05T13:11:39,182244+00:00 eth0: renamed from tmpafa12
2023-09-05T13:11:39,294875+00:00 eth0: renamed from tmp7b5d2
2023-09-05T13:11:39,399220+00:00 eth0: renamed from tmpc3675
2023-09-05T13:11:39,443789+00:00 eth0: renamed from tmpbbe93
2023-09-05T13:11:39,452707+00:00 eth0: renamed from tmp3aec1
2023-09-05T13:11:39,552904+00:00 eth0: renamed from tmpb86e7
2023-09-05T13:11:39,597837+00:00 eth0: renamed from tmp3c2f3
2023-09-05T13:11:39,624213+00:00 eth0: renamed from tmp4e583
2023-09-05T13:11:39,658065+00:00 eth0: renamed from tmp35579
2023-09-05T13:11:39,684969+00:00 eth0: renamed from tmp99f7b
2023-09-05T13:11:39,941856+00:00 eth0: renamed from tmpc6444
2023-09-05T13:11:40,005823+00:00 eth0: renamed from tmp00aec
2023-09-05T13:11:41,976869+00:00 eth0: renamed from tmp1a6c3
2023-09-05T13:11:50,871753+00:00 eth0: renamed from tmpa3730
2023-09-05T13:11:51,836911+00:00 eth0: renamed from tmp41ec5
2023-09-05T13:11:52,112743+00:00 eth0: renamed from tmpd35dd
2023-09-05T13:19:26,561812+00:00 usb 7-1.1.1-port4: disabled by hub (EMI?), re-enabling...
2023-09-05T13:19:26,561819+00:00 usb 7-1.1.1.4: USB disconnect, device number 9
2023-09-05T13:19:27,007781+00:00 usb 7-1.1.1.4: new full-speed USB device number 10 using xhci_hcd
2023-09-05T13:19:27,221951+00:00 usb 7-1.1.1.4: New USB device found, idVendor=258a, idProduct=0059, bcdDevice=10.21
2023-09-05T13:19:27,221955+00:00 usb 7-1.1.1.4: New USB device strings: Mfr=1, Product=2, SerialNumber=0
2023-09-05T13:19:27,221957+00:00 usb 7-1.1.1.4: Product: RK Bluetooth Keyboar
2023-09-05T13:19:27,221959+00:00 usb 7-1.1.1.4: Manufacturer: SINO WEALTH
2023-09-05T13:19:27,304141+00:00 input: SINO WEALTH RK Bluetooth Keyboar as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.1/7-1.1.1.4/7-1.1.1.4:1.0/0003:258A:0059.0008/input/input21
2023-09-05T13:19:27,356060+00:00 hid-generic 0003:258A:0059.0008: input,hidraw5: USB HID v1.11 Keyboard [SINO WEALTH RK Bluetooth Keyboar] on usb-0000:10:00.3-1.1.1.4/input0
2023-09-05T13:19:27,362148+00:00 input: SINO WEALTH RK Bluetooth Keyboar System Control as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.1/7-1.1.1.4/7-1.1.1.4:1.1/0003:258A:0059.0009/input/input22
2023-09-05T13:19:27,413873+00:00 input: SINO WEALTH RK Bluetooth Keyboar Consumer Control as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.1/7-1.1.1.4/7-1.1.1.4:1.1/0003:258A:0059.0009/input/input23
2023-09-05T13:19:27,413951+00:00 input: SINO WEALTH RK Bluetooth Keyboar Keyboard as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.1/7-1.1.1.4/7-1.1.1.4:1.1/0003:258A:0059.0009/input/input24
2023-09-05T13:19:27,414076+00:00 hid-generic 0003:258A:0059.0009: input,hiddev98,hidraw6: USB HID v1.11 Keyboard [SINO WEALTH RK Bluetooth Keyboar] on usb-0000:10:00.3-1.1.1.4/input1
2023-09-05T13:28:11,091722+00:00 eth0: renamed from tmp4739e
2023-09-05T13:28:11,133251+00:00 eth0: renamed from tmp628fe
2023-09-05T13:28:11,145391+00:00 eth0: renamed from tmp7bdfa
2023-09-05T13:28:11,436333+00:00 eth0: renamed from tmp22d5a
2023-09-05T13:28:11,637297+00:00 eth0: renamed from tmpf0d5d
2023-09-05T13:37:23,819191+00:00 br-e429376abcdb: port 2(veth57022e7) entered disabled state
2023-09-05T13:37:23,819246+00:00 vethcc39f77: renamed from eth0
2023-09-05T13:37:23,852660+00:00 br-e429376abcdb: port 2(veth57022e7) entered disabled state
2023-09-05T13:37:23,853207+00:00 veth57022e7 (unregistering): left allmulticast mode
2023-09-05T13:37:23,853210+00:00 veth57022e7 (unregistering): left promiscuous mode
2023-09-05T13:37:23,853213+00:00 br-e429376abcdb: port 2(veth57022e7) entered disabled state
2023-09-05T13:37:24,110557+00:00 br-e429376abcdb: port 1(vethac7f714) entered disabled state
2023-09-05T13:37:24,110615+00:00 veth56d4d86: renamed from eth0
2023-09-05T13:37:24,278933+00:00 br-e429376abcdb: port 1(vethac7f714) entered disabled state
2023-09-05T13:37:24,279604+00:00 vethac7f714 (unregistering): left allmulticast mode
2023-09-05T13:37:24,279607+00:00 vethac7f714 (unregistering): left promiscuous mode
2023-09-05T13:37:24,279610+00:00 br-e429376abcdb: port 1(vethac7f714) entered disabled state
2023-09-05T13:37:29,703412+00:00 br-e429376abcdb: port 1(veth22a50ac) entered blocking state
2023-09-05T13:37:29,703416+00:00 br-e429376abcdb: port 1(veth22a50ac) entered disabled state
2023-09-05T13:37:29,703426+00:00 veth22a50ac: entered allmulticast mode
2023-09-05T13:37:29,703493+00:00 veth22a50ac: entered promiscuous mode
2023-09-05T13:37:29,860799+00:00 eth0: renamed from veth418fa16
2023-09-05T13:37:29,873741+00:00 br-e429376abcdb: port 1(veth22a50ac) entered blocking state
2023-09-05T13:37:29,873746+00:00 br-e429376abcdb: port 1(veth22a50ac) entered forwarding state
2023-09-05T13:37:30,596319+00:00 br-e429376abcdb: port 1(veth22a50ac) entered disabled state
2023-09-05T13:37:30,596389+00:00 veth418fa16: renamed from eth0
2023-09-05T13:37:30,623030+00:00 br-e429376abcdb: port 1(veth22a50ac) entered disabled state
2023-09-05T13:37:30,623521+00:00 veth22a50ac (unregistering): left allmulticast mode
2023-09-05T13:37:30,623524+00:00 veth22a50ac (unregistering): left promiscuous mode
2023-09-05T13:37:30,623526+00:00 br-e429376abcdb: port 1(veth22a50ac) entered disabled state
2023-09-05T13:37:30,765424+00:00 br-e429376abcdb: port 1(veth47a3b1e) entered blocking state
2023-09-05T13:37:30,765428+00:00 br-e429376abcdb: port 1(veth47a3b1e) entered disabled state
2023-09-05T13:37:30,765440+00:00 veth47a3b1e: entered allmulticast mode
2023-09-05T13:37:30,765507+00:00 veth47a3b1e: entered promiscuous mode
2023-09-05T13:37:30,765635+00:00 br-e429376abcdb: port 1(veth47a3b1e) entered blocking state
2023-09-05T13:37:30,765638+00:00 br-e429376abcdb: port 1(veth47a3b1e) entered forwarding state
2023-09-05T13:37:30,765729+00:00 br-e429376abcdb: port 1(veth47a3b1e) entered disabled state
2023-09-05T13:37:30,929716+00:00 eth0: renamed from veth3a6d262
2023-09-05T13:37:30,938723+00:00 br-e429376abcdb: port 1(veth47a3b1e) entered blocking state
2023-09-05T13:37:30,938728+00:00 br-e429376abcdb: port 1(veth47a3b1e) entered forwarding state
2023-09-05T13:37:33,317658+00:00 br-e429376abcdb: port 2(veth015a38b) entered blocking state
2023-09-05T13:37:33,317666+00:00 br-e429376abcdb: port 2(veth015a38b) entered disabled state
2023-09-05T13:37:33,317683+00:00 veth015a38b: entered allmulticast mode
2023-09-05T13:37:33,317741+00:00 veth015a38b: entered promiscuous mode
2023-09-05T13:37:33,519644+00:00 eth0: renamed from vethcf154aa
2023-09-05T13:37:33,535774+00:00 br-e429376abcdb: port 2(veth015a38b) entered blocking state
2023-09-05T13:37:33,535778+00:00 br-e429376abcdb: port 2(veth015a38b) entered forwarding state
2023-09-05T13:38:09,222987+00:00 cilium_vxlan: Caught tx_queue_len zero misconfig
2023-09-05T13:38:10,255648+00:00 eth0: renamed from tmp76869
2023-09-05T13:38:10,287665+00:00 eth0: renamed from tmp7aea9
2023-09-05T13:38:10,319639+00:00 eth0: renamed from tmpefd68
2023-09-05T13:38:10,349354+00:00 eth0: renamed from tmpde373
2023-09-05T13:38:10,384544+00:00 eth0: renamed from tmpe66fa
2023-09-05T13:38:10,442421+00:00 eth0: renamed from tmp54789
2023-09-05T13:38:10,460795+00:00 eth0: renamed from tmp61d4c
2023-09-05T13:38:10,479704+00:00 eth0: renamed from tmp802c1
2023-09-05T13:38:10,528345+00:00 eth0: renamed from tmp85fe4
2023-09-05T13:38:10,551397+00:00 eth0: renamed from tmpb14a4
2023-09-05T13:38:10,586489+00:00 eth0: renamed from tmp00cc9
2023-09-05T13:38:10,600380+00:00 eth0: renamed from tmp16ba1
2023-09-05T13:38:10,616436+00:00 eth0: renamed from tmpbc846
2023-09-05T13:38:10,771894+00:00 eth0: Caught tx_queue_len zero misconfig
2023-09-05T13:39:56,321022+00:00 eth0: renamed from tmp536d7
2023-09-05T13:39:56,350655+00:00 eth0: renamed from tmp38707
2023-09-05T13:39:56,380951+00:00 eth0: renamed from tmpf181b
2023-09-05T13:39:56,408017+00:00 eth0: renamed from tmp4ab0b
2023-09-05T13:39:56,421738+00:00 eth0: renamed from tmp3d9af
2023-09-05T13:40:01,091027+00:00 eth0: renamed from tmp779bd
2023-09-05T13:40:01,155015+00:00 eth0: renamed from tmp4e673
2023-09-05T13:40:01,228966+00:00 eth0: renamed from tmpbd81c
2023-09-05T13:40:01,297314+00:00 eth0: renamed from tmp32b5e
2023-09-05T13:40:01,330211+00:00 eth0: renamed from tmp8b977
2023-09-05T13:40:01,400263+00:00 eth0: renamed from tmp336ca
2023-09-05T13:40:01,441103+00:00 eth0: renamed from tmp48162
2023-09-05T13:40:01,463106+00:00 eth0: renamed from tmp5e103
2023-09-05T13:40:01,489090+00:00 eth0: renamed from tmp6e528
2023-09-05T13:40:01,522786+00:00 eth0: renamed from tmp2bb1b
2023-09-05T13:40:01,568431+00:00 eth0: renamed from tmp88b2f
2023-09-05T13:40:01,576851+00:00 eth0: renamed from tmpc958e
2023-09-05T13:40:01,607107+00:00 eth0: renamed from tmp683d2
2023-09-05T13:40:01,636071+00:00 eth0: renamed from tmp48cd2
2023-09-05T13:40:01,963918+00:00 eth0: renamed from tmp2c832
2023-09-05T13:40:02,170860+00:00 eth0: renamed from tmpd1d4c
2023-09-05T13:40:02,313907+00:00 eth0: renamed from tmp95267
2023-09-05T13:40:02,978931+00:00 eth0: renamed from tmp0ca98
2023-09-05T13:40:17,951830+00:00 eth0: renamed from tmp0da82
2023-09-05T13:40:17,981773+00:00 eth0: renamed from tmpdbbdb
2023-09-05T13:40:18,500748+00:00 eth0: renamed from tmp21393
2023-09-05T13:43:39,063433+00:00 br-e429376abcdb: port 2(veth015a38b) entered disabled state
2023-09-05T13:43:39,063511+00:00 vethcf154aa: renamed from eth0
2023-09-05T13:43:39,099486+00:00 br-e429376abcdb: port 2(veth015a38b) entered disabled state
2023-09-05T13:43:39,100122+00:00 veth015a38b (unregistering): left allmulticast mode
2023-09-05T13:43:39,100125+00:00 veth015a38b (unregistering): left promiscuous mode
2023-09-05T13:43:39,100128+00:00 br-e429376abcdb: port 2(veth015a38b) entered disabled state
2023-09-05T13:43:39,351184+00:00 br-e429376abcdb: port 1(veth47a3b1e) entered disabled state
2023-09-05T13:43:39,351246+00:00 veth3a6d262: renamed from eth0
2023-09-05T13:43:39,396178+00:00 br-e429376abcdb: port 1(veth47a3b1e) entered disabled state
2023-09-05T13:43:39,397126+00:00 veth47a3b1e (unregistering): left allmulticast mode
2023-09-05T13:43:39,397128+00:00 veth47a3b1e (unregistering): left promiscuous mode
2023-09-05T13:43:39,397130+00:00 br-e429376abcdb: port 1(veth47a3b1e) entered disabled state
2023-09-05T13:45:45,742866+00:00 br-e429376abcdb: port 1(vethf4694c2) entered blocking state
2023-09-05T13:45:45,742871+00:00 br-e429376abcdb: port 1(vethf4694c2) entered disabled state
2023-09-05T13:45:45,742883+00:00 vethf4694c2: entered allmulticast mode
2023-09-05T13:45:45,742954+00:00 vethf4694c2: entered promiscuous mode
2023-09-05T13:45:45,906606+00:00 eth0: renamed from vethadfb38d
2023-09-05T13:45:45,921624+00:00 br-e429376abcdb: port 1(vethf4694c2) entered blocking state
2023-09-05T13:45:45,921628+00:00 br-e429376abcdb: port 1(vethf4694c2) entered forwarding state
2023-09-05T13:45:46,887670+00:00 br-e429376abcdb: port 1(vethf4694c2) entered disabled state
2023-09-05T13:45:46,887738+00:00 vethadfb38d: renamed from eth0
2023-09-05T13:45:46,918495+00:00 br-e429376abcdb: port 1(vethf4694c2) entered disabled state
2023-09-05T13:45:46,918985+00:00 vethf4694c2 (unregistering): left allmulticast mode
2023-09-05T13:45:46,918989+00:00 vethf4694c2 (unregistering): left promiscuous mode
2023-09-05T13:45:46,918992+00:00 br-e429376abcdb: port 1(vethf4694c2) entered disabled state
2023-09-05T13:45:47,063567+00:00 br-e429376abcdb: port 1(vethcff43a6) entered blocking state
2023-09-05T13:45:47,063572+00:00 br-e429376abcdb: port 1(vethcff43a6) entered disabled state
2023-09-05T13:45:47,063584+00:00 vethcff43a6: entered allmulticast mode
2023-09-05T13:45:47,063627+00:00 vethcff43a6: entered promiscuous mode
2023-09-05T13:45:47,063740+00:00 br-e429376abcdb: port 1(vethcff43a6) entered blocking state
2023-09-05T13:45:47,063743+00:00 br-e429376abcdb: port 1(vethcff43a6) entered forwarding state
2023-09-05T13:45:47,225523+00:00 eth0: renamed from vethb2f414d
2023-09-05T13:45:50,500859+00:00 br-e429376abcdb: port 2(vethe91c21d) entered blocking state
2023-09-05T13:45:50,500865+00:00 br-e429376abcdb: port 2(vethe91c21d) entered disabled state
2023-09-05T13:45:50,500882+00:00 vethe91c21d: entered allmulticast mode
2023-09-05T13:45:50,500936+00:00 vethe91c21d: entered promiscuous mode
2023-09-05T13:45:50,684599+00:00 eth0: renamed from vethc2811b6
2023-09-05T13:45:50,691614+00:00 br-e429376abcdb: port 2(vethe91c21d) entered blocking state
2023-09-05T13:45:50,691620+00:00 br-e429376abcdb: port 2(vethe91c21d) entered forwarding state
2023-09-05T13:46:27,538215+00:00 eth0: Caught tx_queue_len zero misconfig
2023-09-05T13:46:32,328356+00:00 eth0: renamed from tmp09250
2023-09-05T13:46:32,395157+00:00 eth0: renamed from tmpd5a94
2023-09-05T13:46:32,408055+00:00 eth0: renamed from tmpc4863
2023-09-05T13:46:32,416058+00:00 eth0: renamed from tmpf05c9
2023-09-05T13:46:32,425038+00:00 eth0: renamed from tmp8a5a5
2023-09-05T13:46:32,710249+00:00 eth0: renamed from tmpc977e
2023-09-05T13:46:32,766450+00:00 eth0: renamed from tmp2bee8
2023-09-05T13:46:32,800482+00:00 eth0: renamed from tmp2b204
2023-09-05T13:46:32,867160+00:00 eth0: renamed from tmp7cf2c
2023-09-05T13:46:32,877018+00:00 eth0: renamed from tmpe0647
2023-09-05T13:46:32,884033+00:00 eth0: renamed from tmpddd90
2023-09-05T13:46:32,894038+00:00 eth0: renamed from tmp22099
2023-09-05T13:46:32,919242+00:00 eth0: renamed from tmp37fc5
2023-09-05T13:47:50,286797+00:00 eth0: renamed from tmpfaa56
2023-09-05T13:47:50,313624+00:00 eth0: renamed from tmp805a4
2023-09-05T13:47:50,360856+00:00 eth0: renamed from tmp43b8f
2023-09-05T13:47:50,383937+00:00 eth0: renamed from tmp0976c
2023-09-05T13:47:50,408055+00:00 eth0: renamed from tmp0979f
2023-09-05T13:47:50,436881+00:00 eth0: renamed from tmp906de
2023-09-05T13:47:50,467979+00:00 eth0: renamed from tmpf01e7
2023-09-05T13:47:50,501288+00:00 eth0: renamed from tmp67443
2023-09-05T13:47:50,527050+00:00 eth0: renamed from tmpf6403
2023-09-05T13:47:50,554581+00:00 eth0: renamed from tmp1de2e
2023-09-05T13:47:50,585703+00:00 eth0: renamed from tmp529b2
2023-09-05T13:47:50,662807+00:00 eth0: renamed from tmp3a280
2023-09-05T13:47:50,688588+00:00 eth0: renamed from tmpc1f85
2023-09-05T13:47:50,711808+00:00 eth0: renamed from tmpa8814
2023-09-05T13:47:50,781556+00:00 eth0: renamed from tmp28176
2023-09-05T13:47:50,869676+00:00 eth0: renamed from tmpfce1a
2023-09-05T13:47:51,102543+00:00 eth0: renamed from tmpd66e3
2023-09-05T13:47:52,073555+00:00 eth0: renamed from tmpbf043
2023-09-05T13:48:08,139511+00:00 eth0: renamed from tmpc0bac
2023-09-05T13:48:08,450396+00:00 eth0: renamed from tmp55b58
2023-09-05T13:48:09,542374+00:00 eth0: renamed from tmp38ef7
2023-09-05T13:49:09,840639+00:00 vethc2811b6: renamed from eth0
2023-09-05T13:49:09,854738+00:00 br-e429376abcdb: port 2(vethe91c21d) entered disabled state
2023-09-05T13:49:09,886308+00:00 br-e429376abcdb: port 2(vethe91c21d) entered disabled state
2023-09-05T13:49:09,886762+00:00 vethe91c21d (unregistering): left allmulticast mode
2023-09-05T13:49:09,886764+00:00 vethe91c21d (unregistering): left promiscuous mode
2023-09-05T13:49:09,886767+00:00 br-e429376abcdb: port 2(vethe91c21d) entered disabled state
2023-09-05T13:49:10,172809+00:00 br-e429376abcdb: port 1(vethcff43a6) entered disabled state
2023-09-05T13:49:10,172873+00:00 vethb2f414d: renamed from eth0
2023-09-05T13:49:10,233335+00:00 br-e429376abcdb: port 1(vethcff43a6) entered disabled state
2023-09-05T13:49:10,234596+00:00 vethcff43a6 (unregistering): left allmulticast mode
2023-09-05T13:49:10,234599+00:00 vethcff43a6 (unregistering): left promiscuous mode
2023-09-05T13:49:10,234602+00:00 br-e429376abcdb: port 1(vethcff43a6) entered disabled state
2023-09-05T13:51:34,824488+00:00 docker0: port 1(veth9b2c052) entered blocking state
2023-09-05T13:51:34,824492+00:00 docker0: port 1(veth9b2c052) entered disabled state
2023-09-05T13:51:34,824501+00:00 veth9b2c052: entered allmulticast mode
2023-09-05T13:51:34,824568+00:00 veth9b2c052: entered promiscuous mode
2023-09-05T13:51:35,003695+00:00 eth0: renamed from vethda53314
2023-09-05T13:51:35,012732+00:00 docker0: port 1(veth9b2c052) entered blocking state
2023-09-05T13:51:35,012737+00:00 docker0: port 1(veth9b2c052) entered forwarding state
2023-09-05T13:53:28,412863+00:00 docker0: port 1(veth9b2c052) entered disabled state
2023-09-05T13:53:28,412920+00:00 vethda53314: renamed from eth0
2023-09-05T13:53:28,445405+00:00 docker0: port 1(veth9b2c052) entered disabled state
2023-09-05T13:53:28,445799+00:00 veth9b2c052 (unregistering): left allmulticast mode
2023-09-05T13:53:28,445802+00:00 veth9b2c052 (unregistering): left promiscuous mode
2023-09-05T13:53:28,445804+00:00 docker0: port 1(veth9b2c052) entered disabled state
2023-09-05T13:53:28,717717+00:00 docker0: port 1(vethc4d92bf) entered blocking state
2023-09-05T13:53:28,717722+00:00 docker0: port 1(vethc4d92bf) entered disabled state
2023-09-05T13:53:28,717734+00:00 vethc4d92bf: entered allmulticast mode
2023-09-05T13:53:28,717799+00:00 vethc4d92bf: entered promiscuous mode
2023-09-05T13:53:28,717899+00:00 docker0: port 1(vethc4d92bf) entered blocking state
2023-09-05T13:53:28,717902+00:00 docker0: port 1(vethc4d92bf) entered forwarding state
2023-09-05T13:53:28,900833+00:00 eth0: renamed from vethb307507
2023-09-05T13:55:08,734406+00:00 docker0: port 1(vethc4d92bf) entered disabled state
2023-09-05T13:55:08,734468+00:00 vethb307507: renamed from eth0
2023-09-05T13:55:08,768125+00:00 docker0: port 1(vethc4d92bf) entered disabled state
2023-09-05T13:55:08,768467+00:00 vethc4d92bf (unregistering): left allmulticast mode
2023-09-05T13:55:08,768469+00:00 vethc4d92bf (unregistering): left promiscuous mode
2023-09-05T13:55:08,768471+00:00 docker0: port 1(vethc4d92bf) entered disabled state
2023-09-05T13:55:09,046394+00:00 docker0: port 1(veth0c84845) entered blocking state
2023-09-05T13:55:09,046397+00:00 docker0: port 1(veth0c84845) entered disabled state
2023-09-05T13:55:09,046407+00:00 veth0c84845: entered allmulticast mode
2023-09-05T13:55:09,046448+00:00 veth0c84845: entered promiscuous mode
2023-09-05T13:55:09,046544+00:00 docker0: port 1(veth0c84845) entered blocking state
2023-09-05T13:55:09,046548+00:00 docker0: port 1(veth0c84845) entered forwarding state
2023-09-05T13:55:09,227109+00:00 eth0: renamed from vethc3da8e0
2023-09-05T13:57:44,648127+00:00 docker0: port 1(veth0c84845) entered disabled state
2023-09-05T13:57:44,648185+00:00 vethc3da8e0: renamed from eth0
2023-09-05T13:57:44,686046+00:00 docker0: port 1(veth0c84845) entered disabled state
2023-09-05T13:57:44,686541+00:00 veth0c84845 (unregistering): left allmulticast mode
2023-09-05T13:57:44,686544+00:00 veth0c84845 (unregistering): left promiscuous mode
2023-09-05T13:57:44,686546+00:00 docker0: port 1(veth0c84845) entered disabled state
2023-09-05T13:57:44,958507+00:00 docker0: port 1(veth628e7f8) entered blocking state
2023-09-05T13:57:44,958512+00:00 docker0: port 1(veth628e7f8) entered disabled state
2023-09-05T13:57:44,958524+00:00 veth628e7f8: entered allmulticast mode
2023-09-05T13:57:44,958574+00:00 veth628e7f8: entered promiscuous mode
2023-09-05T13:57:44,958700+00:00 docker0: port 1(veth628e7f8) entered blocking state
2023-09-05T13:57:44,958704+00:00 docker0: port 1(veth628e7f8) entered forwarding state
2023-09-05T13:57:45,147004+00:00 eth0: renamed from veth1dc749f
2023-09-05T13:58:54,089344+00:00 veth1dc749f: renamed from eth0
2023-09-05T13:58:54,098467+00:00 docker0: port 1(veth628e7f8) entered disabled state
2023-09-05T13:58:54,123375+00:00 docker0: port 1(veth628e7f8) entered disabled state
2023-09-05T13:58:54,123678+00:00 veth628e7f8 (unregistering): left allmulticast mode
2023-09-05T13:58:54,123680+00:00 veth628e7f8 (unregistering): left promiscuous mode
2023-09-05T13:58:54,123683+00:00 docker0: port 1(veth628e7f8) entered disabled state
2023-09-05T13:58:54,394740+00:00 docker0: port 1(veth59ec3ae) entered blocking state
2023-09-05T13:58:54,394745+00:00 docker0: port 1(veth59ec3ae) entered disabled state
2023-09-05T13:58:54,394758+00:00 veth59ec3ae: entered allmulticast mode
2023-09-05T13:58:54,394811+00:00 veth59ec3ae: entered promiscuous mode
2023-09-05T13:58:54,394907+00:00 docker0: port 1(veth59ec3ae) entered blocking state
2023-09-05T13:58:54,394910+00:00 docker0: port 1(veth59ec3ae) entered forwarding state
2023-09-05T13:58:54,586615+00:00 eth0: renamed from vethd2c9b25
2023-09-05T14:00:02,642906+00:00 docker0: port 1(veth59ec3ae) entered disabled state
2023-09-05T14:00:02,642962+00:00 vethd2c9b25: renamed from eth0
2023-09-05T14:00:02,675936+00:00 docker0: port 1(veth59ec3ae) entered disabled state
2023-09-05T14:00:02,676297+00:00 veth59ec3ae (unregistering): left allmulticast mode
2023-09-05T14:00:02,676300+00:00 veth59ec3ae (unregistering): left promiscuous mode
2023-09-05T14:00:02,676303+00:00 docker0: port 1(veth59ec3ae) entered disabled state
2023-09-05T14:01:19,099363+00:00 docker0: port 1(veth3517a53) entered blocking state
2023-09-05T14:01:19,099368+00:00 docker0: port 1(veth3517a53) entered disabled state
2023-09-05T14:01:19,099380+00:00 veth3517a53: entered allmulticast mode
2023-09-05T14:01:19,099435+00:00 veth3517a53: entered promiscuous mode
2023-09-05T14:01:19,099534+00:00 docker0: port 1(veth3517a53) entered blocking state
2023-09-05T14:01:19,099537+00:00 docker0: port 1(veth3517a53) entered forwarding state
2023-09-05T14:01:19,099757+00:00 docker0: port 1(veth3517a53) entered disabled state
2023-09-05T14:01:19,282536+00:00 eth0: renamed from vethf704c9d
2023-09-05T14:01:19,290675+00:00 docker0: port 1(veth3517a53) entered blocking state
2023-09-05T14:01:19,290679+00:00 docker0: port 1(veth3517a53) entered forwarding state
2023-09-05T14:03:11,268752+00:00 docker0: port 1(veth3517a53) entered disabled state
2023-09-05T14:03:11,268824+00:00 vethf704c9d: renamed from eth0
2023-09-05T14:03:11,296270+00:00 docker0: port 1(veth3517a53) entered disabled state
2023-09-05T14:03:11,296742+00:00 veth3517a53 (unregistering): left allmulticast mode
2023-09-05T14:03:11,296745+00:00 veth3517a53 (unregistering): left promiscuous mode
2023-09-05T14:03:11,296747+00:00 docker0: port 1(veth3517a53) entered disabled state
2023-09-05T14:03:11,578580+00:00 docker0: port 1(veth11863f8) entered blocking state
2023-09-05T14:03:11,578586+00:00 docker0: port 1(veth11863f8) entered disabled state
2023-09-05T14:03:11,578597+00:00 veth11863f8: entered allmulticast mode
2023-09-05T14:03:11,578649+00:00 veth11863f8: entered promiscuous mode
2023-09-05T14:03:11,578758+00:00 docker0: port 1(veth11863f8) entered blocking state
2023-09-05T14:03:11,578762+00:00 docker0: port 1(veth11863f8) entered forwarding state
2023-09-05T14:03:11,754806+00:00 eth0: renamed from vethb667da5
2023-09-05T14:04:03,423592+00:00 eth0: renamed from tmpfc34e
2023-09-05T14:04:03,467379+00:00 eth0: renamed from tmpd41fc
2023-09-05T14:04:03,478462+00:00 eth0: renamed from tmpaf091
2023-09-05T14:04:03,802562+00:00 eth0: renamed from tmp95cba
2023-09-05T14:04:03,860562+00:00 eth0: renamed from tmp83f1a
2023-09-05T14:04:03,919414+00:00 eth0: renamed from tmp5fb28
2023-09-05T14:04:03,941336+00:00 eth0: renamed from tmp2d0ff
2023-09-05T14:04:03,952463+00:00 eth0: renamed from tmp8dc20
2023-09-05T14:04:04,006586+00:00 eth0: renamed from tmp19ab7
2023-09-05T14:04:04,012498+00:00 eth0: renamed from tmp1fa62
2023-09-05T14:04:04,021385+00:00 eth0: renamed from tmp387f9
2023-09-05T14:04:04,030384+00:00 eth0: renamed from tmpd82c4
2023-09-05T14:04:05,075970+00:00 eth0: Caught tx_queue_len zero misconfig
2023-09-05T14:05:42,359955+00:00 eth0: renamed from tmp16a15
2023-09-05T14:05:42,386880+00:00 eth0: renamed from tmpc00f2
2023-09-05T14:05:42,445945+00:00 eth0: renamed from tmp076fb
2023-09-05T14:05:42,490280+00:00 eth0: renamed from tmp338d3
2023-09-05T14:05:42,516629+00:00 eth0: renamed from tmp94d14
2023-09-05T14:05:42,556077+00:00 eth0: renamed from tmp7ded3
2023-09-05T14:05:42,563717+00:00 eth0: renamed from tmp574e1
2023-09-05T14:05:42,596107+00:00 eth0: renamed from tmp424c0
2023-09-05T14:05:42,624054+00:00 eth0: renamed from tmp89b95
2023-09-05T14:05:42,670843+00:00 eth0: renamed from tmpb755c
2023-09-05T14:05:42,685472+00:00 eth0: renamed from tmp474fa
2023-09-05T14:05:42,726055+00:00 eth0: renamed from tmp6c352
2023-09-05T14:05:42,736981+00:00 eth0: renamed from tmp72284
2023-09-05T14:05:42,759923+00:00 eth0: renamed from tmpbac11
2023-09-05T14:05:42,810130+00:00 eth0: renamed from tmp991c6
2023-09-05T14:05:42,847152+00:00 eth0: renamed from tmp8223c
2023-09-05T14:05:42,919985+00:00 eth0: renamed from tmp934b8
2023-09-05T14:05:43,758905+00:00 eth0: renamed from tmp4c7b2
2023-09-05T14:05:57,084782+00:00 eth0: renamed from tmp6f1b4
2023-09-05T14:05:57,425780+00:00 eth0: renamed from tmpb5529
2023-09-05T14:05:59,070777+00:00 eth0: renamed from tmpa804e
2023-09-05T14:06:35,991797+00:00 eth0: renamed from tmpd1b3f
2023-09-05T14:06:36,029511+00:00 eth0: renamed from tmpd4946
2023-09-05T14:06:36,050553+00:00 eth0: renamed from tmp0ead2
2023-09-05T14:06:36,364523+00:00 eth0: renamed from tmpc07e9
2023-09-05T14:06:36,549490+00:00 eth0: renamed from tmpef0b1
2023-09-05T14:21:08,426548+00:00 docker0: port 1(veth11863f8) entered disabled state
2023-09-05T14:21:08,426611+00:00 vethb667da5: renamed from eth0
2023-09-05T14:21:08,454744+00:00 docker0: port 1(veth11863f8) entered disabled state
2023-09-05T14:21:08,455044+00:00 veth11863f8 (unregistering): left allmulticast mode
2023-09-05T14:21:08,455046+00:00 veth11863f8 (unregistering): left promiscuous mode
2023-09-05T14:21:08,455048+00:00 docker0: port 1(veth11863f8) entered disabled state
2023-09-05T14:21:13,950111+00:00 docker0: port 1(veth363c4ed) entered blocking state
2023-09-05T14:21:13,950116+00:00 docker0: port 1(veth363c4ed) entered disabled state
2023-09-05T14:21:13,950126+00:00 veth363c4ed: entered allmulticast mode
2023-09-05T14:21:13,950221+00:00 veth363c4ed: entered promiscuous mode
2023-09-05T14:21:14,141360+00:00 eth0: renamed from vethc0fd3ca
2023-09-05T14:21:14,154369+00:00 docker0: port 1(veth363c4ed) entered blocking state
2023-09-05T14:21:14,154373+00:00 docker0: port 1(veth363c4ed) entered forwarding state
2023-09-05T14:23:19,358150+00:00 docker0: port 1(veth363c4ed) entered disabled state
2023-09-05T14:23:19,358219+00:00 vethc0fd3ca: renamed from eth0
2023-09-05T14:23:19,391720+00:00 docker0: port 1(veth363c4ed) entered disabled state
2023-09-05T14:23:19,392104+00:00 veth363c4ed (unregistering): left allmulticast mode
2023-09-05T14:23:19,392107+00:00 veth363c4ed (unregistering): left promiscuous mode
2023-09-05T14:23:19,392109+00:00 docker0: port 1(veth363c4ed) entered disabled state
2023-09-05T14:23:21,841940+00:00 docker0: port 1(vetheb6dee0) entered blocking state
2023-09-05T14:23:21,841945+00:00 docker0: port 1(vetheb6dee0) entered disabled state
2023-09-05T14:23:21,841954+00:00 vetheb6dee0: entered allmulticast mode
2023-09-05T14:23:21,842163+00:00 vetheb6dee0: entered promiscuous mode
2023-09-05T14:23:22,034228+00:00 eth0: renamed from veth804fa82
2023-09-05T14:23:22,046260+00:00 docker0: port 1(vetheb6dee0) entered blocking state
2023-09-05T14:23:22,046265+00:00 docker0: port 1(vetheb6dee0) entered forwarding state
2023-09-05T14:24:36,310137+00:00 docker0: port 1(vetheb6dee0) entered disabled state
2023-09-05T14:24:36,310212+00:00 veth804fa82: renamed from eth0
2023-09-05T14:24:36,342967+00:00 docker0: port 1(vetheb6dee0) entered disabled state
2023-09-05T14:24:36,343349+00:00 vetheb6dee0 (unregistering): left allmulticast mode
2023-09-05T14:24:36,343352+00:00 vetheb6dee0 (unregistering): left promiscuous mode
2023-09-05T14:24:36,343354+00:00 docker0: port 1(vetheb6dee0) entered disabled state
2023-09-05T14:24:39,574783+00:00 docker0: port 1(veth349a5a4) entered blocking state
2023-09-05T14:24:39,574787+00:00 docker0: port 1(veth349a5a4) entered disabled state
2023-09-05T14:24:39,574796+00:00 veth349a5a4: entered allmulticast mode
2023-09-05T14:24:39,574839+00:00 veth349a5a4: entered promiscuous mode
2023-09-05T14:24:39,574931+00:00 docker0: port 1(veth349a5a4) entered blocking state
2023-09-05T14:24:39,574935+00:00 docker0: port 1(veth349a5a4) entered forwarding state
2023-09-05T14:24:39,575176+00:00 docker0: port 1(veth349a5a4) entered disabled state
2023-09-05T14:24:39,760522+00:00 eth0: renamed from veth86bd722
2023-09-05T14:24:39,776597+00:00 docker0: port 1(veth349a5a4) entered blocking state
2023-09-05T14:24:39,776601+00:00 docker0: port 1(veth349a5a4) entered forwarding state
2023-09-05T14:25:31,908018+00:00 eth0: renamed from tmp03d22
2023-09-05T14:25:31,975264+00:00 eth0: renamed from tmpc32eb
2023-09-05T14:25:32,005190+00:00 eth0: renamed from tmp2358b
2023-09-05T14:25:32,018965+00:00 eth0: renamed from tmp346ad
2023-09-05T14:25:32,058024+00:00 eth0: renamed from tmpf7270
2023-09-05T14:25:32,076089+00:00 eth0: renamed from tmp95d96
2023-09-05T14:25:32,118054+00:00 eth0: renamed from tmp9ad43
2023-09-05T14:25:32,129093+00:00 eth0: renamed from tmp8f655
2023-09-05T14:25:32,138111+00:00 eth0: renamed from tmp74677
2023-09-05T14:25:32,167306+00:00 eth0: renamed from tmp14b44
2023-09-05T14:25:32,187064+00:00 eth0: renamed from tmp18d75
2023-09-05T14:25:32,198405+00:00 eth0: renamed from tmp5172e
2023-09-05T14:25:33,392769+00:00 eth0: Caught tx_queue_len zero misconfig
2023-09-05T14:26:58,736067+00:00 veth86bd722: renamed from eth0
2023-09-05T14:26:58,744309+00:00 docker0: port 1(veth349a5a4) entered disabled state
2023-09-05T14:26:58,771686+00:00 docker0: port 1(veth349a5a4) entered disabled state
2023-09-05T14:26:58,772318+00:00 veth349a5a4 (unregistering): left allmulticast mode
2023-09-05T14:26:58,772322+00:00 veth349a5a4 (unregistering): left promiscuous mode
2023-09-05T14:26:58,772326+00:00 docker0: port 1(veth349a5a4) entered disabled state
2023-09-05T14:26:59,076762+00:00 docker0: port 1(veth3940ee9) entered blocking state
2023-09-05T14:26:59,076767+00:00 docker0: port 1(veth3940ee9) entered disabled state
2023-09-05T14:26:59,076780+00:00 veth3940ee9: entered allmulticast mode
2023-09-05T14:26:59,076821+00:00 veth3940ee9: entered promiscuous mode
2023-09-05T14:26:59,076924+00:00 docker0: port 1(veth3940ee9) entered blocking state
2023-09-05T14:26:59,076927+00:00 docker0: port 1(veth3940ee9) entered forwarding state
2023-09-05T14:26:59,262388+00:00 eth0: renamed from vethea150a7
2023-09-05T14:27:46,953954+00:00 eth0: renamed from tmp80b32
2023-09-05T14:27:46,965875+00:00 eth0: renamed from tmp064e7
2023-09-05T14:27:46,984999+00:00 eth0: renamed from tmp8584a
2023-09-05T14:27:46,995865+00:00 eth0: renamed from tmp2281c
2023-09-05T14:27:48,352075+00:00 eth0: Caught tx_queue_len zero misconfig
2023-09-05T14:28:13,980484+00:00 docker0: port 1(veth3940ee9) entered disabled state
2023-09-05T14:28:13,980539+00:00 vethea150a7: renamed from eth0
2023-09-05T14:28:14,016311+00:00 docker0: port 1(veth3940ee9) entered disabled state
2023-09-05T14:28:14,016635+00:00 veth3940ee9 (unregistering): left allmulticast mode
2023-09-05T14:28:14,016637+00:00 veth3940ee9 (unregistering): left promiscuous mode
2023-09-05T14:28:14,016639+00:00 docker0: port 1(veth3940ee9) entered disabled state
2023-09-05T14:28:14,307862+00:00 docker0: port 1(veth56abf56) entered blocking state
2023-09-05T14:28:14,307867+00:00 docker0: port 1(veth56abf56) entered disabled state
2023-09-05T14:28:14,307880+00:00 veth56abf56: entered allmulticast mode
2023-09-05T14:28:14,307931+00:00 veth56abf56: entered promiscuous mode
2023-09-05T14:28:14,308040+00:00 docker0: port 1(veth56abf56) entered blocking state
2023-09-05T14:28:14,308043+00:00 docker0: port 1(veth56abf56) entered forwarding state
2023-09-05T14:28:14,498771+00:00 eth0: renamed from veth01124f6
2023-09-05T14:28:46,446389+00:00 docker0: port 1(veth56abf56) entered disabled state
2023-09-05T14:28:46,446455+00:00 veth01124f6: renamed from eth0
2023-09-05T14:28:46,476517+00:00 docker0: port 1(veth56abf56) entered disabled state
2023-09-05T14:28:46,476981+00:00 veth56abf56 (unregistering): left allmulticast mode
2023-09-05T14:28:46,476984+00:00 veth56abf56 (unregistering): left promiscuous mode
2023-09-05T14:28:46,476986+00:00 docker0: port 1(veth56abf56) entered disabled state
2023-09-05T14:28:46,739863+00:00 docker0: port 1(veth6e5f153) entered blocking state
2023-09-05T14:28:46,739867+00:00 docker0: port 1(veth6e5f153) entered disabled state
2023-09-05T14:28:46,739876+00:00 veth6e5f153: entered allmulticast mode
2023-09-05T14:28:46,739930+00:00 veth6e5f153: entered promiscuous mode
2023-09-05T14:28:46,740026+00:00 docker0: port 1(veth6e5f153) entered blocking state
2023-09-05T14:28:46,740030+00:00 docker0: port 1(veth6e5f153) entered forwarding state
2023-09-05T14:28:46,940528+00:00 eth0: renamed from veth7738420
2023-09-05T14:29:17,615442+00:00 docker0: port 1(veth6e5f153) entered disabled state
2023-09-05T14:29:17,615507+00:00 veth7738420: renamed from eth0
2023-09-05T14:29:17,649674+00:00 docker0: port 1(veth6e5f153) entered disabled state
2023-09-05T14:29:17,650143+00:00 veth6e5f153 (unregistering): left allmulticast mode
2023-09-05T14:29:17,650146+00:00 veth6e5f153 (unregistering): left promiscuous mode
2023-09-05T14:29:17,650149+00:00 docker0: port 1(veth6e5f153) entered disabled state
2023-09-05T14:29:17,912697+00:00 docker0: port 1(vethdbbd7ea) entered blocking state
2023-09-05T14:29:17,912702+00:00 docker0: port 1(vethdbbd7ea) entered disabled state
2023-09-05T14:29:17,912711+00:00 vethdbbd7ea: entered allmulticast mode
2023-09-05T14:29:17,912758+00:00 vethdbbd7ea: entered promiscuous mode
2023-09-05T14:29:17,912858+00:00 docker0: port 1(vethdbbd7ea) entered blocking state
2023-09-05T14:29:17,912861+00:00 docker0: port 1(vethdbbd7ea) entered forwarding state
2023-09-05T14:29:18,106265+00:00 eth0: renamed from vethab9f227
2023-09-05T14:30:08,628002+00:00 eth0: Caught tx_queue_len zero misconfig
2023-09-05T14:30:18,287701+00:00 eth0: renamed from tmp33e89
2023-09-05T14:30:18,309709+00:00 eth0: renamed from tmp627e2
2023-09-05T14:30:18,316669+00:00 eth0: renamed from tmp0dde4
2023-09-05T14:30:18,324774+00:00 eth0: renamed from tmpd9738
2023-09-05T14:31:28,662998+00:00 docker0: port 1(vethdbbd7ea) entered disabled state
2023-09-05T14:31:28,663122+00:00 vethab9f227: renamed from eth0
2023-09-05T14:31:28,699492+00:00 docker0: port 1(vethdbbd7ea) entered disabled state
2023-09-05T14:31:28,699898+00:00 vethdbbd7ea (unregistering): left allmulticast mode
2023-09-05T14:31:28,699901+00:00 vethdbbd7ea (unregistering): left promiscuous mode
2023-09-05T14:31:28,699903+00:00 docker0: port 1(vethdbbd7ea) entered disabled state
2023-09-05T14:33:04,949246+00:00 docker0: port 1(vethd55737b) entered blocking state
2023-09-05T14:33:04,949251+00:00 docker0: port 1(vethd55737b) entered disabled state
2023-09-05T14:33:04,949259+00:00 vethd55737b: entered allmulticast mode
2023-09-05T14:33:04,949339+00:00 vethd55737b: entered promiscuous mode
2023-09-05T14:33:05,157536+00:00 eth0: renamed from veth4299af0
2023-09-05T14:33:05,165620+00:00 docker0: port 1(vethd55737b) entered blocking state
2023-09-05T14:33:05,165624+00:00 docker0: port 1(vethd55737b) entered forwarding state
2023-09-05T14:33:55,968400+00:00 eth0: Caught tx_queue_len zero misconfig
2023-09-05T14:34:02,011033+00:00 eth0: renamed from tmpceff3
2023-09-05T14:34:02,020007+00:00 eth0: renamed from tmpb65b2
2023-09-05T14:34:02,030980+00:00 eth0: renamed from tmpc4347
2023-09-05T14:34:02,047016+00:00 eth0: renamed from tmp0aa7d
2023-09-05T14:34:02,070054+00:00 eth0: renamed from tmpb6d9a
2023-09-05T14:34:02,079982+00:00 eth0: renamed from tmpfe23c
2023-09-05T14:34:02,104015+00:00 eth0: renamed from tmpae0d2
2023-09-05T14:34:02,132078+00:00 eth0: renamed from tmpd4f1f
2023-09-05T14:34:02,139338+00:00 eth0: renamed from tmpa5a49
2023-09-05T14:34:02,157227+00:00 eth0: renamed from tmpedede
2023-09-05T14:34:02,164038+00:00 eth0: renamed from tmpa5567
2023-09-05T14:34:02,172234+00:00 eth0: renamed from tmp72923
2023-09-05T14:35:09,322767+00:00 eth0: renamed from tmp0517e
2023-09-05T14:35:09,348696+00:00 eth0: renamed from tmp26fe3
2023-09-05T14:35:09,403716+00:00 eth0: renamed from tmp0985f
2023-09-05T14:35:09,522758+00:00 eth0: renamed from tmp1965f
2023-09-05T14:35:09,563771+00:00 eth0: renamed from tmpe1974
2023-09-05T14:35:09,717892+00:00 eth0: renamed from tmp36232
2023-09-05T14:35:09,797941+00:00 eth0: renamed from tmp4d2a0
2023-09-05T14:35:09,828934+00:00 eth0: renamed from tmpf8c7d
2023-09-05T14:35:09,858809+00:00 eth0: renamed from tmp801a4
2023-09-05T14:35:09,912814+00:00 eth0: renamed from tmpff852
2023-09-05T14:35:09,980044+00:00 eth0: renamed from tmp4febf
2023-09-05T14:35:10,008907+00:00 eth0: renamed from tmp36a8a
2023-09-05T14:35:10,063798+00:00 eth0: renamed from tmp60afc
2023-09-05T14:35:10,074749+00:00 eth0: renamed from tmp40f8c
2023-09-05T14:35:10,115990+00:00 eth0: renamed from tmp31518
2023-09-05T14:35:10,161223+00:00 eth0: renamed from tmp0cdce
2023-09-05T14:35:10,169561+00:00 eth0: renamed from tmpfd45f
2023-09-05T14:35:10,870664+00:00 eth0: renamed from tmp0d5b7
2023-09-05T14:35:18,806063+00:00 eth0: renamed from tmp19abb
2023-09-05T14:35:18,831588+00:00 eth0: renamed from tmp03281
2023-09-05T14:35:24,182583+00:00 eth0: renamed from tmp9e5f5
2023-09-05T14:35:31,246523+00:00 eth0: renamed from tmp50293
2023-09-05T14:35:40,706443+00:00 eth0: renamed from tmp5fc98
2023-09-05T14:35:41,640500+00:00 eth0: renamed from tmp50f11
2023-09-05T14:35:50,442348+00:00 eth0: renamed from tmp1e7ec
2023-09-05T14:38:00,523568+00:00 docker0: port 1(vethd55737b) entered disabled state
2023-09-05T14:38:00,523634+00:00 veth4299af0: renamed from eth0
2023-09-05T14:38:00,555109+00:00 docker0: port 1(vethd55737b) entered disabled state
2023-09-05T14:38:00,555524+00:00 vethd55737b (unregistering): left allmulticast mode
2023-09-05T14:38:00,555527+00:00 vethd55737b (unregistering): left promiscuous mode
2023-09-05T14:38:00,555529+00:00 docker0: port 1(vethd55737b) entered disabled state
2023-09-05T14:38:03,524375+00:00 docker0: port 1(veth7cf2bff) entered blocking state
2023-09-05T14:38:03,524380+00:00 docker0: port 1(veth7cf2bff) entered disabled state
2023-09-05T14:38:03,524389+00:00 veth7cf2bff: entered allmulticast mode
2023-09-05T14:38:03,524462+00:00 veth7cf2bff: entered promiscuous mode
2023-09-05T14:38:03,736390+00:00 eth0: renamed from vethd522892
2023-09-05T14:38:03,746419+00:00 docker0: port 1(veth7cf2bff) entered blocking state
2023-09-05T14:38:03,746423+00:00 docker0: port 1(veth7cf2bff) entered forwarding state
2023-09-05T14:38:55,505978+00:00 eth0: renamed from tmp00af5
2023-09-05T14:38:55,523867+00:00 eth0: renamed from tmp2fe35
2023-09-05T14:38:55,536853+00:00 eth0: renamed from tmp3dde0
2023-09-05T14:38:55,564885+00:00 eth0: renamed from tmp6ca95
2023-09-05T14:38:55,585897+00:00 eth0: renamed from tmpec535
2023-09-05T14:38:55,600894+00:00 eth0: renamed from tmp942ad
2023-09-05T14:38:55,632895+00:00 eth0: renamed from tmpc91c8
2023-09-05T14:38:55,644971+00:00 eth0: renamed from tmpdf975
2023-09-05T14:38:55,655289+00:00 eth0: renamed from tmp61294
2023-09-05T14:38:55,670901+00:00 eth0: renamed from tmp466d1
2023-09-05T14:38:55,681823+00:00 eth0: renamed from tmp54f4b
2023-09-05T14:38:55,700335+00:00 eth0: renamed from tmpe0d48
2023-09-05T14:38:56,832870+00:00 eth0: Caught tx_queue_len zero misconfig
2023-09-05T14:39:27,451887+00:00 eth0: renamed from tmp8d19d
2023-09-05T14:39:27,484842+00:00 eth0: renamed from tmp68ca6
2023-09-05T14:39:27,614929+00:00 eth0: renamed from tmp25609
2023-09-05T14:39:27,673133+00:00 eth0: renamed from tmpa038b
2023-09-05T14:39:27,700837+00:00 eth0: renamed from tmp28c45
2023-09-05T14:39:27,756343+00:00 eth0: renamed from tmp265c9
2023-09-05T14:39:27,783081+00:00 eth0: renamed from tmp3aa76
2023-09-05T14:39:27,829354+00:00 eth0: renamed from tmpd71d2
2023-09-05T14:39:27,852896+00:00 eth0: renamed from tmpe2432
2023-09-05T14:39:27,896703+00:00 eth0: renamed from tmp0320c
2023-09-05T14:39:27,910728+00:00 eth0: renamed from tmp22f57
2023-09-05T14:39:27,935675+00:00 eth0: renamed from tmpdaece
2023-09-05T14:39:27,958857+00:00 eth0: renamed from tmp7ebfe
2023-09-05T14:39:27,993053+00:00 eth0: renamed from tmp5054a
2023-09-05T14:39:28,117281+00:00 eth0: renamed from tmp8103d
2023-09-05T14:39:28,148907+00:00 eth0: renamed from tmp0428a
2023-09-05T14:39:28,168923+00:00 eth0: renamed from tmp9b6d9
2023-09-05T14:39:29,109761+00:00 eth0: renamed from tmpe168e
2023-09-05T14:39:51,205728+00:00 eth0: renamed from tmp0dd6f
2023-09-05T14:39:52,212665+00:00 eth0: renamed from tmp7476c
2023-09-05T14:39:58,620731+00:00 eth0: renamed from tmp5bac8
2023-09-05T14:39:58,976630+00:00 eth0: renamed from tmp0c051
