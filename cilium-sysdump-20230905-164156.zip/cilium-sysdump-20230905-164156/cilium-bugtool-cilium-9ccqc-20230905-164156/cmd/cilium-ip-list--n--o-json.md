[
  {
    "cidr": "0.0.0.0/0",
    "identity": 2
  },
  {
    "cidr": "10.244.0.26/32",
    "hostIP": "172.17.0.2",
    "identity": 12173,
    "metadata": {
      "name": "livestreamdb-6877b6fc75-7w45t",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.29/32",
    "hostIP": "172.17.0.2",
    "identity": 4
  },
  {
    "cidr": "10.244.0.40/32",
    "hostIP": "172.17.0.2",
    "identity": 17675,
    "metadata": {
      "name": "cert-manager-webhook-879c48cd4-qp49t",
      "namespace": "cert-manager",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.41/32",
    "hostIP": "172.17.0.2",
    "identity": 29809,
    "metadata": {
      "name": "frontend-58b6bf847f-xgnzm",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.46/32",
    "hostIP": "172.17.0.2",
    "identity": 290,
    "metadata": {
      "name": "hubble-ui-6b468cff75-zwm9s",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.47/32",
    "hostIP": "172.17.0.2",
    "identity": 36400,
    "metadata": {
      "name": "kratos-77cbf98c8f-k2l6k",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.49/32",
    "hostIP": "172.17.0.2",
    "identity": 31330,
    "metadata": {
      "name": "coredns-878bb57ff-lgfbn",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.52/32",
    "hostIP": "172.17.0.2",
    "identity": 5710,
    "metadata": {
      "name": "cert-manager-cainjector-6774f986b-jw7hp",
      "namespace": "cert-manager",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.62/32",
    "hostIP": "172.17.0.2",
    "identity": 12060,
    "metadata": {
      "name": "minio-d496dbccf-8rsnz",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.81/32",
    "hostIP": "172.17.0.2",
    "identity": 4626,
    "metadata": {
      "name": "traffic-manager-55d995585d-xn8tw",
      "namespace": "ambassador",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.86/32",
    "hostIP": "172.17.0.2",
    "identity": 44885,
    "metadata": {
      "name": "hubble-relay-777496bf44-h6sbk",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.106/32",
    "hostIP": "172.17.0.2",
    "identity": 6602,
    "metadata": {
      "name": "cert-manager-78ddc5db85-nbbjs",
      "namespace": "cert-manager",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.112/32",
    "hostIP": "172.17.0.2",
    "identity": 10281,
    "metadata": {
      "name": "metrics-server-7f86dff975-tb5rv",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.123/32",
    "hostIP": "172.17.0.2",
    "identity": 62607,
    "metadata": {
      "name": "openebs-ndm-cluster-exporter-589554f487-g4gzj",
      "namespace": "openebs",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.124/32",
    "hostIP": "172.17.0.2",
    "identity": 20103,
    "metadata": {
      "name": "redis-68c95977f4-5ldmf",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.129/32",
    "hostIP": "172.17.0.2",
    "identity": 19125,
    "metadata": {
      "name": "openebs-ndm-operator-7c667b76f8-8bkbl",
      "namespace": "openebs",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.130/32",
    "hostIP": "172.17.0.2",
    "identity": 1
  },
  {
    "cidr": "10.244.0.132/32",
    "hostIP": "172.17.0.2",
    "identity": 5148,
    "metadata": {
      "name": "postgres-7c845b6448-hmx74",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.137/32",
    "hostIP": "172.17.0.2",
    "identity": 22996,
    "metadata": {
      "name": "backend-855f6c7b4-2lvs2",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.143/32",
    "hostIP": "172.17.0.2",
    "identity": 40792,
    "metadata": {
      "name": "openebs-ndm-node-exporter-bg5c6",
      "namespace": "openebs",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.149/32",
    "hostIP": "172.17.0.2",
    "identity": 63175,
    "metadata": {
      "name": "openebs-localpv-provisioner-7d6ccb7795-pnpxg",
      "namespace": "openebs",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.159/32",
    "hostIP": "172.17.0.2",
    "identity": 29809,
    "metadata": {
      "name": "frontend-58b6bf847f-nzgv5",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.160/32",
    "hostIP": "172.17.0.2",
    "identity": 29809,
    "metadata": {
      "name": "frontend-58b6bf847f-sxngk",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.177/32",
    "hostIP": "172.17.0.2",
    "identity": 10456,
    "metadata": {
      "name": "streamchat-79dfbb9bb4-5bt4p",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.178/32",
    "hostIP": "172.17.0.2",
    "identity": 43844,
    "metadata": {
      "name": "pgweb-b74849bb6-rd2fs",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.222/32",
    "hostIP": "172.17.0.2",
    "identity": 22996,
    "metadata": {
      "name": "backend-855f6c7b4-j4k6m",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.231/32",
    "hostIP": "172.17.0.2",
    "identity": 29809,
    "metadata": {
      "name": "frontend-58b6bf847f-rm7qs",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.243/32",
    "hostIP": "172.17.0.2",
    "identity": 8
  },
  {
    "cidr": "172.17.0.2/32",
    "identity": 1
  }
]

