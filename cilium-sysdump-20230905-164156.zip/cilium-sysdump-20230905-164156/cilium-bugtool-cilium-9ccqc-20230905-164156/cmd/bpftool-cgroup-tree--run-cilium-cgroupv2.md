CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2
63       cgroup_inet_ingress multi           sd_fw_ingress  
62       cgroup_inet_egress multi           sd_fw_egress   
15114    cgroup_inet4_connect multi           cil_sock4_connect
15115    cgroup_inet6_connect multi           cil_sock6_connect
15113    cgroup_inet4_post_bind multi           cil_sock4_post_bind
15120    cgroup_inet6_post_bind multi           cil_sock6_post_bind
15122    cgroup_udp4_sendmsg multi           cil_sock4_sendmsg
15121    cgroup_udp6_sendmsg multi           cil_sock6_sendmsg
15118    cgroup_udp4_recvmsg multi           cil_sock4_recvmsg
15119    cgroup_udp6_recvmsg multi           cil_sock6_recvmsg
15116    cgroup_inet4_getpeername multi           cil_sock4_getpeername
15117    cgroup_inet6_getpeername multi           cil_sock6_getpeername
/run/cilium/cgroupv2/sys-fs-fuse-connections.mount
    65       cgroup_inet_ingress multi           sd_fw_ingress  
    64       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/sys-kernel-config.mount
    67       cgroup_inet_ingress multi           sd_fw_ingress  
    66       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/sys-kernel-debug.mount
    38       cgroup_inet_ingress multi           sd_fw_ingress  
    37       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/kubepods/burstable/pod65e9d483-85fe-46a1-8495-00ad7e6976b5/3cb8a14d05d37835cdabafe08a31567d18eb9b765c42ddb326bacc9c114f4417
    15475    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/burstable/pod65e9d483-85fe-46a1-8495-00ad7e6976b5/942ad978de370916d091d112a88cf9cee9f716a5a4a0dbe28acde61376fe6148
    15345    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/burstable/podde74130d-b039-4a9f-a47d-920f4c13beb1/44ae9903bcb2bdc69d69b6d8256db0affeec5d8a266781acdd6b4dd2aba83502
    14794    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/burstable/podde74130d-b039-4a9f-a47d-920f4c13beb1/fb08e8fab9ef1179e41c31eb2b5acedf3a5df6c67f89093334220207ebbca3a9
    14764    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/burstable/pod448e990e-961f-4e6d-abe0-f7f97efba492/61294bfeb9bab421b3fd30eb07bc5b1e99f478d0234fd3dea0143cc6ffab7a26
    15314    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/burstable/pod448e990e-961f-4e6d-abe0-f7f97efba492/b47b21d5e9b26374e953f5813a4269e88d71312eea9d42d675cd8f9a95abaa8d
    15402    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod62e6decf-830f-4d18-a2e1-b5c5ab392b19/5bac844af1051a34909dc3e13d7027ef733b1316326314a5735d892ee8723303
    15862    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod62e6decf-830f-4d18-a2e1-b5c5ab392b19/9a075d89ecbc1cf217e13adfac036575fa9bae2e487609fa264b958152c3cbcb
    15908    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod42939137-fb3c-4671-be78-ffad88d5effa/7476cb2824b94ca1f9d7c75eefdeb82529918eaa1d2b2072688282345eeb7480
    15837    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod42939137-fb3c-4671-be78-ffad88d5effa/4ea70fa7ca9277694910a7791a2516a6b8f6cd3afec913e95606dea3f606290f
    15902    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod6951dcb8-577e-415f-bd2c-fc9398ae1e7c/18a2aedb0c22e165f3e4164b6f5ea5db0fbce6c68708440fe924f3c0a637193c
    15881    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod6951dcb8-577e-415f-bd2c-fc9398ae1e7c/e168e8852c21772a25793515dc6522aa960f49e6b8f4cbc31f943cc5f8478217
    15714    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podb70abd3d-f201-47fb-b585-022349956460/466d11cd15f1579e8ecfbb1ea6e424f6ec5a8e0b3f698da856abf2d63b506c70
    15361    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podb70abd3d-f201-47fb-b585-022349956460/b084a78b39597ed66d467e9ed512498913fcad8322542072ea9e3521727afb06
    15478    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod8227832f-d2d8-468c-a5af-33eb835a2948/8b1ee1d262092709c4ef995bbc9e8c0c2edc7f4f102e334b0fe741f3417ba01d
    14767    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod8227832f-d2d8-468c-a5af-33eb835a2948/2934e0c5e84dba6016f0e9f75252c26875fb0f472112fa1865940345ca5c5838
    14791    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podcd539a42-97c2-4fe1-a6dd-d0950a06286e/68ca637dcd2d136ef756aae37df6750149931c80fa9f7df41e04214b18c7e84b
    15545    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podcd539a42-97c2-4fe1-a6dd-d0950a06286e/8b12648ed79dbc58c8e5f3a865c43a939c251ebee33ef6a3f6b516fedefd36aa
    15711    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poda7afe9d5-c427-4452-8ba5-aa73273b062a/e2432f9b67206bd3fe1782ed853c17ad2388fa781ef5a9f96cc8db9e32a7122a
    15609    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poda7afe9d5-c427-4452-8ba5-aa73273b062a/76fc62543be30e9fa07fa0c06184b63b48117ff15bcf318b39b72c435d146815
    15799    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod4745369b-f5b5-4403-bfb0-1ab1940e0dd0/fe531199b532bcf179b4eda20f88a9626c48f22a8ac12c505e00d5218b5d13ea
    15472    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod4745369b-f5b5-4403-bfb0-1ab1940e0dd0/00af56099af799154b2566f9aa3a622f9f0f94e45a3713d4a89ad558a14536a2
    15326    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod171df4b5-ae18-48de-b989-8def46a2f735/daf97eecd0de47d668680a3e42c80f4eadf33ae0a647d4ee11b6be11fdfa0b8f
    15784    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod171df4b5-ae18-48de-b989-8def46a2f735/28c45285a69dd33c7d6eb5facaf0a6ad533aeee0627a77b5bf33d53b5cf9e8b8
    15555    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod1b9028b7-c7f2-43d2-abcf-baa49db879e3/ec535af9ad510280608bf4224d80c8daf6dfbef3d9859d74d969cceda312715c
    15320    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod1b9028b7-c7f2-43d2-abcf-baa49db879e3/4663798fff68e004985ea294f9d52bcc3479321bfd847fe37147fd4355b03f98
    15466    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod277efc27-e3ef-40fd-a32d-a920a41b4c2c/71def5443f42f601b1201a85dc93edb18bd5f60c8ab3299f2bf7577e4527eef1
    15887    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod277efc27-e3ef-40fd-a32d-a920a41b4c2c/8103d27e0622ccdea67d45171fd8e11d482d3a8068d96e8111659906a7817319
    15772    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod49dcbada-10c5-4230-8ca6-09b8a0187c9d/e0d48a21c88ad3f49000e4eade8d9f8ac3d347e2e0ac35648b27bed7878f55c9
    15396    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod49dcbada-10c5-4230-8ca6-09b8a0187c9d/ab7f1506121a0b67871fafcf594df7cc1c8f25210cfb29774d4e63febfff60ac
    15676    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podd119b32f-ca31-4f9b-8088-0db67b1c8973/06c7d313c5d18e26194a7f8998c147e0c49fdf8209a8710cba7a6a4713d7cc54
    15787    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podd119b32f-ca31-4f9b-8088-0db67b1c8973/a038bc390c1c6cb49b5646c1633294f7616d87c61bd806ffa62abafae9a14797
    15558    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podf0b3c79a-07b4-42c7-9f55-2d91bce52e02/ed577f6f72142bcce52d2f78ce2f55696f872650d562ac063ebbad7021a14ff2
    15796    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podf0b3c79a-07b4-42c7-9f55-2d91bce52e02/3aa76d2e40568b710d8e8328f5fb784b4896d9be23fd8073e544b990277d5ae8
    15593    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod343b04d8-3d0d-45d9-b5ed-86ccdbaaec31/e6e0370b0c0d274a1ee6320f064cec282e5d004567e9e0d7050cdbae05f747e5
    15405    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod343b04d8-3d0d-45d9-b5ed-86ccdbaaec31/df9757790004eb9c93ed75616aac1414c5c518094e1b11070ec968b56b46ae89
    15317    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod14ef4e41-77ec-4fa4-9a2e-7a196bf6c0e2/c3dd343a8b150a043b9e43ba9f11838b361abc204c75a323d33c5feb0a5f568d
    14763    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod14ef4e41-77ec-4fa4-9a2e-7a196bf6c0e2/4f27bc10fb780d64f6d63b4b86f40c08841ef7f2776ac4fe5b0c7c53a86eb846
    14782    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod8ed04157-bd6f-4b85-9b09-64e181b24455/5ea1e4f7bbf314e0c016c6f8367e1f5897f2158f85a8bc0747197eac7a19c26c
    15695    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod8ed04157-bd6f-4b85-9b09-64e181b24455/8d19df63511ab0d49a9719b078dadf169461d0b0adb8e920c6c1a73643d52aad
    15514    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podf478d693-c623-423f-b3de-f45229f45150/9b6d9c3d70cf6bfe9e4e0ee1830aa11fccbba5b90c4e6e8956054ed6e04b5885
    15769    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podf478d693-c623-423f-b3de-f45229f45150/612832e179654c543fa75f42180d3213854a09fbaf00adb128e132c8d42051e5
    15914    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poda7b488b1-0655-46ab-adb6-30f63d99fb5d/54f4b829a13411e875774e2f9e706feb989ebf219ad738a2b5bdabdfad993ebe
    15308    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poda7b488b1-0655-46ab-adb6-30f63d99fb5d/725d428b5275e07be852804494ee4312d5293777e8019a4b3218ce38b39b3076
    15364    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod88475714-5951-4aab-a470-f84bf90fb096/a45fde5a6f4b7e5f4c50e4367fc08b4cf2f2afcabc63544bce58b1d481772b9e
    15899    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod88475714-5951-4aab-a470-f84bf90fb096/0dd6f650e52fc8872438556cf3b4b639ee03fa3d9d4fc7385cf0390c65ea5174
    15821    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podfe548dcc-8789-48c8-8288-488a9aa4c04a/88778d17a8681072ae03ad3eb49624e5c363c293e7ab6c3cb28db039d22b35a8
    15561    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podfe548dcc-8789-48c8-8288-488a9aa4c04a/c91c81f3261d7411efb70ba81f8e9117e1e45ad3b32ae6b72da97c967915b14c
    15380    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podfe548dcc-8789-48c8-8288-488a9aa4c04a/070bd0d3b9bd1fefe1efcfaff7f99a366718df9ae84f2f499a0a33d38114f6eb
    15790    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poda59b6fe3-6d31-4327-8171-f2f23daf9d20/2fe35873da099fbf47ce91e841d43ef34116605bffc4b992b95f56e9819f0ccc
    15311    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poda59b6fe3-6d31-4327-8171-f2f23daf9d20/586abc3041698bfe13828ab4b1474c1c8ae7c1877565107e56f41dd8697ed2ee
    15399    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poddd555fad-2599-4f22-82aa-2257f3cb7e76/8cf9035015acce00c89d035a3995f6d7d602dfceb76d88891ff04ef169517f4e
    15110    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poddd555fad-2599-4f22-82aa-2257f3cb7e76/cb550c40e049136568af0bf652b590e6f0f4adf65cc7ba3b684186161c30fb3d
    15125    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod76a9876a-cb69-454f-8661-c82a89f669b2/52dd4c7897815c8d46d7c4ea31355544236c37169026e5c0c50173fc0f8cc204
    15463    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod76a9876a-cb69-454f-8661-c82a89f669b2/6ca953f974aa020416ea54dab4ebd97c6f12b0519337d529b4d152be715be274
    15323    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod03f5212b-d699-4f61-ae05-c46e665bc3d6/256095e2394a7c59e331e4689f9da81be2de5b97786cd03961d365e086eb2237
    15552    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod03f5212b-d699-4f61-ae05-c46e665bc3d6/9c8b8a2d1d90a6079660ffb9e69cc934c28c7cfda1f31ce709e8bfd428247b98
    15781    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod34e37066-ae94-4a73-8d49-c23fe42d6dab/e293a121236cbabd11a92e7cd2b16c99adc4ab855c8538ba4d1fcff46940d953
    15920    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod34e37066-ae94-4a73-8d49-c23fe42d6dab/5054acf2cf7818c85d996a1fdc0aff265b95a4e92d3c37b6a959cb5194cf33b0
    15778    cgroup_device   multi                          
/run/cilium/cgroupv2/dev-mqueue.mount
    36       cgroup_inet_ingress multi           sd_fw_ingress  
    35       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/user.slice
    161      cgroup_inet_ingress multi           sd_fw_ingress  
    160      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/user.slice/user-1000.slice
    163      cgroup_inet_ingress multi           sd_fw_ingress  
    162      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/user.slice/user-1000.slice/user@1000.service
    167      cgroup_inet_ingress multi           sd_fw_ingress  
    166      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/user.slice/user-1000.slice/session-1.scope
    169      cgroup_inet_ingress multi           sd_fw_ingress  
    168      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/init.scope
    24       cgroup_inet_ingress multi           sd_fw_ingress  
    23       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice
    61       cgroup_inet_ingress multi           sd_fw_ingress  
    60       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/system-systemd\x2dfsck.slice
    30       cgroup_inet_ingress multi           sd_fw_ingress  
    29       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    75       cgroup_inet_ingress multi           sd_fw_ingress  
    74       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/docker.service
    184      cgroup_inet_ingress multi           sd_fw_ingress  
    183      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/polkit.service
    139      cgroup_inet_ingress multi           sd_fw_ingress  
    138      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/rtkit-daemon.service
    175      cgroup_inet_ingress multi           sd_fw_ingress  
    174      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/bluetooth.service
    117      cgroup_inet_ingress multi           sd_fw_ingress  
    116      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/accounts-daemon.service
    130      cgroup_inet_ingress multi           sd_fw_ingress  
    129      cgroup_inet_egress multi           sd_fw_egress   
    128      cgroup_device   multi           sd_devices     
/run/cilium/cgroupv2/system.slice/cups.socket
    103      cgroup_inet_ingress multi           sd_fw_ingress  
    102      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/wpa_supplicant.service
    188      cgroup_inet_ingress multi           sd_fw_ingress  
    187      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/system-modprobe.slice
    28       cgroup_inet_ingress multi           sd_fw_ingress  
    27       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/ModemManager.service
    190      cgroup_inet_ingress multi           sd_fw_ingress  
    189      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    53       cgroup_inet_ingress multi           sd_fw_ingress  
    52       cgroup_inet_egress multi           sd_fw_egress   
    51       cgroup_device   multi           sd_devices     
/run/cilium/cgroupv2/system.slice/syncthing.service
    155      cgroup_inet_ingress multi           sd_fw_ingress  
    154      cgroup_inet_egress multi           sd_fw_egress   
    153      cgroup_device   multi           sd_devices     
/run/cilium/cgroupv2/system.slice/power-profiles-daemon.service
    173      cgroup_inet_ingress multi           sd_fw_ingress  
    172      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/display-manager.service
    159      cgroup_inet_ingress multi           sd_fw_ingress  
    158      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/nix-daemon.service
    580      cgroup_inet_ingress multi           sd_fw_ingress  
    579      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/colord.service
    179      cgroup_inet_ingress multi           sd_fw_ingress  
    178      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/NetworkManager.service
    144      cgroup_inet_ingress multi           sd_fw_ingress  
    143      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/boot-efi.mount
    79       cgroup_inet_ingress multi           sd_fw_ingress  
    78       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/nscd.service
    206      cgroup_inet_ingress multi           sd_fw_ingress  
    205      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/cups-browsed.service
    137      cgroup_inet_ingress multi           sd_fw_ingress  
    136      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/docker.socket
    105      cgroup_inet_ingress multi           sd_fw_ingress  
    104      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/docker-f23d624c2c19bed4c75e789286dfba9b464b9df641ba3e7741bd1ef4e982b4f9.scope
    14755    cgroup_inet_ingress multi           sd_fw_ingress  
    14754    cgroup_inet_egress multi           sd_fw_egress   
    14758    cgroup_device   multi                          
/run/cilium/cgroupv2/system.slice/cups.service
    152      cgroup_inet_ingress multi           sd_fw_ingress  
    151      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/upower.service
    171      cgroup_inet_ingress multi           sd_fw_ingress  
    170      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/systemd-oomd.service
    88       cgroup_inet_ingress multi           sd_fw_ingress  
    87       cgroup_inet_egress multi           sd_fw_egress   
    86       cgroup_device   multi           sd_devices     
/run/cilium/cgroupv2/system.slice/udisks2.service
    177      cgroup_inet_ingress multi           sd_fw_ingress  
    176      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/acpid.service
    109      cgroup_inet_ingress multi           sd_fw_ingress  
    108      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/dbus.service
    119      cgroup_inet_ingress multi           sd_fw_ingress  
    118      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/systemd-timesyncd.service
    93       cgroup_inet_ingress multi           sd_fw_ingress  
    92       cgroup_inet_egress multi           sd_fw_egress   
    91       cgroup_device   multi           sd_devices     
/run/cilium/cgroupv2/system.slice/avahi-daemon.service
    115      cgroup_inet_ingress multi           sd_fw_ingress  
    114      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    133      cgroup_inet_ingress multi           sd_fw_ingress  
    132      cgroup_inet_egress multi           sd_fw_egress   
    131      cgroup_device   multi           sd_devices     
/run/cilium/cgroupv2/proc-sys-fs-binfmt_misc.mount
    97       cgroup_inet_ingress multi           sd_fw_ingress  
    96       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/dev-hugepages.mount
    34       cgroup_inet_ingress multi           sd_fw_ingress  
    33       cgroup_inet_egress multi           sd_fw_egress   
