[
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.244.0.29"
      },
      "ipv6": {}
    },
    "ingress-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.244.0.243"
      },
      "ipv6": {}
    },
    "name": "k0s",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.244.0.0/24",
        "enabled": true,
        "ip": "172.17.0.2"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.244.0.130"
      }
    ]
  }
]

