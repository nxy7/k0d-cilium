 14:41:57 up  1:35,  0 users,  load average: 1.79, 0.99, 0.87
