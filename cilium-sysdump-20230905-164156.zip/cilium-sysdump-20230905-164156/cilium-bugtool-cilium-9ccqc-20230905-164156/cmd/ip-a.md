1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
2: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 66:ff:ee:41:ce:cc brd ff:ff:ff:ff:ff:ff
3: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 06:e2:fc:10:79:52 brd ff:ff:ff:ff:ff:ff
    inet 10.244.0.130/32 scope global cilium_host
       valid_lft forever preferred_lft forever
4: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ee:56:e2:38:61:c1 brd ff:ff:ff:ff:ff:ff
6: lxc_health@if5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether d2:69:21:fd:bb:63 brd ff:ff:ff:ff:ff:ff link-netns cilium-health
10: lxc4731b84c7f23@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 96:f2:93:19:ee:19 brd ff:ff:ff:ff:ff:ff link-netnsid 3
12: lxcd5f50712b795@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether aa:29:0a:cd:a9:c7 brd ff:ff:ff:ff:ff:ff link-netnsid 5
14: lxc3ad9da7138e0@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 56:1c:8b:59:c2:f3 brd ff:ff:ff:ff:ff:ff link-netnsid 6
16: lxc8f4963f4d794@if15: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether ae:85:3f:ed:55:fa brd ff:ff:ff:ff:ff:ff link-netnsid 13
18: lxc2553a1209f7b@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 42:ca:ed:d2:b3:59 brd ff:ff:ff:ff:ff:ff link-netnsid 10
20: lxce015178ea3e5@if19: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 92:61:43:a6:2b:2d brd ff:ff:ff:ff:ff:ff link-netnsid 8
22: lxc85e32e5f3830@if21: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:62:28:11:42:11 brd ff:ff:ff:ff:ff:ff link-netnsid 11
24: lxc5aa26ecaf428@if23: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:c0:f0:54:67:48 brd ff:ff:ff:ff:ff:ff link-netnsid 7
26: lxcc4f2ad3599a9@if25: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 62:da:ec:6b:90:90 brd ff:ff:ff:ff:ff:ff link-netnsid 12
28: lxca6e942e43be4@if27: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 56:d6:36:07:e9:45 brd ff:ff:ff:ff:ff:ff link-netnsid 9
30: lxc74e3fcbb5020@if29: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:6f:6a:ae:ce:4c brd ff:ff:ff:ff:ff:ff link-netnsid 2
32: lxc99e06d89f0fa@if31: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether de:fb:8f:a5:eb:ca brd ff:ff:ff:ff:ff:ff link-netnsid 4
34: lxcd4296424070a@if33: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:fd:8e:af:03:32 brd ff:ff:ff:ff:ff:ff link-netnsid 14
36: lxca3bc785de088@if35: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:8b:cf:03:5f:32 brd ff:ff:ff:ff:ff:ff link-netnsid 15
38: lxc7cd25424e3c0@if37: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether d6:fc:9b:b6:91:9f brd ff:ff:ff:ff:ff:ff link-netnsid 16
40: lxc7e22bb71519c@if39: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:9c:eb:75:07:90 brd ff:ff:ff:ff:ff:ff link-netnsid 17
44: lxcdc89b647f006@if43: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether ba:5e:3c:1c:65:9b brd ff:ff:ff:ff:ff:ff link-netnsid 19
48: lxc2d7efae318fd@if47: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 96:02:0a:e8:cd:1f brd ff:ff:ff:ff:ff:ff link-netnsid 21
58: lxcf80faf7bf140@if57: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether e6:02:e8:77:37:28 brd ff:ff:ff:ff:ff:ff link-netnsid 26
60: lxc4889aef29f33@if59: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 52:3b:a8:33:de:89 brd ff:ff:ff:ff:ff:ff link-netnsid 27
63: eth0@if64: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 02:42:ac:11:00:02 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet 172.17.0.2/16 brd 172.17.255.255 scope global eth0
       valid_lft forever preferred_lft forever
65: lxc7f62068e89e0@if64: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 26:63:ac:d3:10:0f brd ff:ff:ff:ff:ff:ff link-netnsid 29
67: lxcc57ce94121eb@if66: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:aa:9c:85:68:59 brd ff:ff:ff:ff:ff:ff link-netnsid 30
69: lxcf0882de5a2d1@if68: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether f2:f7:49:10:e6:ad brd ff:ff:ff:ff:ff:ff link-netnsid 20
71: lxc14e2da0d3f54@if70: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 42:8a:b8:70:f8:45 brd ff:ff:ff:ff:ff:ff link-netnsid 24
73: lxc155b3629c0eb@if72: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 72:c9:e8:7a:6a:98 brd ff:ff:ff:ff:ff:ff link-netnsid 28
