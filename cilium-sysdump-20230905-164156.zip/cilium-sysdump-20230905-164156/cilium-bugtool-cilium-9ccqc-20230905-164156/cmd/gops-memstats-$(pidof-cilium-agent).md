alloc: 61.04MB (64008216 bytes)
total-alloc: 626.42MB (656847760 bytes)
sys: 99.35MB (104177763 bytes)
lookups: 0
mallocs: 8124387
frees: 7439987
heap-alloc: 61.04MB (64008216 bytes)
heap-sys: 76.28MB (79986688 bytes)
heap-idle: 9.98MB (10461184 bytes)
heap-in-use: 66.30MB (69525504 bytes)
heap-released: 9.05MB (9494528 bytes)
heap-objects: 684400
stack-in-use: 7.72MB (8093696 bytes)
stack-sys: 7.72MB (8093696 bytes)
stack-mspan-inuse: 1.10MB (1152480 bytes)
stack-mspan-sys: 1.11MB (1158720 bytes)
stack-mcache-inuse: 14.06KB (14400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 2.21MB (2312979 bytes)
gc-sys: 10.36MB (10862528 bytes)
next-gc: when heap-alloc >= 66.40MB (69629952 bytes)
last-gc: 2023-09-05 14:40:33.476282531 +0000 UTC
gc-pause-total: 1.683057ms
gc-pause: 54536
gc-pause-end: 1693924833476282531
num-gc: 28
num-forced-gc: 0
gc-cpu-fraction: 0.0001880384607443272
enable-gc: true
debug-gc: false
