xdp:

tc:
cilium_net(2) clsact/ingress cil_to_host-cilium_net id 15429
cilium_host(3) clsact/ingress cil_to_host-cilium_host id 15411
cilium_host(3) clsact/egress cil_from_host-cilium_host id 15419
cilium_vxlan(4) clsact/ingress cil_from_overlay-cilium_vxlan id 15128
cilium_vxlan(4) clsact/egress cil_to_overlay-cilium_vxlan id 15129
lxc_health(6) clsact/ingress cil_from_container-lxc_health id 15274
lxc4731b84c7f23(10) clsact/ingress cil_from_container-lxc4731b84c7f23 id 15264
lxcd5f50712b795(12) clsact/ingress cil_from_container-lxcd5f50712b795 id 15288
lxc3ad9da7138e0(14) clsact/ingress cil_from_container-lxc3ad9da7138e0 id 15271
lxc8f4963f4d794(16) clsact/ingress cil_from_container-lxc8f4963f4d794 id 15392
lxc2553a1209f7b(18) clsact/ingress cil_from_container-lxc2553a1209f7b id 15358
lxce015178ea3e5(20) clsact/ingress cil_from_container-lxce015178ea3e5 id 15366
lxc85e32e5f3830(22) clsact/ingress cil_from_container-lxc85e32e5f3830 id 15200
lxc5aa26ecaf428(24) clsact/ingress cil_from_container-lxc5aa26ecaf428 id 15335
lxcc4f2ad3599a9(26) clsact/ingress cil_from_container-lxcc4f2ad3599a9 id 15236
lxca6e942e43be4(28) clsact/ingress cil_from_container-lxca6e942e43be4 id 15292
lxc74e3fcbb5020(30) clsact/ingress cil_from_container-lxc74e3fcbb5020 id 15302
lxc99e06d89f0fa(32) clsact/ingress cil_from_container-lxc99e06d89f0fa id 15479
lxcd4296424070a(34) clsact/ingress cil_from_container-lxcd4296424070a id 15492
lxca3bc785de088(36) clsact/ingress cil_from_container-lxca3bc785de088 id 15516
lxc7cd25424e3c0(38) clsact/ingress cil_from_container-lxc7cd25424e3c0 id 15542
lxc7e22bb71519c(40) clsact/ingress cil_from_container-lxc7e22bb71519c id 15541
lxcdc89b647f006(44) clsact/ingress cil_from_container-lxcdc89b647f006 id 15581
lxc2d7efae318fd(48) clsact/ingress cil_from_container-lxc2d7efae318fd id 15594
lxcf80faf7bf140(58) clsact/ingress cil_from_container-lxcf80faf7bf140 id 15749
lxc4889aef29f33(60) clsact/ingress cil_from_container-lxc4889aef29f33 id 15742
eth0(63) clsact/ingress cil_from_netdev-eth0 id 15446
eth0(63) clsact/egress cil_to_netdev-eth0 id 15450
lxc7f62068e89e0(65) clsact/ingress cil_from_container-lxc7f62068e89e0 id 15721
lxcc57ce94121eb(67) clsact/ingress cil_from_container-lxcc57ce94121eb id 15708
lxcf0882de5a2d1(69) clsact/ingress cil_from_container-lxcf0882de5a2d1 id 15810
lxc14e2da0d3f54(71) clsact/ingress cil_from_container-lxc14e2da0d3f54 id 15826
lxc155b3629c0eb(73) clsact/ingress cil_from_container-lxc155b3629c0eb id 15854

flow_dissector:

