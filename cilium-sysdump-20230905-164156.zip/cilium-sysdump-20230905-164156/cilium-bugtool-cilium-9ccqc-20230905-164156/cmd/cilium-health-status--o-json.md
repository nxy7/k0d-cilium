{
  "local": {
    "name": "k0s"
  },
  "nodes": [
    {
      "endpoint": {
        "http": {
          "latency": 158289
        },
        "icmp": {
          "latency": 102512
        },
        "ip": "10.244.0.29"
      },
      "health-endpoint": {
        "primary-address": {
          "http": {
            "latency": 158289
          },
          "icmp": {
            "latency": 102512
          },
          "ip": "10.244.0.29"
        },
        "secondary-addresses": []
      },
      "host": {
        "primary-address": {
          "http": {
            "latency": 146870
          },
          "icmp": {
            "latency": 87603
          },
          "ip": "172.17.0.2"
        },
        "secondary-addresses": []
      },
      "name": "k0s"
    }
  ],
  "timestamp": "2023-09-05T14:41:57Z"
}

