filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf80faf7bf140 direct-action not_in_hw id 15749 tag 01662193413d794c jited 
