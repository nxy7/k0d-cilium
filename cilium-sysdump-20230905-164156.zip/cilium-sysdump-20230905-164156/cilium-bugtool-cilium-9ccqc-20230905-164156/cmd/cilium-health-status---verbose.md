Probe time:   2023-09-05T14:41:57Z
Nodes:
  k0s (localhost):
    Host connectivity to 172.17.0.2:
      ICMP to stack:   OK, RTT=87.603µs
      HTTP to agent:   OK, RTT=146.87µs
    Endpoint connectivity to 10.244.0.29:
      ICMP to stack:   OK, RTT=102.512µs
      HTTP to agent:   OK, RTT=158.289µs
