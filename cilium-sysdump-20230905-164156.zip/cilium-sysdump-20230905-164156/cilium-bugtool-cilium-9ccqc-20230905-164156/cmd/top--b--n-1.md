top - 14:41:57 up  1:35,  0 users,  load average: 1.79, 0.99, 0.87
Tasks:  17 total,  13 running,   3 sleeping,   0 stopped,   1 zombie
%Cpu(s): 33.1 us, 58.0 sy,  0.0 ni,  8.3 id,  0.6 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :  15915.0 total,    383.0 free,   5369.9 used,  10162.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   9925.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   3916 root      20   0    2928   1280   1280 R  66.7   0.0   0:00.10 cat
      1 root      20   0  880452 159844  68224 S  33.3   1.0   0:05.64 cilium-+
   3924 root      20   0  786424  60544  41088 S  33.3   0.4   0:00.05 cilium
   3922 root      20   0  785912  59520  41088 R  26.7   0.4   0:00.04 cilium
   3923 root      20   0    3916   2048   1920 R  26.7   0.0   0:00.04 cp
   3774 root      20   0  725920  16996  10368 R  20.0   0.1   0:00.04 cilium-+
   3999 root      20   0  785592  57216  40320 R  20.0   0.4   0:00.03 cilium
   4026 root      20   0  785592  41600  33408 R  13.3   0.3   0:00.02 cilium
   4020 root      20   0       0      0      0 Z   6.7   0.0   0:00.01 gops
    199 root      20   0  713924   4480   3712 S   0.0   0.0   0:00.00 cilium-+
   3810 root      20   0    7180   3200   2816 R   0.0   0.0   0:00.00 top
   4034 root      20   0  783992  16256  13824 R   0.0   0.1   0:00.00 cilium
   4040 root      20   0  783736  15872  13568 R   0.0   0.1   0:00.00 cilium
   4041 root      20   0  783736  15104  13056 R   0.0   0.1   0:00.00 cilium
   4049 root      20   0  783480   8448   7808 R   0.0   0.1   0:00.00 cilium
   4050 root      20   0  783480   7808   7424 R   0.0   0.0   0:00.00 cilium
   4055 root      20   0    4236   1152   1024 R   0.0   0.0   0:00.00 bash
