Total: 568
TCP:   296 (estab 49, closed 196, orphaned 0, timewait 101)

Transport Total     IP        IPv6
RAW	  2         2         0        
UDP	  3         2         1        
TCP	  100       66        34       
INET	  105       70        35       
FRAG	  0         0         0        

State  Recv-Q Send-Q Local Address:Port  Peer Address:PortProcess                                                                           
UNCONN 0      0          127.0.0.1:39667      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=33)) ino:634707 sk:b614 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0            0.0.0.0:8472       0.0.0.0:*    ino:645360 sk:b615 cgroup:/ <->                                                  
UNCONN 0      0               [::]:8472          [::]:*    ino:645359 sk:b616 cgroup:/ v6only:1 <->                                         
