goroutine 47 [running]:
runtime/pprof.writeGoroutineStacks({0x3b88080, 0xc0012de000})
	/usr/local/go/src/runtime/pprof/pprof.go:703 +0x70
runtime/pprof.writeGoroutine({0x3b88080?, 0xc0012de000?}, 0xc0015f9300?)
	/usr/local/go/src/runtime/pprof/pprof.go:692 +0x2b
runtime/pprof.(*Profile).WriteTo(0x360ff0b?, {0x3b88080?, 0xc0012de000?}, 0xd?)
	/usr/local/go/src/runtime/pprof/pprof.go:329 +0x14b
github.com/google/gops/agent.handle({0x7ffa49853588?, 0xc0012de000}, {0xc000fc4000?, 0x1?, 0x1?})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:200 +0xe5
github.com/google/gops/agent.listen({0x3bb3640, 0xc001a6d890})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:144 +0x1bc
created by github.com/google/gops/agent.Listen
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:122 +0x390

goroutine 1 [select, 3 minutes]:
github.com/cilium/cilium/pkg/hive.(*Hive).waitForSignalOrShutdown(0xc0009dc640)
	/go/src/github.com/cilium/cilium/pkg/hive/hive.go:217 +0x17f
github.com/cilium/cilium/pkg/hive.(*Hive).Run(0xc0009dc640)
	/go/src/github.com/cilium/cilium/pkg/hive/hive.go:198 +0x147
github.com/cilium/cilium/daemon/cmd.runApp(0x588ea40?, {0x35fe3fd?, 0x1?, 0x1?})
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:67 +0xe5
github.com/spf13/cobra.(*Command).execute(0x588ea40, {0xc000072050, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:944 +0x847
github.com/spf13/cobra.(*Command).ExecuteC(0x588ea40)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1068 +0x3bd
github.com/spf13/cobra.(*Command).Execute(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:992
github.com/cilium/cilium/daemon/cmd.Execute()
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:78 +0x65
main.main()
	/go/src/github.com/cilium/cilium/daemon/main.go:9 +0x17

goroutine 66 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc000400a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:314 +0xa7
created by k8s.io/client-go/util/workqueue.newQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1bc

goroutine 67 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000400ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 59 [select, 2 minutes]:
io.(*pipe).read(0xc000f707e0, {0xc00181819c, 0xfe64, 0x3b99110?})
	/usr/local/go/src/io/pipe.go:57 +0xb1
io.(*PipeReader).Read(0x0?, {0xc00181819c?, 0xc0003d1d70?, 0xc00068bb00?})
	/usr/local/go/src/io/pipe.go:136 +0x25
bufio.(*Scanner).Scan(0xc00328cf28)
	/usr/local/go/src/bufio/scan.go:214 +0x876
github.com/sirupsen/logrus.(*Entry).writerScanner(0xc00080c3c0?, 0xc0012dfbf8, 0xc000fa96f0)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x11f
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x3d1

goroutine 60 [select, 3 minutes]:
io.(*pipe).read(0xc000f70840, {0xc000d88175, 0xfe8b, 0x3b99110?})
	/usr/local/go/src/io/pipe.go:57 +0xb1
io.(*PipeReader).Read(0x0?, {0xc000d88175?, 0xc0003d1d70?, 0xc00068bb00?})
	/usr/local/go/src/io/pipe.go:136 +0x25
bufio.(*Scanner).Scan(0xc0020d5f28)
	/usr/local/go/src/bufio/scan.go:214 +0x876
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0?, 0xc0012dfc08, 0xc000fa9710)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x11f
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x3d1

goroutine 61 [select, 3 minutes]:
io.(*pipe).read(0xc000f708a0, {0xc001000000, 0x10000, 0x423325?})
	/usr/local/go/src/io/pipe.go:57 +0xb1
io.(*PipeReader).Read(0x7ffa49ac8268?, {0xc001000000?, 0x40e05d?, 0x0?})
	/usr/local/go/src/io/pipe.go:136 +0x25
bufio.(*Scanner).Scan(0xc0003fbf28)
	/usr/local/go/src/bufio/scan.go:214 +0x876
github.com/sirupsen/logrus.(*Entry).writerScanner(0xc00069d7d0?, 0xc0012dfc18, 0xc000fa9730)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x11f
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x3d1

goroutine 62 [select, 3 minutes]:
io.(*pipe).read(0xc000f70900, {0xc000714000, 0x10000, 0x423325?})
	/usr/local/go/src/io/pipe.go:57 +0xb1
io.(*PipeReader).Read(0x7ffa49aa1df8?, {0xc000714000?, 0x40e05d?, 0x0?})
	/usr/local/go/src/io/pipe.go:136 +0x25
bufio.(*Scanner).Scan(0xc00072bf28)
	/usr/local/go/src/bufio/scan.go:214 +0x876
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0?, 0xc0012dfc28, 0xc000fa9750)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x11f
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x3d1

goroutine 230 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 97 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction.func1()
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:19 +0x67
created by github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:17 +0x9c

goroutine 86 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc00073a080}, {0x7ffa49960110, 0xc001afc0b0}, {0x3be8e60?, 0x35bf660}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001d6c000, {0x0?, 0x0?}, 0xc001d88000, 0xc0010721e0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001d6c000, 0xc001d88000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001d48200?, {0x3b878e0, 0xc000298c80}, 0x1, 0xc001d88000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001d6c000, 0xc001d88000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 85 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 83 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001d4e5a0, {0xc0010720c0, 0x0, 0x3805780, 0x6fc23ac00, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000298af0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 191 [chan receive, 2 minutes]:
github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch.func1()
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:147 +0x77
created by github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:139 +0x72

goroutine 192 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001326dc0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 193 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001326e60)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 48 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7ffa49daee68, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001d54000?, 0xc0003f6d00?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001d54000)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc001d54000)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*TCPListener).accept(0xc001d52048)
	/usr/local/go/src/net/tcpsock_posix.go:148 +0x25
net.(*TCPListener).Accept(0xc001d52048)
	/usr/local/go/src/net/tcpsock.go:297 +0x3d
net/http.(*Server).Serve(0xc00131c000, {0x3bb3640, 0xc001d52048})
	/usr/local/go/src/net/http/server.go:3059 +0x385
net/http.(*Server).ListenAndServe(0xc00131c000)
	/usr/local/go/src/net/http/server.go:2988 +0x7d
github.com/cilium/cilium/pkg/metrics.NewRegistry.func1.1()
	/go/src/github.com/cilium/cilium/pkg/metrics/registry.go:89 +0xb1
created by github.com/cilium/cilium/pkg/metrics.NewRegistry.func1
	/go/src/github.com/cilium/cilium/pkg/metrics/registry.go:87 +0xca

goroutine 263 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00073af10, 0x4b)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc001ea4180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 225 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000b35548, 0xf)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000d65d68?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000b35530, {0xc003d7eaa4, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc003d7eaa4?, 0xc000d65d08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7ffa49960040, 0xc000b35500}, {0xc003d7eaa4, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc000748030, {0xc00321e000, 0x2000, 0x2500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0003b2190, 0xc003d329c0?, {0x3b9d990, 0xc003055180})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0010c8000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00073a080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 213 [IO wait]:
internal/poll.runtime_pollWait(0x7ffa49daed78, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001a9ec00?, 0xc001a86000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001a9ec00, {0xc001a86000, 0xa000, 0xa000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc001a9ec00, {0xc001a86000?, 0x9ffb?, 0xc0010248a0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc0005dbaf8, {0xc001a86000?, 0xc001a86000?, 0x5?})
	/usr/local/go/src/net/net.go:183 +0x45
crypto/tls.(*atLeastReader).Read(0xc0046a94d0, {0xc001a86000?, 0xc0046a94d0?, 0x0?})
	/usr/local/go/src/crypto/tls/conn.go:788 +0x3d
bytes.(*Buffer).ReadFrom(0xc001aec290, {0x3b720a0, 0xc0046a94d0})
	/usr/local/go/src/bytes/buffer.go:202 +0x98
crypto/tls.(*Conn).readFromUntil(0xc001aec000, {0x7ffa49bd86e0?, 0xc001a6d9c8}, 0xa000?)
	/usr/local/go/src/crypto/tls/conn.go:810 +0xe5
crypto/tls.(*Conn).readRecordOrCCS(0xc001aec000, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:617 +0x116
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:583
crypto/tls.(*Conn).Read(0xc001aec000, {0xc001afa000, 0x1000, 0x0?})
	/usr/local/go/src/crypto/tls/conn.go:1316 +0x16f
bufio.(*Reader).Read(0xc001176b40, {0xc001687000, 0x9, 0xc002f34208?})
	/usr/local/go/src/bufio/bufio.go:237 +0x1bb
io.ReadAtLeast({0x3b71ea0, 0xc001176b40}, {0xc001687000, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
golang.org/x/net/http2.readFrameHeader({0xc001687000?, 0x9?, 0xc000000000?}, {0x3b71ea0?, 0xc001176b40?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x6e
golang.org/x/net/http2.(*Framer).ReadFrame(0xc001686fc0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x95
golang.org/x/net/http2.(*clientConnReadLoop).run(0xc0003f8f98)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2251 +0x12e
golang.org/x/net/http2.(*ClientConn).readLoop(0xc000b34f00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2146 +0x6f
created by golang.org/x/net/http2.(*Transport).newClientConn
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:818 +0xc1f

goroutine 228 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc00075e0d8, 0xe)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc00110dde0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc00075e0b0, 0xc000738780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000d766e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc000738810}, 0x1, 0xc00074e6c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000d76758?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000d766e0, 0xc00074e6c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 244 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc001302c60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 219 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001afc0d8, 0xc)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0003bf720?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001afc0b0, 0xc001b10690)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000f35ea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc001d4c780}, 0x1, 0xc001d88000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000f35f18?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000f35ea0, 0xc001d88000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 223 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000b35500, 0xc0006e4c00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xc0006a2ed0?, 0xc001322ec0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 222 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001d6c000, 0xc001d88000, 0xc001afe780, 0xc001176e40?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 245 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc001d90d50, 0x1a)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc001302b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 241 [chan receive, 2 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager.(*diffStore[...]).run(0x3bca720)
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/diffstore.go:105 +0x185
created by github.com/cilium/cilium/pkg/bgpv1/manager.(*diffStore[...]).Start
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/diffstore.go:85 +0x12a

goroutine 90 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000466d80, 0xc000166400)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xc001ddc000?, 0xc001d88600?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 715 [chan receive, 3 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func5()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:302 +0x3e
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:301 +0x2f2c

goroutine 246 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 231 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc001d90cc0}, {0x7ffa49960110, 0xc00075e0b0}, {0x3be8e60?, 0x35c01a0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc000774000, {0x0?, 0x0?}, 0xc00074e6c0, 0xc0010c8120?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc000774000, 0xc00074e6c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00073c100?, {0x3b878e0, 0xc0003b23c0}, 0x1, 0xc00074e6c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc000774000, 0xc00074e6c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 234 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc000774000, 0xc00074e6c0, 0xc00074ee40, 0xc0013927a0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 31 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000002dc8, 0x10)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000725d68?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000002db0, {0xc0042076c0, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0xc0042076c0?}, {0xc0042076c0?, 0xc000725d08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7ffa49960040, 0xc000002d80}, {0xc0042076c0, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc001d8a690, {0xc003610000, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0003965a0, 0xc0041027d0?, {0x3b9d990, 0xc0042269c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc00107a2a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001d90cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 235 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000002d80, 0xc00079a800)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xc0009dca00?, 0xc0009dc820?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 357 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 236 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00075e2e8, 0x26)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000b686a0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc00075e2c0, 0xc000739890)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000d76aa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc000739920}, 0x1, 0xc00074f260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000d76b18?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000d76aa0, 0xc00074f260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 1244 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0013d4120, {0xc0001641c0, 0x0, 0xc0014b0b10, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002824f00}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 238 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 239 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc00073ae80}, {0x7ffa49960110, 0xc00075e2c0}, {0x3be8e60?, 0x35c0560}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc000774380, {0x0?, 0x0?}, 0xc00074f260, 0xc0010c8780?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc000774380, 0xc00074f260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00073c1c0?, {0x3b878e0, 0xc0003b2640}, 0x1, 0xc00074f260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc000774380, 0xc00074f260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 89 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc000774380, 0xc00074f260, 0xc001d62960, 0xc0000a3fa0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 258 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000466dc8, 0x28)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc00077ad68?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000466db0, {0xc00425a01c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc00425a01c?, 0xc00077ad08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7ffa49960040, 0xc000466d80}, {0xc00425a01c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc000748a50, {0xc00066e800, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0003b27d0, 0xc004102a50?, {0x3b9d990, 0xc004226c00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0010c89c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00073ae80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 262 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc001ea42a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 260 [chan receive]:
github.com/cilium/cilium/pkg/bgpv1/manager.(*diffStore[...]).run(0x3bca6c0)
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/diffstore.go:105 +0x185
created by github.com/cilium/cilium/pkg/bgpv1/manager.(*diffStore[...]).Start
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/diffstore.go:85 +0x12a

goroutine 456 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 264 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 1132 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000d80266, 0x10, 0x1a}, {0xc001862180, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 247 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2.func1()
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:78 +0x32
created by github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:77 +0xb4

goroutine 96 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001f3f200, {0xc000f8f150, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000298eb0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 273 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 274 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 275 [chan receive, 3 minutes]:
github.com/cilium/workerpool.(*WorkerPool).run(0xc000298f00, {0x3bb56d8?, 0xc000298ff0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:173 +0x65
created by github.com/cilium/workerpool.NewWithContext
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:68 +0x14e

goroutine 276 [select]:
github.com/cilium/cilium/pkg/node/manager.(*manager).backgroundSync(0xc0012e6c80, {0x3bb56d8, 0xc000298ff0})
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:301 +0x2a5
github.com/cilium/workerpool.(*WorkerPool).run.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:181 +0x82
created by github.com/cilium/workerpool.(*WorkerPool).run
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:178 +0x4e

goroutine 277 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7ffa49daec88, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc00131b320?, 0xc001f8fed0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00131b320, {0xc001f8fed0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:31
os.(*File).Read(0xc0009aa088, {0xc001f8fed0?, 0x3b64c00?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x5e
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc000299090)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:356 +0xdf
created by github.com/fsnotify/fsnotify.NewWatcher
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:150 +0x1b0

goroutine 278 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001f4c240, {0xc000f8f360, 0x0, 0x3805780, 0x0, 0x0, 0x2540be400, 0x0, {0x3bb56d8, 0xc000299130}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 279 [select, 3 minutes]:
github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).watchForDirectoryChanges(0xc001102540)
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:233 +0x117
created by github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).Start
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:207 +0x3be

goroutine 280 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7ffa49daeb98, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001d54b80?, 0x0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001d54b80)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc001d54b80)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*UnixListener).accept(0x407565?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x1c
net.(*UnixListener).Accept(0xc001d4df20)
	/usr/local/go/src/net/unixsock.go:260 +0x3d
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2(0xc0010727e0, {0x3bb56d8?, 0xc000c67e50}, 0x0?)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:83 +0xef
created by github.com/cilium/cilium/pkg/monitor/agent.ServeMonitorAPI
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:69 +0x19f

goroutine 282 [select, 2 minutes]:
github.com/cilium/cilium/pkg/l2announcer.(*L2Announcer).run(0xc001ab1680, {0x3bb5780, 0xc001f501e0})
	/go/src/github.com/cilium/cilium/pkg/l2announcer/l2announcer.go:188 +0x4bf
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc0002921e0, {0x3bb5780, 0xc001f501e0}, 0x0?, {{{0xc000f90100, 0x1, 0x1}}, {0x3be6410, 0xc0016d23f0}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:267 +0x530
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 283 [select]:
github.com/cilium/cilium/pkg/hive/job.(*jobTimer).start(0xc000292230, {0x3bb5780, 0xc001f50240}, 0x0?, {{{0xc000f90100, 0x1, 0x1}}, {0x3be6410, 0xc0016d23f0}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:384 +0x3c5
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 449 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc00201ae80}, {0x7ffa49960110, 0xc00075e790}, {0x3be8e60?, 0x358fc00}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0016862a0, {0x0?, 0x0?}, 0xc00074f9e0, 0xc00107b040?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0016862a0, 0xc00074f9e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc002039ec8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001ab8ec0?, {0x3b878e0, 0xc0002bf130}, 0x1, 0xc00074f9e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0016862a0, 0xc00074f9e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 291 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc001afc238, 0x1)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc00110d200?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001afc210, 0xc001b11320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000f35f40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc001ea8930}, 0x1, 0xc001d88e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000f35fb8?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000f35f40, 0xc001d88e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 252 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc00075e7b8, 0x3)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000ac0f80?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc00075e790, 0xc00089c1b0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0013268c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc001b4d830}, 0x1, 0xc00074f9e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001326938?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0013268c0, 0xc00074f9e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 266 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 267 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc00073aac0}, {0x7ffa49960110, 0xc001afc210}, {0x3be8e60?, 0x358e620}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0007747e0, {0x0?, 0x0?}, 0xc001d88e40, 0xc00107a540?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0007747e0, 0xc001d88e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0xc001ebbec8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00073c380?, {0x3b878e0, 0xc0003b2af0}, 0x1, 0xc001d88e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0007747e0, 0xc001d88e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 284 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7ffa49daeaa8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001d54d00?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001d54d00)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc001d54d00)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*UnixListener).accept(0x444640?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x1c
net.(*UnixListener).Accept(0xc001f50360)
	/usr/local/go/src/net/unixsock.go:260 +0x3d
google.golang.org/grpc.(*Server).Serve(0xc001f341e0, {0x3bb3670?, 0xc001f50360})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:821 +0x475
github.com/cilium/cilium/pkg/envoy.startXDSGRPCServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:56 +0xb1
created by github.com/cilium/cilium/pkg/envoy.startXDSGRPCServer
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:54 +0x198

goroutine 1388 [IO wait]:
internal/poll.runtime_pollWait(0x7ffa499d92c8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001d54280?, 0xc0013cb000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001d54280, {0xc0013cb000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc001d54280, {0xc0013cb000?, 0x2?, 0x588a5a0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc001444510, {0xc0013cb000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*persistConn).Read(0xc001d36c60, {0xc0013cb000?, 0x44d520?, 0xc001ee3ec8?})
	/usr/local/go/src/net/http/transport.go:1943 +0x4e
bufio.(*Reader).fill(0xc002cdbb00)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc002cdbb00, 0x1)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*persistConn).readLoop(0xc001d36c60)
	/usr/local/go/src/net/http/transport.go:2107 +0x1ac
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1765 +0x16ea

goroutine 285 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7ffa49dae9b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001d54e80?, 0x47b945?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001d54e80)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc001d54e80)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*UnixListener).accept(0x444640?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x1c
net.(*UnixListener).AcceptUnix(0xc001f50ff0)
	/usr/local/go/src/net/unixsock.go:247 +0x3d
github.com/cilium/cilium/pkg/envoy.StartAccessLogServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:69 +0x59
created by github.com/cilium/cilium/pkg/envoy.StartAccessLogServer
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:65 +0x514

goroutine 286 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/envoy.StartAccessLogServer.func2()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:87 +0x35
created by github.com/cilium/cilium/pkg/envoy.StartAccessLogServer
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:86 +0x590

goroutine 305 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc001d52bd0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 306 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000df81e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 307 [select]:
github.com/cilium/cilium/pkg/cgroups/manager.(*CgroupManager).processPodEvents(0xc0006aa230)
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:243 +0x95
created by github.com/cilium/cilium/pkg/cgroups/manager.initManager
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:213 +0x1d6

goroutine 308 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001f7ec60, {0x3805ba0, 0x0, 0x3805780, 0x12a05f200, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0006aabe0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 309 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001f7f440, {0xc003fbcdc0, 0x0, 0x3805780, 0x0, 0xdf8475800, 0x0, 0x0, {0x3bb56d8, 0xc0006aaf00}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 310 [select]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).k8sServiceHandler(0xc001d682c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:677 +0xfd
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).RunK8sServiceHandler
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:690 +0x56

goroutine 311 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0020227e0, {0xc00201a5c0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000afd540}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 465 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc002060000, 0xc0006e4a00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xc0012dfc08?, 0xc000fa9710?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 293 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7ffa49dae6e8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001a9fa80?, 0xc001d440aa?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001a9fa80)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc001a9fa80)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*TCPListener).accept(0xc001b181f8)
	/usr/local/go/src/net/tcpsock_posix.go:148 +0x25
net.(*TCPListener).Accept(0xc001b181f8)
	/usr/local/go/src/net/tcpsock.go:297 +0x3d
github.com/miekg/dns.(*Server).serveTCP(0xc0006e4e00, {0x3bb3640?, 0xc001b181f8})
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:454 +0x148
github.com/miekg/dns.(*Server).ActivateAndServe(0xc0006e4e00)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:372 +0x17c
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc0006e4e00)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:670 +0x20c
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:662 +0x939

goroutine 1213 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0010dc5a0, {0xc0001cae70, 0x0, 0xc001093290, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00178cf00}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 294 [IO wait]:
internal/poll.runtime_pollWait(0x7ffa49dae8c8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001a9fb00?, 0xc00097a600?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsgInet4(0xc001a9fb00, {0xc00097a600, 0x200, 0x200}, {0xc00094e660, 0x2c, 0x2c}, 0xc0003f77c8?, 0x40c409?)
	/usr/local/go/src/internal/poll/fd_unix.go:331 +0x359
net.(*netFD).readMsgInet4(0xc001a9fb00, {0xc00097a600?, 0xc0003f7840?, 0xc0003f7858?}, {0xc00094e660?, 0xc002993000?, 0x24?}, 0x440758?, 0x23?)
	/usr/local/go/src/net/fd_posix.go:84 +0x37
net.(*UDPConn).readMsg(0x68?, {0xc00097a600?, 0x416130?, 0xffffffffffffffff?}, {0xc00094e660?, 0x0?, 0x0?})
	/usr/local/go/src/net/udpsock_posix.go:101 +0x16b
net.(*UDPConn).ReadMsgUDPAddrPort(0xc0005dbbf8, {0xc00097a600?, 0x7ffa49dae8c8?, 0x47bc5e?}, {0xc00094e660?, 0xc0003f79d0?, 0x47ba2e?})
	/usr/local/go/src/net/udpsock.go:203 +0x53
net.(*UDPConn).ReadMsgUDP(0xc001b4c930?, {0xc00097a600?, 0xc0008d5800?, 0xc003ea1e30?}, {0xc00094e660?, 0xc0003f7a30?, 0x40e107?})
	/usr/local/go/src/net/udpsock.go:191 +0x2a
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*sessionUDPFactory).ReadRequest(0xc0005dbbf8?, 0xc0005dbbf8)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/udp.go:178 +0x5f
github.com/miekg/dns.(*Server).readUDP(0xc0006e4f00, 0xc0005dbbf8, 0xc0047c44b0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:688 +0xed
github.com/miekg/dns.defaultReader.ReadUDP({0x470927?}, 0x3b88020?, 0xc0047c44b0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:174 +0x19
github.com/miekg/dns.(*Server).serveUDP(0xc0006e4f00, {0x3bc4870?, 0xc0005dbbf8?})
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:510 +0x2ae
github.com/miekg/dns.(*Server).ActivateAndServe(0xc0006e4f00)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:367 +0x125
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc0006e4f00)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:670 +0x20c
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:662 +0x939

goroutine 1017 [syscall, 3 minutes]:
os/signal.signal_recv()
	/usr/local/go/src/runtime/sigqueue.go:152 +0x2f
os/signal.loop()
	/usr/local/go/src/os/signal/signal_unix.go:23 +0x19
created by os/signal.Notify.func1.1
	/usr/local/go/src/os/signal/signal.go:151 +0x2a

goroutine 199 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000b42180, 0xc000b3e700)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 360 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 358 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000b7f838, 0x88)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000322a40?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000b7f810, 0xc000f781b0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000f35860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc000f78270}, 0x1, 0xc001afeae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000f358d8?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000f35860, 0xc001afeae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 466 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc002060048, 0x6)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc004ed8810?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc002060030, {0xc002821001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc002821001?, 0x2?, 0x3613591?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc000174b40)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc000174b40)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc000174b40, {0x30221e0, 0xc00438c6d8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc00004dd40, {0xc001560c00, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000afdd10, 0xc003d33800?, {0x3b9d990, 0xc004385540})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001072f80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00201ae80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 1090 [select, 3 minutes]:
github.com/cilium/cilium/pkg/hubble/observer.(*namespaceManager).Run(0x91812a?, {0x3bb56d8, 0xc000292370})
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/namespace_manager.go:50 +0xea
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:175 +0x141e

goroutine 255 [select]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).nodeEventLoop(0xc001d682c0, 0xc0011c70c8, 0x0?)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/node.go:67 +0x13b
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).NodesInit.func1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/node.go:55 +0x1b8

goroutine 1096 [select, 3 minutes]:
github.com/cilium/cilium/pkg/fswatcher.(*Watcher).loop(0xc001a449f0)
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:210 +0xdd
created by github.com/cilium/cilium/pkg/fswatcher.New
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:98 +0x1ea

goroutine 413 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc00011b6c0, 0xc001afeae0, 0xc0007dca80, 0xc0008c0fb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 1011 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobObserver[...]).start(0x3ba05e0, {0x3bb5780, 0xc001726540?}, 0x0, {{{0xc000f91620, 0x1, 0x1}}, {0x3be6410, 0xc0016d2690}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:480 +0x409
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 457 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc001769fc0}, {0x7ffa49960110, 0xc001afcbb0}, {0x3be8e60?, 0x35bf2a0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001686700, {0x0?, 0x0?}, 0xc001afea80, 0xc00107b380?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001686700, 0xc001afea80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001ab9500?, {0x3b878e0, 0xc0002bf860}, 0x1, 0xc001afea80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001686700, 0xc001afea80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 356 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0013780d0, 0x111)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0008b8240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 2144 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000e12006, 0x10, 0x1a}, {0xc0003ea210, 0x24}, 0xc00133f880?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1389 [select]:
net/http.(*persistConn).writeLoop(0xc001d36c60)
	/usr/local/go/src/net/http/transport.go:2410 +0xf2
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1766 +0x173d

goroutine 1839 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc003657b30, {0xc001e03078, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc003657b30, {0xc001e03078?, 0xc002b882a0?, 0xc003823560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc0037a87e0, {0xc001e03078?, 0xc0038235d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc0037a87e0}, {0xc001e03078, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc00081d440, {0xc001e03078, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc001e03068, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc0038237a8?, 0xc00081d440, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7ffa499130e0, 0x5e20750}, 0xc0038239f8?, {0x0?, 0x0?}, {0x3472d60, 0xc000a05540}, 0xc0020921e0?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc0008ec000, {0x3472d60?, 0xc000a05540})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/cilium/api.(*networkPolicyDiscoveryServiceStreamNetworkPoliciesServer).Recv(0xc0004341b0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/cilium/api/npds.pb.go:1709 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc0043b1260?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 198 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001686700, 0xc001afea80, 0xc0000d0d80, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 361 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc0003da640}, {0x7ffa49960110, 0xc000b7f810}, {0x3be8e60?, 0x35bfa20}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc00011b6c0, {0x0?, 0x0?}, 0xc001afeae0, 0xc001234100?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc00011b6c0, 0xc001afeae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001436000?, {0x3b878e0, 0xc0008222d0}, 0x1, 0xc001afeae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc00011b6c0, 0xc001afeae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 1837 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7ffa499d9868, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc00526a400?, 0xc0008f7000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsg(0xc00526a400, {0xc0008f7000, 0x1000, 0x1000}, {0x0, 0x0, 0x0}, 0x8?)
	/usr/local/go/src/internal/poll/fd_unix.go:304 +0x3aa
net.(*netFD).readMsg(0xc00526a400, {0xc0008f7000?, 0x0?, 0x0?}, {0x0?, 0xc00107d320?, 0xc00107d2f0?}, 0x4133e2?)
	/usr/local/go/src/net/fd_posix.go:78 +0x37
net.(*UnixConn).readMsg(0xc00091e7f8, {0xc0008f7000?, 0x2716d3a?, 0x2fcad80?}, {0x0?, 0xc000c6afb0?, 0xc?})
	/usr/local/go/src/net/unixsock_posix.go:115 +0x4f
net.(*UnixConn).ReadMsgUnix(0xc00091e7f8, {0xc0008f7000?, 0xc003d5dbb8?, 0x2?}, {0x0?, 0xc135ed47d2447e5e?, 0x92ff85976?})
	/usr/local/go/src/net/unixsock.go:143 +0x3c
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn(0xc000f8f790, {0x3bb56d8?, 0xc000299270}, 0xc00091e7f8)
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:118 +0x1a6
created by github.com/cilium/cilium/pkg/envoy.StartAccessLogServer.func1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:82 +0x138

goroutine 355 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0008b8360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 320 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0016862a0, 0xc00074f9e0, 0xc001d885a0, 0xc001ebcfb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 714 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7ffa499d9ef8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc0020cd200?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0020cd200)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc0020cd200)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*TCPListener).accept(0xc0006c0a80)
	/usr/local/go/src/net/tcpsock_posix.go:148 +0x25
net.(*TCPListener).Accept(0xc0006c0a80)
	/usr/local/go/src/net/tcpsock.go:297 +0x3d
google.golang.org/grpc.(*Server).Serve(0xc00281c000, {0x3bb3640?, 0xc0006c0a80})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:821 +0x475
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func4()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:293 +0x65
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:292 +0x2eac

goroutine 731 [select, 3 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync.func1(0xc000983380)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:871 +0x276
created by github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:863 +0x65

goroutine 333 [select, 2 minutes]:
reflect.rselect({0xc001f5cc60, 0x9, 0xc001af8798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc001f6e400?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001d528d0, {0x3bb5780, 0xc001d8fc50}, 0xc00075a070, {0x7ffa49913108, 0xc000fcd380}, 0xc001f6aba0, {0x36c7bac?, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001d528d0, {0x3bb5780, 0xc001d8fc50}, {0x7ffa49913108?, 0xc000fcd380?}, {0x36c7bac, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamClusters(0xc001ebab30?, {0x3bc6cb0, 0xc000fcd380})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:107 +0x70
github.com/cilium/proxy/go/envoy/service/cluster/v3._ClusterDiscoveryService_StreamClusters_Handler({0x34ffc60?, 0xc001d528d0}, {0x3bc0368?, 0xc0005ec2d0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:332 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001f341e0, {0x3bcc8e0, 0xc001b5f040}, 0xc00081c120, 0xc001f50c30, 0x5880860, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001f341e0, {0x3bcc8e0, 0xc001b5f040}, 0xc00081c120, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 330 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0xc000396230, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x115
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0xc001d96000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x91
google.golang.org/grpc/internal/transport.NewServerTransport.func2()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:341 +0xda
created by google.golang.org/grpc/internal/transport.NewServerTransport
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:338 +0x1bb3

goroutine 331 [select, 3 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0xc001b5f040)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1155 +0x233
created by google.golang.org/grpc/internal/transport.NewServerTransport
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:344 +0x1bf8

goroutine 332 [IO wait]:
internal/poll.runtime_pollWait(0x7ffa49dae7d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001a9e700?, 0xc00079c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001a9e700, {0xc00079c000, 0x8000, 0x8000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc001a9e700, {0xc00079c000?, 0x1060100000000?, 0x8?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc0005da158, {0xc00079c000?, 0xc001b5f1e0?, 0x0?})
	/usr/local/go/src/net/net.go:183 +0x45
bufio.(*Reader).Read(0xc0013021e0, {0xc001d6c120, 0x9, 0x0?})
	/usr/local/go/src/bufio/bufio.go:237 +0x1bb
io.ReadAtLeast({0x3b71ea0, 0xc0013021e0}, {0xc001d6c120, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
golang.org/x/net/http2.readFrameHeader({0xc001d6c120?, 0x9?, 0xc003ea54b8?}, {0x3b71ea0?, 0xc0013021e0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x6e
golang.org/x/net/http2.(*Framer).ReadFrame(0xc001d6c0e0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x95
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0xc001b5f040, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:642 +0x167
google.golang.org/grpc.(*Server).serveStreams(0xc001f341e0, {0x3bcc8e0?, 0xc001b5f040})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:946 +0x162
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:889 +0x46
created by google.golang.org/grpc.(*Server).handleRawConn
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:888 +0x185

goroutine 334 [select, 2 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc000396460, {0xc001d8b300, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc000396460, {0xc001d8b300?, 0xc001a94810?, 0xc000993560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc001d8fb30, {0xc001d8b300?, 0xc0009935d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc001d8fb30}, {0xc001d8b300, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc00081c120, {0xc001d8b300, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc001d8b2f0, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0x5e23660?, 0xc00081c120, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7ffa499130e0, 0x5e20750}, 0xc0009939f8?, {0x0?, 0x0?}, {0x3472d60, 0xc000a054a0}, 0xc001302300?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc0005ec2d0, {0x3472d60?, 0xc000a054a0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/cluster/v3.(*clusterDiscoveryServiceStreamClustersServer).Recv(0xc000fcd380)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:351 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc00075a070?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 336 [select, 2 minutes]:
reflect.rselect({0xc0004125a0, 0x9, 0xc001e4e798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc0006ea400?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001d528d0, {0x3bb5780, 0xc001b4c720}, 0xc001af0150, {0x7ffa498ce9c0, 0xc000f863c0}, 0xc001afe1e0, {0x36cf89b?, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001d528d0, {0x3bb5780, 0xc001b4c720}, {0x7ffa498ce9c0?, 0xc000f863c0?}, {0x36cf89b, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamListeners(0xc001ebab30?, {0x3bc6e10, 0xc000f863c0})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:79 +0x70
github.com/cilium/proxy/go/envoy/service/listener/v3._ListenerDiscoveryService_StreamListeners_Handler({0x34ffc60?, 0xc001d528d0}, {0x3bc0368?, 0xc00131c1e0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:359 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001f341e0, {0x3bcc8e0, 0xc001b5f040}, 0xc00081d200, 0xc001f50d50, 0x5880900, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001f341e0, {0x3bcc8e0, 0xc001b5f040}, 0xc00081d200, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 418 [select, 2 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc0003b2c80, {0xc001b189a0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc0003b2c80, {0xc001b189a0?, 0xc001a950b0?, 0xc002037560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc00081a630, {0xc001b189a0?, 0xc0020375d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc00081a630}, {0xc001b189a0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc00081d200, {0xc001b189a0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc001b18990, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc0020377a8?, 0xc00081d200, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7ffa499130e0, 0x5e20750}, 0xc0020379f8?, {0x0?, 0x0?}, {0x3472d60, 0xc000846500}, 0xc002028a20?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc00131c1e0, {0x3472d60?, 0xc000846500})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/listener/v3.(*listenerDiscoveryServiceStreamListenersServer).Recv(0xc000f863c0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:378 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc001af0150?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 2034 [select, 2 minutes]:
reflect.rselect({0xc00157c360, 0x9, 0xc0037c8798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc004464200?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001d528d0, {0x3bb5780, 0xc000738000}, 0xc000994e00, {0x7ffa49c6e840, 0xc0007a9b50}, 0xc002dfc600, {0x36f79e0?, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001d528d0, {0x3bb5780, 0xc000738000}, {0x7ffa49c6e840?, 0xc0007a9b50?}, {0x36f79e0, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamEndpoints(0xc001ebfb30?, {0x3bc6d60, 0xc0007a9b50})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:121 +0x70
github.com/cilium/proxy/go/envoy/service/endpoint/v3._EndpointDiscoveryService_StreamEndpoints_Handler({0x34ffc60?, 0xc001d528d0}, {0x3bc0368?, 0xc000e8e3c0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:338 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001f341e0, {0x3bcc8e0, 0xc001b5f040}, 0xc001f5c360, 0xc001f50ba0, 0x58808a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001f341e0, {0x3bcc8e0, 0xc001b5f040}, 0xc001f5c360, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 249 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0007747e0, 0xc001d88e40, 0xc001ec8420, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 432 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 250 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000624000, 0xc000533600)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xc001024940?, 0xc001b5f040?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 251 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000624048, 0x4)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc003351380?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000624030, {0xc003322001, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc003322001?, 0x2?, 0x3613591?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc000c68140)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc000c68140)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc000c68140, {0x30221e0, 0xc003e54e58})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc00089c060, {0xc001846c00, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000450320, 0xc003e62070?, {0x3b9d990, 0xc003e5e780})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0010c8900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc00073aac0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 422 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc002029200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 423 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc001d90b10, 0x1b)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0020290e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 424 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 425 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc002029380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 426 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc001d90bd0, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc002029260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 427 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 428 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc002029500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 429 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc001d90c50, 0x8)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0020293e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 430 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 1089 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001b13440, {0x38057e0, 0x0, 0x3805780, 0x37e11d600, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001a3a140}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 437 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 1095 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7ffa49dae058, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc0015e1260?, 0xc002cafed0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0015e1260, {0xc002cafed0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:31
os.(*File).Read(0xc0009aa8a0, {0xc002cafed0?, 0x0?, 0x0?})
	/usr/local/go/src/os/file.go:118 +0x5e
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc001a3a280)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:356 +0xdf
created by github.com/fsnotify/fsnotify.NewWatcher
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:150 +0x1b0

goroutine 460 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc001afcc88, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc002085c18?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001afcc60, 0xc0009591a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001b545a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc0001bfa10}, 0x1, 0xc001afeb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001b54618?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001b545a0, 0xc001afeb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 402 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000972780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 403 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000eac010, 0x12)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0009720c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 404 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 454 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc001afcbd8, 0x3)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc00107b240?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001afcbb0, 0xc0009589c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001b54500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc000958a50}, 0x1, 0xc001afea80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001b54578?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001b54500, 0xc001afea80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 577 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000b421c8, 0x5)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc002031d68?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000b421b0, {0xc003fc8e10, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0xc003fc8e10?}, {0xc003fc8e10?, 0xc002031d08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7ffa49960040, 0xc000b42180}, {0xc003fc8e10, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc001d403f0, {0xc000d86800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000ab5040, 0xc003f98c80?, {0x3b9d990, 0xc003fccbc0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0011cc2c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001769fc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 499 [select, 2 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).serviceEventLoop(0xc001d682c0, 0xc0011c742c, 0xc001dcc778?)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:41 +0x131
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).servicesInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:29 +0x1b8

goroutine 501 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000818960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 502 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc00073be50, 0x7)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc000818840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 503 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 504 [select, 2 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).namespacesInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:48 +0xce
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).namespacesInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:46 +0x20a

goroutine 1322 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0001add40, {0xc00095e480, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001a3ab90}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 691 [select, 3 minutes]:
github.com/cilium/cilium/pkg/datapath/loader.(*objectCache).watchTemplatesDirectory(0xc0008b5e50, {0x3bb56d8, 0xc000c667d0})
	/go/src/github.com/cilium/cilium/pkg/datapath/loader/cache.go:342 +0x225
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0000d2360, {0xc001422f50, 0x0, 0x3805780, 0x0, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000c667d0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 507 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000818ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 508 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00073bf10, 0x4b)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0008189c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 509 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 510 [select]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).endpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:43 +0xf8
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).endpointsInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:41 +0x285

goroutine 2083 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0003e26c0, {0xc001815278, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0003b51d0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 486 [chan receive]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).podsInit.func1.1()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:123 +0x131
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).podsInit.func1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:121 +0xf8

goroutine 340 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000d98c60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 1382 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0015806c0, {0xc000f60810, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000c66640}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 512 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc00075ea78, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0008bfc48?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc00075ea50, 0xc00073bfc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001326a00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc00081aa20}, 0x1, 0xc001f6a420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001326a78?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001326a00, 0xc001f6a420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).networkPoliciesInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/network_policy.go:74 +0x35a

goroutine 514 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc00075eb28, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x40?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc00075eb00, 0xc000f98180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001326aa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc000176000}, 0x1, 0xc001f6a420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001326b18?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001326aa0, 0xc001f6a420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).tlsSecretInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/secret.go:90 +0x253

goroutine 515 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNetworkPoliciesInit.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_network_policy.go:108 +0x372
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNetworkPoliciesInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_network_policy.go:89 +0x158

goroutine 735 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00025c240, {0xc000e26100, 0x0, 0x3805780, 0x0, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000ab4640}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 709 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc0003daa40}, {0x7ffa49960110, 0xc00144c6e0}, {0x3be8e60?, 0x358dde0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc000022460, {0x0?, 0x0?}, 0xc000f522a0, 0xc000323b40?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc000022460, 0xc000f522a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000da9340?, {0x3b878e0, 0xc0006c6af0}, 0x1, 0xc000f522a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc000022460, 0xc000f522a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 1237 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc002824aa0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0032358c0, {0xc0001ce840, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc002824aa0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 519 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNodeInit(0xc001d682c0, {0x3bf05a0, 0xc0006cdef0}, 0xc0011c7410)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:136 +0x656
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).enableK8sWatchers
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:557 +0x5c5

goroutine 520 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEndpointsInit(0xc001d682c0, {0x3bf05a0, 0xc0006cdef0}, 0xc0011c7410)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:101 +0x76
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).initCiliumEndpointOrSlices
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:1074 +0x152

goroutine 370 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0009db7a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 671 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0015ae948, 0x1f)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0041700c0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc0015ae930, {0xc00287f001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc00287f001?, 0x2?, 0x3613591?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc0020ba500)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0020ba500)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc0020ba500, {0x30221e0, 0xc003fcf530})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc000f8bc80, {0xc0015e8a00, 0x1000, 0x1500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000427b80, 0xc003f9f860?, {0x3b9d990, 0xc003fcd800})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0003bee40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0003daa40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 371 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc000f9a190, 0x1a)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0009db680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 1084 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000a85246, 0x10, 0x1a}, {0xc0007d0210, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 372 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 523 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00075ebd8, 0x2b)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000322080?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc00075ebb0, 0xc000f982c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001326b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc00089d8c0}, 0x1, 0xc001ec9a40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001326bb8?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001326b40, 0xc001ec9a40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEndpointsInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:99 +0x6a

goroutine 524 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0x736569636e65646e?)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x37
created by github.com/cilium/cilium/pkg/kvstore.Connected
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x72

goroutine 3061 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0043658c0, {0xc001815440, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00432edc0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 525 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 341 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc001769650, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc000d98b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 490 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc000c22028, 0x3)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0011cdd00?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000c22000, 0xc000f9e200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000846000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc000f8a120}, 0x1, 0xc000825320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000846078?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000846000, 0xc000825320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNodeInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:134 +0x64a

goroutine 342 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 491 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0xc0011c7410?)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x37
created by github.com/cilium/cilium/pkg/kvstore.Connected
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x72

goroutine 1242 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc002824e60})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00130cea0, {0xc0001cec50, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc002824e60}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 705 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc00144c708, 0x1c)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000073960?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc00144c6e0, 0xc001593400)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000b72460)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc0000d74a0}, 0x1, 0xc000f522a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000b724d8?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000b72460, 0xc000f522a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/identitybackend.(*crdBackend).ListAndWatch(0xc0000d6ea0, {0xc00091c320?, 0xd?}, {0x3bb59e8?, 0xc000983438}, 0xc000f522a0)
	/go/src/github.com/cilium/cilium/pkg/k8s/identitybackend/identity.go:396 +0x53d
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:204 +0x4d
created by github.com/cilium/cilium/pkg/allocator.(*cache).start
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:203 +0x118

goroutine 73 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 438 [select, 3 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc0003da400}, {0x7ffa49960110, 0xc00075ea50}, {0x3be8e60?, 0x35c1460}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001d6c460, {0x0?, 0x0?}, 0xc001f6a420, 0xc0010253c0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001d6c460, 0xc001f6a420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001760000?, {0x3b878e0, 0xc0003b3540}, 0x1, 0xc001f6a420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001d6c460, 0xc001f6a420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 411 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001d6c460, 0xc001f6a420, 0xc0007dc660, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 531 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 343 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000d98de0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 526 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc001378400}, {0x7ffa49960110, 0xc00075ebb0}, {0x3be8e60?, 0x358d5a0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001446380, {0x0?, 0x0?}, 0xc001ec9a40, 0xc0010c96e0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001446380, 0xc001ec9a40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00073da40?, {0x3b878e0, 0xc0004511d0}, 0x1, 0xc001ec9a40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001446380, 0xc001ec9a40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 200 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001446380, 0xc001ec9a40, 0xc0000d1260, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 529 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc0015fe028, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x505167?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0015fe000, 0xc000f680f0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000a5c000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc000f681b0}, 0x1, 0xc001d88d80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000a5c078?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000a5c000, 0xc001d88d80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 344 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc001769850, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc000d98cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 345 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 346 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000d98f60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 347 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc0017698d0, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc000d98e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 348 [select, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 532 [select, 3 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc000352880}, {0x7ffa49960110, 0xc0015fe000}, {0x3be8e60?, 0x35a2620}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0018680e0, {0x0?, 0x0?}, 0xc001d88d80, 0xc000072220?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0018680e0, 0xc001d88d80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0018320c0?, {0x3b878e0, 0xc0000ce910}, 0x1, 0xc001d88d80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0018680e0, 0xc001d88d80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 349 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc001ff8028, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x505167?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001ff8000, 0xc000e864b0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc001ffa000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc00081acc0}, 0x1, 0xc001d88de0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc001ffa078?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc001ffa000, 0xc001d88de0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 676 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0018680e0, 0xc001d88d80, 0xc00208efc0, 0xc0012d2fb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 3575 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002faab40, {0xc002bd3030, 0x0, 0xc002a9d4a0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002fac000}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 412 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000e00000, 0xc0007fe400)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa00fc5e01?, 0xc001440fa0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 74 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc000977b00}, {0x7ffa49960110, 0xc000c22000}, {0x3be8e60?, 0x358fc00}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001620000, {0x0?, 0x0?}, 0xc000825320, 0xc0003be0a0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001620000, 0xc000825320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001e201c0?, {0x3b878e0, 0xc000426c30}, 0x1, 0xc000825320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001620000, 0xc000825320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 441 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 1243 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc002cce4b0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 567 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 560 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001620000, 0xc000825320, 0xc000c7a780, 0x2f?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 374 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 80 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000e001c8, 0x8f)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000897d68?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000e001b0, {0xc00419493c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc00419493c?, 0xc000897d08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7ffa49960040, 0xc000e00180}, {0xc00419493c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc0003fe2d0, {0xc002d52000, 0x8000, 0xa000})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000427810, 0xc004205e00?, {0x3b9d990, 0xc00418b700})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0003be960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0003da640)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 442 [select, 3 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc001378cc0}, {0x7ffa49960110, 0xc001ff8000}, {0x3be8e60?, 0x359a3a0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001d6c7e0, {0x0?, 0x0?}, 0xc001d88de0, 0xc0010256e0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001d6c7e0, 0xc001d88de0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001760040?, {0x3b878e0, 0xc0003b3950}, 0x1, 0xc001d88de0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001d6c7e0, 0xc001d88de0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 202 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001d6c7e0, 0xc001d88de0, 0xc0000d1680, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 375 [select, 3 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc0013791c0}, {0x7ffa49960110, 0xc001afcc60}, {0x3be8e60?, 0x3589640}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001e140e0, {0x0?, 0x0?}, 0xc001afeb40, 0xc0011de820?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001e140e0, 0xc001afeb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0013be100?, {0x3b878e0, 0xc000abe370}, 0x1, 0xc001afeb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001e140e0, 0xc001afeb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 673 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001e140e0, 0xc001afeb40, 0xc00208eae0, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 364 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000b42348, 0x2e)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc001aceed0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000b42330, {0xc0008f6001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc0008f6001?, 0x2?, 0x3613591?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc001eee140)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc001eee140)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc001eee140, {0x30221e0, 0xc00419b278})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc000f787e0, {0xc0017ef500, 0x1000, 0x1500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000822410, 0xc0041a6540?, {0x3b9d990, 0xc0041c6700})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001234360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001378400)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 203 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000b42480, 0xc000b3ef00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa007a6001?, 0xc0000a37a0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 561 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc00083c300, 0xc000854600)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa01266001?, 0xc000837fa0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 194 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 1091 [chan receive]:
github.com/cilium/cilium/pkg/hubble/observer.(*LocalObserverServer).Start(0xc0006f9b80)
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/local_observer.go:121 +0xa9
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:187 +0x1645

goroutine 618 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000e00780, 0xc0007ff400)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa0144e001?, 0xc001dcefa0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 674 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc001eec480, 0xc001ee8700)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa01162001?, 0xc0008cdfa0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 414 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000e00180, 0xc0007fec00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xc001682030?, 0xc001ee4fb8?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 195 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc000977c00}, {0x7ffa49960110, 0xc00075eb00}, {0x3be8e60?, 0x35bfde0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0000220e0, {0x0?, 0x0?}, 0xc001f6a420, 0xc000322080?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0000220e0, 0xc001f6a420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000081100?, {0x3b878e0, 0xc0006c6000}, 0x1, 0xc001f6a420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0000220e0, 0xc001f6a420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 77 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0000220e0, 0xc001f6a420, 0xc00045ade0, 0x2022797469727563?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 566 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 78 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0020b0180, 0xc0020ae700)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa01266001?, 0xc000837fa0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 79 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc000e00048, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0007d9380?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000e00030, {0xc0012663b8, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0xc000f8a540?}, {0xc0012663b8?, 0xc001476d08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7ffa49960040, 0xc000e00000}, {0xc0012663b8, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc0003fe288, {0xc0020bc000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000427770, 0xc0000220e0?, {0x3b9d990, 0xc0003da440})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0003be940)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0003da400)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 368 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc000b424c8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000a64b98?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000b424b0, {0xc001ef0800, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc001ef0800?, 0xffffffffffffffff?, 0xffffffffffffffff?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc001eeea00)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc001eeea00)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc001eeea00, {0x30221e0, 0xc000828540})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc000f79170, {0xc001eeac00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000822780, 0xc00045be00?, {0x3b9d990, 0xc001378d00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001234500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001378cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 445 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00083c348, 0x6)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0031ea150?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc00083c330, {0xc00244d001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc00244d001?, 0x2?, 0x3613591?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc0006f8c80)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0006f8c80)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc0006f8c80, {0x30221e0, 0xc003e558a8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc00081bce0, {0xc00066f400, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0003b3ae0, 0xc003e60960?, {0x3b9d990, 0xc003e5eb40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001025ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000977b00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 446 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0020b01c8, 0x3)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc001aafd68?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc0020b01b0, {0xc003fc8f64, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc003fc8f64?, 0xc001aafd08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7ffa49960040, 0xc0020b0180}, {0xc003fc8f64, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc000748900, {0xc000962800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0003b3d10, 0xc003fc5920?, {0x3b9d990, 0xc003fccf00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001025b00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000977c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 447 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 610 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc0009f00d8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x505167?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0009f00b0, 0xc000c43200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000a00820)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc00081bec0}, 0x1, 0xc001f6ab40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000a00898?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000a00820, 0xc001f6ab40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumClusterwideEnvoyConfigInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_clusterwide_envoy_config.go:79 +0x330

goroutine 612 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc0009f0188, 0x4)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc001234f20?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0009f0160, 0xc000c43300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000a008c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc00034b980}, 0x1, 0xc001f6ab40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000a00938?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000a008c0, 0xc001f6ab40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEnvoyConfigInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_envoy_config.go:84 +0x338

goroutine 613 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 679 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7ffa49dae508, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc0008b8c60?, 0xc002279ed0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0008b8c60, {0xc002279ed0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:31
os.(*File).Read(0xc000a38168, {0xc002279ed0?, 0x0?, 0x0?})
	/usr/local/go/src/os/file.go:118 +0x5e
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc000822dc0)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:356 +0xdf
created by github.com/fsnotify/fsnotify.NewWatcher
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:150 +0x1b0

goroutine 614 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc001593000}, {0x7ffa49960110, 0xc0009f0160}, {0x3be8e60?, 0x358d860}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001807340, {0x0?, 0x0?}, 0xc001f6ab40, 0xc00110d040?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001807340, 0xc001f6ab40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000406d20?, {0x3b878e0, 0xc0008b5b80}, 0x1, 0xc001f6ab40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001807340, 0xc001f6ab40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 617 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001807340, 0xc001f6ab40, 0xc0007ddec0, 0xc00201ae80?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 448 [select, 3 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc001592e40}, {0x7ffa49960110, 0xc0009f00b0}, {0x3be8e60?, 0x358d020}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001d6cb60, {0x0?, 0x0?}, 0xc001f6ab40, 0xc001025ba0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001d6cb60, 0xc001f6ab40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00077eeb0?, {0x3b878e0, 0xc0003b3db0}, 0x1, 0xc001f6ab40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001d6cb60, 0xc001f6ab40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 204 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001d6cb60, 0xc001f6ab40, 0xc0000d1b60, 0xc00156ffb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 1235 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000a00000)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1378 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0005c8b40, {0xc0008ba018, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000450870}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1428 [IO wait]:
internal/poll.runtime_pollWait(0x7ffa499d90e8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc00311e980?, 0xc002cde000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00311e980, {0xc002cde000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc00311e980, {0xc002cde000?, 0x4e7b66?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000e4e1c8, {0xc002cde000?, 0x0?, 0xc004b94548?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*connReader).Read(0xc004b94540, {0xc002cde000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:782 +0x171
bufio.(*Reader).fill(0xc002cda1e0)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc002cda1e0, 0x4)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*conn).serve(0xc000cf7710, {0x3bb5780, 0xc001579e30})
	/usr/local/go/src/net/http/server.go:2030 +0x77c
created by net/http.(*Server).Serve
	/usr/local/go/src/net/http/server.go:3089 +0x5ed

goroutine 1240 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000a000a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1239 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc003235d40, {0xc000169880, 0x0, 0xc0014b00f0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002824b40}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1385 [select]:
net/http.(*persistConn).writeLoop(0xc00140de60)
	/usr/local/go/src/net/http/transport.go:2410 +0xf2
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1766 +0x173d

goroutine 1068 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0000d2120, {0xc00004ab70, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0003b2460}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1410 [select, 3 minutes]:
net/http.(*persistConn).writeLoop(0xc0005e0fc0)
	/usr/local/go/src/net/http/transport.go:2410 +0xf2
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1766 +0x173d

goroutine 1203 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc00142c106, 0x10, 0x1a}, {0xc002d00150, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 708 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 207 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000e007c8, 0x7)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc001ace900?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000e007b0, {0xc000356001, 0x1dff, 0x1dff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc000356001?, 0x2?, 0x3613591?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc000df6a00)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc000df6a00)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc000df6a00, {0x30221e0, 0xc00419b0b0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0000d6e10, {0xc00154c000, 0x2000, 0x2500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0006c69b0, 0xc0041a6420?, {0x3b9d990, 0xc0041c66c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000323a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001593000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 968 [select, 3 minutes]:
github.com/cilium/cilium/pkg/stream.FromChannel[...].func1.1()
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:109 +0xde
created by github.com/cilium/cilium/pkg/stream.FromChannel[...].func1
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:106 +0xea

goroutine 1238 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc001ee5fd0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000fd4040?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 747 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000e6e086, 0x10, 0x1a}, {0xc0011500c0, 0x24}, 0xc002cced20?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1115 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x24bb240?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001727e30?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1354 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001acab40, {0xc0009c6680, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002b9d630}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 729 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc000022460, 0xc000f522a0, 0xc001ac0180, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 3800 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001ad8000, {0xc00094ca50, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002aefb30}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 730 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0015ae900, 0xc0014f9200)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0x0?, 0xc001851f98?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 201 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000b42300, 0xc000b3eb00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0x365e6e3?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 675 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc001eec4c8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc001eec4b0, {0xc001ef0c00, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc001ef0c00?, 0x0?, 0x3b72340?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc001eeedc0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc001eeedc0)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc001eeedc0, {0x30221e0, 0xc000828828})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc000f79bf0, {0xc001eeb800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000822a50, 0xc001df9fd0?, {0x3b9d990, 0xc0013792c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001234860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0013791c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 677 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc001eec600, 0xc001ee8b00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xc0012e4f50?, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 678 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc001eec648, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc001eec638?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc001eec630, {0xc001ef1000, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc001ef1000?, 0x3?, 0x3b72300?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc001eef040)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc001eef040)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc001eef040, {0x30221e0, 0xc000828a38})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0006cb500, {0xc0013fc000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000822cd0, 0xc0020ccfd0?, {0x3b9d990, 0xc000352940})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001234ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000352880)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 205 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000b42600, 0xc000b3f300)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0x365e6e3?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 206 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc000b42648, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000b42638?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000b42630, {0xc000b78a00, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc000b78a00?, 0x3?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc000df6500)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc000df6500)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc000df6500, {0x30221e0, 0xc001e03230})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0000d6a80, {0xc001404800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0006c68c0, 0x0?, {0x3b9d990, 0xc001592e80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000323a00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001592e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 1251 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000d802a6, 0x10, 0x1a}, {0xc001862270, 0x24}, 0xc000f40450?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 563 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00089e000, {0xc00095e048, 0x0, 0xc00095e078, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0006c6230}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1013 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0013b2a20, {0xc0001b6690, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0008235e0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3263 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001d5aad0, 0x39)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000c20df0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc001d5aa80, {0x3bb56d8, 0xc0007f3090}, {0xc002fb1220, 0x42}, 0xf, {0xc0016d0225, 0x9}, {0xc000c20df0, 0x1, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 1034 [sleep]:
time.Sleep(0x12a05f200)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer(0xc0015d3230)
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:123 +0x54d
created by github.com/cilium/cilium/cilium-health/launch.Launch
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:68 +0x225

goroutine 1012 [select, 3 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobTimer).start(0xc000293040, {0x3bb5780, 0xc0017265a0}, 0xc001d89440?, {{{0xc000f91620, 0x1, 0x1}}, {0x3be6410, 0xc0016d2690}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:384 +0x3c5
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 1112 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc00096ee60)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1259 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000df8140)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1028 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0010f8000, {0xc0003a3340, 0x0, 0xc0015d2ab0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001f4e140}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3136 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc004644120, {0xc000502e40, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00461a730}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1150 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc00182e026, 0x10, 0x1a}, {0xc003114240, 0x24}, 0xc00135baa0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1128 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000d80246, 0x10, 0x1a}, {0xc0018620f0, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1031 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0010f85a0, {0xc002094a08, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001f4e4b0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1025 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001326c80)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 3727 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0015b9e60, {0xc00026a6e0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002043590}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1014 [select]:
github.com/cilium/cilium/pkg/hive/job.(*jobTimer).start(0xc000293180, {0x3bb5780, 0xc0017267b0}, 0x0?, {{{0x0, 0x0, 0x0}}, {0x3be6500, 0xc001a9e780}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:384 +0x3c5
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 987 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001d377a0, {0xc001b19bd8, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000823180}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1026 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001f4e0a0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0013c3b00, {0xc000933560, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001f4e0a0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2129 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001607b00, {0xc0001cd180, 0x0, 0xc0042808d0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00302cc80}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 989 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1.1()
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:417 +0xcd
created by github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:413 +0x9b

goroutine 1015 [select, 2 minutes]:
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).cycle(0xc0016d32d0, {0x3bb5780, 0xc001726a20}, 0x413bb7?, 0xc001dda000)
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:115 +0x1cb
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).run(0xc0016d32d0, {0x3bb5780, 0xc001726a20})
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:93 +0xd1
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc000293310, {0x3bb5780, 0xc001726a20}, 0xc001ec8e40?, {{{0xc001024180, 0x1, 0x1}}, {0x3be6410, 0xc0016d31f0}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:267 +0x530
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 1010 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobObserver[...]).start(0x3ba0560, {0x3bb5780, 0xc0017264e0?}, 0x0, {{{0xc000f91620, 0x1, 0x1}}, {0x3be6410, 0xc0016d2690}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:480 +0x409
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 1027 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00135bce0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1092 [syscall]:
syscall.Syscall6(0xc000f99bc0?, 0xc000f1b5e0?, 0x50?, 0x48?, 0xc0026f5840?, 0x1000000004e14da?, 0x3b72340?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x36
golang.org/x/sys/unix.EpollWait(0x30?, {0xc001ad6480?, 0xc0000ba140?, 0x3b72340?}, 0x22d13ab?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:56 +0x58
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:125
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0xc000254340, {0xc001ad6480?, 0x20, 0x20}, {0x2550da0?, 0xc0016d2310?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x2b4
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0xc001d3ee40, 0xc001d97570?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:345 +0x2d6
github.com/cilium/ebpf/perf.(*Reader).Read(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:319
github.com/cilium/cilium/pkg/monitor/agent.(*agent).handleEvents(0xc0016d2310, {0x3bb56d8, 0xc001a3a230})
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:340 +0x485
created by github.com/cilium/cilium/pkg/monitor/agent.(*agent).startPerfReaderLocked
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:209 +0xe5

goroutine 1093 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7ffa49dae418, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001a04600?, 0xc00107bc40?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001a04600)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc001a04600)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*UnixListener).accept(0xc001e07410?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x1c
net.(*UnixListener).Accept(0xc001a44480)
	/usr/local/go/src/net/unixsock.go:260 +0x3d
google.golang.org/grpc.(*Server).Serve(0xc0008b03c0, {0x3bb3670?, 0xc001a44480})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:821 +0x475
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func2()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:231 +0x59
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:230 +0x230f

goroutine 990 [semacquire, 3 minutes]:
sync.runtime_Semacquire(0x3124be0?)
	/usr/local/go/src/runtime/sema.go:62 +0x27
sync.(*WaitGroup).Wait(0xc00083c000?)
	/usr/local/go/src/sync/waitgroup.go:116 +0x4b
github.com/cilium/cilium/api/v1/server.(*Server).Serve(0xc00083c000)
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:385 +0x6b
github.com/cilium/cilium/daemon/cmd.runDaemon(_, _, _, {{{}}, {0x3b77d80, 0xc00034b7a0}, {0x3bf05a0, 0xc0006cdef0}, {0x3bdc150, 0xc0012e6800}, ...})
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:1876 +0x15f3
github.com/cilium/cilium/daemon/cmd.newDaemonPromise.func1.1()
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:1657 +0x78
created by github.com/cilium/cilium/daemon/cmd.newDaemonPromise.func1
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:1656 +0x198

goroutine 1403 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0015a2b40, {0xc00110e6c0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00208c230}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1715 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00302f560, {0xc00159a5d0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00178d360}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1145 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc00182e006, 0x10, 0x1a}, {0xc003114180, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1286 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc00178d770})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0013b2ea0, {0xc0002308e0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc00178d770}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 991 [syscall, 3 minutes]:
syscall.Syscall6(0x20?, 0x80000000000?, 0xc001e1f958?, 0x4eaee6?, 0xc000082180?, 0xc001e1fa08?, 0x4eae23?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x36
golang.org/x/sys/unix.EpollWait(0x0?, {0xc0012e2a80?, 0xc000082180?, 0xc001e1f9f0?}, 0xc001e1fa70?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:56 +0x58
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:125
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0xc00107b8a0, {0xc0012e2a80?, 0x20, 0x20}, {0x0?, 0xc001e1fac0?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x2b4
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0xc0011a0d80, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:345 +0x2d6
github.com/cilium/ebpf/perf.(*Reader).Read(0xc0001dd570?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:319 +0x46
github.com/cilium/cilium/pkg/signal.(*signalManager).start.func1()
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:266 +0x8d
created by github.com/cilium/cilium/pkg/signal.(*signalManager).start
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:263 +0x12c

goroutine 1287 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1293 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001b543c0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1108 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000efc026, 0x10, 0x1a}, {0xc00094e0c0, 0x24}, 0xc002ccec90?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1094 [chan receive, 3 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func3()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:236 +0x3e
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:235 +0x238c

goroutine 1288 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0013b3560, {0xc001af0a80, 0x0, 0xc0010973e0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00178d810}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1212 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00208e900?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1114 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc000ab5770})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001d36a20, {0xc0001d2660, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc000ab5770}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1303 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00133f880?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1087 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000a85266, 0x10, 0x1a}, {0xc0007d02a0, 0x24}, 0xc001810f90?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1371 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0005e05a0, {0xc0004106a0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000ab5b30}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1926 [select, 2 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc003657c20, {0xc001710040, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc003657c20, {0xc001710040?, 0xc002b882b8?, 0xc0035fd560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc0037a8930, {0xc001710040?, 0xc0035fd5d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc0037a8930}, {0xc001710040, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc00081d560, {0xc001710040, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc001710030, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc0035fd7a8?, 0xc00081d560, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7ffa499130e0, 0x5e20750}, 0xc0035fd9f8?, {0x0?, 0x0?}, {0x3472d60, 0xc000ea0280}, 0xc000973da0?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc00297c000, {0x3472d60?, 0xc000ea0280})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/route/v3.(*routeDiscoveryServiceStreamRoutesServer).Recv(0xc0011d0010)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/route/v3/rds.pb.go:365 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc0012f8850?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 683 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:246 +0x116
created by github.com/cilium/cilium/pkg/stream.Multicast[...].func3
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:239 +0x3aa

goroutine 925 [select, 3 minutes]:
github.com/cilium/cilium/pkg/maps/ctmap/gc.Enable.func1()
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:115 +0x3a5
created by github.com/cilium/cilium/pkg/maps/ctmap/gc.Enable
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:43 +0x20a

goroutine 713 [select, 3 minutes]:
github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch.func2()
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:138 +0x185
created by github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:135 +0x258

goroutine 1116 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001d370e0, {0xc00013cf50, 0x0, 0xc002dc9ef0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000ab58b0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2037 [select, 1 minutes]:
reflect.rselect({0xc003c1bd40, 0x9, 0xc0037e6798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc003336000?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001d528d0, {0x3bb5780, 0xc0051f81e0}, 0xc0020893b0, {0x7ffa49c6e840, 0xc00051eac0}, 0xc001d886c0, {0x36f79e0?, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001d528d0, {0x3bb5780, 0xc0051f81e0}, {0x7ffa49c6e840?, 0xc00051eac0?}, {0x36f79e0, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamEndpoints(0xc004ebab30?, {0x3bc6d60, 0xc00051eac0})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:121 +0x70
github.com/cilium/proxy/go/envoy/service/endpoint/v3._EndpointDiscoveryService_StreamEndpoints_Handler({0x34ffc60?, 0xc001d528d0}, {0x3bc0368?, 0xc002bfe0f0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:338 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001f341e0, {0x3bcc8e0, 0xc001b5f040}, 0xc001f5c6c0, 0xc001f50ba0, 0x58808a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001f341e0, {0x3bcc8e0, 0xc001b5f040}, 0xc001f5c6c0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 750 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000e6e0a6, 0x10, 0x1a}, {0xc001150120, 0x24}, 0xc001727ec0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2458 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001f4c360, {0xc001b18630, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0031e11d0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1211 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc00178ce60})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0010dc000, {0xc0010797a0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc00178ce60}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1209 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001b54140)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1304 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001e10120, {0xc00034fdc0, 0x0, 0xc0010d2f60, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00208c690}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1284 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001b54280)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 568 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 569 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 570 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 571 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 572 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 573 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 574 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 575 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 576 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1041 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1042 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1043 [IO wait]:
internal/poll.runtime_pollWait(0x7ffa49dae238, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc000874000?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc000874000)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc000874000)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*TCPListener).accept(0xc00095e498)
	/usr/local/go/src/net/tcpsock_posix.go:148 +0x25
net.(*TCPListener).Accept(0xc00095e498)
	/usr/local/go/src/net/tcpsock.go:297 +0x3d
net/http.(*Server).Serve(0xc001b14000, {0x3bb3640, 0xc00095e498})
	/usr/local/go/src/net/http/server.go:3059 +0x385
github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService.func2({0xc0013a60b0, 0xe}, {0x3bb3640, 0xc00095e498})
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:75 +0xdb
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:70 +0x6aa

goroutine 1591 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0016b3e60, {0xc00034ef50, 0x0, 0xc0009e3980, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001c84b90}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1302 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc00208c5f0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000b64fc0, {0xc0001d38e0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc00208c5f0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3355 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0032ea780)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1373 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000f35900)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1046 [IO wait]:
internal/poll.runtime_pollWait(0x7ffa499d9e08, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc002c2f280?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc002c2f280)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc002c2f280)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*UnixListener).accept(0x46e74e?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x1c
net.(*UnixListener).Accept(0xc002cce330)
	/usr/local/go/src/net/unixsock.go:260 +0x3d
net/http.(*Server).Serve(0xc002bfef00, {0x3bb3670, 0xc002cce330})
	/usr/local/go/src/net/http/server.go:3059 +0x385
github.com/cilium/cilium/api/v1/server.(*Server).Start.func1({0x3bb3670?, 0xc002cce330?})
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:433 +0x85
created by github.com/cilium/cilium/api/v1/server.(*Server).Start
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:431 +0x552

goroutine 1048 [syscall, 3 minutes]:
syscall.Syscall6(0x451705?, 0xc002c703d8?, 0xc002c37ce0?, 0x443fd1?, 0xc002c70400?, 0xc002c37d10?, 0xc0029d5d40?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x36
os.(*Process).blockUntilWaitable(0xc002b57a70)
	/usr/local/go/src/os/wait_waitid.go:32 +0x87
os.(*Process).wait(0xc002b57a70)
	/usr/local/go/src/os/exec_unix.go:22 +0x28
os.(*Process).Wait(...)
	/usr/local/go/src/os/exec.go:132
os/exec.(*Cmd).Wait(0xc0020d8580)
	/usr/local/go/src/os/exec/exec.go:890 +0x45
github.com/cilium/cilium/pkg/launcher.(*Launcher).Run.func1()
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:48 +0x45
created by github.com/cilium/cilium/pkg/launcher.(*Launcher).Run
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:47 +0x4db

goroutine 1049 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000a003c0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1180 [IO wait]:
internal/poll.runtime_pollWait(0x7ffa499d94a8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc000ff6780?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc000ff6780)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc000ff6780)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*UnixListener).accept(0x46e74e?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x1c
net.(*UnixListener).Accept(0xc0050b9e30)
	/usr/local/go/src/net/unixsock.go:260 +0x3d
net/http.(*Server).Serve(0xc0023bdef0, {0x3bb3670, 0xc0050b9e30})
	/usr/local/go/src/net/http/server.go:3059 +0x385
github.com/cilium/cilium/api/v1/health/server.(*Server).Start.func1({0x3bb3670?, 0xc0050b9e30?})
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:326 +0x85
created by github.com/cilium/cilium/api/v1/health/server.(*Server).Start
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:324 +0x52f

goroutine 1442 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00081c360, {0xc003d415f0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000293360}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1435 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001327040)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 3754 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001123506, 0x10, 0x1a}, {0xc001297110, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1355 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001acbb00, {0xc003d40e20, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002b9d810}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2036 [select, 2 minutes]:
reflect.rselect({0xc0015a3e60, 0x9, 0xc0037e2798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc002a18600?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001d528d0, {0x3bb5780, 0xc0017e9410}, 0xc00011ee70, {0x7ffa49c6e840, 0xc001304c00}, 0xc000964ae0, {0x36f79e0?, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001d528d0, {0x3bb5780, 0xc0017e9410}, {0x7ffa49c6e840?, 0xc001304c00?}, {0x36f79e0, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamEndpoints(0xc00229ab30?, {0x3bc6d60, 0xc001304c00})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:121 +0x70
github.com/cilium/proxy/go/envoy/service/endpoint/v3._EndpointDiscoveryService_StreamEndpoints_Handler({0x34ffc60?, 0xc001d528d0}, {0x3bc0368?, 0xc001b142d0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:338 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001f341e0, {0x3bcc8e0, 0xc001b5f040}, 0xc001f5c5a0, 0xc001f50ba0, 0x58808a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001f341e0, {0x3bcc8e0, 0xc001b5f040}, 0xc001f5c5a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 1136 [sleep, 3 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000d80286, 0x10, 0x1a}, {0xc001862210, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2147 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0003e2b40, {0xc000184150, 0x0, 0xc001096090, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc004e7f0e0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1414 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc002e4ddb0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0005e19e0, {0xc0002b5730, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc002e4ddb0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1429 [IO wait]:
internal/poll.runtime_pollWait(0x7ffa499d91d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc00311ec00?, 0xc0046c0800?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadFrom(0xc00311ec00, {0xc0046c0800, 0x200, 0x200})
	/usr/local/go/src/internal/poll/fd_unix.go:223 +0x2ab
net.(*netFD).readFrom(0xc00311ec00, {0xc0046c0800?, 0x50?, 0x72?})
	/usr/local/go/src/net/fd_posix.go:61 +0x29
net.(*IPConn).readFrom(0xc001dd2e68?, {0xc0046c0800, 0x200, 0x200})
	/usr/local/go/src/net/iprawsock_posix.go:49 +0x32
net.(*IPConn).ReadFrom(0xc000e4e1e0, {0xc0046c0800?, 0xc000d7dbe8?, 0xc001dd2ea8?})
	/usr/local/go/src/net/iprawsock.go:129 +0x31
golang.org/x/net/icmp.(*PacketConn).ReadFrom(0xc135ed6d757fee68?, {0xc0046c0800?, 0x58c5060?, 0x58c5060?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/icmp/endpoint.go:58 +0x30
github.com/servak/go-fastping.(*Pinger).recvICMP(0xc000d7db90, 0xc0010736a0, 0xc0008dd380, 0xc0010736c0, 0xc004b94540?)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:570 +0x145
created by github.com/servak/go-fastping.(*Pinger).run
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:425 +0x398

goroutine 1975 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7ffa499d8ff8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc0020ccc00?, 0xc0035d9000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0020ccc00, {0xc0035d9000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc0020ccc00, {0xc0035d9000?, 0x43c147?, 0xc001ecfc30?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000a20ac8, {0xc0035d9000?, 0x0?, 0xc0011d9520?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*persistConn).Read(0xc00081d320, {0xc0035d9000?, 0xc002d040c0?, 0xc001ecfd30?})
	/usr/local/go/src/net/http/transport.go:1943 +0x4e
bufio.(*Reader).fill(0xc0035c1320)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc0035c1320, 0x1)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*persistConn).readLoop(0xc00081d320)
	/usr/local/go/src/net/http/transport.go:2107 +0x1ac
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1765 +0x16ea

goroutine 1505 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00089eb40, {0xc00011d650, 0x0, 0xc004ed9170, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002964c30}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1295 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc00178df40})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00095afc0, {0xc000231660, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc00178df40}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1296 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001ec8c00?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1313 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00095b7a0, {0xc0020881c0, 0x0, 0xc0013352f0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001a3a000}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1409 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7ffa49c6b868, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001d78080?, 0xc0010de000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001d78080, {0xc0010de000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc001d78080, {0xc0010de000?, 0x43c147?, 0xc002378c30?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000ae81b0, {0xc0010de000?, 0x0?, 0xc001012b60?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*persistConn).Read(0xc0005e0fc0, {0xc0010de000?, 0xc0007c3c80?, 0xc002378d30?})
	/usr/local/go/src/net/http/transport.go:1943 +0x4e
bufio.(*Reader).fill(0xc001784f60)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc001784f60, 0x1)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*persistConn).readLoop(0xc0005e0fc0)
	/usr/local/go/src/net/http/transport.go:2107 +0x1ac
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1765 +0x16ea

goroutine 1353 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002d079e0, {0xc0003ba0e0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00178d0e0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1372 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0005e07e0, {0xc000e5f590, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000ab5d10}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1977 [select]:
reflect.rselect({0xc000daa480, 0x9, 0xc00147a798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc003bfe600?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001d528d0, {0x3bb5780, 0xc0034109f0}, 0xc0001db110, {0x7ffa4992cb98, 0xc0004341b0}, 0xc001e8e660, {0x3696c3c?, 0x28})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001d528d0, {0x3bb5780, 0xc0034109f0}, {0x7ffa4992cb98?, 0xc0004341b0?}, {0x3696c3c, 0x28})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamNetworkPolicies(0xc002dcdb30?, {0x3bc6ba8, 0xc0004341b0})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:145 +0x70
github.com/cilium/proxy/go/cilium/api._NetworkPolicyDiscoveryService_StreamNetworkPolicies_Handler({0x34ffc60?, 0xc001d528d0}, {0x3bc0368?, 0xc0008ec000})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/cilium/api/npds.pb.go:1690 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001f341e0, {0x3bcc8e0, 0xc001b5f040}, 0xc00081d440, 0xc001f50de0, 0x5876d00, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001f341e0, {0x3bcc8e0, 0xc001b5f040}, 0xc00081d440, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 1331 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0003d6900, {0xc001d8b650, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0028258b0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1333 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0003d77a0, {0xc001d8b740, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002825bd0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1280 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000412ea0, {0xc000503a10, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0002bf220}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3722 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc001d315a8?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1438 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00143cf88?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1427 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002fbe7e0, {0xc0009335a0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001a3a370}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1364 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7ffa49c6b4a8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001ef4100?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001ef4100)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc001ef4100)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*TCPListener).accept(0xc00095fa28)
	/usr/local/go/src/net/tcpsock_posix.go:148 +0x25
net.(*TCPListener).Accept(0xc00095fa28)
	/usr/local/go/src/net/tcpsock.go:297 +0x3d
net/http.(*Server).Serve(0xc0023bd1d0, {0x3bb3640, 0xc00095fa28})
	/usr/local/go/src/net/http/server.go:3059 +0x385
net/http.(*Server).ListenAndServe(0xc0023bd1d0)
	/usr/local/go/src/net/http/server.go:2988 +0x7d
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:35
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:365 +0x2f
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:364 +0x85

goroutine 1311 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00089fe60, {0xc001e03c68, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00208d2c0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1395 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7ffa49c6b598, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc000979b00?, 0xc0031e2000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc000979b00, {0xc0031e2000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc000979b00, {0xc0031e2000?, 0x4e7b66?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc001444458, {0xc0031e2000?, 0x0?, 0xc001754a88?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*connReader).Read(0xc001754a80, {0xc0031e2000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:782 +0x171
bufio.(*Reader).fill(0xc0015e0660)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc0015e0660, 0x4)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*conn).serve(0xc000d4a480, {0x3bb5780, 0xc002cce4b0})
	/usr/local/go/src/net/http/server.go:2030 +0x77c
created by net/http.(*Server).Serve
	/usr/local/go/src/net/http/server.go:3089 +0x5ed

goroutine 1351 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/health/server.(*Server).Serve(0xc0009e0200)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:373 +0xee
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer.func1()
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:91 +0x77
created by github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:89 +0x1e5

goroutine 1365 [semacquire, 3 minutes]:
sync.runtime_Semacquire(0x3124be0?)
	/usr/local/go/src/runtime/sema.go:62 +0x27
sync.(*WaitGroup).Wait(0xc0009e0200?)
	/usr/local/go/src/sync/waitgroup.go:116 +0x4b
github.com/cilium/cilium/api/v1/health/server.(*Server).Serve(0xc0009e0200)
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:278 +0x6b
github.com/cilium/cilium/pkg/health/server.(*Server).runActiveServices(0xc0009e0200)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:351 +0x113
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func2()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:369 +0x26
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:368 +0xd9

goroutine 1589 [select, 2 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001c84af0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0016b39e0, {0xc000cfcd20, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001c84af0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1437 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001a3b9a0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00157cb40, {0xc000fa1790, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001a3b9a0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1587 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000a5c0a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1415 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00133f880?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1416 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0005e1e60, {0xc00011d7a0, 0x0, 0xc0017b93b0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002e4de50}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2047 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000747a06, 0x10, 0x1a}, {0xc001817020, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1418 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0011245a0, {0xc0007d8a50, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0006c6410}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1384 [IO wait]:
internal/poll.runtime_pollWait(0x7ffa49c6b1d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc0020d7f00?, 0xc000e37000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0020d7f00, {0xc000e37000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc0020d7f00, {0xc000e37000?, 0x2?, 0x588a5a0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc001444410, {0xc000e37000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*persistConn).Read(0xc00140de60, {0xc000e37000?, 0x44d520?, 0xc0024a9ec8?})
	/usr/local/go/src/net/http/transport.go:1943 +0x4e
bufio.(*Reader).fill(0xc002cdb3e0)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc002cdb3e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*persistConn).readLoop(0xc00140de60)
	/usr/local/go/src/net/http/transport.go:2107 +0x1ac
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1765 +0x16ea

goroutine 2088 [select, 2 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0xc00165d040)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1155 +0x233
created by google.golang.org/grpc/internal/transport.NewServerTransport
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:344 +0x1bf8

goroutine 1178 [select]:
github.com/servak/go-fastping.(*Pinger).run(0xc000d7db90, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:439 +0x611
created by github.com/servak/go-fastping.(*Pinger).RunLoop
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:362 +0x14a

goroutine 1768 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000f0c146, 0x10, 0x1a}, {0xc0011485a0, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2366 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00157c900, {0xc001815248, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0004505f0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1179 [select]:
github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:334 +0x8a
created by github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:330 +0x65

goroutine 1439 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00157d0e0, {0xc000153ab0, 0x0, 0xc001425b60, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001a3ba40}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2039 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc001d5aa50, 0x1)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000270bd0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc001d5aa00, {0x3bb56d8, 0xc0000cfd10}, {0xc001f31fc0, 0x33}, 0x6, {0xc001daf1e5, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 2855 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002b2cea0, {0xc0011dc0e0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0039deb90}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1424 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0013c2360, {0xc0013aa570, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002e4ceb0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1636 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002e1b9e0, {0xc000e5fc80, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc004282aa0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2186 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001d4e240, {0xc000749020, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc003417590}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1407 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc003235440, {0xc00110fad0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001fc72c0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1984 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x284f97f?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc002d047e0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2551 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002fbf8c0, {0xc0006956c0, 0x0, 0xc003138330, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001c858b0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1376 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1550 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000707560, {0xc00041acb0, 0x0, 0xc0043a14a0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00417b090}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1375 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc002964b90})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00089e480, {0xc0009f93c0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc002964b90}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3357 [select, 2 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001d600f0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001d7a6c0, {0xc00129f3d0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001d600f0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2550 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000ee80d0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1538 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001606c60, {0xc00159ae50, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc004e7fa90}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2035 [select, 2 minutes]:
reflect.rselect({0xc0015b8120, 0x9, 0xc0037de798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc00046d400?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001d528d0, {0x3bb5780, 0xc000f25560}, 0xc0002c1570, {0x7ffa49c6e840, 0xc0001b6b40}, 0xc00135a5a0, {0x36f79e0?, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001d528d0, {0x3bb5780, 0xc000f25560}, {0x7ffa49c6e840?, 0xc0001b6b40?}, {0x36f79e0, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamEndpoints(0xc005148b30?, {0x3bc6d60, 0xc0001b6b40})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:121 +0x70
github.com/cilium/proxy/go/envoy/service/endpoint/v3._EndpointDiscoveryService_StreamEndpoints_Handler({0x34ffc60?, 0xc001d528d0}, {0x3bc0368?, 0xc0005ecd20})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:338 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001f341e0, {0x3bcc8e0, 0xc001b5f040}, 0xc001f5c480, 0xc001f50ba0, 0x58808a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001f341e0, {0x3bcc8e0, 0xc001b5f040}, 0xc001f5c480, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 1549 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc002dccfd0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001354b90?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1590 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0013541a0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1511 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0004130e0, {0xc000749380, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc004efa2d0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1650 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00090f560, {0xc000409920, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0051b2960}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1548 [select, 3 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc00417aff0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000706ea0, {0xc001354e20, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc00417aff0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1836 [select]:
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000824180?, {0x3b87900, 0xc0035e4990}, 0x1, 0xc000824180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:238 +0x135
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0035c3e50?, 0x77359400, 0x0, 0xa0?, 0x20?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/leaderelection.(*LeaderElector).renew(0xc001d37d40, {0x3bb56d8?, 0xc0035c3e00?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/leaderelection/leaderelection.go:266 +0x125
k8s.io/client-go/tools/leaderelection.(*LeaderElector).Run(0xc001d37d40, {0x3bb56d8, 0xc003627ea0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/leaderelection/leaderelection.go:209 +0x119
k8s.io/client-go/tools/leaderelection.RunOrDie({0x3bb56d8, 0xc003627ea0}, {{0x3bc0b48, 0xc0003d6b40}, 0x37e11d600, 0x12a05f200, 0x77359400, {0xc0014ca1b0, 0xc0014ca1c0, 0x0}, ...})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/leaderelection/leaderelection.go:223 +0x94
github.com/cilium/cilium/pkg/l2announcer.(*selectedService).serviceLeaderElection(0xc0001dad20, {0x3bb5780?, 0xc0037098f0?})
	/go/src/github.com/cilium/cilium/pkg/l2announcer/l2announcer.go:1061 +0x218
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc00370b4a0, {0x3bb5780, 0xc0037098f0}, 0xc00074eae0?, {{{0xc000f90100, 0x1, 0x1}}, {0x3be6410, 0xc0016d23f0}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:267 +0x530
created by github.com/cilium/cilium/pkg/hive/job.(*group).Add.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:181 +0x158

goroutine 2453 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0001ac480, {0xc000198a10, 0x0, 0xc0039916b0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0031e0c80}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2087 [select, 2 minutes]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0xc00417b4a0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x115
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0xc00013ce70)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x91
google.golang.org/grpc/internal/transport.NewServerTransport.func2()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:341 +0xda
created by google.golang.org/grpc/internal/transport.NewServerTransport
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:338 +0x1bb3

goroutine 1838 [select, 2 minutes]:
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:103 +0x71
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:102 +0x10a

goroutine 1546 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001ffbc20)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2549 [select, 2 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001c85810})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002fbf440, {0xc000dac2c0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001c85810}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2466 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002bcf0e0, {0xc000eb5930, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0032c8a00}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2106 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002e1b7a0, {0xc0009c74d0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00178c370}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2368 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001e106c0, {0xc000e5eae0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0006c7a40}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1495 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00140c6c0, {0xc0018148d0, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001b8ab90}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2146 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc0019e61c0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001114240?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 4602 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001d5aad0, 0x3a)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc003c1e9c0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc001d5aa80, {0x3bb56d8, 0xc003c2acd0}, {0xc003c2e190, 0x42}, 0x12, {0xc0013c65e5, 0x9}, {0xc003c1e9c0, 0x1, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 2246 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002e1a480, {0xc001533c90, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0029779a0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2449 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0007320a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1976 [select, 2 minutes]:
net/http.(*persistConn).writeLoop(0xc00081d320)
	/usr/local/go/src/net/http/transport.go:2410 +0xf2
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1766 +0x173d

goroutine 1996 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc001d5a9d0, 0x3)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000270bd0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc001d5a980, {0x3bb56d8, 0xc001c84cd0}, {0xc0015e4780, 0x3c}, 0x4, {0xc000da6005, 0x9}, {0xc000040f20, 0x1, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 3175 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001d5aad0, 0x37)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0001d30c0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc001d5aa80, {0x3bb56d8, 0xc002ccc910}, {0xc0038530e0, 0x42}, 0xd, {0xc0002d5045, 0x9}, {0xc0001d30c0, 0x1, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 2159 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0016d08e6, 0x10, 0x1a}, {0xc001260b10, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2038 [select]:
reflect.rselect({0xc0003d6a20, 0x9, 0xc0037ea798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc003bfec00?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001d528d0, {0x3bb5780, 0xc004ef8ab0}, 0xc000139d50, {0x7ffa49c6e840, 0xc001376a00}, 0xc001e8ed80, {0x36f79e0?, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001d528d0, {0x3bb5780, 0xc004ef8ab0}, {0x7ffa49c6e840?, 0xc001376a00?}, {0x36f79e0, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamEndpoints(0xc002dccb30?, {0x3bc6d60, 0xc001376a00})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:121 +0x70
github.com/cilium/proxy/go/envoy/service/endpoint/v3._EndpointDiscoveryService_StreamEndpoints_Handler({0x34ffc60?, 0xc001d528d0}, {0x3bc0368?, 0xc0008ec3c0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:338 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001f341e0, {0x3bcc8e0, 0xc001b5f040}, 0xc001f5c7e0, 0xc001f50ba0, 0x58808a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001f341e0, {0x3bcc8e0, 0xc001b5f040}, 0xc001f5c7e0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 1978 [select, 2 minutes]:
reflect.rselect({0xc0013b3680, 0x9, 0xc00516c798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc0035b0000?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001d528d0, {0x3bb5780, 0xc0032ca2d0}, 0xc002020000, {0x7ffa49d829e0, 0xc0011d0010}, 0xc002d041e0, {0x36e8b90?, 0x3c})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001d528d0, {0x3bb5780, 0xc0032ca2d0}, {0x7ffa49d829e0?, 0xc0011d0010?}, {0x36e8b90, 0x3c})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamRoutes(0xc000899b30?, {0x3bc6ec0, 0xc0011d0010})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:93 +0x70
github.com/cilium/proxy/go/envoy/service/route/v3._RouteDiscoveryService_StreamRoutes_Handler({0x34ffc60?, 0xc001d528d0}, {0x3bc0368?, 0xc00297c000})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/route/v3/rds.pb.go:346 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001f341e0, {0x3bcc8e0, 0xc001b5f040}, 0xc00081d560, 0xc001f50cc0, 0x5880920, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001f341e0, {0x3bcc8e0, 0xc001b5f040}, 0xc00081d560, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 1936 [sync.Cond.Wait, 2 minutes]:
sync.runtime_notifyListWait(0xc001d5a950, 0x1)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000270bd0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc001d5a900, {0x3bb56d8, 0xc0035ee730}, {0xc002004d40, 0x35}, 0x2, {0xc001b4a025, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 4136 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7ffa499d9c28, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc002605a80?, 0xc002bac000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002605a80, {0xc002bac000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc002605a80, {0xc002bac000?, 0x43c147?, 0xc00292bc30?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc00040b5d8, {0xc002bac000?, 0x0?, 0xc003947d40?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*persistConn).Read(0xc002bcaea0, {0xc002bac000?, 0xc0007c30e0?, 0xc00292bd30?})
	/usr/local/go/src/net/http/transport.go:1943 +0x4e
bufio.(*Reader).fill(0xc002ab7d40)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc002ab7d40, 0x1)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*persistConn).readLoop(0xc002bcaea0)
	/usr/local/go/src/net/http/transport.go:2107 +0x1ac
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1765 +0x16ea

goroutine 1960 [select, 2 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc0000cf680, {0xc00200c7d8, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc0000cf680, {0xc00200c7d8?, 0xc0037a4b40?, 0xc0026f7560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc003355ce0, {0xc00200c7d8?, 0xc0026f75d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc003355ce0}, {0xc00200c7d8, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc001f5c5a0, {0xc00200c7d8, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc00200c7c8, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc0026f77a8?, 0xc001f5c5a0, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7ffa499130e0, 0x5e20750}, 0xc0026f79f8?, {0x0?, 0x0?}, {0x3472d60, 0xc001b55220}, 0xc0008dd800?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc001b142d0, {0x3472d60?, 0xc001b55220})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/endpoint/v3.(*endpointDiscoveryServiceStreamEndpointsServer).Recv(0xc001304c00)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:357 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc000f1e420?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 1987 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc0000cfcc0, {0xc001e038a0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc0000cfcc0, {0xc001e038a0?, 0xc0037a4b70?, 0xc0008f3560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc003355f80, {0xc001e038a0?, 0xc0008f35d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc003355f80}, {0xc001e038a0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc001f5c7e0, {0xc001e038a0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc001e03890, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc0008f37a8?, 0xc001f5c7e0, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7ffa499130e0, 0x5e20750}, 0xc0008f39f8?, {0x0?, 0x0?}, {0x3472d60, 0xc0032ea1e0}, 0xc002092b40?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc0008ec3c0, {0x3472d60?, 0xc0032ea1e0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/endpoint/v3.(*endpointDiscoveryServiceStreamEndpointsServer).Recv(0xc001376a00)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:357 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc0007c3440?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 1691 [select, 2 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc0000cf400, {0xc0008285c8, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc0000cf400, {0xc0008285c8?, 0xc0037a4b10?, 0xc003407560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc003355a40, {0xc0008285c8?, 0xc0034075d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc003355a40}, {0xc0008285c8, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc001f5c360, {0xc0008285c8, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc0008285b8, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc0034077a8?, 0xc001f5c360, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7ffa499130e0, 0x5e20750}, 0x0?, {0x0?, 0x0?}, {0x3472d60, 0xc001326820}, 0xc00080c660?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc000e8e3c0, {0x3472d60?, 0xc001326820})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/endpoint/v3.(*endpointDiscoveryServiceStreamEndpointsServer).Recv(0xc0007a9b50)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:357 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc00064d320?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 2145 [select, 2 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc004e7f040})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0003e25a0, {0xc000cfc990, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc004e7f040}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1598 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc0000cfae0, {0xc000ad1588, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc0000cfae0, {0xc000ad1588?, 0xc0037a4b58?, 0xc003825560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc003355e30, {0xc000ad1588?, 0xc0038255d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc003355e30}, {0xc000ad1588, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc001f5c6c0, {0xc000ad1588, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc000ad1578, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc0038257a8?, 0xc001f5c6c0, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7ffa499130e0, 0x5e20750}, 0xc0038259f8?, {0x0?, 0x0?}, {0x3472d60, 0xc002fa9b80}, 0xc0017849c0?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc002bfe0f0, {0x3472d60?, 0xc002fa9b80})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/endpoint/v3.(*endpointDiscoveryServiceStreamEndpointsServer).Recv(0xc00051eac0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:357 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc001aff7a0?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 1655 [select, 2 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc0000cf590, {0xc002094700, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc0000cf590, {0xc002094700?, 0xc0037a4b28?, 0xc0032f7560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc003355b90, {0xc002094700?, 0xc0032f75d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc003355b90}, {0xc002094700, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc001f5c480, {0xc002094700, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc0020946f0, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc0032f77a8?, 0xc001f5c480, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7ffa499130e0, 0x5e20750}, 0xc0032f79f8?, {0x0?, 0x0?}, {0x3472d60, 0xc0008472c0}, 0xc002d090e0?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc0005ecd20, {0x3472d60?, 0xc0008472c0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/endpoint/v3.(*endpointDiscoveryServiceStreamEndpointsServer).Recv(0xc0001b6b40)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:357 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc001443f88?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 2274 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000e6e3e6, 0x10, 0x1a}, {0xc001296c60, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 3571 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002fa8000)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1983 [select, 2 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc00302cbe0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001607680, {0xc0009f8730, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc00302cbe0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2049 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0017fbbc6, 0x10, 0x1a}, {0xc00186f980, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2114 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0013c79a6, 0x10, 0x1a}, {0xc001439f20, 0x24}, 0xc002dc9fb0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1999 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000ea03c0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 5046 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001d5abd0, 0x1c)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000270bd0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc001d5ab80, {0x3bb56d8, 0xc002313e00}, {0xc0023169c0, 0x28}, 0x2d, {0xc000f0d485, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 2065 [select, 2 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001c85720})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0000d38c0, {0xc0000418b0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001c85720}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2066 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x284f966?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000434200?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2067 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0000d3d40, {0xc0002cc690, 0x0, 0xc0019e4150, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001c857c0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2073 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000ea0460)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2075 [select, 2 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0003b3400})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001125440, {0xc00129e750, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0003b3400}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2076 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x284f966?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0003d6900?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2077 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0011259e0, {0xc0001cc9a0, 0x0, 0xc0010a43f0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0003b34f0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1981 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000846280)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2098 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0013d59e0, {0xc0006c1f98, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00302c460}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2105 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002e1ab40, {0xc000f61390, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00178c140}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1951 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0038546e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2142 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000297320, {0xc0013ab230, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00302dd60}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2108 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0007b4426, 0x10, 0x1a}, {0xc000db3a40, 0x24}, 0xc000f1e420?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2164 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000d81c46, 0x10, 0x1a}, {0xc0010a1920, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2168 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc001b54d20)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2768 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001d5aad0, 0x38)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0010789d0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc001d5aa80, {0x3bb56d8, 0xc002986fa0}, {0xc00397a2d0, 0x42}, 0xc, {0xc001dae4c5, 0x9}, {0xc0010789d0, 0x1, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 2170 [select, 2 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc00454ce10})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002fbe480, {0xc0011804b0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc00454ce10}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2171 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00133f880?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2172 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002fbeb40, {0xc00075a460, 0x0, 0xc003679bf0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00454cff0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2194 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00140d440, {0xc00110ef90, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002977630}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2193 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0030c8a20, {0xc0007af488, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00454d590}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2188 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001b4a1e6, 0x10, 0x1a}, {0xc0007ba6c0, 0x24}, 0xc0003e2b40?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2191 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000297680, {0xc000f62640, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002a488c0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2253 [select, 2 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0042834a0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0005e10e0, {0xc0011dde20, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0042834a0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2238 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001daffc6, 0x10, 0x1a}, {0xc0003eaf90, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2254 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc001815b30?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2268 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000e12326, 0x10, 0x1a}, {0xc0003ea750, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2291 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000e12466, 0x10, 0x1a}, {0xc0003eaa20, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2302 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000e12686, 0x10, 0x1a}, {0xc0003eb050, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2096 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7ffa49c6b3b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc002aafd00?, 0xc00322c580?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002aafd00, {0xc00322c580, 0x580, 0x580})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc002aafd00, {0xc00322c580?, 0xc00322c585?, 0x1a?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000ae90d8, {0xc00322c580?, 0x40dd2a?, 0xc001812530?})
	/usr/local/go/src/net/net.go:183 +0x45
crypto/tls.(*atLeastReader).Read(0xc001814588, {0xc00322c580?, 0xc001814588?, 0x0?})
	/usr/local/go/src/crypto/tls/conn.go:788 +0x3d
bytes.(*Buffer).ReadFrom(0xc001812610, {0x3b720a0, 0xc001814588})
	/usr/local/go/src/bytes/buffer.go:202 +0x98
crypto/tls.(*Conn).readFromUntil(0xc001812380, {0x3b88060?, 0xc000ae90d8}, 0x580?)
	/usr/local/go/src/crypto/tls/conn.go:810 +0xe5
crypto/tls.(*Conn).readRecordOrCCS(0xc001812380, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:617 +0x116
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:583
crypto/tls.(*Conn).Read(0xc001812380, {0xc0032e2000, 0x8000, 0x0?})
	/usr/local/go/src/crypto/tls/conn.go:1316 +0x16f
bufio.(*Reader).Read(0xc00323d7a0, {0xc001d6d2a0, 0x9, 0x30?})
	/usr/local/go/src/bufio/bufio.go:237 +0x1bb
io.ReadAtLeast({0x3b71ea0, 0xc00323d7a0}, {0xc001d6d2a0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
golang.org/x/net/http2.readFrameHeader({0xc001d6d2a0?, 0x9?, 0xc002b55a40?}, {0x3b71ea0?, 0xc00323d7a0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x6e
golang.org/x/net/http2.(*Framer).ReadFrame(0xc001d6d260)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x95
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0xc00165d1e0, 0x0?, 0x46c985?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:642 +0x167
google.golang.org/grpc.(*Server).serveStreams(0xc00281c000, {0x3bcc8e0?, 0xc00165d1e0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:946 +0x162
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:889 +0x46
created by google.golang.org/grpc.(*Server).handleRawConn
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:888 +0x185

goroutine 2281 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000e6e4a6, 0x10, 0x1a}, {0xc0012976e0, 0x24}, 0xc002fbe480?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2324 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000e6eb26, 0x10, 0x1a}, {0xc0010341e0, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 3359 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001d7ab40, {0xc0001788c0, 0x0, 0xc000fe5110, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001d60190}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2095 [select, 2 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0xc00165d1e0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1155 +0x233
created by google.golang.org/grpc/internal/transport.NewServerTransport
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:344 +0x1bf8

goroutine 2663 [select, 2 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001f4f0e0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0032347e0, {0xc00136cfe0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001f4f0e0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2340 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0009a5d26, 0x10, 0x1a}, {0xc000f9de60, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2452 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x284f97f?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00133f880?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2527 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000b64b40, {0xc00015b2d0, 0x0, 0xc003bf5410, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002a48f50}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 5737 [select]:
net/http.(*persistConn).writeLoop(0xc0047186c0)
	/usr/local/go/src/net/http/transport.go:2410 +0xf2
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1766 +0x173d

goroutine 2251 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc003854820)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2451 [select, 2 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0031e0be0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0001ac000, {0xc000edc350, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0031e0be0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2092 [select, 2 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func2()
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:73 +0x117
golang.org/x/sync/errgroup.(*Group).Go.func1()
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:75 +0x64
created by golang.org/x/sync/errgroup.(*Group).Go
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:72 +0xa5

goroutine 4137 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0xc002bcaea0)
	/usr/local/go/src/net/http/transport.go:2410 +0xf2
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1766 +0x173d

goroutine 2491 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000e6ec06, 0x10, 0x1a}, {0xc00187ca20, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2255 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0005e1560, {0xc0001c9dc0, 0x0, 0xc001306180, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc004283540}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2523 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc00096f2c0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 3573 [select, 2 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc002bebf40})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002faa6c0, {0xc0011d1d00, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc002bebf40}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2547 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000a04f00)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2525 [select, 2 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc002a48eb0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0016b3b00, {0xc000a15060, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc002a48eb0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2091 [select, 2 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func1()
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:59 +0xcf
golang.org/x/sync/errgroup.(*Group).Go.func1()
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:75 +0x64
created by golang.org/x/sync/errgroup.(*Group).Go
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:72 +0xa5

goroutine 2094 [select, 2 minutes]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0xc0028251d0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x115
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0xc00013df80)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x91
google.golang.org/grpc/internal/transport.NewServerTransport.func2()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:341 +0xda
created by google.golang.org/grpc/internal/transport.NewServerTransport
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:338 +0x1bb3

goroutine 2089 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0x7ffa49c6b688, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc002aafc80?, 0xc00322c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002aafc80, {0xc00322c000, 0x580, 0x580})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc002aafc80, {0xc00322c000?, 0xc00322c005?, 0x2f?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000ae90d0, {0xc00322c000?, 0x40dd2a?, 0xc000feac30?})
	/usr/local/go/src/net/net.go:183 +0x45
crypto/tls.(*atLeastReader).Read(0xc000828a50, {0xc00322c000?, 0xc000828a50?, 0x0?})
	/usr/local/go/src/crypto/tls/conn.go:788 +0x3d
bytes.(*Buffer).ReadFrom(0xc000fead10, {0x3b720a0, 0xc000828a50})
	/usr/local/go/src/bytes/buffer.go:202 +0x98
crypto/tls.(*Conn).readFromUntil(0xc000feaa80, {0x3b88060?, 0xc000ae90d0}, 0x580?)
	/usr/local/go/src/crypto/tls/conn.go:810 +0xe5
crypto/tls.(*Conn).readRecordOrCCS(0xc000feaa80, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:617 +0x116
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:583
crypto/tls.(*Conn).Read(0xc000feaa80, {0xc0032b8000, 0x8000, 0xc003476cc8?})
	/usr/local/go/src/crypto/tls/conn.go:1316 +0x16f
bufio.(*Reader).Read(0xc0027d5080, {0xc001d6d000, 0x9, 0xc003476cf0?})
	/usr/local/go/src/bufio/bufio.go:237 +0x1bb
io.ReadAtLeast({0x3b71ea0, 0xc0027d5080}, {0xc001d6d000, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
golang.org/x/net/http2.readFrameHeader({0xc001d6d000?, 0x9?, 0x3b86be0?}, {0x3b71ea0?, 0xc0027d5080?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x6e
golang.org/x/net/http2.(*Framer).ReadFrame(0xc001d6cfc0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x95
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0xc00165d040, 0x0?, 0x46c985?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:642 +0x167
google.golang.org/grpc.(*Server).serveStreams(0xc00281c000, {0x3bcc8e0?, 0xc00165d040})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:946 +0x162
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:889 +0x46
created by google.golang.org/grpc.(*Server).handleRawConn
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:888 +0x185

goroutine 5746 [IO wait]:
internal/poll.runtime_pollWait(0x7ffa499d93b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc0040f8f80?, 0xc0025cb000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0040f8f80, {0xc0025cb000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc0040f8f80, {0xc0025cb000?, 0x4e7b66?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000f54000, {0xc0025cb000?, 0x0?, 0xc001acf718?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*connReader).Read(0xc001acf710, {0xc0025cb000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:782 +0x171
bufio.(*Reader).fill(0xc0025c6780)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc0025c6780, 0x4)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*conn).serve(0xc003f53710, {0x3bb5780, 0xc002cce4b0})
	/usr/local/go/src/net/http/server.go:2030 +0x77c
created by net/http.(*Server).Serve
	/usr/local/go/src/net/http/server.go:3089 +0x5ed

goroutine 2526 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc000828558?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 3635 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0031057a0, {0xc0009327f0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001c8ef00}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2664 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc003479fd0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00136c9c0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 3574 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc0044a2101?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000dad960?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2665 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc003234d80, {0xc00041bdc0, 0x0, 0xc001578b40, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001f4f220}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2661 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0032ea0a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2093 [select, 2 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*buffer).Pop(0xc0010994c0)
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/buffer.go:80 +0x11e
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func3()
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:91 +0x3f
golang.org/x/sync/errgroup.(*Group).Go.func1()
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:75 +0x64
created by golang.org/x/sync/errgroup.(*Group).Go
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:72 +0xa5

goroutine 3719 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc002fa86e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 5736 [IO wait]:
internal/poll.runtime_pollWait(0x7ffa499d9688, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc00425d680?, 0xc004135000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00425d680, {0xc004135000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc00425d680, {0xc004135000?, 0x43c147?, 0xc002fd5c30?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000f08020, {0xc004135000?, 0x0?, 0xc003060d00?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*persistConn).Read(0xc0047186c0, {0xc004135000?, 0xc004035620?, 0xc002fd5d30?})
	/usr/local/go/src/net/http/transport.go:1943 +0x4e
bufio.(*Reader).fill(0xc003cd50e0)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc003cd50e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*persistConn).readLoop(0xc0047186c0)
	/usr/local/go/src/net/http/transport.go:2107 +0x1ac
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1765 +0x16ea

goroutine 3723 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00023bb00, {0xc000510930, 0x0, 0xc0045af590, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0017567d0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3625 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001055e66, 0x10, 0x1a}, {0xc000ff0d80, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2712 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc003854640)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2714 [select, 2 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc00454d950})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0005dc5a0, {0xc001165000, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc00454d950}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2715 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x284f966?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000fcc600?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2716 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0005dcea0, {0xc0001a0150, 0x0, 0xc001811320, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00454d9f0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2090 [semacquire, 2 minutes]:
sync.runtime_Semacquire(0x5?)
	/usr/local/go/src/runtime/sema.go:62 +0x27
sync.(*WaitGroup).Wait(0x0?)
	/usr/local/go/src/sync/waitgroup.go:116 +0x4b
golang.org/x/sync/errgroup.(*Group).Wait(0xc001099480)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:53 +0x27
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify(0xc0013e4040, 0x32b8e80?, {0x3bc2a20?, 0xc0001b7e50})
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:107 +0x43b
github.com/cilium/cilium/api/v1/peer._Peer_Notify_Handler({0x3027f60?, 0xc0013e4040}, {0x3bc0368, 0xc0031b2000})
	/go/src/github.com/cilium/cilium/api/v1/peer/peer_grpc.pb.go:114 +0xd0
google.golang.org/grpc.(*Server).processStreamingRPC(0xc00281c000, {0x3bcc8e0, 0xc00165d040}, 0xc00140d560, 0xc0028164b0, 0x5876aa0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc00281c000, {0x3bcc8e0, 0xc00165d040}, 0xc00140d560, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 2846 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001d4f560, {0xc0007ae138, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc004efac30}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2765 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001f3f440, {0xc002095a70, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0035b5bd0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3721 [select, 2 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001756730})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0008f9c20, {0xc000ee8220, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001756730}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1556 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001aca480, {0xc000411b90, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0004502d0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2687 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0015a2c60, {0xc00145f848, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002aef180}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2767 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0010f8360, {0xc000f62fc0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002986c30}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3351 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001daf926, 0x10, 0x1a}, {0xc001053530, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2977 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0016b26c0, {0xc000eb4ff0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000afd3b0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2853 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0000d25a0, {0xc001d8a8b8, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002986190}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3358 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x284f97f?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0016b26c0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 3328 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001c4b680, {0xc001532710, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002336b40}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4138 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7ffa49c6ba48, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc002605d00?, 0xc002bee000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002605d00, {0xc002bee000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc002605d00, {0xc002bee000?, 0x4e7b66?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc00040b630, {0xc002bee000?, 0x0?, 0xc003709298?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*connReader).Read(0xc003709290, {0xc002bee000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:782 +0x171
bufio.(*Reader).fill(0xc002ab7ec0)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc002ab7ec0, 0x4)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*conn).serve(0xc002adddd0, {0x3bb5780, 0xc0050b9fb0})
	/usr/local/go/src/net/http/server.go:2030 +0x77c
created by net/http.(*Server).Serve
	/usr/local/go/src/net/http/server.go:3089 +0x5ed

goroutine 3471 [sleep, 2 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0007b3046, 0x10, 0x1a}, {0xc001dbbad0, 0x24}, 0xc0012f7ef0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 4865 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001d5aad0, 0x3b)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000270bd0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc001d5aa80, {0x3bb56d8, 0xc0033b85a0}, {0xc002776190, 0x42}, 0x13, {0xc001d46645, 0x9}, {0xc0009dfc60, 0x1, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b
