[{
        "key": {
            "ip4": 3137868204,
            "ifindex": 63
        },
        "value": {
            "responses_sent": 3
        }
    }
]
