Module                  Size  Used by
tcp_diag               12288  0
udp_diag               12288  0
inet_diag              28672  2 tcp_diag,udp_diag
ip6table_nat           12288  1
ip6table_mangle        12288  1
xt_TPROXY              12288  4
nf_tproxy_ipv6         16384  1 xt_TPROXY
nf_tproxy_ipv4         16384  1 xt_TPROXY
iptable_mangle         12288  1
iptable_filter         12288  1
iptable_nat            12288  1
iptable_raw            12288  1
xt_socket              12288  1
nf_socket_ipv4         12288  1 xt_socket
nf_socket_ipv6         16384  1 xt_socket
ip6table_filter        12288  1
ip6_tables             28672  3 ip6table_filter,ip6table_nat,ip6table_mangle
input_leds             12288  0
ip_set                 65536  0
xt_CT                  12288  5
xt_mark                12288  21
vxlan                 143360  0
ip6_udp_tunnel         12288  1 vxlan
udp_tunnel             24576  1 vxlan
xt_comment             12288  34
nft_chain_nat          12288  3
xt_MASQUERADE          16384  7
nf_conntrack_netlink    61440  0
xfrm_user              57344  2
xfrm_algo              16384  1 xfrm_user
xt_addrtype            12288  2
overlay               192512  66
qrtr                   57344  4
rfcomm                102400  16
snd_seq_dummy          12288  0
snd_hrtimer            12288  1
snd_seq               110592  7 snd_seq_dummy
af_packet              65536  4
cmac                   12288  3
algif_skcipher         12288  1
bnep                   28672  2
xt_conntrack           12288  7
ip6t_rpfilter          12288  1
ipt_rpfilter           12288  1
xt_pkttype             12288  2
xt_LOG                 16384  2
nf_log_syslog          24576  2
xt_tcpudp              16384  3
nft_compat             20480  25
nf_tables             368640  847 nft_compat,nft_chain_nat
nfnetlink              20480  6 nft_compat,nf_conntrack_netlink,nf_tables,ip_set
sch_fq_codel           20480  3
uinput                 20480  0
nvidia_uvm           1732608  0
nvidia_drm             94208  11
mousedev               24576  0
joydev                 24576  0
nvidia_modeset       1552384  15 nvidia_drm
iwlmvm                593920  0
mac80211             1294336  1 iwlmvm
libarc4                12288  1 mac80211
snd_hda_codec_realtek   192512  1
snd_hda_codec_generic   114688  1 snd_hda_codec_realtek
ledtrig_audio          12288  1 snd_hda_codec_generic
led_class              20480  3 snd_hda_codec_generic,input_leds,iwlmvm
iwlwifi               540672  1 iwlmvm
snd_hda_codec_hdmi     94208  1
snd_usb_audio         417792  3
btusb                  81920  0
btrtl                  28672  1 btusb
ucsi_ccg               24576  0
snd_hda_intel          61440  2
btbcm                  24576  1 btusb
typec_ucsi             57344  1 ucsi_ccg
snd_intel_dspcfg       32768  1 snd_hda_intel
btintel                57344  1 btusb
snd_usbmidi_lib        49152  1 snd_usb_audio
snd_intel_sdw_acpi     16384  1 snd_intel_dspcfg
typec                 106496  1 typec_ucsi
evdev                  28672  34
btmtk                  12288  1 btusb
hid_generic            12288  0
mxm_wmi                12288  0
nzxt_kraken2           12288  0
roles                  16384  1 typec_ucsi
intel_rapl_msr         20480  0
wmi_bmof               12288  0
mac_hid                12288  0
snd_rawmidi            53248  1 snd_usbmidi_lib
snd_hda_codec         217088  4 snd_hda_codec_generic,snd_hda_codec_hdmi,snd_hda_intel,snd_hda_codec_realtek
igb                   311296  0
cfg80211             1327104  3 iwlmvm,iwlwifi,mac80211
drm_kms_helper        253952  1 nvidia_drm
nls_iso8859_1          12288  1
snd_seq_device         16384  2 snd_seq,snd_rawmidi
edac_mce_amd           40960  0
bluetooth            1081344  46 btrtl,btmtk,btintel,btbcm,bnep,btusb,rfcomm
snd_hda_core          143360  5 snd_hda_codec_generic,snd_hda_codec_hdmi,snd_hda_intel,snd_hda_codec,snd_hda_codec_realtek
mc                     90112  1 snd_usb_audio
nls_cp437              16384  1
tiny_power_button      12288  0
ptp                    40960  2 iwlmvm,igb
sp5100_tco             16384  0
video                  69632  1 nvidia_modeset
snd_hwdep              20480  2 snd_usb_audio,snd_hda_codec
edac_core              86016  0
vfat                   20480  1
pps_core               28672  1 ptp
tpm_crb                20480  0
intel_rapl_common      36864  1 intel_rapl_msr
crc32_pclmul           12288  0
snd_pcm               192512  5 snd_hda_codec_hdmi,snd_hda_intel,snd_usb_audio,snd_hda_codec,snd_hda_core
polyval_clmulni        12288  0
polyval_generic        12288  1 polyval_clmulni
gf128mul               16384  1 polyval_generic
ghash_clmulni_intel    16384  0
sha512_ssse3           45056  0
sha512_generic         16384  1 sha512_ssse3
snd_timer              53248  3 snd_seq,snd_hrtimer,snd_pcm
aesni_intel           360448  4
i2c_nvidia_gpu         12288  0
watchdog               40960  1 sp5100_tco
usbhid                 77824  0
ecdh_generic           16384  2 bluetooth
crypto_simd            16384  1 aesni_intel
snd                   147456  25 snd_hda_codec_generic,snd_seq,snd_seq_device,snd_hda_codec_hdmi,snd_hwdep,snd_hda_intel,snd_usb_audio,snd_usbmidi_lib,snd_hda_codec,snd_hda_codec_realtek,snd_timer,snd_pcm,snd_rawmidi
dca                    16384  1 igb
ecc                    40960  1 ecdh_generic
cryptd                 28672  3 crypto_simd,ghash_clmulni_intel
tpm_tis                20480  0
gpio_amdpt             16384  0
fat                    98304  1 vfat
hid                   172032  3 usbhid,hid_generic,nzxt_kraken2
rapl                   20480  0
soundcore              16384  1 snd
k10temp                12288  0
acpi_cpufreq           32768  0
i2c_piix4              28672  0
i2c_algo_bit           12288  1 igb
i2c_ccgx_ucsi          12288  1 i2c_nvidia_gpu
rfkill                 28672  6 iwlmvm,bluetooth,cfg80211
libaes                 12288  2 bluetooth,aesni_intel
wmi                    36864  3 video,wmi_bmof,mxm_wmi
tpm_tis_core           32768  1 tpm_tis
gpio_generic           20480  1 gpio_amdpt
button                 24576  0
nvidia              62701568  756 nvidia_uvm,nvidia_modeset
ctr                    12288  0
atkbd                  40960  0
libps2                 20480  1 atkbd
serio                  28672  1 atkbd
vivaldi_fmap           12288  1 atkbd
loop                   36864  0
xt_nat                 12288  6
nf_nat                 65536  5 ip6table_nat,xt_nat,nft_chain_nat,iptable_nat,xt_MASQUERADE
nf_conntrack          200704  6 xt_conntrack,nf_nat,xt_nat,nf_conntrack_netlink,xt_CT,xt_MASQUERADE
nf_defrag_ipv6         24576  3 nf_conntrack,xt_socket,xt_TPROXY
nf_defrag_ipv4         12288  3 nf_conntrack,xt_socket,xt_TPROXY
libcrc32c              12288  3 nf_conntrack,nf_nat,nf_tables
br_netfilter           32768  0
veth                   40960  0
tun                    69632  0
tap                    28672  0
macvlan                36864  0
bridge                385024  1 br_netfilter
stp                    12288  1 bridge
llc                    16384  2 bridge,stp
kvm_amd               184320  0
ccp                   139264  1 kvm_amd
kvm                  1339392  1 kvm_amd
drm                   741376  15 drm_kms_helper,nvidia,nvidia_drm
irqbypass              12288  1 kvm
fuse                  184320  5
deflate                16384  1
efi_pstore             12288  0
backlight              28672  3 video,drm,nvidia_modeset
configfs               69632  1
efivarfs               24576  1
tpm                   102400  3 tpm_tis,tpm_crb,tpm_tis_core
rng_core               20480  2 ccp,tpm
dmi_sysfs              20480  0
ip_tables              28672  4 iptable_filter,iptable_raw,iptable_nat,iptable_mangle
x_tables               53248  24 ip6table_filter,xt_conntrack,iptable_filter,ip6table_nat,ip6t_rpfilter,nft_compat,xt_LOG,xt_socket,xt_tcpudp,xt_addrtype,xt_nat,xt_comment,ip6_tables,xt_TPROXY,ipt_rpfilter,xt_CT,xt_pkttype,iptable_raw,ip_tables,iptable_nat,ip6table_mangle,xt_MASQUERADE,iptable_mangle,xt_mark
autofs4                57344  2
ext4                 1114112  1
crc32c_generic         12288  0
crc16                  12288  2 bluetooth,ext4
mbcache                16384  1 ext4
jbd2                  196608  1 ext4
sd_mod                 61440  2
xhci_pci               24576  0
xhci_pci_renesas       16384  1 xhci_pci
firmware_class         53248  13 ccp,ucsi_ccg,btrtl,snd_hda_intel,xhci_pci_renesas,btmtk,nvidia,btintel,btbcm,iwlwifi,btusb,cfg80211,drm
xhci_hcd              352256  1 xhci_pci
ahci                   49152  2
libahci                61440  1 ahci
libata                458752  2 libahci,ahci
nvme                   57344  0
nvme_core             184320  1 nvme
usbcore               401408  6 xhci_hcd,snd_usb_audio,usbhid,snd_usbmidi_lib,btusb,xhci_pci
scsi_mod              319488  2 sd_mod,libata
crc32c_intel           16384  3
t10_pi                 20480  2 sd_mod,nvme_core
crc64_rocksoft         16384  1 t10_pi
crc64                  16384  1 crc64_rocksoft
crc_t10dif             16384  1 t10_pi
crct10dif_generic      12288  0
crct10dif_pclmul       12288  1
crct10dif_common       12288  3 crct10dif_generic,crc_t10dif,crct10dif_pclmul
usb_common             16384  2 xhci_hcd,usbcore
scsi_common            16384  3 scsi_mod,sd_mod,libata
rtc_cmos               28672  1
dm_mod                184320  0
dax                    53248  1 dm_mod
