Error: bpf obj get (/sys/fs/bpf/tc/globals/cilium_ktime_cache): No such file or directory
> Error while running 'bpftool map dump pinned /sys/fs/bpf/tc/globals/cilium_ktime_cache':  exit status 255

