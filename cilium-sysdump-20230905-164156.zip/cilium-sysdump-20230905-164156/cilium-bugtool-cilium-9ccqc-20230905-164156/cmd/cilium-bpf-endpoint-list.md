IP ADDRESS       LOCAL ENDPOINT INFO
10.244.0.52:0    id=119   sec_id=5710  flags=0x0000 ifindex=26  mac=7A:B6:AD:7C:CA:04 nodemac=62:DA:EC:6B:90:90   
10.244.0.160:0   id=3903  sec_id=29809 flags=0x0000 ifindex=48  mac=4A:D8:6E:BC:92:E7 nodemac=96:02:0A:E8:CD:1F   
10.244.0.222:0   id=2856  sec_id=22996 flags=0x0000 ifindex=34  mac=F2:AA:EC:70:BA:10 nodemac=6E:FD:8E:AF:03:32   
10.244.0.46:0    id=3933  sec_id=290   flags=0x0000 ifindex=20  mac=16:B6:3C:F9:FF:C8 nodemac=92:61:43:A6:2B:2D   
10.244.0.26:0    id=702   sec_id=12173 flags=0x0000 ifindex=69  mac=D2:77:D5:FC:41:BC nodemac=F2:F7:49:10:E6:AD   
10.244.0.29:0    id=160   sec_id=4     flags=0x0000 ifindex=6   mac=62:3B:02:92:50:78 nodemac=D2:69:21:FD:BB:63   
10.244.0.143:0   id=82    sec_id=40792 flags=0x0000 ifindex=12  mac=F2:0F:57:B3:6C:28 nodemac=AA:29:0A:CD:A9:C7   
10.244.0.41:0    id=471   sec_id=29809 flags=0x0000 ifindex=40  mac=6A:0F:F8:EE:78:20 nodemac=2E:9C:EB:75:07:90   
10.244.0.123:0   id=4067  sec_id=62607 flags=0x0000 ifindex=18  mac=96:D2:F4:A7:BB:C0 nodemac=42:CA:ED:D2:B3:59   
10.244.0.106:0   id=626   sec_id=6602  flags=0x0000 ifindex=30  mac=86:DA:B5:28:CC:22 nodemac=3E:6F:6A:AE:CE:4C   
10.244.0.86:0    id=208   sec_id=44885 flags=0x0000 ifindex=16  mac=4E:F0:2D:CA:14:AD nodemac=AE:85:3F:ED:55:FA   
10.244.0.149:0   id=2207  sec_id=63175 flags=0x0000 ifindex=14  mac=FA:8E:C3:46:E1:72 nodemac=56:1C:8B:59:C2:F3   
10.244.0.124:0   id=645   sec_id=20103 flags=0x0000 ifindex=60  mac=42:1D:71:D0:63:FC nodemac=52:3B:A8:33:DE:89   
10.244.0.177:0   id=1288  sec_id=10456 flags=0x0000 ifindex=65  mac=CA:87:CB:2D:C5:29 nodemac=26:63:AC:D3:10:0F   
10.244.0.178:0   id=215   sec_id=43844 flags=0x0000 ifindex=58  mac=2E:AA:55:F4:55:5D nodemac=E6:02:E8:77:37:28   
10.244.0.40:0    id=198   sec_id=17675 flags=0x0000 ifindex=28  mac=AE:BF:FE:6B:BA:0D nodemac=56:D6:36:07:E9:45   
172.17.0.2:0     (localhost)                                                                                      
10.244.0.81:0    id=2497  sec_id=4626  flags=0x0000 ifindex=67  mac=32:B7:61:05:6B:B1 nodemac=1A:AA:9C:85:68:59   
10.244.0.129:0   id=2326  sec_id=19125 flags=0x0000 ifindex=10  mac=2E:7D:11:22:A4:40 nodemac=96:F2:93:19:EE:19   
10.244.0.112:0   id=2747  sec_id=10281 flags=0x0000 ifindex=22  mac=66:05:5C:95:ED:56 nodemac=2E:62:28:11:42:11   
10.244.0.137:0   id=257   sec_id=22996 flags=0x0000 ifindex=32  mac=76:EA:FD:64:AA:73 nodemac=DE:FB:8F:A5:EB:CA   
10.244.0.62:0    id=455   sec_id=12060 flags=0x0000 ifindex=71  mac=A6:EE:91:65:9A:32 nodemac=42:8A:B8:70:F8:45   
10.244.0.231:0   id=105   sec_id=29809 flags=0x0000 ifindex=36  mac=EA:46:93:6D:E7:E6 nodemac=9E:8B:CF:03:5F:32   
10.244.0.132:0   id=606   sec_id=5148  flags=0x0000 ifindex=73  mac=FE:76:8C:09:97:60 nodemac=72:C9:E8:7A:6A:98   
10.244.0.159:0   id=1493  sec_id=29809 flags=0x0000 ifindex=44  mac=CA:77:CB:4E:1C:80 nodemac=BA:5E:3C:1C:65:9B   
10.244.0.47:0    id=2128  sec_id=36400 flags=0x0000 ifindex=38  mac=5A:C9:E6:AB:85:D9 nodemac=D6:FC:9B:B6:91:9F   
10.244.0.49:0    id=633   sec_id=31330 flags=0x0000 ifindex=24  mac=4A:C9:92:BD:4D:EE nodemac=0A:C0:F0:54:67:48   
10.244.0.130:0   (localhost)                                                                                      
