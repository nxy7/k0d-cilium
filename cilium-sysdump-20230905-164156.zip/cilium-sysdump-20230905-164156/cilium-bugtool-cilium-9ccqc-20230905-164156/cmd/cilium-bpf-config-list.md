KEY             VALUE
AgentLiveness   5717263128939
UTimeOffset     3308435937500000
