USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        3774  0.0  0.0 725088 15616 ?        Ssl  14:41   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        3793  0.0  0.0   7060  2560 ?        R    14:41   0:00  \_ ps auxfw
root        3803  0.0  0.0   3932  2176 ?        R    14:41   0:00  \_ ss -u -p -a -i -s -n -e
root        3805  0.0  0.0   3932  2176 ?        R    14:41   0:00  \_ ss -t -p -a -i -s -n -e
root        3807  0.0  0.0   5076  1280 ?        R    14:41   0:00  \_ tc -d -s qdisc show
root        3808  0.0  0.0   5076   896 ?        R    14:41   0:00  \_ tc qdisc show
root        3810  0.0  0.0   4360  3200 ?        R    14:41   0:00  \_ bash -c top -b -n 1
root        3811  0.0  0.0   4360  3200 ?        R    14:41   0:00  \_ bash -c uptime
root        3812  0.0  0.0   4360  3200 ?        R    14:41   0:00  \_ bash -c dmesg --time-format=iso
root        3813  0.0  0.0   4360  3072 ?        R    14:41   0:00  \_ bash -c sysctl -a
root        3814  0.0  0.0   4236  1152 ?        R    14:41   0:00  \_ bash -c bpftool map show
root           1  2.9  0.9 880452 156772 ?       Ssl  14:38   0:05 cilium-agent --config-dir=/tmp/cilium/config-map
root         199  0.0  0.0 713924  4480 ?        Sl   14:38   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
