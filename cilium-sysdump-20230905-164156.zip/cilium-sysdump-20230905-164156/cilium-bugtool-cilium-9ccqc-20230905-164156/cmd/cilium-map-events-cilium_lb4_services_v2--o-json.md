{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.110.139.40:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.386Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "172.17.0.2:32245",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.386Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "0.0.0.0:32245",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.386Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.101.144.182:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.386Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.101.144.182:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.386Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.110.18.206:6379",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.386Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.110.18.206:6379",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.386Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.102.49.223:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.386Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.29.148:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.386Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.29.148:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.386Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.98.181.249:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.386Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.98.181.249:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.386Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.99.211.214:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.386Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.99.211.214:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.386Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.99.211.214:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.386Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:9153",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.386Z",
  "value": "0 0 (97) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.96.0.10:9153",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.386Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:53",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.386Z",
  "value": "0 0 (96) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.96.0.10:53",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.386Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.16.102:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.815Z",
  "value": "174 0 (185) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.16.102:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:38:55.815Z",
  "value": "0 1 (185) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.176.195:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:05.780Z",
  "value": "0 0 (186) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.101.73:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:08.783Z",
  "value": "0 0 (181) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.101.73:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:13.854Z",
  "value": "175 0 (181) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.101.73:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:13.854Z",
  "value": "0 1 (181) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.81.197:9402",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:20.802Z",
  "value": "176 0 (183) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.81.197:9402",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:20.802Z",
  "value": "0 1 (183) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:53",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:23.807Z",
  "value": "0 0 (96) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:9153",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:23.807Z",
  "value": "0 0 (97) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:9153",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:23.811Z",
  "value": "177 0 (97) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:9153",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:23.811Z",
  "value": "0 1 (97) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:53",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:23.811Z",
  "value": "178 0 (96) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:53",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:23.811Z",
  "value": "0 1 (96) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.236.194:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:26.848Z",
  "value": "0 0 (187) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.174.65:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:26.858Z",
  "value": "0 0 (188) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.58.195:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:26.867Z",
  "value": "0 0 (189) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.105.189:4433",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:26.876Z",
  "value": "0 0 (190) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.1.38:5432",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:26.885Z",
  "value": "0 0 (191) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.110.167:9000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:26.894Z",
  "value": "0 0 (192) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.110.167:9001",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:26.894Z",
  "value": "0 0 (193) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.161.190:8081",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:26.904Z",
  "value": "0 0 (194) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.2.13:5432",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:26.913Z",
  "value": "0 0 (195) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.188.83:6379",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:26.922Z",
  "value": "0 0 (196) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.78.2:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.201Z",
  "value": "0 0 (197) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.8.187:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.201Z",
  "value": "0 0 (198) [0x60 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.0.2:30888",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.201Z",
  "value": "0 0 (199) [0x42 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:30888",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.201Z",
  "value": "0 0 (200) [0x2 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.0.2:30888",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.311Z",
  "value": "30008 0 (199) [0x42 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:30888",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.311Z",
  "value": "30008 0 (200) [0x2 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.78.2:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.311Z",
  "value": "30008 0 (197) [0x0 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.8.187:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.311Z",
  "value": "30008 0 (198) [0x60 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.0.2:30888",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.319Z",
  "value": "30008 0 (199) [0x42 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:30888",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.319Z",
  "value": "30008 0 (200) [0x2 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.78.2:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.319Z",
  "value": "30008 0 (197) [0x0 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.8.187:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.319Z",
  "value": "30008 0 (198) [0x60 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.236.194:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.319Z",
  "value": "0 0 (187) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.58.195:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.319Z",
  "value": "0 0 (189) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.105.189:4433",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.319Z",
  "value": "0 0 (190) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.110.167:9000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.319Z",
  "value": "0 0 (192) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.110.167:9001",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.319Z",
  "value": "0 0 (193) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.161.190:8081",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.319Z",
  "value": "0 0 (194) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.78.2:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.325Z",
  "value": "30008 0 (197) [0x0 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.8.187:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.325Z",
  "value": "30008 0 (198) [0x60 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.0.2:30888",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.325Z",
  "value": "30008 0 (199) [0x42 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:30888",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.325Z",
  "value": "30008 0 (200) [0x2 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.236.194:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.325Z",
  "value": "0 0 (187) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.58.195:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.325Z",
  "value": "0 0 (189) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.105.189:4433",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.325Z",
  "value": "0 0 (190) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.110.167:9001",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.325Z",
  "value": "0 0 (193) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.110.167:9000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.326Z",
  "value": "0 0 (192) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.161.190:8081",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.326Z",
  "value": "0 0 (194) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.0.2:30888",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.336Z",
  "value": "30008 0 (199) [0x42 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:30888",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.336Z",
  "value": "30008 0 (200) [0x2 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.78.2:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.336Z",
  "value": "30008 0 (197) [0x0 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.8.187:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.336Z",
  "value": "30008 0 (198) [0x60 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.236.194:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.336Z",
  "value": "0 0 (187) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.58.195:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.336Z",
  "value": "0 0 (189) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.105.189:4433",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.336Z",
  "value": "0 0 (190) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.110.167:9001",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.336Z",
  "value": "0 0 (193) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.110.167:9000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.336Z",
  "value": "0 0 (192) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.161.190:8081",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:27.336Z",
  "value": "0 0 (194) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.194.147:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:28.619Z",
  "value": "0 0 (201) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.176.195:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:28.846Z",
  "value": "179 0 (186) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.176.195:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:28.846Z",
  "value": "0 1 (186) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.217.47:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:31.824Z",
  "value": "0 0 (182) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.217.47:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:31.831Z",
  "value": "180 0 (182) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.217.47:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:31.831Z",
  "value": "0 1 (182) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.236.194:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:32.825Z",
  "value": "181 0 (187) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.236.194:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:32.825Z",
  "value": "0 1 (187) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.58.195:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:33.828Z",
  "value": "182 0 (189) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.58.195:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:33.828Z",
  "value": "0 1 (189) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.58.195:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:33.834Z",
  "value": "182 0 (189) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.58.195:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:33.834Z",
  "value": "183 0 (189) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.58.195:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:33.834Z",
  "value": "0 2 (189) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.236.194:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:33.840Z",
  "value": "181 0 (187) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.236.194:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:33.840Z",
  "value": "184 0 (187) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.236.194:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:33.840Z",
  "value": "0 2 (187) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.105.189:4433",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:37.836Z",
  "value": "185 0 (190) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.101.105.189:4433",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:37.836Z",
  "value": "0 1 (190) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.68.211:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:40.841Z",
  "value": "186 0 (184) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.68.211:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:40.841Z",
  "value": "0 1 (184) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.58.195:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:44.849Z",
  "value": "182 0 (189) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.58.195:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:44.849Z",
  "value": "183 0 (189) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.58.195:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:44.849Z",
  "value": "187 0 (189) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.58.195:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:44.849Z",
  "value": "0 3 (189) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.58.195:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:45.851Z",
  "value": "182 0 (189) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.58.195:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:45.851Z",
  "value": "183 0 (189) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.58.195:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:45.851Z",
  "value": "187 0 (189) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.58.195:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:45.851Z",
  "value": "188 0 (189) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.58.195:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:39:45.851Z",
  "value": "0 4 (189) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.194.147:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:40:00.885Z",
  "value": "189 0 (201) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.194.147:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:40:00.885Z",
  "value": "0 1 (201) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.188.83:6379",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:40:05.910Z",
  "value": "190 0 (196) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.188.83:6379",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:40:05.910Z",
  "value": "0 1 (196) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.161.190:8081",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:40:12.073Z",
  "value": "191 0 (194) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.161.190:8081",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:40:12.073Z",
  "value": "0 1 (194) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.161.190:8081",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:40:12.919Z",
  "value": "0 0 (194) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.109.161.190:8081",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:40:12.919Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.1.38:5432",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:40:21.922Z",
  "value": "192 0 (191) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.1.38:5432",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:40:21.922Z",
  "value": "0 1 (191) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.110.167:9000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:40:27.940Z",
  "value": "193 0 (192) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.110.167:9000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:40:27.940Z",
  "value": "0 1 (192) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.110.167:9001",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:40:27.940Z",
  "value": "194 0 (193) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.110.167:9001",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:40:27.940Z",
  "value": "0 1 (193) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.2.13:5432",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:40:36.961Z",
  "value": "195 0 (195) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.103.2.13:5432",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:40:36.961Z",
  "value": "0 1 (195) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.161.190:8081",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:40:43.968Z",
  "value": "196 0 (194) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.161.190:8081",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-05T14:40:43.968Z",
  "value": "0 1 (194) [0x0 0x0]"
}

