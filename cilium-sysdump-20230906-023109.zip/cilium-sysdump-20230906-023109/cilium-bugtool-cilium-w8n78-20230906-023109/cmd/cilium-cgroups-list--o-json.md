[
  {
    "containers": [
      {
        "cgroup-id": 66143,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podcef60463-86d5-4447-ae90-55ff54bb1682/a5cf477eaac0cf0d27fa5ebd98da8f46edb10a44a815a41cbaae1d82c63ff82e"
      }
    ],
    "ips": [
      "10.244.0.50"
    ],
    "name": "frontend-58b6bf847f-k8mbl",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 67179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podbd3ce3ac-da37-4a29-8a72-4e5facf4f533/2d4b4b61014c06877ce8ffbb7ee7da5d620d12bed28306f6de8207f43c4290d9"
      }
    ],
    "ips": [
      "10.244.0.155"
    ],
    "name": "kratos-migrations-km25z",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 63701,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podd3e76d6d-442a-471e-a978-a566a4a37d9a/d5116bdbbafb36c079ab78f84f76663024a0c823bc82768964d62524d148f65a"
      }
    ],
    "ips": [
      "10.244.0.34"
    ],
    "name": "openebs-ndm-operator-7c667b76f8-xbj7v",
    "namespace": "openebs"
  },
  {
    "containers": [
      {
        "cgroup-id": 62887,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod9b6e2c75-2acc-4649-a728-ded630529fa4/6ae97fc3a57b7af375a8dea72b2b286dc127fad2061a36d004df67a51d8e6f3f"
      }
    ],
    "ips": [
      "10.244.0.253"
    ],
    "name": "openebs-ndm-cluster-exporter-589554f487-vj8m5",
    "namespace": "openebs"
  },
  {
    "containers": [
      {
        "cgroup-id": 63109,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podd1e6a52c-f4f0-4e2e-b1f4-e3976160f692/498bd48e6f1b7993ef1376032680c1af5b40e818b0ae71cd3c3c7e8531f31cda"
      }
    ],
    "ips": [
      "10.244.0.240"
    ],
    "name": "cert-manager-78ddc5db85-h92qs",
    "namespace": "cert-manager"
  },
  {
    "containers": [
      {
        "cgroup-id": 66291,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod11561df7-bcc5-4fe3-b479-6c1b472b150b/ef3251296a8043ed80107fe67cd08766421abaeec65b3a1a1fa4c2ca8c50056c"
      }
    ],
    "ips": [
      "10.244.0.21"
    ],
    "name": "frontend-58b6bf847f-cv4lc",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 65847,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod44597ca4-d5fc-4e10-bffa-eb3d057f0c21/0f8b8e9272d4911f754b62a2ceba4bdc4ad2ce5757377e3775acc4eff9e544a4"
      }
    ],
    "ips": [
      "10.244.0.28"
    ],
    "name": "backend-855f6c7b4-8bqth",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 63257,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod1f988a8c-170f-43e1-af48-e87b9415e57c/818ed5d107366c8e1ea3c665039d9f227a04f6d207088caf1d6d2c44ecd73bc9"
      }
    ],
    "ips": [
      "10.244.0.219"
    ],
    "name": "cert-manager-webhook-879c48cd4-b4q2j",
    "namespace": "cert-manager"
  },
  {
    "containers": [
      {
        "cgroup-id": 63405,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/burstable/podbb1b5999-8373-4289-a662-2086e2be11e2/4312e0184c30ab22dd100d8d02846bf17a1b6a3bd997368a66db25befe93f0cc"
      }
    ],
    "ips": [
      "10.244.0.207"
    ],
    "name": "coredns-878bb57ff-j98j5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 63775,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod393b75cc-6f60-444f-bd9a-be1a2da57465/b3ffcc5fa56bac9d04fbe67ba3b02ff3df0830d559e146eaae8e8af8cf12c802"
      },
      {
        "cgroup-id": 63331,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod393b75cc-6f60-444f-bd9a-be1a2da57465/a3cd6405d7ca7abbc3fad2860d4114b92867aeed5d1bf95912dff89d1ebbf2ee"
      }
    ],
    "ips": [
      "10.244.0.77"
    ],
    "name": "hubble-ui-6b468cff75-sv8hh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 62739,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod309940c1-7558-4706-8b87-1123dd0f4110/83d93cc6809de780df5ef30147d897614e961e106823f7e3eda46d215c6b4870"
      }
    ],
    "ips": [
      "172.17.0.2"
    ],
    "name": "openebs-ndm-2gzjg",
    "namespace": "openebs"
  },
  {
    "containers": [
      {
        "cgroup-id": 63035,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/poda26db218-f175-4bfd-9e4a-be3bcbe19ded/6801d91bb624528c51377184cbc1394344927c03377eef9e58911faf047aeed9"
      }
    ],
    "ips": [
      "10.244.0.171"
    ],
    "name": "cert-manager-cainjector-6774f986b-5fqd9",
    "namespace": "cert-manager"
  },
  {
    "containers": [
      {
        "cgroup-id": 65699,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podb9382c97-d2bd-489e-a8cc-2b1e28d83147/97801f2dceed95074e9cb6ad1349547fc4cf3c1c0bd9abeef54904107c069ecf"
      }
    ],
    "ips": [
      "10.244.0.193"
    ],
    "name": "backend-855f6c7b4-fkt9r",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 67031,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod5847827a-05a6-49d9-90a8-d367663b5a93/3c8c395ae380bea7e49818c852d4ccfef8a97c1636f6ca85914371e15e5e70f0"
      }
    ],
    "ips": [
      "10.244.0.105"
    ],
    "name": "redis-68c95977f4-bl8l4",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 65995,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod2002cc00-09af-4175-be45-ece3965028fc/41754c1e47648127e5257f7e50a28338bb667b419a8d2263d40facb3e651de3e"
      }
    ],
    "ips": [
      "10.244.0.119"
    ],
    "name": "frontend-58b6bf847f-j9rzh",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 60815,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/burstable/pod22427fab-9a39-4cc2-a426-74ae96f5c12c/ebfa399b6b02e802a4544d7a53cf917c07cb088b16670b354b648be7c6d78fa6"
      }
    ],
    "ips": [
      "172.17.0.2"
    ],
    "name": "cilium-w8n78",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 63479,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod7fa8a095-e02b-4106-8f29-6f045bb564b2/941cfaa7dc5ea7e82294255275eec64909df44edfabb1a5a483e37ab6737ce60"
      }
    ],
    "ips": [
      "10.244.0.172"
    ],
    "name": "openebs-localpv-provisioner-7d6ccb7795-4rhmc",
    "namespace": "openebs"
  },
  {
    "containers": [
      {
        "cgroup-id": 63553,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/burstable/pod4e17e3f2-6ad3-4991-9b19-2f578b1d614b/e985250bd5b6671f7a97690eef341523d12737355868efc97fdbbac5d1a5edf2"
      }
    ],
    "ips": [
      "10.244.0.212"
    ],
    "name": "metrics-server-7f86dff975-b2xzk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 63627,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod30b355fb-ed2e-4a97-af27-c5bf015652e0/1c45619b207e9b8c1c4844994d09bc150bf8753ed129a093406b5f3013641662"
      }
    ],
    "ips": [
      "10.244.0.199"
    ],
    "name": "openebs-ndm-node-exporter-prqkp",
    "namespace": "openebs"
  },
  {
    "containers": [
      {
        "cgroup-id": 62961,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pod9d49a98f-0374-4080-8883-0a8f172373f0/ac233f55b65f4dbcdc6346255e42eb5ce67d325f8895542b37858ed753b0af93"
      }
    ],
    "ips": [
      "10.244.0.197"
    ],
    "name": "hubble-relay-777496bf44-ngd9p",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 66809,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podf605b138-0374-4f21-a0d1-0cc7c730412e/51a7c56673e2630b4a1267c788fd06a744218b81f685139e06e62abe8acd517d"
      }
    ],
    "ips": [
      "10.244.0.192"
    ],
    "name": "kratos-77cbf98c8f-wcvxh",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 66069,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/pode84e0674-5c1f-4ec3-8f3c-54da3c1784b9/e7499fe83363d30fc5287b5c98449a92472c91488e9a77e9e02426c7fdbf83af"
      }
    ],
    "ips": [
      "10.244.0.104"
    ],
    "name": "frontend-58b6bf847f-rg7lb",
    "namespace": "streampai"
  },
  {
    "containers": [
      {
        "cgroup-id": 60519,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods/besteffort/podc79c68a3-a6fe-436a-8bfc-3345bdb10cf9/ea59852f98278992dfae29aa3608632c75800db531483515313dbc5a8e945940"
      }
    ],
    "ips": [
      "172.17.0.2"
    ],
    "name": "cilium-envoy-pfg6l",
    "namespace": "kube-system"
  }
]

