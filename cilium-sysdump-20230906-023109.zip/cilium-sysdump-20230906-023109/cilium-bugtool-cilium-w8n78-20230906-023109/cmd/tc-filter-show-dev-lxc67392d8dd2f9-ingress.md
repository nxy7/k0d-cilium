filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc67392d8dd2f9 direct-action not_in_hw id 7448 tag 703e54dc8bbf86d8 jited 
