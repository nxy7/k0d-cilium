Error: bpf obj get (/sys/fs/bpf/tc/globals/cilium_ep_to_policy): No such file or directory
> Error while running 'bpftool map dump pinned /sys/fs/bpf/tc/globals/cilium_ep_to_policy':  exit status 255

