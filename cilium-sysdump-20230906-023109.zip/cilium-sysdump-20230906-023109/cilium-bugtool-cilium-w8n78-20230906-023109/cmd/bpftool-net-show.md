xdp:

tc:
cilium_net(2) clsact/ingress cil_to_host-cilium_net id 7486
cilium_host(3) clsact/ingress cil_to_host-cilium_host id 7463
cilium_host(3) clsact/egress cil_from_host-cilium_host id 7475
cilium_vxlan(4) clsact/ingress cil_from_overlay-cilium_vxlan id 7184
cilium_vxlan(4) clsact/egress cil_to_overlay-cilium_vxlan id 7185
lxc_health(6) clsact/ingress cil_from_container-lxc_health id 7334
lxcd2c3af8db6db(10) clsact/ingress cil_from_container-lxcd2c3af8db6db id 7340
lxcfe0350a80770(12) clsact/ingress cil_from_container-lxcfe0350a80770 id 7311
lxcc3b0024664c5(14) clsact/ingress cil_from_container-lxcc3b0024664c5 id 7294
lxcde06b44aa784(16) clsact/ingress cil_from_container-lxcde06b44aa784 id 7326
lxcf43f6d46ba72(18) clsact/ingress cil_from_container-lxcf43f6d46ba72 id 7318
eth0(19) clsact/ingress cil_from_netdev-eth0 id 7498
eth0(19) clsact/egress cil_to_netdev-eth0 id 7508
lxc8d6e8e4b0477(21) clsact/ingress cil_from_container-lxc8d6e8e4b0477 id 7291
lxc4810a327af6a(23) clsact/ingress cil_from_container-lxc4810a327af6a id 7407
lxc57de2208c7d6(25) clsact/ingress cil_from_container-lxc57de2208c7d6 id 7273
lxcdac5f40c881a(27) clsact/ingress cil_from_container-lxcdac5f40c881a id 7432
lxc67392d8dd2f9(29) clsact/ingress cil_from_container-lxc67392d8dd2f9 id 7448
lxc32e5e00a9fb8(31) clsact/ingress cil_from_container-lxc32e5e00a9fb8 id 7389
lxc6cffdbcb447a(33) clsact/ingress cil_from_container-lxc6cffdbcb447a id 7583
lxc9ab0fdf09458(35) clsact/ingress cil_from_container-lxc9ab0fdf09458 id 7573
lxc97b3ebf9b0a3(37) clsact/ingress cil_from_container-lxc97b3ebf9b0a3 id 7560
lxc4782bc321b2a(39) clsact/ingress cil_from_container-lxc4782bc321b2a id 7568
lxc2d18f368a137(41) clsact/ingress cil_from_container-lxc2d18f368a137 id 7620
lxc097a7596acc7(43) clsact/ingress cil_from_container-lxc097a7596acc7 id 7634
lxcd1d1b64f4030(45) clsact/ingress cil_from_container-lxcd1d1b64f4030 id 7553
lxc15ef011ff99c(47) clsact/ingress cil_from_container-lxc15ef011ff99c id 7670
lxcf382a3fb49e9(49) clsact/ingress cil_from_container-lxcf382a3fb49e9 id 7692
lxcc175dc79836e(51) clsact/ingress cil_from_container-lxcc175dc79836e id 7716
lxc4efd61adef5f(53) clsact/ingress cil_from_container-lxc4efd61adef5f id 7730
lxcd430f9df641c(55) clsact/ingress cil_from_container-lxcd430f9df641c id 7748
lxc24236c43383d(57) clsact/ingress cil_from_container-lxc24236c43383d id 7762
lxc454e019d1f91(59) clsact/ingress cil_from_container-lxc454e019d1f91 id 7784
lxc630e7e15710e(61) clsact/ingress cil_from_container-lxc630e7e15710e id 7801
lxc3dc0cfd41a9f(63) clsact/ingress cil_from_container-lxc3dc0cfd41a9f id 7814
lxcb390a3f00bab(65) clsact/ingress cil_from_container-lxcb390a3f00bab id 7835
lxc827eb49d10c9(67) clsact/ingress cil_from_container-lxc827eb49d10c9 id 7842

flow_dissector:

