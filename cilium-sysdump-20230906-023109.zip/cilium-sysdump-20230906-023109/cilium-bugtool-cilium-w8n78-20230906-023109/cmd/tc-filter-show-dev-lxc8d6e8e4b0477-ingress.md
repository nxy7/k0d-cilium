filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc8d6e8e4b0477 direct-action not_in_hw id 7291 tag 7f5ad5b0ae2b827a jited 
