filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf382a3fb49e9 direct-action not_in_hw id 7692 tag f453480b3e48bf10 jited 
