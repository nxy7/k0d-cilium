[
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "postgres",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.106.247.125",
        "port": 5432,
        "scope": "external"
      },
      "id": 130
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "postgres",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.106.247.125",
          "port": 5432,
          "scope": "external"
        },
        "id": 130
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.207",
          "nodeName": "k0s",
          "port": 9153,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kube-dns",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.96.0.10",
        "port": 9153,
        "scope": "external"
      },
      "id": 9
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.207",
            "nodeName": "k0s",
            "port": 9153,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kube-dns",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.96.0.10",
          "port": 9153,
          "scope": "external"
        },
        "id": 9
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.105",
          "nodeName": "k0s",
          "port": 6379,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "redis",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.99.225.9",
        "port": 6379,
        "scope": "external"
      },
      "id": 131
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.105",
            "nodeName": "k0s",
            "port": 6379,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "redis",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.99.225.9",
          "port": 6379,
          "scope": "external"
        },
        "id": 131
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cilium-gateway-sgtw",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "NodePort"
      },
      "frontend-address": {
        "ip": "0.0.0.0",
        "port": 30867,
        "scope": "external"
      },
      "id": 134
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cilium-gateway-sgtw",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "NodePort"
        },
        "frontend-address": {
          "ip": "0.0.0.0",
          "port": 30867,
          "scope": "external"
        },
        "id": 134
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cilium-gateway-sgtw",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "LoadBalancer"
      },
      "frontend-address": {
        "ip": "172.17.223.107",
        "port": 80,
        "scope": "external"
      },
      "id": 133
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cilium-gateway-sgtw",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "LoadBalancer"
        },
        "frontend-address": {
          "ip": "172.17.223.107",
          "port": 80,
          "scope": "external"
        },
        "id": 133
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.240",
          "nodeName": "k0s",
          "port": 9402,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cert-manager",
        "namespace": "cert-manager",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.105.180.26",
        "port": 9402,
        "scope": "external"
      },
      "id": 118
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.240",
            "nodeName": "k0s",
            "port": 9402,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cert-manager",
          "namespace": "cert-manager",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.105.180.26",
          "port": 9402,
          "scope": "external"
        },
        "id": 118
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.28",
          "nodeName": "k0s",
          "port": 7000,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.244.0.193",
          "nodeName": "k0s",
          "port": 7000,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "backend",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.108.77.184",
        "port": 7000,
        "scope": "external"
      },
      "id": 122
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.28",
            "nodeName": "k0s",
            "port": 7000,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.244.0.193",
            "nodeName": "k0s",
            "port": 7000,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "backend",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.108.77.184",
          "port": 7000,
          "scope": "external"
        },
        "id": 122
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "coqui",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.105.72.35",
        "port": 7000,
        "scope": "external"
      },
      "id": 123
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "coqui",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.105.72.35",
          "port": 7000,
          "scope": "external"
        },
        "id": 123
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "minio",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.98.222.33",
        "port": 9001,
        "scope": "external"
      },
      "id": 127
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "minio",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.98.222.33",
          "port": 9001,
          "scope": "external"
        },
        "id": 127
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.207",
          "nodeName": "k0s",
          "port": 53,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kube-dns",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.96.0.10",
        "port": 53,
        "scope": "external"
      },
      "id": 8
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.207",
            "nodeName": "k0s",
            "port": 53,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kube-dns",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.96.0.10",
          "port": 53,
          "scope": "external"
        },
        "id": 8
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.219",
          "nodeName": "k0s",
          "port": 10250,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cert-manager-webhook",
        "namespace": "cert-manager",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.108.137.97",
        "port": 443,
        "scope": "external"
      },
      "id": 119
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.219",
            "nodeName": "k0s",
            "port": 10250,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cert-manager-webhook",
          "namespace": "cert-manager",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.108.137.97",
          "port": 443,
          "scope": "external"
        },
        "id": 119
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.197",
          "nodeName": "k0s",
          "port": 4245,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "hubble-relay",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.104.172.173",
        "port": 80,
        "scope": "external"
      },
      "id": 121
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.197",
            "nodeName": "k0s",
            "port": 4245,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "hubble-relay",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.104.172.173",
          "port": 80,
          "scope": "external"
        },
        "id": 121
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "agent-injector",
        "namespace": "ambassador",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.107.136.162",
        "port": 443,
        "scope": "external"
      },
      "id": 136
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "agent-injector",
          "namespace": "ambassador",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.107.136.162",
          "port": 443,
          "scope": "external"
        },
        "id": 136
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.212",
          "nodeName": "k0s",
          "port": 10250,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "metrics-server",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.109.147.188",
        "port": 443,
        "scope": "external"
      },
      "id": 117
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.212",
            "nodeName": "k0s",
            "port": 10250,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "metrics-server",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.109.147.188",
          "port": 443,
          "scope": "external"
        },
        "id": 117
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "172.17.0.2",
          "nodeName": "k0s",
          "port": 4244,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Local",
        "name": "hubble-peer",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.109.115.136",
        "port": 443,
        "scope": "external"
      },
      "id": 120
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "172.17.0.2",
            "nodeName": "k0s",
            "port": 4244,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Local",
          "name": "hubble-peer",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.109.115.136",
          "port": 443,
          "scope": "external"
        },
        "id": 120
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.104",
          "nodeName": "k0s",
          "port": 3000,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.244.0.50",
          "nodeName": "k0s",
          "port": 3000,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.244.0.119",
          "nodeName": "k0s",
          "port": 3000,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.244.0.21",
          "nodeName": "k0s",
          "port": 3000,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "frontend",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.123.5",
        "port": 3000,
        "scope": "external"
      },
      "id": 124
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.104",
            "nodeName": "k0s",
            "port": 3000,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.244.0.50",
            "nodeName": "k0s",
            "port": 3000,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.244.0.119",
            "nodeName": "k0s",
            "port": 3000,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.244.0.21",
            "nodeName": "k0s",
            "port": 3000,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "frontend",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.123.5",
          "port": 3000,
          "scope": "external"
        },
        "id": 124
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "livestreamdb",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.109.149.13",
        "port": 5432,
        "scope": "external"
      },
      "id": 126
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "livestreamdb",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.109.149.13",
          "port": 5432,
          "scope": "external"
        },
        "id": 126
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "minio",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.98.222.33",
        "port": 9000,
        "scope": "external"
      },
      "id": 128
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "minio",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.98.222.33",
          "port": 9000,
          "scope": "external"
        },
        "id": 128
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cilium-gateway-sgtw",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.99.89.133",
        "port": 80,
        "scope": "external"
      },
      "id": 132
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cilium-gateway-sgtw",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.99.89.133",
          "port": 80,
          "scope": "external"
        },
        "id": 132
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.77",
          "nodeName": "k0s",
          "port": 8081,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "hubble-ui",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.102.228.233",
        "port": 80,
        "scope": "external"
      },
      "id": 116
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.77",
            "nodeName": "k0s",
            "port": 8081,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "hubble-ui",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.102.228.233",
          "port": 80,
          "scope": "external"
        },
        "id": 116
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.244.0.192",
          "nodeName": "k0s",
          "port": 4433,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kratos",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.110.120.45",
        "port": 4433,
        "scope": "external"
      },
      "id": 125
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.244.0.192",
            "nodeName": "k0s",
            "port": 4433,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kratos",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.110.120.45",
          "port": 4433,
          "scope": "external"
        },
        "id": 125
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "pgweb",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.105.143.77",
        "port": 8081,
        "scope": "external"
      },
      "id": 129
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "pgweb",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.105.143.77",
          "port": 8081,
          "scope": "external"
        },
        "id": 129
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "cilium-gateway-sgtw",
        "namespace": "streampai",
        "trafficPolicy": "Cluster",
        "type": "NodePort"
      },
      "frontend-address": {
        "ip": "172.17.0.2",
        "port": 30867,
        "scope": "external"
      },
      "id": 135
    },
    "status": {
      "realized": {
        "backend-addresses": [],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "cilium-gateway-sgtw",
          "namespace": "streampai",
          "trafficPolicy": "Cluster",
          "type": "NodePort"
        },
        "frontend-address": {
          "ip": "172.17.0.2",
          "port": 30867,
          "scope": "external"
        },
        "id": 135
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "172.17.0.2",
          "port": 6443,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kubernetes",
        "namespace": "default",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.96.0.1",
        "port": 443,
        "scope": "external"
      },
      "id": 4
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "172.17.0.2",
            "port": 6443,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kubernetes",
          "namespace": "default",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.96.0.1",
          "port": 443,
          "scope": "external"
        },
        "id": 4
      }
    }
  }
]

