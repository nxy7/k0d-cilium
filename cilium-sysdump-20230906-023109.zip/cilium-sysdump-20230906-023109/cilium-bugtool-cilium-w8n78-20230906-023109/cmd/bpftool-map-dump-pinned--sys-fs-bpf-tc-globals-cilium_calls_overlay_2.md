key: 01 00 00 00  value: 13 1c 00 00
key: 07 00 00 00  value: 12 1c 00 00
key: 0f 00 00 00  value: 0d 1c 00 00
key: 11 00 00 00  value: 0e 1c 00 00
key: 24 00 00 00  value: 14 1c 00 00
key: 26 00 00 00  value: 0f 1c 00 00
Found 6 elements
