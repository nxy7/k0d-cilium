{
  "local": {
    "name": "k0s"
  },
  "nodes": [
    {
      "endpoint": {
        "icmp": {
          "status": "Connection timed out"
        },
        "ip": "10.244.0.206"
      },
      "health-endpoint": {
        "primary-address": {
          "icmp": {
            "status": "Connection timed out"
          },
          "ip": "10.244.0.206"
        },
        "secondary-addresses": []
      },
      "host": {
        "primary-address": {
          "icmp": {
            "latency": 226844
          },
          "ip": "172.17.0.2"
        },
        "secondary-addresses": []
      },
      "name": "k0s"
    }
  ],
  "timestamp": "2023-09-06T00:30:53Z"
}

