KEY             VALUE
AgentLiveness   9119707226134
UTimeOffset     3308498343750000
