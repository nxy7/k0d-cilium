filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc630e7e15710e direct-action not_in_hw id 7801 tag 34c2c6483ee84559 jited 
