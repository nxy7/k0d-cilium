KVStore:                Ok   Disabled
Kubernetes:             Ok   1.27 (v1.27.4+k0s) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideEnvoyConfig", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumEnvoyConfig", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Secrets", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   True   [eth0 172.17.0.2]
Host firewall:          Disabled
CNI Chaining:           none
Cilium:                 Ok   1.14.1 (v1.14.1-c191ef6f)
NodeMonitor:            Listening for events on 32 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 32/254 allocated from 10.244.0.0/24, 
Allocated addresses:
  10.244.0.101 (streampai/livestream-migrations-8nnxm)
  10.244.0.104 (streampai/frontend-58b6bf847f-rg7lb)
  10.244.0.105 (streampai/redis-68c95977f4-bl8l4)
  10.244.0.119 (streampai/frontend-58b6bf847f-j9rzh)
  10.244.0.144 (streampai/create-minio-buckets-2hsfq)
  10.244.0.155 (streampai/kratos-migrations-km25z)
  10.244.0.171 (cert-manager/cert-manager-cainjector-6774f986b-5fqd9)
  10.244.0.172 (openebs/openebs-localpv-provisioner-7d6ccb7795-4rhmc)
  10.244.0.176 (router)
  10.244.0.18 (openebs/init-pvc-4f2ec5d9-e41b-425e-bdb7-332c06f7825a)
  10.244.0.182 (openebs/init-pvc-bf475e5e-08fc-4f1e-95bf-5e66e3b2ccb5)
  10.244.0.186 (openebs/init-pvc-a98007c1-4485-4928-9e38-355a6ab271ae)
  10.244.0.192 (streampai/kratos-77cbf98c8f-wcvxh)
  10.244.0.193 (streampai/backend-855f6c7b4-fkt9r)
  10.244.0.197 (kube-system/hubble-relay-777496bf44-ngd9p)
  10.244.0.199 (openebs/openebs-ndm-node-exporter-prqkp)
  10.244.0.206 (health)
  10.244.0.207 (kube-system/coredns-878bb57ff-j98j5)
  10.244.0.209 (streampai/streamchat-79dfbb9bb4-c954g)
  10.244.0.21 (streampai/frontend-58b6bf847f-cv4lc)
  10.244.0.212 (kube-system/metrics-server-7f86dff975-b2xzk)
  10.244.0.219 (cert-manager/cert-manager-webhook-879c48cd4-b4q2j)
  10.244.0.230 (ingress)
  10.244.0.240 (cert-manager/cert-manager-78ddc5db85-h92qs)
  10.244.0.253 (openebs/openebs-ndm-cluster-exporter-589554f487-vj8m5)
  10.244.0.28 (streampai/backend-855f6c7b4-8bqth)
  10.244.0.34 (openebs/openebs-ndm-operator-7c667b76f8-xbj7v)
  10.244.0.50 (streampai/frontend-58b6bf847f-k8mbl)
  10.244.0.57 (streampai/postgres-migrations-79t9m)
  10.244.0.77 (kube-system/hubble-ui-6b468cff75-sv8hh)
  10.244.0.84 (ambassador/traffic-manager-55d995585d-cs5xg)
  10.244.0.93 (streampai/pgweb-b74849bb6-hrcb8)
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Host Routing:           Legacy
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      136/136 healthy
  Name                                  Last success   Last error   Count   Message
  cilium-health-ep                      19s ago        never        0       no error   
  dns-garbage-collector-job             23s ago        never        0       no error   
  endpoint-1164-regeneration-recovery   never          never        0       no error   
  endpoint-1412-regeneration-recovery   never          never        0       no error   
  endpoint-1526-regeneration-recovery   never          never        0       no error   
  endpoint-1528-regeneration-recovery   never          never        0       no error   
  endpoint-1618-regeneration-recovery   never          never        0       no error   
  endpoint-17-regeneration-recovery     never          never        0       no error   
  endpoint-178-regeneration-recovery    never          never        0       no error   
  endpoint-182-regeneration-recovery    never          never        0       no error   
  endpoint-1959-regeneration-recovery   never          never        0       no error   
  endpoint-199-regeneration-recovery    never          never        0       no error   
  endpoint-1992-regeneration-recovery   never          never        0       no error   
  endpoint-2084-regeneration-recovery   never          never        0       no error   
  endpoint-2201-regeneration-recovery   never          never        0       no error   
  endpoint-246-regeneration-recovery    never          never        0       no error   
  endpoint-2589-regeneration-recovery   never          never        0       no error   
  endpoint-2682-regeneration-recovery   never          never        0       no error   
  endpoint-293-regeneration-recovery    never          never        0       no error   
  endpoint-3168-regeneration-recovery   never          never        0       no error   
  endpoint-3501-regeneration-recovery   never          never        0       no error   
  endpoint-3565-regeneration-recovery   never          never        0       no error   
  endpoint-359-regeneration-recovery    never          never        0       no error   
  endpoint-3726-regeneration-recovery   never          never        0       no error   
  endpoint-398-regeneration-recovery    never          never        0       no error   
  endpoint-443-regeneration-recovery    never          never        0       no error   
  endpoint-48-regeneration-recovery     never          never        0       no error   
  endpoint-509-regeneration-recovery    never          never        0       no error   
  endpoint-620-regeneration-recovery    never          never        0       no error   
  endpoint-628-regeneration-recovery    never          never        0       no error   
  endpoint-824-regeneration-recovery    never          never        0       no error   
  endpoint-858-regeneration-recovery    never          never        0       no error   
  endpoint-951-regeneration-recovery    never          never        0       no error   
  endpoint-gc                           1m23s ago      never        0       no error   
  ipcache-inject-labels                 21s ago        1m22s ago    0       no error   
  k8s-heartbeat                         24s ago        never        0       no error   
  link-cache                            5s ago         never        0       no error   
  metricsmap-bpf-prom-sync              3s ago         never        0       no error   
  resolve-identity-1164                 14s ago        never        0       no error   
  resolve-identity-1412                 13s ago        never        0       no error   
  resolve-identity-1526                 14s ago        never        0       no error   
  resolve-identity-1528                 1m17s ago      never        0       no error   
  resolve-identity-1618                 12s ago        never        0       no error   
  resolve-identity-17                   1m19s ago      never        0       no error   
  resolve-identity-178                  1m7s ago       never        0       no error   
  resolve-identity-182                  19s ago        never        0       no error   
  resolve-identity-1959                 1m16s ago      never        0       no error   
  resolve-identity-199                  1m18s ago      never        0       no error   
  resolve-identity-1992                 1m19s ago      never        0       no error   
  resolve-identity-2084                 1m18s ago      never        0       no error   
  resolve-identity-2201                 15s ago        never        0       no error   
  resolve-identity-246                  1m19s ago      never        0       no error   
  resolve-identity-2589                 15s ago        never        0       no error   
  resolve-identity-2682                 16s ago        never        0       no error   
  resolve-identity-293                  19s ago        never        0       no error   
  resolve-identity-3168                 1m18s ago      never        0       no error   
  resolve-identity-3501                 1m15s ago      never        0       no error   
  resolve-identity-3565                 17s ago        never        0       no error   
  resolve-identity-359                  1m14s ago      never        0       no error   
  resolve-identity-3726                 1m19s ago      never        0       no error   
  resolve-identity-398                  12s ago        never        0       no error   
  resolve-identity-443                  16s ago        never        0       no error   
  resolve-identity-48                   19s ago        never        0       no error   
  resolve-identity-509                  17s ago        never        0       no error   
  resolve-identity-620                  19s ago        never        0       no error   
  resolve-identity-628                  19s ago        never        0       no error   
  resolve-identity-824                  19s ago        never        0       no error   
  resolve-identity-858                  19s ago        never        0       no error   
  resolve-identity-951                  1m19s ago      never        0       no error   
  sync-host-ips                         21s ago        never        0       no error   
  sync-lb-maps-with-k8s-services        1m21s ago      never        0       no error   
  sync-policymap-1164                   10s ago        never        0       no error   
  sync-policymap-1412                   10s ago        never        0       no error   
  sync-policymap-1526                   10s ago        never        0       no error   
  sync-policymap-1528                   10s ago        never        0       no error   
  sync-policymap-1618                   10s ago        never        0       no error   
  sync-policymap-17                     10s ago        never        0       no error   
  sync-policymap-178                    10s ago        never        0       no error   
  sync-policymap-182                    10s ago        never        0       no error   
  sync-policymap-1959                   10s ago        never        0       no error   
  sync-policymap-199                    10s ago        never        0       no error   
  sync-policymap-1992                   10s ago        never        0       no error   
  sync-policymap-2084                   10s ago        never        0       no error   
  sync-policymap-2201                   10s ago        never        0       no error   
  sync-policymap-246                    10s ago        never        0       no error   
  sync-policymap-2589                   10s ago        never        0       no error   
  sync-policymap-2682                   10s ago        never        0       no error   
  sync-policymap-293                    10s ago        never        0       no error   
  sync-policymap-3168                   10s ago        never        0       no error   
  sync-policymap-3501                   10s ago        never        0       no error   
  sync-policymap-3565                   10s ago        never        0       no error   
  sync-policymap-359                    10s ago        never        0       no error   
  sync-policymap-3726                   10s ago        never        0       no error   
  sync-policymap-398                    10s ago        never        0       no error   
  sync-policymap-443                    10s ago        never        0       no error   
  sync-policymap-48                     10s ago        never        0       no error   
  sync-policymap-509                    10s ago        never        0       no error   
  sync-policymap-620                    10s ago        never        0       no error   
  sync-policymap-628                    10s ago        never        0       no error   
  sync-policymap-824                    10s ago        never        0       no error   
  sync-policymap-858                    10s ago        never        0       no error   
  sync-policymap-951                    10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1164)     3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1412)     2s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1526)     3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1528)     6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1618)     1s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (17)       8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (178)      7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (182)      8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1959)     5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (199)      7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1992)     9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2084)     7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2201)     4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (246)      9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2589)     4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2682)     6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (293)      9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3168)     6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3501)     5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3565)     6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (359)      4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3726)     9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (398)      2s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (443)      5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (48)       9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (509)      7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (620)      8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (628)      8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (824)      9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (858)      9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (951)      7s ago         never        0       no error   
  sync-utime                            21s ago        never        0       no error   
  template-dir-watcher                  never          never        0       no error   
  write-cni-file                        1m23s ago      never        0       no error   
Proxy Status:            OK, ip 10.244.0.176, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 256, max 65535
Hubble:                  Ok   Current/Max Flows: 2144/4095 (52.36%), Flows/s: 20.74   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 True
  Socket LB:              Enabled
  Socket LB Tracing:      Enabled
  Socket LB Coverage:     Full
  Devices:                eth0 172.17.0.2
  Mode:                   SNAT
  Backend Selection:      Random
  Session Affinity:       Enabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  XDP Acceleration:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Enabled (Range: 30000-32767) 
  - LoadBalancer:   Enabled 
  - externalIPs:    Enabled 
  - HostPort:       Enabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   73193
  TCP connection tracking       146386
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           146386
  Neighbor table                146386
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              73193
  Tunnel                        65536
Encryption:         Disabled        
Cluster health:     0/1 reachable   (2023-09-06T00:30:53Z)
  Name              IP              Node      Endpoints
  k0s (localhost)   172.17.0.2      unknown   unreachable
