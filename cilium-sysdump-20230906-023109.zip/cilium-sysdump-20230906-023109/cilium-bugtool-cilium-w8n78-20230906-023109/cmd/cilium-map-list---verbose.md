## Map: cilium_policy_03565
Cache is disabled


## Map: cilium_policy_01164
Cache is disabled


## Map: cilium_lb4_source_range
Cache is empty


## Map: cilium_policy_01992
Cache is disabled


## Map: cilium_policy_00199
Cache is disabled


## Map: cilium_policy_03168
Cache is disabled


## Map: cilium_policy_00048
Cache is disabled


## Map: cilium_policy_00628
Cache is disabled


## Map: cilium_policy_02682
Cache is disabled


## Map: cilium_policy_01526
Cache is disabled


## Map: cilium_lb_affinity_match
Cache is empty


## Map: cilium_policy_02084
Cache is disabled


## Map: cilium_policy_03501
Cache is disabled


## Map: cilium_ipcache
Key               Value                                                State   Error
10.244.0.212/32   identity=32957 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.209/32   identity=3108 encryptkey=0 tunnelendpoint=0.0.0.0    sync    
10.244.0.18/32    identity=1847 encryptkey=0 tunnelendpoint=0.0.0.0    sync    
10.244.0.28/32    identity=9256 encryptkey=0 tunnelendpoint=0.0.0.0    sync    
10.244.0.93/32    identity=2199 encryptkey=0 tunnelendpoint=0.0.0.0    sync    
10.244.0.176/32   identity=1 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.244.0.206/32   identity=4 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.244.0.240/32   identity=33925 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.172/32   identity=13128 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.207/32   identity=6400 encryptkey=0 tunnelendpoint=0.0.0.0    sync    
10.244.0.101/32   identity=7207 encryptkey=0 tunnelendpoint=0.0.0.0    sync    
10.244.0.57/32    identity=58695 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.171/32   identity=28402 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.21/32    identity=40807 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.144/32   identity=24494 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.219/32   identity=12886 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.253/32   identity=48566 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.182/32   identity=1847 encryptkey=0 tunnelendpoint=0.0.0.0    sync    
10.244.0.84/32    identity=63576 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.119/32   identity=40807 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.193/32   identity=9256 encryptkey=0 tunnelendpoint=0.0.0.0    sync    
10.244.0.192/32   identity=11535 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.50/32    identity=40807 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.104/32   identity=40807 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.155/32   identity=707 encryptkey=0 tunnelendpoint=0.0.0.0     sync    
10.244.0.186/32   identity=1847 encryptkey=0 tunnelendpoint=0.0.0.0    sync    
172.17.0.2/32     identity=1 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.244.0.230/32   identity=8 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.244.0.197/32   identity=25058 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
10.244.0.34/32    identity=44793 encryptkey=0 tunnelendpoint=0.0.0.0   sync    
0.0.0.0/0         identity=2 encryptkey=0 tunnelendpoint=0.0.0.0       sync    
10.244.0.77/32    identity=5267 encryptkey=0 tunnelendpoint=0.0.0.0    sync    
10.244.0.199/32   identity=8310 encryptkey=0 tunnelendpoint=0.0.0.0    sync    
10.244.0.105/32   identity=11487 encryptkey=0 tunnelendpoint=0.0.0.0   sync    

## Map: cilium_lb4_affinity
Cache is disabled


## Map: cilium_policy_00293
Cache is disabled


## Map: cilium_policy_00443
Cache is disabled


## Map: cilium_policy_02201
Cache is disabled


## Map: cilium_policy_00398
Cache is disabled


## Map: cilium_policy_01618
Cache is disabled


## Map: cilium_lb4_backends_v3
Key   Value                State   Error
128   ANY://10.244.0.192   sync    
115   ANY://10.244.0.197   sync    
122   ANY://10.244.0.28    sync    
125   ANY://10.244.0.50    sync    
126   ANY://10.244.0.119   sync    
116   ANY://10.244.0.240   sync    
120   ANY://10.244.0.77    sync    
124   ANY://10.244.0.104   sync    
127   ANY://10.244.0.21    sync    
114   ANY://172.17.0.2     sync    
117   ANY://10.244.0.207   sync    
119   ANY://10.244.0.219   sync    
129   ANY://10.244.0.105   sync    
118   ANY://10.244.0.207   sync    
121   ANY://10.244.0.212   sync    
123   ANY://10.244.0.193   sync    

## Map: cilium_policy_00858
Cache is disabled


## Map: cilium_policy_00620
Cache is disabled


## Map: cilium_policy_00359
Cache is disabled


## Map: cilium_lxc
Key              Value                                                                                            State   Error
10.244.0.240:0   id=246   sec_id=33925 flags=0x0000 ifindex=10  mac=A6:42:AE:DA:D1:C4 nodemac=06:A9:F0:57:19:3D   sync    
10.244.0.207:0   id=3168  sec_id=6400  flags=0x0000 ifindex=25  mac=EE:62:D3:7F:DC:20 nodemac=3A:84:72:3F:4A:4B   sync    
10.244.0.212:0   id=1959  sec_id=32957 flags=0x0000 ifindex=23  mac=3E:C5:77:C1:57:89 nodemac=F2:D2:26:63:C2:BF   sync    
10.244.0.105:0   id=509   sec_id=11487 flags=0x0000 ifindex=47  mac=92:14:45:FD:C1:6C nodemac=42:31:E2:9F:82:88   sync    
10.244.0.84:0    id=1618  sec_id=63576 flags=0x0000 ifindex=67  mac=3A:47:05:14:D0:A9 nodemac=5A:A2:A3:FA:DC:A1   sync    
10.244.0.171:0   id=951   sec_id=28402 flags=0x0000 ifindex=14  mac=46:DF:A0:A0:AA:A9 nodemac=0E:81:DB:58:A2:B2   sync    
10.244.0.219:0   id=1992  sec_id=12886 flags=0x0000 ifindex=12  mac=B2:4A:F6:62:12:FF nodemac=9E:20:BE:E0:16:EA   sync    
10.244.0.34:0    id=359   sec_id=44793 flags=0x0000 ifindex=29  mac=7E:64:96:7F:B8:AD nodemac=AA:5D:0B:89:F1:D6   sync    
10.244.0.192:0   id=628   sec_id=11535 flags=0x0000 ifindex=41  mac=0A:F2:22:4E:68:39 nodemac=8A:CE:AB:1C:CC:C5   sync    
10.244.0.253:0   id=199   sec_id=48566 flags=0x0000 ifindex=16  mac=06:F8:17:7D:21:E0 nodemac=E6:DE:8A:8E:EE:75   sync    
10.244.0.21:0    id=293   sec_id=40807 flags=0x0000 ifindex=37  mac=52:E2:47:6E:D7:69 nodemac=16:0F:CB:E8:F8:AC   sync    
10.244.0.186:0   id=398   sec_id=1847  flags=0x0000 ifindex=65  mac=02:19:6F:4E:F7:BF nodemac=6E:10:4A:7B:7E:6E   sync    
10.244.0.172:0   id=1528  sec_id=13128 flags=0x0000 ifindex=31  mac=C2:95:3D:99:19:2F nodemac=02:B6:C3:46:2E:6E   sync    
10.244.0.206:0   id=3726  sec_id=4     flags=0x0000 ifindex=6   mac=9A:CC:54:68:7F:51 nodemac=6E:98:93:71:C9:4B   sync    
10.244.0.57:0    id=1526  sec_id=58695 flags=0x0000 ifindex=59  mac=32:66:C4:6C:D4:9D nodemac=9A:FF:95:7A:3A:A5   sync    
10.244.0.182:0   id=1164  sec_id=1847  flags=0x0000 ifindex=61  mac=C2:33:1E:DC:6B:F2 nodemac=B6:8E:44:F6:B8:F6   sync    
10.244.0.176:0   (localhost)                                                                                      sync    
10.244.0.199:0   id=3501  sec_id=8310  flags=0x0000 ifindex=27  mac=56:E6:51:21:0F:FF nodemac=36:91:B2:7C:E4:EA   sync    
10.244.0.104:0   id=48    sec_id=40807 flags=0x0000 ifindex=39  mac=86:3C:12:8D:15:6B nodemac=6E:F4:A6:4F:30:C1   sync    
10.244.0.193:0   id=824   sec_id=9256  flags=0x0000 ifindex=33  mac=82:EE:55:10:C1:FC nodemac=22:53:7C:C2:23:1B   sync    
10.244.0.50:0    id=182   sec_id=40807 flags=0x0000 ifindex=43  mac=22:B8:59:10:36:69 nodemac=6E:BB:F6:9A:2B:EE   sync    
10.244.0.144:0   id=3565  sec_id=24494 flags=0x0000 ifindex=49  mac=B2:21:B4:61:5A:C6 nodemac=32:2A:C3:8E:1D:F0   sync    
10.244.0.209:0   id=443   sec_id=3108  flags=0x0000 ifindex=53  mac=5E:62:80:99:33:97 nodemac=0A:AA:87:00:2E:21   sync    
10.244.0.197:0   id=17    sec_id=25058 flags=0x0000 ifindex=18  mac=66:16:18:31:3F:90 nodemac=66:42:A2:8D:AB:3F   sync    
10.244.0.77:0    id=2084  sec_id=5267  flags=0x0000 ifindex=21  mac=CE:23:25:D8:95:26 nodemac=B6:B6:9C:8F:6F:8E   sync    
10.244.0.119:0   id=858   sec_id=40807 flags=0x0000 ifindex=45  mac=A6:FC:4C:03:97:3B nodemac=36:EF:DF:4D:59:5C   sync    
10.244.0.155:0   id=2682  sec_id=707   flags=0x0000 ifindex=51  mac=B6:C0:7C:EA:99:3D nodemac=82:01:69:E5:9B:81   sync    
10.244.0.101:0   id=2589  sec_id=7207  flags=0x0000 ifindex=55  mac=16:16:64:75:1D:1A nodemac=76:06:9A:F2:1F:BC   sync    
10.244.0.18:0    id=2201  sec_id=1847  flags=0x0000 ifindex=57  mac=5A:E4:69:FA:22:17 nodemac=92:2C:59:88:16:40   sync    
10.244.0.93:0    id=1412  sec_id=2199  flags=0x0000 ifindex=63  mac=26:95:E8:15:41:ED nodemac=5E:99:AE:2C:23:55   sync    
10.244.0.28:0    id=620   sec_id=9256  flags=0x0000 ifindex=35  mac=C2:77:0F:81:D9:80 nodemac=2E:06:C0:AD:5F:9D   sync    

## Map: cilium_lb4_services_v2
Key                   Value                      State   Error
10.98.222.33:9001     0 0 (127) [0x0 0x0]        sync    
10.106.247.125:5432   0 0 (130) [0x0 0x0]        sync    
172.17.0.2:30867      25921 0 (135) [0x42 0x4]   sync    
10.107.136.162:443    0 0 (136) [0x0 0x0]        sync    
10.108.137.97:443     0 1 (119) [0x0 0x0]        sync    
10.108.77.184:7000    0 2 (122) [0x0 0x0]        sync    
10.105.72.35:7000     0 0 (123) [0x0 0x0]        sync    
10.100.123.5:3000     0 4 (124) [0x0 0x0]        sync    
10.109.115.136:443    0 1 (120) [0x0 0x10]       sync    
10.96.0.10:53         0 1 (8) [0x0 0x0]          sync    
10.96.0.10:9153       0 1 (9) [0x0 0x0]          sync    
10.105.180.26:9402    0 1 (118) [0x0 0x0]        sync    
10.96.0.1:443         0 1 (4) [0x0 0x0]          sync    
0.0.0.0:30867         25921 0 (134) [0x2 0x4]    sync    
10.102.228.233:80     0 1 (116) [0x0 0x0]        sync    
10.98.222.33:9000     0 0 (128) [0x0 0x0]        sync    
10.105.143.77:8081    0 0 (129) [0x0 0x0]        sync    
172.17.223.107:80     25921 0 (133) [0x60 0x4]   sync    
10.99.225.9:6379      0 1 (131) [0x0 0x0]        sync    
10.99.89.133:80       25921 0 (132) [0x0 0x4]    sync    
10.109.147.188:443    0 1 (117) [0x0 0x0]        sync    
10.104.172.173:80     0 1 (121) [0x0 0x0]        sync    
10.110.120.45:4433    0 1 (125) [0x0 0x0]        sync    
10.109.149.13:5432    0 0 (126) [0x0 0x0]        sync    

## Map: cilium_lb4_reverse_nat
Key   Value                 State   Error
9     10.96.0.10:9153       sync    
121   10.104.172.173:80     sync    
128   10.98.222.33:9000     sync    
133   172.17.223.107:80     sync    
116   10.102.228.233:80     sync    
8     10.96.0.10:53         sync    
127   10.98.222.33:9001     sync    
129   10.105.143.77:8081    sync    
130   10.106.247.125:5432   sync    
131   10.99.225.9:6379      sync    
135   172.17.0.2:30867      sync    
117   10.109.147.188:443    sync    
4     10.96.0.1:443         sync    
122   10.108.77.184:7000    sync    
124   10.100.123.5:3000     sync    
125   10.110.120.45:4433    sync    
126   10.109.149.13:5432    sync    
118   10.105.180.26:9402    sync    
119   10.108.137.97:443     sync    
120   10.109.115.136:443    sync    
123   10.105.72.35:7000     sync    
132   10.99.89.133:80       sync    
134   0.0.0.0:30867         sync    
136   10.107.136.162:443    sync    

## Map: cilium_policy_03726
Cache is disabled


## Map: cilium_policy_01412
Cache is disabled


## Map: cilium_runtime_config
Cache is disabled


## Map: cilium_policy_00017
Cache is disabled


## Map: cilium_policy_01528
Cache is disabled


## Map: cilium_policy_01959
Cache is disabled


## Map: cilium_policy_00824
Cache is disabled


## Map: cilium_policy_00182
Cache is disabled


## Map: cilium_policy_02589
Cache is disabled


## Map: cilium_policy_00246
Cache is disabled


## Map: cilium_policy_00178
Cache is disabled


## Map: cilium_policy_00509
Cache is disabled


## Map: cilium_policy_00951
Cache is disabled


## Map: cilium_tunnel_map
Cache is empty


## Map: cilium_node_map
Cache is disabled


## Map: cilium_metrics
Cache is disabled


## Map: cilium_l2_responder_v4
Cache is disabled


## Map: cilium_auth_map
Cache is disabled


