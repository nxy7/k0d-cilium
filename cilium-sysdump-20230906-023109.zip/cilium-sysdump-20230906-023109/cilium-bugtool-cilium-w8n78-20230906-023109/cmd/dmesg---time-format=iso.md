2023-09-05T21:59:12,000000+00:00 Linux version 6.5.0 (nixbld@localhost) (gcc (GCC) 12.3.0, GNU ld (GNU Binutils) 2.40) #1-NixOS SMP PREEMPT_DYNAMIC Sun Aug 27 21:49:51 UTC 2023
2023-09-05T21:59:12,000000+00:00 Command line: initrd=\efi\nixos\7iziifwb9in6d9y2z16m10z4avbz8sxz-initrd-linux-6.5-initrd.efi init=/nix/store/6zhcn3ndafmmnvx6ka1axfgv546ggfsd-nixos-system-nixos-23.05.20230902.9075cba/init cgroup_no_v1=all cgroup_enable=memory cgroup_enable=cpuset systemd.unified_cgroup_hierarchy=1 loglevel=4 nvidia-drm.modeset=1
2023-09-05T21:59:12,000000+00:00 BIOS-provided physical RAM map:
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x0000000000000000-0x000000000009ffff] usable
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000000a0000-0x00000000000fffff] reserved
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x0000000000100000-0x0000000009bfefff] usable
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x0000000009bff000-0x0000000009ffffff] reserved
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x000000000a000000-0x000000000a1fffff] usable
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x000000000a200000-0x000000000a20dfff] ACPI NVS
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x000000000a20e000-0x000000000affffff] usable
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x000000000b000000-0x000000000b01ffff] reserved
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x000000000b020000-0x00000000ba9bbfff] usable
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000ba9bc000-0x00000000bc0fefff] reserved
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000bc0ff000-0x00000000bc135fff] ACPI data
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000bc136000-0x00000000bc810fff] ACPI NVS
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000bc811000-0x00000000bdbfefff] reserved
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000bdbff000-0x00000000beffffff] usable
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000bf000000-0x00000000bfffffff] reserved
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000f0000000-0x00000000f7ffffff] reserved
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000fd200000-0x00000000fd2fffff] reserved
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000fd600000-0x00000000fd7fffff] reserved
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000fea00000-0x00000000fea0ffff] reserved
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000feb80000-0x00000000fec01fff] reserved
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000fec10000-0x00000000fec10fff] reserved
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000fec30000-0x00000000fec30fff] reserved
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000fed00000-0x00000000fed00fff] reserved
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000fed40000-0x00000000fed44fff] reserved
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000fed80000-0x00000000fed8ffff] reserved
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000fedc2000-0x00000000fedcffff] reserved
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000fedd4000-0x00000000fedd5fff] reserved
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x00000000ff000000-0x00000000ffffffff] reserved
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x0000000100000000-0x000000043f37ffff] usable
2023-09-05T21:59:12,000000+00:00 BIOS-e820: [mem 0x000000043f380000-0x000000043fffffff] reserved
2023-09-05T21:59:12,000000+00:00 NX (Execute Disable) protection: active
2023-09-05T21:59:12,000000+00:00 e820: update [mem 0xb537a018-0xb5399e57] usable ==> usable
2023-09-05T21:59:12,000000+00:00 e820: update [mem 0xb537a018-0xb5399e57] usable ==> usable
2023-09-05T21:59:12,000000+00:00 extended physical RAM map:
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x0000000000000000-0x000000000009ffff] usable
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000000a0000-0x00000000000fffff] reserved
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x0000000000100000-0x0000000009bfefff] usable
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x0000000009bff000-0x0000000009ffffff] reserved
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x000000000a000000-0x000000000a1fffff] usable
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x000000000a200000-0x000000000a20dfff] ACPI NVS
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x000000000a20e000-0x000000000affffff] usable
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x000000000b000000-0x000000000b01ffff] reserved
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x000000000b020000-0x00000000b537a017] usable
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000b537a018-0x00000000b5399e57] usable
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000b5399e58-0x00000000ba9bbfff] usable
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000ba9bc000-0x00000000bc0fefff] reserved
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000bc0ff000-0x00000000bc135fff] ACPI data
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000bc136000-0x00000000bc810fff] ACPI NVS
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000bc811000-0x00000000bdbfefff] reserved
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000bdbff000-0x00000000beffffff] usable
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000bf000000-0x00000000bfffffff] reserved
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000f0000000-0x00000000f7ffffff] reserved
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000fd200000-0x00000000fd2fffff] reserved
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000fd600000-0x00000000fd7fffff] reserved
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000fea00000-0x00000000fea0ffff] reserved
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000feb80000-0x00000000fec01fff] reserved
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000fec10000-0x00000000fec10fff] reserved
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000fec30000-0x00000000fec30fff] reserved
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000fed00000-0x00000000fed00fff] reserved
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000fed40000-0x00000000fed44fff] reserved
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000fed80000-0x00000000fed8ffff] reserved
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000fedc2000-0x00000000fedcffff] reserved
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000fedd4000-0x00000000fedd5fff] reserved
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x00000000ff000000-0x00000000ffffffff] reserved
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x0000000100000000-0x000000043f37ffff] usable
2023-09-05T21:59:12,000000+00:00 reserve setup_data: [mem 0x000000043f380000-0x000000043fffffff] reserved
2023-09-05T21:59:12,000000+00:00 efi: EFI v2.7 by American Megatrends
2023-09-05T21:59:12,000000+00:00 efi: ACPI=0xbc7fa000 ACPI 2.0=0xbc7fa014 TPMFinalLog=0xbc7c4000 SMBIOS=0xbda22000 SMBIOS 3.0=0xbda21000 MEMATTR=0xb7020298 ESRT=0xb914bb18 RNG=0xbc10af18 INITRD=0xb5f16a98 TPMEventLog=0xb539a018 
2023-09-05T21:59:12,000000+00:00 random: crng init done
2023-09-05T21:59:12,000000+00:00 efi: Remove mem334: MMIO range=[0xf0000000-0xf7ffffff] (128MB) from e820 map
2023-09-05T21:59:12,000000+00:00 e820: remove [mem 0xf0000000-0xf7ffffff] reserved
2023-09-05T21:59:12,000000+00:00 efi: Remove mem335: MMIO range=[0xfd200000-0xfd2fffff] (1MB) from e820 map
2023-09-05T21:59:12,000000+00:00 e820: remove [mem 0xfd200000-0xfd2fffff] reserved
2023-09-05T21:59:12,000000+00:00 efi: Remove mem336: MMIO range=[0xfd600000-0xfd7fffff] (2MB) from e820 map
2023-09-05T21:59:12,000000+00:00 e820: remove [mem 0xfd600000-0xfd7fffff] reserved
2023-09-05T21:59:12,000000+00:00 efi: Not removing mem337: MMIO range=[0xfea00000-0xfea0ffff] (64KB) from e820 map
2023-09-05T21:59:12,000000+00:00 efi: Remove mem338: MMIO range=[0xfeb80000-0xfec01fff] (0MB) from e820 map
2023-09-05T21:59:12,000000+00:00 e820: remove [mem 0xfeb80000-0xfec01fff] reserved
2023-09-05T21:59:12,000000+00:00 efi: Not removing mem339: MMIO range=[0xfec10000-0xfec10fff] (4KB) from e820 map
2023-09-05T21:59:12,000000+00:00 efi: Not removing mem340: MMIO range=[0xfec30000-0xfec30fff] (4KB) from e820 map
2023-09-05T21:59:12,000000+00:00 efi: Not removing mem341: MMIO range=[0xfed00000-0xfed00fff] (4KB) from e820 map
2023-09-05T21:59:12,000000+00:00 efi: Not removing mem342: MMIO range=[0xfed40000-0xfed44fff] (20KB) from e820 map
2023-09-05T21:59:12,000000+00:00 efi: Not removing mem343: MMIO range=[0xfed80000-0xfed8ffff] (64KB) from e820 map
2023-09-05T21:59:12,000000+00:00 efi: Not removing mem344: MMIO range=[0xfedc2000-0xfedcffff] (56KB) from e820 map
2023-09-05T21:59:12,000000+00:00 efi: Not removing mem345: MMIO range=[0xfedd4000-0xfedd5fff] (8KB) from e820 map
2023-09-05T21:59:12,000000+00:00 efi: Remove mem346: MMIO range=[0xff000000-0xffffffff] (16MB) from e820 map
2023-09-05T21:59:12,000000+00:00 e820: remove [mem 0xff000000-0xffffffff] reserved
2023-09-05T21:59:12,000000+00:00 SMBIOS 3.3.0 present.
2023-09-05T21:59:12,000000+00:00 DMI: To Be Filled By O.E.M. To Be Filled By O.E.M./X470 Taichi, BIOS P10.01 04/17/2023
2023-09-05T21:59:12,000000+00:00 tsc: Fast TSC calibration using PIT
2023-09-05T21:59:12,000000+00:00 tsc: Detected 3500.178 MHz processor
2023-09-05T21:59:12,000357+00:00 e820: update [mem 0x00000000-0x00000fff] usable ==> reserved
2023-09-05T21:59:12,000358+00:00 e820: remove [mem 0x000a0000-0x000fffff] usable
2023-09-05T21:59:12,000363+00:00 last_pfn = 0x43f380 max_arch_pfn = 0x400000000
2023-09-05T21:59:12,000367+00:00 MTRR map: 7 entries (3 fixed + 4 variable; max 20), built from 9 variable MTRRs
2023-09-05T21:59:12,000368+00:00 x86/PAT: Configuration [0-7]: WB  WC  UC- UC  WB  WP  UC- WT  
2023-09-05T21:59:12,001102+00:00 e820: update [mem 0xbc2a0000-0xbc2affff] usable ==> reserved
2023-09-05T21:59:12,001106+00:00 e820: update [mem 0xc0000000-0xffffffff] usable ==> reserved
2023-09-05T21:59:12,001109+00:00 last_pfn = 0xbf000 max_arch_pfn = 0x400000000
2023-09-05T21:59:12,003890+00:00 esrt: Reserving ESRT space from 0x00000000b914bb18 to 0x00000000b914bb50.
2023-09-05T21:59:12,003896+00:00 e820: update [mem 0xb914b000-0xb914bfff] usable ==> reserved
2023-09-05T21:59:12,003926+00:00 Using GB pages for direct mapping
2023-09-05T21:59:12,004022+00:00 Secure boot disabled
2023-09-05T21:59:12,004023+00:00 RAMDISK: [mem 0xb0af6000-0xb166bfff]
2023-09-05T21:59:12,004026+00:00 ACPI: Early table checksum verification disabled
2023-09-05T21:59:12,004028+00:00 ACPI: RSDP 0x00000000BC7FA014 000024 (v02 ALASKA)
2023-09-05T21:59:12,004030+00:00 ACPI: XSDT 0x00000000BC7F9728 0000BC (v01 ALASKA A M I    01072009 AMI  01000013)
2023-09-05T21:59:12,004034+00:00 ACPI: FACP 0x00000000BC127000 000114 (v06 ALASKA A M I    01072009 AMI  00010013)
2023-09-05T21:59:12,004036+00:00 ACPI: DSDT 0x00000000BC120000 0065BE (v02 ALASKA A M I    01072009 INTL 20120913)
2023-09-05T21:59:12,004038+00:00 ACPI: FACS 0x00000000BC7F4000 000040
2023-09-05T21:59:12,004040+00:00 ACPI: SSDT 0x00000000BC12D000 008CE9 (v02 AMD    AmdTable 00000002 MSFT 04000000)
2023-09-05T21:59:12,004041+00:00 ACPI: SSDT 0x00000000BC129000 003CB6 (v02 AMD    AMD AOD  00000001 INTL 20120913)
2023-09-05T21:59:12,004043+00:00 ACPI: SSDT 0x00000000BC128000 0000C8 (v02 ALASKA CPUSSDT  01072009 AMI  01072009)
2023-09-05T21:59:12,004044+00:00 ACPI: FIDT 0x00000000BC11F000 00009C (v01 ALASKA A M I    01072009 AMI  00010013)
2023-09-05T21:59:12,004045+00:00 ACPI: MCFG 0x00000000BC11E000 00003C (v01 ALASKA A M I    01072009 MSFT 00010013)
2023-09-05T21:59:12,004047+00:00 ACPI: AAFT 0x00000000BC11D000 0000F1 (v01 ALASKA OEMAAFT  01072009 MSFT 00000097)
2023-09-05T21:59:12,004048+00:00 ACPI: HPET 0x00000000BC11C000 000038 (v01 ALASKA A M I    01072009 AMI  00000005)
2023-09-05T21:59:12,004049+00:00 ACPI: TPM2 0x00000000BC11B000 00004C (v04 ALASKA A M I    00000001 AMI  00000000)
2023-09-05T21:59:12,004051+00:00 ACPI: PCCT 0x00000000BC11A000 00006E (v02 AMD    AmdTable 00000001 AMD  00000001)
2023-09-05T21:59:12,004052+00:00 ACPI: SSDT 0x00000000BC117000 002AEF (v02 AMD    AmdTable 00000001 AMD  00000001)
2023-09-05T21:59:12,004054+00:00 ACPI: CRAT 0x00000000BC116000 000B90 (v01 AMD    AmdTable 00000001 AMD  00000001)
2023-09-05T21:59:12,004055+00:00 ACPI: CDIT 0x00000000BC115000 000029 (v01 AMD    AmdTable 00000001 AMD  00000001)
2023-09-05T21:59:12,004056+00:00 ACPI: SSDT 0x00000000BC111000 0037C4 (v02 AMD    MYRTLE   00000001 INTL 20120913)
2023-09-05T21:59:12,004058+00:00 ACPI: SSDT 0x00000000BC110000 0000BF (v01 AMD    AmdTable 00001000 INTL 20120913)
2023-09-05T21:59:12,004059+00:00 ACPI: WSMT 0x00000000BC10F000 000028 (v01 ALASKA A M I    01072009 AMI  00010013)
2023-09-05T21:59:12,004061+00:00 ACPI: APIC 0x00000000BC10E000 00015E (v03 ALASKA A M I    01072009 AMI  00010013)
2023-09-05T21:59:12,004062+00:00 ACPI: SSDT 0x00000000BC10C000 0010AF (v02 AMD    MYRTLE   00000001 INTL 20120913)
2023-09-05T21:59:12,004063+00:00 ACPI: FPDT 0x00000000BC10B000 000044 (v01 ALASKA A M I    01072009 AMI  01000013)
2023-09-05T21:59:12,004065+00:00 ACPI: Reserving FACP table memory at [mem 0xbc127000-0xbc127113]
2023-09-05T21:59:12,004065+00:00 ACPI: Reserving DSDT table memory at [mem 0xbc120000-0xbc1265bd]
2023-09-05T21:59:12,004066+00:00 ACPI: Reserving FACS table memory at [mem 0xbc7f4000-0xbc7f403f]
2023-09-05T21:59:12,004066+00:00 ACPI: Reserving SSDT table memory at [mem 0xbc12d000-0xbc135ce8]
2023-09-05T21:59:12,004067+00:00 ACPI: Reserving SSDT table memory at [mem 0xbc129000-0xbc12ccb5]
2023-09-05T21:59:12,004067+00:00 ACPI: Reserving SSDT table memory at [mem 0xbc128000-0xbc1280c7]
2023-09-05T21:59:12,004067+00:00 ACPI: Reserving FIDT table memory at [mem 0xbc11f000-0xbc11f09b]
2023-09-05T21:59:12,004068+00:00 ACPI: Reserving MCFG table memory at [mem 0xbc11e000-0xbc11e03b]
2023-09-05T21:59:12,004068+00:00 ACPI: Reserving AAFT table memory at [mem 0xbc11d000-0xbc11d0f0]
2023-09-05T21:59:12,004069+00:00 ACPI: Reserving HPET table memory at [mem 0xbc11c000-0xbc11c037]
2023-09-05T21:59:12,004069+00:00 ACPI: Reserving TPM2 table memory at [mem 0xbc11b000-0xbc11b04b]
2023-09-05T21:59:12,004069+00:00 ACPI: Reserving PCCT table memory at [mem 0xbc11a000-0xbc11a06d]
2023-09-05T21:59:12,004070+00:00 ACPI: Reserving SSDT table memory at [mem 0xbc117000-0xbc119aee]
2023-09-05T21:59:12,004070+00:00 ACPI: Reserving CRAT table memory at [mem 0xbc116000-0xbc116b8f]
2023-09-05T21:59:12,004071+00:00 ACPI: Reserving CDIT table memory at [mem 0xbc115000-0xbc115028]
2023-09-05T21:59:12,004071+00:00 ACPI: Reserving SSDT table memory at [mem 0xbc111000-0xbc1147c3]
2023-09-05T21:59:12,004071+00:00 ACPI: Reserving SSDT table memory at [mem 0xbc110000-0xbc1100be]
2023-09-05T21:59:12,004072+00:00 ACPI: Reserving WSMT table memory at [mem 0xbc10f000-0xbc10f027]
2023-09-05T21:59:12,004072+00:00 ACPI: Reserving APIC table memory at [mem 0xbc10e000-0xbc10e15d]
2023-09-05T21:59:12,004072+00:00 ACPI: Reserving SSDT table memory at [mem 0xbc10c000-0xbc10d0ae]
2023-09-05T21:59:12,004073+00:00 ACPI: Reserving FPDT table memory at [mem 0xbc10b000-0xbc10b043]
2023-09-05T21:59:12,004115+00:00 No NUMA configuration found
2023-09-05T21:59:12,004116+00:00 Faking a node at [mem 0x0000000000000000-0x000000043f37ffff]
2023-09-05T21:59:12,004118+00:00 NODE_DATA(0) allocated [mem 0x43f37a000-0x43f37ffff]
2023-09-05T21:59:12,004135+00:00 Zone ranges:
2023-09-05T21:59:12,004136+00:00   DMA      [mem 0x0000000000001000-0x0000000000ffffff]
2023-09-05T21:59:12,004137+00:00   DMA32    [mem 0x0000000001000000-0x00000000ffffffff]
2023-09-05T21:59:12,004137+00:00   Normal   [mem 0x0000000100000000-0x000000043f37ffff]
2023-09-05T21:59:12,004138+00:00   Device   empty
2023-09-05T21:59:12,004139+00:00 Movable zone start for each node
2023-09-05T21:59:12,004139+00:00 Early memory node ranges
2023-09-05T21:59:12,004139+00:00   node   0: [mem 0x0000000000001000-0x000000000009ffff]
2023-09-05T21:59:12,004140+00:00   node   0: [mem 0x0000000000100000-0x0000000009bfefff]
2023-09-05T21:59:12,004141+00:00   node   0: [mem 0x000000000a000000-0x000000000a1fffff]
2023-09-05T21:59:12,004141+00:00   node   0: [mem 0x000000000a20e000-0x000000000affffff]
2023-09-05T21:59:12,004142+00:00   node   0: [mem 0x000000000b020000-0x00000000ba9bbfff]
2023-09-05T21:59:12,004142+00:00   node   0: [mem 0x00000000bdbff000-0x00000000beffffff]
2023-09-05T21:59:12,004143+00:00   node   0: [mem 0x0000000100000000-0x000000043f37ffff]
2023-09-05T21:59:12,004144+00:00 Initmem setup node 0 [mem 0x0000000000001000-0x000000043f37ffff]
2023-09-05T21:59:12,004147+00:00 On node 0, zone DMA: 1 pages in unavailable ranges
2023-09-05T21:59:12,004158+00:00 On node 0, zone DMA: 96 pages in unavailable ranges
2023-09-05T21:59:12,004253+00:00 On node 0, zone DMA32: 1025 pages in unavailable ranges
2023-09-05T21:59:12,004263+00:00 On node 0, zone DMA32: 14 pages in unavailable ranges
2023-09-05T21:59:12,006819+00:00 On node 0, zone DMA32: 32 pages in unavailable ranges
2023-09-05T21:59:12,006924+00:00 On node 0, zone DMA32: 12867 pages in unavailable ranges
2023-09-05T21:59:12,026448+00:00 On node 0, zone Normal: 4096 pages in unavailable ranges
2023-09-05T21:59:12,026470+00:00 On node 0, zone Normal: 3200 pages in unavailable ranges
2023-09-05T21:59:12,026698+00:00 ACPI: PM-Timer IO Port: 0x808
2023-09-05T21:59:12,026703+00:00 ACPI: LAPIC_NMI (acpi_id[0xff] high edge lint[0x1])
2023-09-05T21:59:12,026714+00:00 IOAPIC[0]: apic_id 13, version 33, address 0xfec00000, GSI 0-23
2023-09-05T21:59:12,026719+00:00 IOAPIC[1]: apic_id 14, version 33, address 0xfec01000, GSI 24-55
2023-09-05T21:59:12,026721+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 0 global_irq 2 dfl dfl)
2023-09-05T21:59:12,026722+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 9 global_irq 9 low level)
2023-09-05T21:59:12,026724+00:00 ACPI: Using ACPI (MADT) for SMP configuration information
2023-09-05T21:59:12,026725+00:00 ACPI: HPET id: 0x10228201 base: 0xfed00000
2023-09-05T21:59:12,026727+00:00 smpboot: Allowing 32 CPUs, 20 hotplug CPUs
2023-09-05T21:59:12,026744+00:00 PM: hibernation: Registered nosave memory: [mem 0x00000000-0x00000fff]
2023-09-05T21:59:12,026745+00:00 PM: hibernation: Registered nosave memory: [mem 0x000a0000-0x000fffff]
2023-09-05T21:59:12,026746+00:00 PM: hibernation: Registered nosave memory: [mem 0x09bff000-0x09ffffff]
2023-09-05T21:59:12,026747+00:00 PM: hibernation: Registered nosave memory: [mem 0x0a200000-0x0a20dfff]
2023-09-05T21:59:12,026748+00:00 PM: hibernation: Registered nosave memory: [mem 0x0b000000-0x0b01ffff]
2023-09-05T21:59:12,026749+00:00 PM: hibernation: Registered nosave memory: [mem 0xb537a000-0xb537afff]
2023-09-05T21:59:12,026750+00:00 PM: hibernation: Registered nosave memory: [mem 0xb5399000-0xb5399fff]
2023-09-05T21:59:12,026751+00:00 PM: hibernation: Registered nosave memory: [mem 0xb914b000-0xb914bfff]
2023-09-05T21:59:12,026752+00:00 PM: hibernation: Registered nosave memory: [mem 0xba9bc000-0xbc0fefff]
2023-09-05T21:59:12,026752+00:00 PM: hibernation: Registered nosave memory: [mem 0xbc0ff000-0xbc135fff]
2023-09-05T21:59:12,026753+00:00 PM: hibernation: Registered nosave memory: [mem 0xbc136000-0xbc810fff]
2023-09-05T21:59:12,026753+00:00 PM: hibernation: Registered nosave memory: [mem 0xbc811000-0xbdbfefff]
2023-09-05T21:59:12,026754+00:00 PM: hibernation: Registered nosave memory: [mem 0xbf000000-0xbfffffff]
2023-09-05T21:59:12,026754+00:00 PM: hibernation: Registered nosave memory: [mem 0xc0000000-0xfe9fffff]
2023-09-05T21:59:12,026755+00:00 PM: hibernation: Registered nosave memory: [mem 0xfea00000-0xfea0ffff]
2023-09-05T21:59:12,026755+00:00 PM: hibernation: Registered nosave memory: [mem 0xfea10000-0xfec0ffff]
2023-09-05T21:59:12,026755+00:00 PM: hibernation: Registered nosave memory: [mem 0xfec10000-0xfec10fff]
2023-09-05T21:59:12,026756+00:00 PM: hibernation: Registered nosave memory: [mem 0xfec11000-0xfec2ffff]
2023-09-05T21:59:12,026756+00:00 PM: hibernation: Registered nosave memory: [mem 0xfec30000-0xfec30fff]
2023-09-05T21:59:12,026756+00:00 PM: hibernation: Registered nosave memory: [mem 0xfec31000-0xfecfffff]
2023-09-05T21:59:12,026756+00:00 PM: hibernation: Registered nosave memory: [mem 0xfed00000-0xfed00fff]
2023-09-05T21:59:12,026757+00:00 PM: hibernation: Registered nosave memory: [mem 0xfed01000-0xfed3ffff]
2023-09-05T21:59:12,026757+00:00 PM: hibernation: Registered nosave memory: [mem 0xfed40000-0xfed44fff]
2023-09-05T21:59:12,026757+00:00 PM: hibernation: Registered nosave memory: [mem 0xfed45000-0xfed7ffff]
2023-09-05T21:59:12,026758+00:00 PM: hibernation: Registered nosave memory: [mem 0xfed80000-0xfed8ffff]
2023-09-05T21:59:12,026758+00:00 PM: hibernation: Registered nosave memory: [mem 0xfed90000-0xfedc1fff]
2023-09-05T21:59:12,026758+00:00 PM: hibernation: Registered nosave memory: [mem 0xfedc2000-0xfedcffff]
2023-09-05T21:59:12,026759+00:00 PM: hibernation: Registered nosave memory: [mem 0xfedd0000-0xfedd3fff]
2023-09-05T21:59:12,026759+00:00 PM: hibernation: Registered nosave memory: [mem 0xfedd4000-0xfedd5fff]
2023-09-05T21:59:12,026759+00:00 PM: hibernation: Registered nosave memory: [mem 0xfedd6000-0xffffffff]
2023-09-05T21:59:12,026761+00:00 [mem 0xc0000000-0xfe9fffff] available for PCI devices
2023-09-05T21:59:12,026763+00:00 Booting paravirtualized kernel on bare hardware
2023-09-05T21:59:12,026765+00:00 clocksource: refined-jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 1910969940391419 ns
2023-09-05T21:59:12,029291+00:00 setup_percpu: NR_CPUS:384 nr_cpumask_bits:32 nr_cpu_ids:32 nr_node_ids:1
2023-09-05T21:59:12,030250+00:00 percpu: Embedded 62 pages/cpu s217088 r8192 d28672 u262144
2023-09-05T21:59:12,030255+00:00 pcpu-alloc: s217088 r8192 d28672 u262144 alloc=1*2097152
2023-09-05T21:59:12,030256+00:00 pcpu-alloc: [0] 00 01 02 03 04 05 06 07 [0] 08 09 10 11 12 13 14 15 
2023-09-05T21:59:12,030261+00:00 pcpu-alloc: [0] 16 17 18 19 20 21 22 23 [0] 24 25 26 27 28 29 30 31 
2023-09-05T21:59:12,030276+00:00 Kernel command line: initrd=\efi\nixos\7iziifwb9in6d9y2z16m10z4avbz8sxz-initrd-linux-6.5-initrd.efi init=/nix/store/6zhcn3ndafmmnvx6ka1axfgv546ggfsd-nixos-system-nixos-23.05.20230902.9075cba/init cgroup_no_v1=all cgroup_enable=memory cgroup_enable=cpuset systemd.unified_cgroup_hierarchy=1 loglevel=4 nvidia-drm.modeset=1
2023-09-05T21:59:12,030327+00:00 Unknown kernel command line parameters "cgroup_enable=cpuset", will be passed to user space.
2023-09-05T21:59:12,031808+00:00 Dentry cache hash table entries: 2097152 (order: 12, 16777216 bytes, linear)
2023-09-05T21:59:12,032466+00:00 Inode-cache hash table entries: 1048576 (order: 11, 8388608 bytes, linear)
2023-09-05T21:59:12,032592+00:00 Fallback order for Node 0: 0 
2023-09-05T21:59:12,032595+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 4107609
2023-09-05T21:59:12,032596+00:00 Policy zone: Normal
2023-09-05T21:59:12,032597+00:00 mem auto-init: stack:all(zero), heap alloc:off, heap free:off
2023-09-05T21:59:12,032601+00:00 software IO TLB: area num 32.
2023-09-05T21:59:12,070000+00:00 Memory: 16184624K/16691892K available (14336K kernel code, 2305K rwdata, 9160K rodata, 2932K init, 5104K bss, 507008K reserved, 0K cma-reserved)
2023-09-05T21:59:12,070142+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=32, Nodes=1
2023-09-05T21:59:12,070161+00:00 ftrace: allocating 39493 entries in 155 pages
2023-09-05T21:59:12,075896+00:00 ftrace: allocated 155 pages with 5 groups
2023-09-05T21:59:12,076358+00:00 Dynamic Preempt: voluntary
2023-09-05T21:59:12,076407+00:00 rcu: Preemptible hierarchical RCU implementation.
2023-09-05T21:59:12,076407+00:00 rcu: 	RCU event tracing is enabled.
2023-09-05T21:59:12,076407+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=384 to nr_cpu_ids=32.
2023-09-05T21:59:12,076408+00:00 	Trampoline variant of Tasks RCU enabled.
2023-09-05T21:59:12,076409+00:00 	Rude variant of Tasks RCU enabled.
2023-09-05T21:59:12,076409+00:00 	Tracing variant of Tasks RCU enabled.
2023-09-05T21:59:12,076409+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 100 jiffies.
2023-09-05T21:59:12,076410+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=32
2023-09-05T21:59:12,077868+00:00 NR_IRQS: 24832, nr_irqs: 1224, preallocated irqs: 16
2023-09-05T21:59:12,078039+00:00 rcu: srcu_init: Setting srcu_struct sizes based on contention.
2023-09-05T21:59:12,078107+00:00 Console: colour dummy device 80x25
2023-09-05T21:59:12,078109+00:00 printk: console [tty0] enabled
2023-09-05T21:59:12,078139+00:00 ACPI: Core revision 20230331
2023-09-05T21:59:12,078217+00:00 clocksource: hpet: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 133484873504 ns
2023-09-05T21:59:12,078233+00:00 APIC: Switch to symmetric I/O mode setup
2023-09-05T21:59:12,078365+00:00 x2apic: IRQ remapping doesn't support X2APIC mode
2023-09-05T21:59:12,078425+00:00 Switched APIC routing to physical flat.
2023-09-05T21:59:12,079029+00:00 ..TIMER: vector=0x30 apic1=0 pin1=2 apic2=-1 pin2=-1
2023-09-05T21:59:12,083233+00:00 clocksource: tsc-early: mask: 0xffffffffffffffff max_cycles: 0x3273f8a44a1, max_idle_ns: 440795233776 ns
2023-09-05T21:59:12,083237+00:00 Calibrating delay loop (skipped), value calculated using timer frequency.. 7000.35 BogoMIPS (lpj=3500178)
2023-09-05T21:59:12,083248+00:00 x86/cpu: User Mode Instruction Prevention (UMIP) activated
2023-09-05T21:59:12,083284+00:00 LVT offset 1 assigned for vector 0xf9
2023-09-05T21:59:12,083394+00:00 LVT offset 2 assigned for vector 0xf4
2023-09-05T21:59:12,083428+00:00 process: using mwait in idle threads
2023-09-05T21:59:12,083429+00:00 Last level iTLB entries: 4KB 512, 2MB 512, 4MB 256
2023-09-05T21:59:12,083430+00:00 Last level dTLB entries: 4KB 2048, 2MB 2048, 4MB 1024, 1GB 0
2023-09-05T21:59:12,083432+00:00 Spectre V1 : Mitigation: usercopy/swapgs barriers and __user pointer sanitization
2023-09-05T21:59:12,083433+00:00 Spectre V2 : Mitigation: Retpolines
2023-09-05T21:59:12,083434+00:00 Spectre V2 : Spectre v2 / SpectreRSB mitigation: Filling RSB on context switch
2023-09-05T21:59:12,083434+00:00 Spectre V2 : Spectre v2 / SpectreRSB : Filling RSB on VMEXIT
2023-09-05T21:59:12,083435+00:00 Spectre V2 : Enabling Restricted Speculation for firmware calls
2023-09-05T21:59:12,083436+00:00 Spectre V2 : mitigation: Enabling conditional Indirect Branch Prediction Barrier
2023-09-05T21:59:12,083436+00:00 Spectre V2 : User space: Mitigation: STIBP always-on protection
2023-09-05T21:59:12,083437+00:00 Speculative Store Bypass: Mitigation: Speculative Store Bypass disabled via prctl
2023-09-05T21:59:12,083439+00:00 Speculative Return Stack Overflow: IBPB-extending microcode not applied!
2023-09-05T21:59:12,083440+00:00 Speculative Return Stack Overflow: WARNING: See https://kernel.org/doc/html/latest/admin-guide/hw-vuln/srso.html for mitigation options.
2023-09-05T21:59:12,083440+00:00 Speculative Return Stack Overflow: Mitigation: safe RET, no microcode
2023-09-05T21:59:12,083443+00:00 x86/fpu: Supporting XSAVE feature 0x001: 'x87 floating point registers'
2023-09-05T21:59:12,083444+00:00 x86/fpu: Supporting XSAVE feature 0x002: 'SSE registers'
2023-09-05T21:59:12,083444+00:00 x86/fpu: Supporting XSAVE feature 0x004: 'AVX registers'
2023-09-05T21:59:12,083445+00:00 x86/fpu: Supporting XSAVE feature 0x200: 'Protection Keys User registers'
2023-09-05T21:59:12,083445+00:00 x86/fpu: xstate_offset[2]:  576, xstate_sizes[2]:  256
2023-09-05T21:59:12,083446+00:00 x86/fpu: xstate_offset[9]:  832, xstate_sizes[9]:    8
2023-09-05T21:59:12,083447+00:00 x86/fpu: Enabled xstate features 0x207, context size is 840 bytes, using 'compacted' format.
2023-09-05T21:59:12,096822+00:00 Freeing SMP alternatives memory: 32K
2023-09-05T21:59:12,096824+00:00 pid_max: default: 32768 minimum: 301
2023-09-05T21:59:12,099993+00:00 LSM: initializing lsm=capability,landlock,yama,selinux,bpf,integrity
2023-09-05T21:59:12,100007+00:00 landlock: Up and running.
2023-09-05T21:59:12,100008+00:00 Yama: becoming mindful.
2023-09-05T21:59:12,100011+00:00 SELinux:  Initializing.
2023-09-05T21:59:12,100025+00:00 LSM support for eBPF active
2023-09-05T21:59:12,100068+00:00 Mount-cache hash table entries: 32768 (order: 6, 262144 bytes, linear)
2023-09-05T21:59:12,100089+00:00 Mountpoint-cache hash table entries: 32768 (order: 6, 262144 bytes, linear)
2023-09-05T21:59:12,100221+00:00 Disabling cpuset control group subsystem in v1 mounts
2023-09-05T21:59:12,100225+00:00 Disabling cpu control group subsystem in v1 mounts
2023-09-05T21:59:12,100227+00:00 Disabling cpuacct control group subsystem in v1 mounts
2023-09-05T21:59:12,100231+00:00 Disabling io control group subsystem in v1 mounts
2023-09-05T21:59:12,100251+00:00 Disabling memory control group subsystem in v1 mounts
2023-09-05T21:59:12,100255+00:00 Disabling devices control group subsystem in v1 mounts
2023-09-05T21:59:12,100260+00:00 Disabling freezer control group subsystem in v1 mounts
2023-09-05T21:59:12,100262+00:00 Disabling net_cls control group subsystem in v1 mounts
2023-09-05T21:59:12,100265+00:00 Disabling perf_event control group subsystem in v1 mounts
2023-09-05T21:59:12,100266+00:00 Disabling net_prio control group subsystem in v1 mounts
2023-09-05T21:59:12,100268+00:00 Disabling hugetlb control group subsystem in v1 mounts
2023-09-05T21:59:12,100269+00:00 Disabling pids control group subsystem in v1 mounts
2023-09-05T21:59:12,100271+00:00 Disabling rdma control group subsystem in v1 mounts
2023-09-05T21:59:12,100273+00:00 Disabling misc control group subsystem in v1 mounts
2023-09-05T21:59:12,100275+00:00 Disabling debug control group subsystem in v1 mounts
2023-09-05T21:59:12,204044+00:00 smpboot: CPU0: AMD Ryzen 5 5600 6-Core Processor (family: 0x19, model: 0x21, stepping: 0x2)
2023-09-05T21:59:12,204163+00:00 RCU Tasks: Setting shift to 5 and lim to 1 rcu_task_cb_adjust=1.
2023-09-05T21:59:12,204177+00:00 RCU Tasks Rude: Setting shift to 5 and lim to 1 rcu_task_cb_adjust=1.
2023-09-05T21:59:12,204191+00:00 RCU Tasks Trace: Setting shift to 5 and lim to 1 rcu_task_cb_adjust=1.
2023-09-05T21:59:12,204203+00:00 Performance Events: Fam17h+ core perfctr, AMD PMU driver.
2023-09-05T21:59:12,204206+00:00 ... version:                0
2023-09-05T21:59:12,204207+00:00 ... bit width:              48
2023-09-05T21:59:12,204208+00:00 ... generic registers:      6
2023-09-05T21:59:12,204209+00:00 ... value mask:             0000ffffffffffff
2023-09-05T21:59:12,204210+00:00 ... max period:             00007fffffffffff
2023-09-05T21:59:12,204211+00:00 ... fixed-purpose events:   0
2023-09-05T21:59:12,204211+00:00 ... event mask:             000000000000003f
2023-09-05T21:59:12,204234+00:00 signal: max sigframe size: 3376
2023-09-05T21:59:12,204234+00:00 rcu: Hierarchical SRCU implementation.
2023-09-05T21:59:12,204234+00:00 rcu: 	Max phase no-delay instances is 400.
2023-09-05T21:59:12,204234+00:00 smp: Bringing up secondary CPUs ...
2023-09-05T21:59:12,204234+00:00 smpboot: x86: Booting SMP configuration:
2023-09-05T21:59:12,204234+00:00 .... node  #0, CPUs:        #1  #2  #3  #4  #5  #6  #7  #8  #9 #10 #11
2023-09-05T21:59:12,212290+00:00 Spectre V2 : Update user space SMT mitigation: STIBP always-on
2023-09-05T21:59:12,217248+00:00 smp: Brought up 1 node, 12 CPUs
2023-09-05T21:59:12,217248+00:00 smpboot: Max logical packages: 3
2023-09-05T21:59:12,217248+00:00 smpboot: Total of 12 processors activated (84004.27 BogoMIPS)
2023-09-05T21:59:12,219575+00:00 devtmpfs: initialized
2023-09-05T21:59:12,219575+00:00 x86/mm: Memory block size: 128MB
2023-09-05T21:59:12,221449+00:00 ACPI: PM: Registering ACPI NVS region [mem 0x0a200000-0x0a20dfff] (57344 bytes)
2023-09-05T21:59:12,221449+00:00 ACPI: PM: Registering ACPI NVS region [mem 0xbc136000-0xbc810fff] (7188480 bytes)
2023-09-05T21:59:12,221451+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 1911260446275000 ns
2023-09-05T21:59:12,221454+00:00 futex hash table entries: 8192 (order: 7, 524288 bytes, linear)
2023-09-05T21:59:12,221520+00:00 pinctrl core: initialized pinctrl subsystem
2023-09-05T21:59:12,221883+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2023-09-05T21:59:12,222246+00:00 DMA: preallocated 2048 KiB GFP_KERNEL pool for atomic allocations
2023-09-05T21:59:12,222249+00:00 DMA: preallocated 2048 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2023-09-05T21:59:12,222252+00:00 DMA: preallocated 2048 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2023-09-05T21:59:12,222259+00:00 audit: initializing netlink subsys (disabled)
2023-09-05T21:59:12,222264+00:00 audit: type=2000 audit(1693958351.144:1): state=initialized audit_enabled=0 res=1
2023-09-05T21:59:12,222324+00:00 thermal_sys: Registered thermal governor 'bang_bang'
2023-09-05T21:59:12,222325+00:00 thermal_sys: Registered thermal governor 'step_wise'
2023-09-05T21:59:12,222326+00:00 thermal_sys: Registered thermal governor 'user_space'
2023-09-05T21:59:12,222342+00:00 cpuidle: using governor menu
2023-09-05T21:59:12,222342+00:00 Detected 1 PCC Subspaces
2023-09-05T21:59:12,222342+00:00 Registering PCC driver as Mailbox controller
2023-09-05T21:59:12,222371+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2023-09-05T21:59:12,222371+00:00 PCI: MMCONFIG for domain 0000 [bus 00-7f] at [mem 0xf0000000-0xf7ffffff] (base 0xf0000000)
2023-09-05T21:59:12,222371+00:00 PCI: not using MMCONFIG
2023-09-05T21:59:12,222371+00:00 PCI: Using configuration type 1 for base access
2023-09-05T21:59:12,222371+00:00 PCI: Using configuration type 1 for extended access
2023-09-05T21:59:12,222829+00:00 kprobes: kprobe jump-optimization is enabled. All kprobes are optimized if possible.
2023-09-05T21:59:12,223275+00:00 HugeTLB: registered 1.00 GiB page size, pre-allocated 0 pages
2023-09-05T21:59:12,223275+00:00 HugeTLB: 16380 KiB vmemmap can be freed for a 1.00 GiB page
2023-09-05T21:59:12,223275+00:00 HugeTLB: registered 2.00 MiB page size, pre-allocated 0 pages
2023-09-05T21:59:12,223275+00:00 HugeTLB: 28 KiB vmemmap can be freed for a 2.00 MiB page
2023-09-05T21:59:12,223383+00:00 ACPI: Added _OSI(Module Device)
2023-09-05T21:59:12,223384+00:00 ACPI: Added _OSI(Processor Device)
2023-09-05T21:59:12,223386+00:00 ACPI: Added _OSI(3.0 _SCP Extensions)
2023-09-05T21:59:12,223387+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2023-09-05T21:59:12,238553+00:00 ACPI: 8 ACPI AML tables successfully acquired and loaded
2023-09-05T21:59:12,240424+00:00 ACPI: [Firmware Bug]: BIOS _OSI(Linux) query ignored
2023-09-05T21:59:12,243910+00:00 ACPI: Interpreter enabled
2023-09-05T21:59:12,243924+00:00 ACPI: PM: (supports S0 S3 S4 S5)
2023-09-05T21:59:12,243925+00:00 ACPI: Using IOAPIC for interrupt routing
2023-09-05T21:59:12,244510+00:00 PCI: MMCONFIG for domain 0000 [bus 00-7f] at [mem 0xf0000000-0xf7ffffff] (base 0xf0000000)
2023-09-05T21:59:12,244543+00:00 PCI: MMCONFIG at [mem 0xf0000000-0xf7ffffff] reserved as ACPI motherboard resource
2023-09-05T21:59:12,244551+00:00 PCI: Using host bridge windows from ACPI; if necessary, use "pci=nocrs" and report a bug
2023-09-05T21:59:12,244553+00:00 PCI: Ignoring E820 reservations for host bridge windows
2023-09-05T21:59:12,244898+00:00 ACPI: Enabled 3 GPEs in block 00 to 1F
2023-09-05T21:59:12,255255+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-ff])
2023-09-05T21:59:12,255259+00:00 acpi PNP0A08:00: _OSC: OS supports [ExtendedConfig ASPM ClockPM Segments MSI HPX-Type3]
2023-09-05T21:59:12,255335+00:00 acpi PNP0A08:00: _OSC: platform does not support [LTR]
2023-09-05T21:59:12,255471+00:00 acpi PNP0A08:00: _OSC: OS now controls [PCIeHotplug PME PCIeCapability]
2023-09-05T21:59:12,255480+00:00 acpi PNP0A08:00: [Firmware Info]: MMCONFIG for domain 0000 [bus 00-7f] only partially covers this bridge
2023-09-05T21:59:12,255978+00:00 PCI host bridge to bus 0000:00
2023-09-05T21:59:12,255980+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0x03af window]
2023-09-05T21:59:12,255982+00:00 pci_bus 0000:00: root bus resource [io  0x03e0-0x0cf7 window]
2023-09-05T21:59:12,255983+00:00 pci_bus 0000:00: root bus resource [io  0x03b0-0x03df window]
2023-09-05T21:59:12,255984+00:00 pci_bus 0000:00: root bus resource [io  0x0d00-0xffff window]
2023-09-05T21:59:12,255986+00:00 pci_bus 0000:00: root bus resource [mem 0x000a0000-0x000dffff window]
2023-09-05T21:59:12,255987+00:00 pci_bus 0000:00: root bus resource [mem 0xc0000000-0xfec2ffff window]
2023-09-05T21:59:12,255989+00:00 pci_bus 0000:00: root bus resource [mem 0xfee00000-0xffffffff window]
2023-09-05T21:59:12,255990+00:00 pci_bus 0000:00: root bus resource [bus 00-ff]
2023-09-05T21:59:12,256005+00:00 pci 0000:00:00.0: [1022:1480] type 00 class 0x060000
2023-09-05T21:59:12,256105+00:00 pci 0000:00:01.0: [1022:1482] type 00 class 0x060000
2023-09-05T21:59:12,256174+00:00 pci 0000:00:01.3: [1022:1483] type 01 class 0x060400
2023-09-05T21:59:12,256204+00:00 pci 0000:00:01.3: enabling Extended Tags
2023-09-05T21:59:12,256260+00:00 pci 0000:00:01.3: PME# supported from D0 D3hot D3cold
2023-09-05T21:59:12,256435+00:00 pci 0000:00:02.0: [1022:1482] type 00 class 0x060000
2023-09-05T21:59:12,256501+00:00 pci 0000:00:03.0: [1022:1482] type 00 class 0x060000
2023-09-05T21:59:12,256564+00:00 pci 0000:00:03.1: [1022:1483] type 01 class 0x060400
2023-09-05T21:59:12,256634+00:00 pci 0000:00:03.1: PME# supported from D0 D3hot D3cold
2023-09-05T21:59:12,256757+00:00 pci 0000:00:03.2: [1022:1483] type 01 class 0x060400
2023-09-05T21:59:12,256827+00:00 pci 0000:00:03.2: PME# supported from D0 D3hot D3cold
2023-09-05T21:59:12,256948+00:00 pci 0000:00:04.0: [1022:1482] type 00 class 0x060000
2023-09-05T21:59:12,257014+00:00 pci 0000:00:05.0: [1022:1482] type 00 class 0x060000
2023-09-05T21:59:12,257080+00:00 pci 0000:00:07.0: [1022:1482] type 00 class 0x060000
2023-09-05T21:59:12,257142+00:00 pci 0000:00:07.1: [1022:1484] type 01 class 0x060400
2023-09-05T21:59:12,257167+00:00 pci 0000:00:07.1: enabling Extended Tags
2023-09-05T21:59:12,257208+00:00 pci 0000:00:07.1: PME# supported from D0 D3hot D3cold
2023-09-05T21:59:12,257320+00:00 pci 0000:00:08.0: [1022:1482] type 00 class 0x060000
2023-09-05T21:59:12,257383+00:00 pci 0000:00:08.1: [1022:1484] type 01 class 0x060400
2023-09-05T21:59:12,257409+00:00 pci 0000:00:08.1: enabling Extended Tags
2023-09-05T21:59:12,257453+00:00 pci 0000:00:08.1: PME# supported from D0 D3hot D3cold
2023-09-05T21:59:12,257572+00:00 pci 0000:00:08.3: [1022:1484] type 01 class 0x060400
2023-09-05T21:59:12,257598+00:00 pci 0000:00:08.3: enabling Extended Tags
2023-09-05T21:59:12,257642+00:00 pci 0000:00:08.3: PME# supported from D0 D3hot D3cold
2023-09-05T21:59:12,257770+00:00 pci 0000:00:14.0: [1022:790b] type 00 class 0x0c0500
2023-09-05T21:59:12,257891+00:00 pci 0000:00:14.3: [1022:790e] type 00 class 0x060100
2023-09-05T21:59:12,258023+00:00 pci 0000:00:18.0: [1022:1440] type 00 class 0x060000
2023-09-05T21:59:12,258060+00:00 pci 0000:00:18.1: [1022:1441] type 00 class 0x060000
2023-09-05T21:59:12,258096+00:00 pci 0000:00:18.2: [1022:1442] type 00 class 0x060000
2023-09-05T21:59:12,258132+00:00 pci 0000:00:18.3: [1022:1443] type 00 class 0x060000
2023-09-05T21:59:12,258169+00:00 pci 0000:00:18.4: [1022:1444] type 00 class 0x060000
2023-09-05T21:59:12,258205+00:00 pci 0000:00:18.5: [1022:1445] type 00 class 0x060000
2023-09-05T21:59:12,258244+00:00 pci 0000:00:18.6: [1022:1446] type 00 class 0x060000
2023-09-05T21:59:12,258280+00:00 pci 0000:00:18.7: [1022:1447] type 00 class 0x060000
2023-09-05T21:59:12,258382+00:00 pci 0000:01:00.0: [1022:43d0] type 00 class 0x0c0330
2023-09-05T21:59:12,258402+00:00 pci 0000:01:00.0: reg 0x10: [mem 0xfc7a0000-0xfc7a7fff 64bit]
2023-09-05T21:59:12,258449+00:00 pci 0000:01:00.0: enabling Extended Tags
2023-09-05T21:59:12,258514+00:00 pci 0000:01:00.0: PME# supported from D3hot D3cold
2023-09-05T21:59:12,258676+00:00 pci 0000:01:00.1: [1022:43c8] type 00 class 0x010601
2023-09-05T21:59:12,258731+00:00 pci 0000:01:00.1: reg 0x24: [mem 0xfc780000-0xfc79ffff]
2023-09-05T21:59:12,258740+00:00 pci 0000:01:00.1: reg 0x30: [mem 0xfc700000-0xfc77ffff pref]
2023-09-05T21:59:12,258747+00:00 pci 0000:01:00.1: enabling Extended Tags
2023-09-05T21:59:12,258794+00:00 pci 0000:01:00.1: PME# supported from D3hot D3cold
2023-09-05T21:59:12,258884+00:00 pci 0000:01:00.2: [1022:43c6] type 01 class 0x060400
2023-09-05T21:59:12,258934+00:00 pci 0000:01:00.2: enabling Extended Tags
2023-09-05T21:59:12,258986+00:00 pci 0000:01:00.2: PME# supported from D3hot D3cold
2023-09-05T21:59:12,259105+00:00 pci 0000:00:01.3: PCI bridge to [bus 01-0c]
2023-09-05T21:59:12,259109+00:00 pci 0000:00:01.3:   bridge window [io  0xd000-0xefff]
2023-09-05T21:59:12,259111+00:00 pci 0000:00:01.3:   bridge window [mem 0xfc200000-0xfc7fffff]
2023-09-05T21:59:12,259205+00:00 pci 0000:02:00.0: [1022:43c7] type 01 class 0x060400
2023-09-05T21:59:12,259260+00:00 pci 0000:02:00.0: enabling Extended Tags
2023-09-05T21:59:12,259329+00:00 pci 0000:02:00.0: PME# supported from D3hot D3cold
2023-09-05T21:59:12,259453+00:00 pci 0000:02:02.0: [1022:43c7] type 01 class 0x060400
2023-09-05T21:59:12,259507+00:00 pci 0000:02:02.0: enabling Extended Tags
2023-09-05T21:59:12,259575+00:00 pci 0000:02:02.0: PME# supported from D3hot D3cold
2023-09-05T21:59:12,259695+00:00 pci 0000:02:03.0: [1022:43c7] type 01 class 0x060400
2023-09-05T21:59:12,259749+00:00 pci 0000:02:03.0: enabling Extended Tags
2023-09-05T21:59:12,259817+00:00 pci 0000:02:03.0: PME# supported from D3hot D3cold
2023-09-05T21:59:12,259939+00:00 pci 0000:02:04.0: [1022:43c7] type 01 class 0x060400
2023-09-05T21:59:12,259993+00:00 pci 0000:02:04.0: enabling Extended Tags
2023-09-05T21:59:12,260062+00:00 pci 0000:02:04.0: PME# supported from D3hot D3cold
2023-09-05T21:59:12,260190+00:00 pci 0000:02:09.0: [1022:43c7] type 01 class 0x060400
2023-09-05T21:59:12,260247+00:00 pci 0000:02:09.0: enabling Extended Tags
2023-09-05T21:59:12,260322+00:00 pci 0000:02:09.0: PME# supported from D3hot D3cold
2023-09-05T21:59:12,260434+00:00 pci 0000:01:00.2: PCI bridge to [bus 02-0c]
2023-09-05T21:59:12,260440+00:00 pci 0000:01:00.2:   bridge window [io  0xd000-0xefff]
2023-09-05T21:59:12,260444+00:00 pci 0000:01:00.2:   bridge window [mem 0xfc200000-0xfc6fffff]
2023-09-05T21:59:12,260522+00:00 pci 0000:03:00.0: [1b21:2142] type 00 class 0x0c0330
2023-09-05T21:59:12,260555+00:00 pci 0000:03:00.0: reg 0x10: [mem 0xfc600000-0xfc607fff 64bit]
2023-09-05T21:59:12,260630+00:00 pci 0000:03:00.0: enabling Extended Tags
2023-09-05T21:59:12,260733+00:00 pci 0000:03:00.0: PME# supported from D0
2023-09-05T21:59:12,260791+00:00 pci 0000:03:00.0: 8.000 Gb/s available PCIe bandwidth, limited by 5.0 GT/s PCIe x2 link at 0000:02:00.0 (capable of 15.752 Gb/s with 8.0 GT/s PCIe x2 link)
2023-09-05T21:59:12,260910+00:00 pci 0000:02:00.0: PCI bridge to [bus 03]
2023-09-05T21:59:12,260918+00:00 pci 0000:02:00.0:   bridge window [mem 0xfc600000-0xfc6fffff]
2023-09-05T21:59:12,260995+00:00 pci 0000:04:00.0: [1b21:0612] type 00 class 0x010601
2023-09-05T21:59:12,261020+00:00 pci 0000:04:00.0: reg 0x10: [io  0xe050-0xe057]
2023-09-05T21:59:12,261035+00:00 pci 0000:04:00.0: reg 0x14: [io  0xe040-0xe043]
2023-09-05T21:59:12,261048+00:00 pci 0000:04:00.0: reg 0x18: [io  0xe030-0xe037]
2023-09-05T21:59:12,261062+00:00 pci 0000:04:00.0: reg 0x1c: [io  0xe020-0xe023]
2023-09-05T21:59:12,261077+00:00 pci 0000:04:00.0: reg 0x20: [io  0xe000-0xe01f]
2023-09-05T21:59:12,261091+00:00 pci 0000:04:00.0: reg 0x24: [mem 0xfc500000-0xfc5001ff]
2023-09-05T21:59:12,261292+00:00 pci 0000:02:02.0: PCI bridge to [bus 04]
2023-09-05T21:59:12,261298+00:00 pci 0000:02:02.0:   bridge window [io  0xe000-0xefff]
2023-09-05T21:59:12,261302+00:00 pci 0000:02:02.0:   bridge window [mem 0xfc500000-0xfc5fffff]
2023-09-05T21:59:12,261378+00:00 pci 0000:05:00.0: [1b21:1184] type 01 class 0x060400
2023-09-05T21:59:12,261456+00:00 pci 0000:05:00.0: enabling Extended Tags
2023-09-05T21:59:12,261555+00:00 pci 0000:05:00.0: PME# supported from D0 D3hot D3cold
2023-09-05T21:59:12,261698+00:00 pci 0000:02:03.0: PCI bridge to [bus 05-0a]
2023-09-05T21:59:12,261703+00:00 pci 0000:02:03.0:   bridge window [io  0xd000-0xdfff]
2023-09-05T21:59:12,261707+00:00 pci 0000:02:03.0:   bridge window [mem 0xfc200000-0xfc3fffff]
2023-09-05T21:59:12,261790+00:00 pci 0000:06:01.0: [1b21:1184] type 01 class 0x060400
2023-09-05T21:59:12,261871+00:00 pci 0000:06:01.0: enabling Extended Tags
2023-09-05T21:59:12,261968+00:00 pci 0000:06:01.0: PME# supported from D0 D3hot D3cold
2023-09-05T21:59:12,262090+00:00 pci 0000:06:03.0: [1b21:1184] type 01 class 0x060400
2023-09-05T21:59:12,262171+00:00 pci 0000:06:03.0: enabling Extended Tags
2023-09-05T21:59:12,262267+00:00 pci 0000:06:03.0: PME# supported from D0 D3hot D3cold
2023-09-05T21:59:12,262390+00:00 pci 0000:06:05.0: [1b21:1184] type 01 class 0x060400
2023-09-05T21:59:12,262471+00:00 pci 0000:06:05.0: enabling Extended Tags
2023-09-05T21:59:12,262567+00:00 pci 0000:06:05.0: PME# supported from D0 D3hot D3cold
2023-09-05T21:59:12,262691+00:00 pci 0000:06:07.0: [1b21:1184] type 01 class 0x060400
2023-09-05T21:59:12,262772+00:00 pci 0000:06:07.0: enabling Extended Tags
2023-09-05T21:59:12,262868+00:00 pci 0000:06:07.0: PME# supported from D0 D3hot D3cold
2023-09-05T21:59:12,263010+00:00 pci 0000:05:00.0: PCI bridge to [bus 06-0a]
2023-09-05T21:59:12,263018+00:00 pci 0000:05:00.0:   bridge window [io  0xd000-0xdfff]
2023-09-05T21:59:12,263023+00:00 pci 0000:05:00.0:   bridge window [mem 0xfc200000-0xfc3fffff]
2023-09-05T21:59:12,263142+00:00 pci 0000:07:00.0: [8086:24fb] type 00 class 0x028000
2023-09-05T21:59:12,263194+00:00 pci 0000:07:00.0: reg 0x10: [mem 0xfc300000-0xfc301fff 64bit]
2023-09-05T21:59:12,263475+00:00 pci 0000:07:00.0: PME# supported from D0 D3hot D3cold
2023-09-05T21:59:12,263773+00:00 pci 0000:06:01.0: PCI bridge to [bus 07]
2023-09-05T21:59:12,263785+00:00 pci 0000:06:01.0:   bridge window [mem 0xfc300000-0xfc3fffff]
2023-09-05T21:59:12,263849+00:00 pci 0000:06:03.0: PCI bridge to [bus 08]
2023-09-05T21:59:12,263972+00:00 pci 0000:09:00.0: [8086:1539] type 00 class 0x020000
2023-09-05T21:59:12,264011+00:00 pci 0000:09:00.0: reg 0x10: [mem 0xfc200000-0xfc21ffff]
2023-09-05T21:59:12,264053+00:00 pci 0000:09:00.0: reg 0x18: [io  0xd000-0xd01f]
2023-09-05T21:59:12,264075+00:00 pci 0000:09:00.0: reg 0x1c: [mem 0xfc220000-0xfc223fff]
2023-09-05T21:59:12,264301+00:00 pci 0000:09:00.0: PME# supported from D0 D3hot D3cold
2023-09-05T21:59:12,264533+00:00 pci 0000:06:05.0: PCI bridge to [bus 09]
2023-09-05T21:59:12,264541+00:00 pci 0000:06:05.0:   bridge window [io  0xd000-0xdfff]
2023-09-05T21:59:12,264546+00:00 pci 0000:06:05.0:   bridge window [mem 0xfc200000-0xfc2fffff]
2023-09-05T21:59:12,264608+00:00 pci 0000:06:07.0: PCI bridge to [bus 0a]
2023-09-05T21:59:12,264734+00:00 pci 0000:0b:00.0: [144d:a808] type 00 class 0x010802
2023-09-05T21:59:12,264764+00:00 pci 0000:0b:00.0: reg 0x10: [mem 0xfc400000-0xfc403fff 64bit]
2023-09-05T21:59:12,265023+00:00 pci 0000:0b:00.0: 16.000 Gb/s available PCIe bandwidth, limited by 5.0 GT/s PCIe x4 link at 0000:02:04.0 (capable of 31.504 Gb/s with 8.0 GT/s PCIe x4 link)
2023-09-05T21:59:12,265166+00:00 pci 0000:02:04.0: PCI bridge to [bus 0b]
2023-09-05T21:59:12,265174+00:00 pci 0000:02:04.0:   bridge window [mem 0xfc400000-0xfc4fffff]
2023-09-05T21:59:12,265219+00:00 pci 0000:02:09.0: PCI bridge to [bus 0c]
2023-09-05T21:59:12,265315+00:00 pci 0000:0d:00.0: [10de:1f02] type 00 class 0x030000
2023-09-05T21:59:12,265329+00:00 pci 0000:0d:00.0: reg 0x10: [mem 0xfb000000-0xfbffffff]
2023-09-05T21:59:12,265342+00:00 pci 0000:0d:00.0: reg 0x14: [mem 0xd0000000-0xdfffffff 64bit pref]
2023-09-05T21:59:12,265354+00:00 pci 0000:0d:00.0: reg 0x1c: [mem 0xe0000000-0xe1ffffff 64bit pref]
2023-09-05T21:59:12,265363+00:00 pci 0000:0d:00.0: reg 0x24: [io  0xf000-0xf07f]
2023-09-05T21:59:12,265371+00:00 pci 0000:0d:00.0: reg 0x30: [mem 0xfc000000-0xfc07ffff pref]
2023-09-05T21:59:12,265390+00:00 pci 0000:0d:00.0: BAR 3: assigned to efifb
2023-09-05T21:59:12,265395+00:00 pci 0000:0d:00.0: Video device with shadowed ROM at [mem 0x000c0000-0x000dffff]
2023-09-05T21:59:12,265446+00:00 pci 0000:0d:00.0: PME# supported from D0 D3hot
2023-09-05T21:59:12,265501+00:00 pci 0000:0d:00.0: 16.000 Gb/s available PCIe bandwidth, limited by 2.5 GT/s PCIe x8 link at 0000:00:03.1 (capable of 126.016 Gb/s with 8.0 GT/s PCIe x16 link)
2023-09-05T21:59:12,265616+00:00 pci 0000:0d:00.1: [10de:10f9] type 00 class 0x040300
2023-09-05T21:59:12,265630+00:00 pci 0000:0d:00.1: reg 0x10: [mem 0xfc080000-0xfc083fff]
2023-09-05T21:59:12,265778+00:00 pci 0000:0d:00.2: [10de:1ada] type 00 class 0x0c0330
2023-09-05T21:59:12,265796+00:00 pci 0000:0d:00.2: reg 0x10: [mem 0xe2000000-0xe203ffff 64bit pref]
2023-09-05T21:59:12,265816+00:00 pci 0000:0d:00.2: reg 0x1c: [mem 0xe2040000-0xe204ffff 64bit pref]
2023-09-05T21:59:12,265877+00:00 pci 0000:0d:00.2: PME# supported from D0 D3hot
2023-09-05T21:59:12,265941+00:00 pci 0000:0d:00.3: [10de:1adb] type 00 class 0x0c8000
2023-09-05T21:59:12,265956+00:00 pci 0000:0d:00.3: reg 0x10: [mem 0xfc084000-0xfc084fff]
2023-09-05T21:59:12,266045+00:00 pci 0000:0d:00.3: PME# supported from D0 D3hot
2023-09-05T21:59:12,266140+00:00 pci 0000:00:03.1: PCI bridge to [bus 0d]
2023-09-05T21:59:12,266144+00:00 pci 0000:00:03.1:   bridge window [io  0xf000-0xffff]
2023-09-05T21:59:12,266146+00:00 pci 0000:00:03.1:   bridge window [mem 0xfb000000-0xfc0fffff]
2023-09-05T21:59:12,266149+00:00 pci 0000:00:03.1:   bridge window [mem 0xd0000000-0xe20fffff 64bit pref]
2023-09-05T21:59:12,266201+00:00 pci 0000:0e:00.0: [12ab:0710] type 00 class 0x048000
2023-09-05T21:59:12,266214+00:00 pci 0000:0e:00.0: reg 0x10: [mem 0xfcb00000-0xfcbfffff]
2023-09-05T21:59:12,266221+00:00 pci 0000:0e:00.0: reg 0x14: [mem 0xfcc00000-0xfcc0ffff]
2023-09-05T21:59:12,266298+00:00 pci 0000:0e:00.0: PME# supported from D0 D1 D2 D3hot
2023-09-05T21:59:12,266361+00:00 pci 0000:00:03.2: PCI bridge to [bus 0e]
2023-09-05T21:59:12,266366+00:00 pci 0000:00:03.2:   bridge window [mem 0xfcb00000-0xfccfffff]
2023-09-05T21:59:12,266411+00:00 pci 0000:0f:00.0: [1022:148a] type 00 class 0x130000
2023-09-05T21:59:12,266440+00:00 pci 0000:0f:00.0: enabling Extended Tags
2023-09-05T21:59:12,266581+00:00 pci 0000:00:07.1: PCI bridge to [bus 0f]
2023-09-05T21:59:12,266637+00:00 pci 0000:10:00.0: [1022:1485] type 00 class 0x130000
2023-09-05T21:59:12,266671+00:00 pci 0000:10:00.0: enabling Extended Tags
2023-09-05T21:59:12,266812+00:00 pci 0000:10:00.1: [1022:1486] type 00 class 0x108000
2023-09-05T21:59:12,266829+00:00 pci 0000:10:00.1: reg 0x18: [mem 0xfc900000-0xfc9fffff]
2023-09-05T21:59:12,266841+00:00 pci 0000:10:00.1: reg 0x24: [mem 0xfca08000-0xfca09fff]
2023-09-05T21:59:12,266850+00:00 pci 0000:10:00.1: enabling Extended Tags
2023-09-05T21:59:12,266971+00:00 pci 0000:10:00.3: [1022:149c] type 00 class 0x0c0330
2023-09-05T21:59:12,266985+00:00 pci 0000:10:00.3: reg 0x10: [mem 0xfc800000-0xfc8fffff 64bit]
2023-09-05T21:59:12,267015+00:00 pci 0000:10:00.3: enabling Extended Tags
2023-09-05T21:59:12,267062+00:00 pci 0000:10:00.3: PME# supported from D0 D3hot D3cold
2023-09-05T21:59:12,267160+00:00 pci 0000:10:00.4: [1022:1487] type 00 class 0x040300
2023-09-05T21:59:12,267170+00:00 pci 0000:10:00.4: reg 0x10: [mem 0xfca00000-0xfca07fff]
2023-09-05T21:59:12,267197+00:00 pci 0000:10:00.4: enabling Extended Tags
2023-09-05T21:59:12,267242+00:00 pci 0000:10:00.4: PME# supported from D0 D3hot D3cold
2023-09-05T21:59:12,267350+00:00 pci 0000:00:08.1: PCI bridge to [bus 10]
2023-09-05T21:59:12,267355+00:00 pci 0000:00:08.1:   bridge window [mem 0xfc800000-0xfcafffff]
2023-09-05T21:59:12,267403+00:00 pci 0000:11:00.0: [1022:7901] type 00 class 0x010601
2023-09-05T21:59:12,267439+00:00 pci 0000:11:00.0: reg 0x24: [mem 0xfcd00000-0xfcd007ff]
2023-09-05T21:59:12,267449+00:00 pci 0000:11:00.0: enabling Extended Tags
2023-09-05T21:59:12,267508+00:00 pci 0000:11:00.0: PME# supported from D3hot D3cold
2023-09-05T21:59:12,267634+00:00 pci 0000:00:08.3: PCI bridge to [bus 11]
2023-09-05T21:59:12,267639+00:00 pci 0000:00:08.3:   bridge window [mem 0xfcd00000-0xfcdfffff]
2023-09-05T21:59:12,267976+00:00 ACPI: PCI: Interrupt link LNKA configured for IRQ 0
2023-09-05T21:59:12,268023+00:00 ACPI: PCI: Interrupt link LNKB configured for IRQ 0
2023-09-05T21:59:12,268063+00:00 ACPI: PCI: Interrupt link LNKC configured for IRQ 0
2023-09-05T21:59:12,268110+00:00 ACPI: PCI: Interrupt link LNKD configured for IRQ 0
2023-09-05T21:59:12,268153+00:00 ACPI: PCI: Interrupt link LNKE configured for IRQ 0
2023-09-05T21:59:12,268189+00:00 ACPI: PCI: Interrupt link LNKF configured for IRQ 0
2023-09-05T21:59:12,268226+00:00 ACPI: PCI: Interrupt link LNKG configured for IRQ 0
2023-09-05T21:59:12,268265+00:00 ACPI: PCI: Interrupt link LNKH configured for IRQ 0
2023-09-05T21:59:12,268940+00:00 iommu: Default domain type: Translated
2023-09-05T21:59:12,268941+00:00 iommu: DMA domain TLB invalidation policy: lazy mode
2023-09-05T21:59:12,268996+00:00 efivars: Registered efivars operations
2023-09-05T21:59:12,269258+00:00 NetLabel: Initializing
2023-09-05T21:59:12,269259+00:00 NetLabel:  domain hash size = 128
2023-09-05T21:59:12,269260+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2023-09-05T21:59:12,269276+00:00 NetLabel:  unlabeled traffic allowed by default
2023-09-05T21:59:12,269277+00:00 PCI: Using ACPI for IRQ routing
2023-09-05T21:59:12,273037+00:00 PCI: pci_cache_line_size set to 64 bytes
2023-09-05T21:59:12,273147+00:00 e820: reserve RAM buffer [mem 0x09bff000-0x0bffffff]
2023-09-05T21:59:12,273149+00:00 e820: reserve RAM buffer [mem 0x0a200000-0x0bffffff]
2023-09-05T21:59:12,273150+00:00 e820: reserve RAM buffer [mem 0x0b000000-0x0bffffff]
2023-09-05T21:59:12,273151+00:00 e820: reserve RAM buffer [mem 0xb537a018-0xb7ffffff]
2023-09-05T21:59:12,273152+00:00 e820: reserve RAM buffer [mem 0xb914b000-0xbbffffff]
2023-09-05T21:59:12,273153+00:00 e820: reserve RAM buffer [mem 0xba9bc000-0xbbffffff]
2023-09-05T21:59:12,273154+00:00 e820: reserve RAM buffer [mem 0xbf000000-0xbfffffff]
2023-09-05T21:59:12,273154+00:00 e820: reserve RAM buffer [mem 0x43f380000-0x43fffffff]
2023-09-05T21:59:12,273247+00:00 pci 0000:0d:00.0: vgaarb: setting as boot VGA device
2023-09-05T21:59:12,273249+00:00 pci 0000:0d:00.0: vgaarb: bridge control possible
2023-09-05T21:59:12,273250+00:00 pci 0000:0d:00.0: vgaarb: VGA device added: decodes=io+mem,owns=io+mem,locks=none
2023-09-05T21:59:12,273253+00:00 vgaarb: loaded
2023-09-05T21:59:12,273306+00:00 hpet0: at MMIO 0xfed00000, IRQs 2, 8, 0
2023-09-05T21:59:12,273311+00:00 hpet0: 3 comparators, 32-bit 14.318180 MHz counter
2023-09-05T21:59:12,275282+00:00 clocksource: Switched to clocksource tsc-early
2023-09-05T21:59:12,275392+00:00 VFS: Disk quotas dquot_6.6.0
2023-09-05T21:59:12,275411+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2023-09-05T21:59:12,275487+00:00 pnp: PnP ACPI init
2023-09-05T21:59:12,275583+00:00 system 00:00: [mem 0xf0000000-0xf7ffffff] has been reserved
2023-09-05T21:59:12,275638+00:00 system 00:01: [mem 0xfeb80000-0xfebfffff] has been reserved
2023-09-05T21:59:12,275753+00:00 system 00:02: [mem 0xfd200000-0xfd2fffff] has been reserved
2023-09-05T21:59:12,276024+00:00 system 00:04: [io  0x0280-0x028f] has been reserved
2023-09-05T21:59:12,276027+00:00 system 00:04: [io  0x0290-0x029f] has been reserved
2023-09-05T21:59:12,276029+00:00 system 00:04: [io  0x02a0-0x02af] has been reserved
2023-09-05T21:59:12,276031+00:00 system 00:04: [io  0x02b0-0x02bf] has been reserved
2023-09-05T21:59:12,276284+00:00 system 00:05: [io  0x04d0-0x04d1] has been reserved
2023-09-05T21:59:12,276286+00:00 system 00:05: [io  0x040b] has been reserved
2023-09-05T21:59:12,276289+00:00 system 00:05: [io  0x04d6] has been reserved
2023-09-05T21:59:12,276291+00:00 system 00:05: [io  0x0c00-0x0c01] has been reserved
2023-09-05T21:59:12,276293+00:00 system 00:05: [io  0x0c14] has been reserved
2023-09-05T21:59:12,276295+00:00 system 00:05: [io  0x0c50-0x0c51] has been reserved
2023-09-05T21:59:12,276297+00:00 system 00:05: [io  0x0c52] has been reserved
2023-09-05T21:59:12,276299+00:00 system 00:05: [io  0x0c6c] has been reserved
2023-09-05T21:59:12,276301+00:00 system 00:05: [io  0x0c6f] has been reserved
2023-09-05T21:59:12,276303+00:00 system 00:05: [io  0x0cd8-0x0cdf] has been reserved
2023-09-05T21:59:12,276305+00:00 system 00:05: [io  0x0800-0x089f] has been reserved
2023-09-05T21:59:12,276307+00:00 system 00:05: [io  0x0b00-0x0b0f] has been reserved
2023-09-05T21:59:12,276309+00:00 system 00:05: [io  0x0b20-0x0b3f] has been reserved
2023-09-05T21:59:12,276311+00:00 system 00:05: [io  0x0900-0x090f] has been reserved
2023-09-05T21:59:12,276313+00:00 system 00:05: [io  0x0910-0x091f] has been reserved
2023-09-05T21:59:12,276316+00:00 system 00:05: [mem 0xfec00000-0xfec00fff] could not be reserved
2023-09-05T21:59:12,276318+00:00 system 00:05: [mem 0xfec01000-0xfec01fff] could not be reserved
2023-09-05T21:59:12,276321+00:00 system 00:05: [mem 0xfedc0000-0xfedc0fff] has been reserved
2023-09-05T21:59:12,276324+00:00 system 00:05: [mem 0xfee00000-0xfee00fff] has been reserved
2023-09-05T21:59:12,276326+00:00 system 00:05: [mem 0xfed80000-0xfed8ffff] could not be reserved
2023-09-05T21:59:12,276329+00:00 system 00:05: [mem 0xfec10000-0xfec10fff] has been reserved
2023-09-05T21:59:12,276331+00:00 system 00:05: [mem 0xff000000-0xffffffff] has been reserved
2023-09-05T21:59:12,276950+00:00 pnp: PnP ACPI: found 6 devices
2023-09-05T21:59:12,283063+00:00 clocksource: acpi_pm: mask: 0xffffff max_cycles: 0xffffff, max_idle_ns: 2085701024 ns
2023-09-05T21:59:12,283132+00:00 NET: Registered PF_INET protocol family
2023-09-05T21:59:12,283246+00:00 IP idents hash table entries: 262144 (order: 9, 2097152 bytes, linear)
2023-09-05T21:59:12,285645+00:00 tcp_listen_portaddr_hash hash table entries: 8192 (order: 5, 131072 bytes, linear)
2023-09-05T21:59:12,285659+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2023-09-05T21:59:12,285663+00:00 TCP established hash table entries: 131072 (order: 8, 1048576 bytes, linear)
2023-09-05T21:59:12,285770+00:00 TCP bind hash table entries: 65536 (order: 9, 2097152 bytes, linear)
2023-09-05T21:59:12,285874+00:00 TCP: Hash tables configured (established 131072 bind 65536)
2023-09-05T21:59:12,285994+00:00 MPTCP token hash table entries: 16384 (order: 6, 393216 bytes, linear)
2023-09-05T21:59:12,286023+00:00 UDP hash table entries: 8192 (order: 6, 262144 bytes, linear)
2023-09-05T21:59:12,286047+00:00 UDP-Lite hash table entries: 8192 (order: 6, 262144 bytes, linear)
2023-09-05T21:59:12,286157+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2023-09-05T21:59:12,286163+00:00 NET: Registered PF_XDP protocol family
2023-09-05T21:59:12,286177+00:00 pci 0000:02:00.0: PCI bridge to [bus 03]
2023-09-05T21:59:12,286183+00:00 pci 0000:02:00.0:   bridge window [mem 0xfc600000-0xfc6fffff]
2023-09-05T21:59:12,286192+00:00 pci 0000:02:02.0: PCI bridge to [bus 04]
2023-09-05T21:59:12,286196+00:00 pci 0000:02:02.0:   bridge window [io  0xe000-0xefff]
2023-09-05T21:59:12,286201+00:00 pci 0000:02:02.0:   bridge window [mem 0xfc500000-0xfc5fffff]
2023-09-05T21:59:12,286210+00:00 pci 0000:06:01.0: PCI bridge to [bus 07]
2023-09-05T21:59:12,286218+00:00 pci 0000:06:01.0:   bridge window [mem 0xfc300000-0xfc3fffff]
2023-09-05T21:59:12,286230+00:00 pci 0000:06:03.0: PCI bridge to [bus 08]
2023-09-05T21:59:12,286248+00:00 pci 0000:06:05.0: PCI bridge to [bus 09]
2023-09-05T21:59:12,286251+00:00 pci 0000:06:05.0:   bridge window [io  0xd000-0xdfff]
2023-09-05T21:59:12,286258+00:00 pci 0000:06:05.0:   bridge window [mem 0xfc200000-0xfc2fffff]
2023-09-05T21:59:12,286271+00:00 pci 0000:06:07.0: PCI bridge to [bus 0a]
2023-09-05T21:59:12,286289+00:00 pci 0000:05:00.0: PCI bridge to [bus 06-0a]
2023-09-05T21:59:12,286292+00:00 pci 0000:05:00.0:   bridge window [io  0xd000-0xdfff]
2023-09-05T21:59:12,286299+00:00 pci 0000:05:00.0:   bridge window [mem 0xfc200000-0xfc3fffff]
2023-09-05T21:59:12,286312+00:00 pci 0000:02:03.0: PCI bridge to [bus 05-0a]
2023-09-05T21:59:12,286315+00:00 pci 0000:02:03.0:   bridge window [io  0xd000-0xdfff]
2023-09-05T21:59:12,286320+00:00 pci 0000:02:03.0:   bridge window [mem 0xfc200000-0xfc3fffff]
2023-09-05T21:59:12,286329+00:00 pci 0000:02:04.0: PCI bridge to [bus 0b]
2023-09-05T21:59:12,286334+00:00 pci 0000:02:04.0:   bridge window [mem 0xfc400000-0xfc4fffff]
2023-09-05T21:59:12,286343+00:00 pci 0000:02:09.0: PCI bridge to [bus 0c]
2023-09-05T21:59:12,286356+00:00 pci 0000:01:00.2: PCI bridge to [bus 02-0c]
2023-09-05T21:59:12,286358+00:00 pci 0000:01:00.2:   bridge window [io  0xd000-0xefff]
2023-09-05T21:59:12,286363+00:00 pci 0000:01:00.2:   bridge window [mem 0xfc200000-0xfc6fffff]
2023-09-05T21:59:12,286372+00:00 pci 0000:00:01.3: PCI bridge to [bus 01-0c]
2023-09-05T21:59:12,286374+00:00 pci 0000:00:01.3:   bridge window [io  0xd000-0xefff]
2023-09-05T21:59:12,286378+00:00 pci 0000:00:01.3:   bridge window [mem 0xfc200000-0xfc7fffff]
2023-09-05T21:59:12,286385+00:00 pci 0000:00:03.1: PCI bridge to [bus 0d]
2023-09-05T21:59:12,286388+00:00 pci 0000:00:03.1:   bridge window [io  0xf000-0xffff]
2023-09-05T21:59:12,286391+00:00 pci 0000:00:03.1:   bridge window [mem 0xfb000000-0xfc0fffff]
2023-09-05T21:59:12,286394+00:00 pci 0000:00:03.1:   bridge window [mem 0xd0000000-0xe20fffff 64bit pref]
2023-09-05T21:59:12,286399+00:00 pci 0000:00:03.2: PCI bridge to [bus 0e]
2023-09-05T21:59:12,286403+00:00 pci 0000:00:03.2:   bridge window [mem 0xfcb00000-0xfccfffff]
2023-09-05T21:59:12,286409+00:00 pci 0000:00:07.1: PCI bridge to [bus 0f]
2023-09-05T21:59:12,286416+00:00 pci 0000:00:08.1: PCI bridge to [bus 10]
2023-09-05T21:59:12,286420+00:00 pci 0000:00:08.1:   bridge window [mem 0xfc800000-0xfcafffff]
2023-09-05T21:59:12,286425+00:00 pci 0000:00:08.3: PCI bridge to [bus 11]
2023-09-05T21:59:12,286429+00:00 pci 0000:00:08.3:   bridge window [mem 0xfcd00000-0xfcdfffff]
2023-09-05T21:59:12,286435+00:00 pci_bus 0000:00: resource 4 [io  0x0000-0x03af window]
2023-09-05T21:59:12,286437+00:00 pci_bus 0000:00: resource 5 [io  0x03e0-0x0cf7 window]
2023-09-05T21:59:12,286439+00:00 pci_bus 0000:00: resource 6 [io  0x03b0-0x03df window]
2023-09-05T21:59:12,286441+00:00 pci_bus 0000:00: resource 7 [io  0x0d00-0xffff window]
2023-09-05T21:59:12,286443+00:00 pci_bus 0000:00: resource 8 [mem 0x000a0000-0x000dffff window]
2023-09-05T21:59:12,286445+00:00 pci_bus 0000:00: resource 9 [mem 0xc0000000-0xfec2ffff window]
2023-09-05T21:59:12,286447+00:00 pci_bus 0000:00: resource 10 [mem 0xfee00000-0xffffffff window]
2023-09-05T21:59:12,286449+00:00 pci_bus 0000:01: resource 0 [io  0xd000-0xefff]
2023-09-05T21:59:12,286451+00:00 pci_bus 0000:01: resource 1 [mem 0xfc200000-0xfc7fffff]
2023-09-05T21:59:12,286453+00:00 pci_bus 0000:02: resource 0 [io  0xd000-0xefff]
2023-09-05T21:59:12,286455+00:00 pci_bus 0000:02: resource 1 [mem 0xfc200000-0xfc6fffff]
2023-09-05T21:59:12,286456+00:00 pci_bus 0000:03: resource 1 [mem 0xfc600000-0xfc6fffff]
2023-09-05T21:59:12,286458+00:00 pci_bus 0000:04: resource 0 [io  0xe000-0xefff]
2023-09-05T21:59:12,286460+00:00 pci_bus 0000:04: resource 1 [mem 0xfc500000-0xfc5fffff]
2023-09-05T21:59:12,286462+00:00 pci_bus 0000:05: resource 0 [io  0xd000-0xdfff]
2023-09-05T21:59:12,286464+00:00 pci_bus 0000:05: resource 1 [mem 0xfc200000-0xfc3fffff]
2023-09-05T21:59:12,286466+00:00 pci_bus 0000:06: resource 0 [io  0xd000-0xdfff]
2023-09-05T21:59:12,286468+00:00 pci_bus 0000:06: resource 1 [mem 0xfc200000-0xfc3fffff]
2023-09-05T21:59:12,286470+00:00 pci_bus 0000:07: resource 1 [mem 0xfc300000-0xfc3fffff]
2023-09-05T21:59:12,286472+00:00 pci_bus 0000:09: resource 0 [io  0xd000-0xdfff]
2023-09-05T21:59:12,286474+00:00 pci_bus 0000:09: resource 1 [mem 0xfc200000-0xfc2fffff]
2023-09-05T21:59:12,286476+00:00 pci_bus 0000:0b: resource 1 [mem 0xfc400000-0xfc4fffff]
2023-09-05T21:59:12,286478+00:00 pci_bus 0000:0d: resource 0 [io  0xf000-0xffff]
2023-09-05T21:59:12,286479+00:00 pci_bus 0000:0d: resource 1 [mem 0xfb000000-0xfc0fffff]
2023-09-05T21:59:12,286481+00:00 pci_bus 0000:0d: resource 2 [mem 0xd0000000-0xe20fffff 64bit pref]
2023-09-05T21:59:12,286483+00:00 pci_bus 0000:0e: resource 1 [mem 0xfcb00000-0xfccfffff]
2023-09-05T21:59:12,286486+00:00 pci_bus 0000:10: resource 1 [mem 0xfc800000-0xfcafffff]
2023-09-05T21:59:12,286488+00:00 pci_bus 0000:11: resource 1 [mem 0xfcd00000-0xfcdfffff]
2023-09-05T21:59:12,286698+00:00 pci 0000:03:00.0: PME# does not work under D0, disabling it
2023-09-05T21:59:12,286882+00:00 pci 0000:0d:00.1: extending delay after power-on from D3hot to 20 msec
2023-09-05T21:59:12,286913+00:00 pci 0000:0d:00.1: D0 power state depends on 0000:0d:00.0
2023-09-05T21:59:12,286977+00:00 pci 0000:0d:00.2: D0 power state depends on 0000:0d:00.0
2023-09-05T21:59:12,287131+00:00 pci 0000:0d:00.3: D0 power state depends on 0000:0d:00.0
2023-09-05T21:59:12,287307+00:00 PCI: CLS 64 bytes, default 64
2023-09-05T21:59:12,287312+00:00 PCI-DMA: Using software bounce buffering for IO (SWIOTLB)
2023-09-05T21:59:12,287313+00:00 software IO TLB: mapped [mem 0x00000000acaf6000-0x00000000b0af6000] (64MB)
2023-09-05T21:59:12,287361+00:00 Trying to unpack rootfs image as initramfs...
2023-09-05T21:59:12,287364+00:00 LVT offset 0 assigned for vector 0x400
2023-09-05T21:59:12,294051+00:00 perf: AMD IBS detected (0x000003ff)
2023-09-05T21:59:12,294652+00:00 Initialise system trusted keyrings
2023-09-05T21:59:12,294675+00:00 workingset: timestamp_bits=40 max_order=22 bucket_order=0
2023-09-05T21:59:12,294686+00:00 zbud: loaded
2023-09-05T21:59:12,294901+00:00 NET: Registered PF_ALG protocol family
2023-09-05T21:59:12,294903+00:00 Key type asymmetric registered
2023-09-05T21:59:12,294904+00:00 Asymmetric key parser 'x509' registered
2023-09-05T21:59:12,294911+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 252)
2023-09-05T21:59:12,294938+00:00 io scheduler mq-deadline registered
2023-09-05T21:59:12,294939+00:00 io scheduler kyber registered
2023-09-05T21:59:12,295723+00:00 amd_gpio AMDI0030:00: Invalid config param 0014
2023-09-05T21:59:12,295727+00:00 fbcon: Taking over console
2023-09-05T21:59:12,295858+00:00 pcieport 0000:00:01.3: PME: Signaling with IRQ 28
2023-09-05T21:59:12,295981+00:00 pcieport 0000:00:03.1: PME: Signaling with IRQ 29
2023-09-05T21:59:12,296089+00:00 pcieport 0000:00:03.2: PME: Signaling with IRQ 30
2023-09-05T21:59:12,296231+00:00 pcieport 0000:00:07.1: PME: Signaling with IRQ 31
2023-09-05T21:59:12,296331+00:00 pcieport 0000:00:08.1: PME: Signaling with IRQ 32
2023-09-05T21:59:12,296479+00:00 pcieport 0000:00:08.3: PME: Signaling with IRQ 33
2023-09-05T21:59:12,297941+00:00 efifb: probing for efifb
2023-09-05T21:59:12,297949+00:00 efifb: No BGRT, not showing boot graphics
2023-09-05T21:59:12,297949+00:00 efifb: framebuffer at 0xe1000000, using 2400k, total 2400k
2023-09-05T21:59:12,297951+00:00 efifb: mode is 800x600x32, linelength=4096, pages=1
2023-09-05T21:59:12,297952+00:00 efifb: scrolling: redraw
2023-09-05T21:59:12,297952+00:00 efifb: Truecolor: size=8:8:8:8, shift=24:16:8:0
2023-09-05T21:59:12,298026+00:00 Console: switching to colour frame buffer device 100x37
2023-09-05T21:59:12,299298+00:00 fb0: EFI VGA frame buffer device
2023-09-05T21:59:12,300108+00:00 Estimated ratio of average max frequency by base frequency (times 1024): 1165
2023-09-05T21:59:12,301181+00:00 Serial: 8250/16550 driver, 4 ports, IRQ sharing enabled
2023-09-05T21:59:12,302253+00:00 amd_pstate: driver load is disabled, boot with specific mode to enable this
2023-09-05T21:59:12,302292+00:00 drop_monitor: Initializing network drop monitor service
2023-09-05T21:59:12,309826+00:00 NET: Registered PF_INET6 protocol family
2023-09-05T21:59:12,327967+00:00 Freeing initrd memory: 11736K
2023-09-05T21:59:12,328308+00:00 Segment Routing with IPv6
2023-09-05T21:59:12,328317+00:00 In-situ OAM (IOAM) with IPv6
2023-09-05T21:59:12,329254+00:00 microcode: CPU1: patch_level=0x0a20120a
2023-09-05T21:59:12,329254+00:00 microcode: CPU3: patch_level=0x0a20120a
2023-09-05T21:59:12,329254+00:00 microcode: CPU2: patch_level=0x0a20120a
2023-09-05T21:59:12,329254+00:00 microcode: CPU4: patch_level=0x0a20120a
2023-09-05T21:59:12,329255+00:00 microcode: CPU5: patch_level=0x0a20120a
2023-09-05T21:59:12,329255+00:00 microcode: CPU7: patch_level=0x0a20120a
2023-09-05T21:59:12,329255+00:00 microcode: CPU8: patch_level=0x0a20120a
2023-09-05T21:59:12,329256+00:00 microcode: CPU10: patch_level=0x0a20120a
2023-09-05T21:59:12,329255+00:00 microcode: CPU6: patch_level=0x0a20120a
2023-09-05T21:59:12,329255+00:00 microcode: CPU0: patch_level=0x0a20120a
2023-09-05T21:59:12,329256+00:00 microcode: CPU9: patch_level=0x0a20120a
2023-09-05T21:59:12,329257+00:00 microcode: CPU11: patch_level=0x0a20120a
2023-09-05T21:59:12,329274+00:00 microcode: Microcode Update Driver: v2.2.
2023-09-05T21:59:12,329278+00:00 IPI shorthand broadcast: enabled
2023-09-05T21:59:12,330714+00:00 sched_clock: Marking stable (329925555, 168777)->(619056637, -288962305)
2023-09-05T21:59:12,330803+00:00 registered taskstats version 1
2023-09-05T21:59:12,330948+00:00 Loading compiled-in X.509 certificates
2023-09-05T21:59:12,332640+00:00 Key type .fscrypt registered
2023-09-05T21:59:12,332641+00:00 Key type fscrypt-provisioning registered
2023-09-05T21:59:12,332857+00:00 clk: Disabling unused clocks
2023-09-05T21:59:12,333678+00:00 Freeing unused decrypted memory: 2036K
2023-09-05T21:59:12,334151+00:00 Freeing unused kernel image (initmem) memory: 2932K
2023-09-05T21:59:12,342099+00:00 Write protecting the kernel read-only data: 24576k
2023-09-05T21:59:12,342427+00:00 Freeing unused kernel image (rodata/data gap) memory: 1080K
2023-09-05T21:59:12,382986+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2023-09-05T21:59:12,382990+00:00 Run /init as init process
2023-09-05T21:59:12,382991+00:00   with arguments:
2023-09-05T21:59:12,382992+00:00     /init
2023-09-05T21:59:12,382993+00:00   with environment:
2023-09-05T21:59:12,382994+00:00     HOME=/
2023-09-05T21:59:12,382995+00:00     TERM=linux
2023-09-05T21:59:12,382996+00:00     cgroup_enable=cpuset
2023-09-05T21:59:12,403829+00:00 stage-1-init: [Tue Sep  5 23:59:11 UTC 2023] loading module dm_mod...
2023-09-05T21:59:12,411850+00:00 device-mapper: ioctl: 4.48.0-ioctl (2023-03-01) initialised: dm-devel@redhat.com
2023-09-05T21:59:12,412688+00:00 stage-1-init: [Tue Sep  5 23:59:11 UTC 2023] running udev...
2023-09-05T21:59:12,420811+00:00 stage-1-init: [Tue Sep  5 23:59:11 UTC 2023] Starting systemd-udevd version 253.6
2023-09-05T21:59:12,494117+00:00 rtc_cmos 00:03: RTC can wake from S4
2023-09-05T21:59:12,494379+00:00 rtc_cmos 00:03: registered as rtc0
2023-09-05T21:59:12,494408+00:00 rtc_cmos 00:03: alarms up to one month, y3k, 114 bytes nvram, hpet irqs
2023-09-05T21:59:12,506973+00:00 SCSI subsystem initialized
2023-09-05T21:59:12,511182+00:00 ACPI: bus type USB registered
2023-09-05T21:59:12,511201+00:00 usbcore: registered new interface driver usbfs
2023-09-05T21:59:12,511212+00:00 usbcore: registered new interface driver hub
2023-09-05T21:59:12,511234+00:00 usbcore: registered new device driver usb
2023-09-05T21:59:12,511288+00:00 nvme nvme0: pci function 0000:0b:00.0
2023-09-05T21:59:12,517336+00:00 nvme nvme0: missing or invalid SUBNQN field.
2023-09-05T21:59:12,517457+00:00 nvme nvme0: Shutdown timeout set to 8 seconds
2023-09-05T21:59:12,521041+00:00 libata version 3.00 loaded.
2023-09-05T21:59:12,544317+00:00 nvme nvme0: 32/0/0 default/read/poll queues
2023-09-05T21:59:12,549658+00:00  nvme0n1: p1 p2
2023-09-05T21:59:12,553227+00:00 ahci 0000:01:00.1: version 3.0
2023-09-05T21:59:12,553357+00:00 ahci 0000:01:00.1: SSS flag set, parallel bus scan disabled
2023-09-05T21:59:12,553424+00:00 ahci 0000:01:00.1: AHCI 0001.0301 32 slots 8 ports 6 Gbps 0xff impl SATA mode
2023-09-05T21:59:12,553427+00:00 ahci 0000:01:00.1: flags: 64bit ncq sntf stag pm led clo only pmp pio slum part sxs deso sadm sds apst 
2023-09-05T21:59:12,554252+00:00 scsi host0: ahci
2023-09-05T21:59:12,554534+00:00 scsi host1: ahci
2023-09-05T21:59:12,554665+00:00 scsi host2: ahci
2023-09-05T21:59:12,554780+00:00 scsi host3: ahci
2023-09-05T21:59:12,554900+00:00 scsi host4: ahci
2023-09-05T21:59:12,555027+00:00 scsi host5: ahci
2023-09-05T21:59:12,555156+00:00 scsi host6: ahci
2023-09-05T21:59:12,555292+00:00 scsi host7: ahci
2023-09-05T21:59:12,555360+00:00 ata1: SATA max UDMA/133 abar m131072@0xfc780000 port 0xfc780100 irq 77
2023-09-05T21:59:12,555363+00:00 ata2: SATA max UDMA/133 abar m131072@0xfc780000 port 0xfc780180 irq 77
2023-09-05T21:59:12,555366+00:00 ata3: SATA max UDMA/133 abar m131072@0xfc780000 port 0xfc780200 irq 77
2023-09-05T21:59:12,555368+00:00 ata4: SATA max UDMA/133 abar m131072@0xfc780000 port 0xfc780280 irq 77
2023-09-05T21:59:12,555371+00:00 ata5: SATA max UDMA/133 abar m131072@0xfc780000 port 0xfc780300 irq 77
2023-09-05T21:59:12,555372+00:00 ata6: SATA max UDMA/133 abar m131072@0xfc780000 port 0xfc780380 irq 77
2023-09-05T21:59:12,555374+00:00 ata7: SATA max UDMA/133 abar m131072@0xfc780000 port 0xfc780400 irq 77
2023-09-05T21:59:12,555376+00:00 ata8: SATA max UDMA/133 abar m131072@0xfc780000 port 0xfc780480 irq 77
2023-09-05T21:59:12,555549+00:00 ahci 0000:04:00.0: SSS flag set, parallel bus scan disabled
2023-09-05T21:59:12,555596+00:00 ahci 0000:04:00.0: AHCI 0001.0200 32 slots 2 ports 6 Gbps 0x3 impl SATA mode
2023-09-05T21:59:12,555599+00:00 ahci 0000:04:00.0: flags: 64bit ncq sntf stag led clo pmp pio slum part ccc 
2023-09-05T21:59:12,555848+00:00 scsi host8: ahci
2023-09-05T21:59:12,555966+00:00 scsi host9: ahci
2023-09-05T21:59:12,556029+00:00 ata9: SATA max UDMA/133 abar m512@0xfc500000 port 0xfc500100 irq 78
2023-09-05T21:59:12,556033+00:00 ata10: SATA max UDMA/133 abar m512@0xfc500000 port 0xfc500180 irq 78
2023-09-05T21:59:12,556214+00:00 ahci 0000:11:00.0: AHCI 0001.0301 32 slots 1 ports 6 Gbps 0x20 impl SATA mode
2023-09-05T21:59:12,556217+00:00 ahci 0000:11:00.0: flags: 64bit ncq sntf ilck pm led clo only pmp fbs pio slum part 
2023-09-05T21:59:12,556877+00:00 scsi host10: ahci
2023-09-05T21:59:12,556999+00:00 scsi host11: ahci
2023-09-05T21:59:12,557104+00:00 scsi host12: ahci
2023-09-05T21:59:12,557197+00:00 scsi host13: ahci
2023-09-05T21:59:12,557284+00:00 scsi host14: ahci
2023-09-05T21:59:12,557377+00:00 scsi host15: ahci
2023-09-05T21:59:12,557427+00:00 ata11: DUMMY
2023-09-05T21:59:12,557428+00:00 ata12: DUMMY
2023-09-05T21:59:12,557429+00:00 ata13: DUMMY
2023-09-05T21:59:12,557429+00:00 ata14: DUMMY
2023-09-05T21:59:12,557430+00:00 ata15: DUMMY
2023-09-05T21:59:12,557432+00:00 ata16: SATA max UDMA/133 abar m2048@0xfcd00000 port 0xfcd00380 irq 80
2023-09-05T21:59:12,861107+00:00 ata1: SATA link down (SStatus 0 SControl 330)
2023-09-05T21:59:12,868666+00:00 ata9: SATA link down (SStatus 0 SControl 300)
2023-09-05T21:59:13,030988+00:00 ata16: SATA link up 6.0 Gbps (SStatus 133 SControl 300)
2023-09-05T21:59:13,031290+00:00 ata16.00: supports DRM functions and may not be fully accessible
2023-09-05T21:59:13,031292+00:00 ata16.00: ATA-11: Samsung SSD 860 EVO M.2 2TB, RVT21B6Q, max UDMA/133
2023-09-05T21:59:13,031969+00:00 ata16.00: 3907029168 sectors, multi 1: LBA48 NCQ (depth 32), AA
2023-09-05T21:59:13,035154+00:00 ata16.00: Features: Trust Dev-Sleep NCQ-sndrcv
2023-09-05T21:59:13,035566+00:00 ata16.00: supports DRM functions and may not be fully accessible
2023-09-05T21:59:13,039635+00:00 ata16.00: configured for UDMA/133
2023-09-05T21:59:13,174096+00:00 ata2: SATA link down (SStatus 0 SControl 330)
2023-09-05T21:59:13,326177+00:00 tsc: Refined TSC clocksource calibration: 3500.284 MHz
2023-09-05T21:59:13,326183+00:00 clocksource: tsc: mask: 0xffffffffffffffff max_cycles: 0x32745d5253d, max_idle_ns: 440795222606 ns
2023-09-05T21:59:13,326202+00:00 clocksource: Switched to clocksource tsc
2023-09-05T21:59:13,483276+00:00 ata3: SATA link down (SStatus 0 SControl 330)
2023-09-05T21:59:13,787272+00:00 ata4: SATA link down (SStatus 0 SControl 330)
2023-09-05T21:59:14,091294+00:00 ata5: SATA link down (SStatus 0 SControl 300)
2023-09-05T21:59:14,395286+00:00 ata6: SATA link down (SStatus 0 SControl 330)
2023-09-05T21:59:14,699285+00:00 ata7: SATA link down (SStatus 0 SControl 330)
2023-09-05T21:59:15,003288+00:00 ata8: SATA link down (SStatus 0 SControl 330)
2023-09-05T21:59:15,307306+00:00 ata10: SATA link down (SStatus 0 SControl 300)
2023-09-05T21:59:15,307404+00:00 scsi 15:0:0:0: Direct-Access     ATA      Samsung SSD 860  1B6Q PQ: 0 ANSI: 5
2023-09-05T21:59:15,310876+00:00 xhci_hcd 0000:01:00.0: xHCI Host Controller
2023-09-05T21:59:15,310882+00:00 xhci_hcd 0000:01:00.0: new USB bus registered, assigned bus number 1
2023-09-05T21:59:15,315514+00:00 ata16.00: Enabling discard_zeroes_data
2023-09-05T21:59:15,315526+00:00 sd 15:0:0:0: [sda] 3907029168 512-byte logical blocks: (2.00 TB/1.82 TiB)
2023-09-05T21:59:15,315534+00:00 sd 15:0:0:0: [sda] Write Protect is off
2023-09-05T21:59:15,315536+00:00 sd 15:0:0:0: [sda] Mode Sense: 00 3a 00 00
2023-09-05T21:59:15,315547+00:00 sd 15:0:0:0: [sda] Write cache: enabled, read cache: enabled, doesn't support DPO or FUA
2023-09-05T21:59:15,315571+00:00 sd 15:0:0:0: [sda] Preferred minimum I/O size 512 bytes
2023-09-05T21:59:15,315965+00:00 ata16.00: Enabling discard_zeroes_data
2023-09-05T21:59:15,318761+00:00  sda: sda1 sda2
2023-09-05T21:59:15,319864+00:00 sd 15:0:0:0: [sda] supports TCG Opal
2023-09-05T21:59:15,319865+00:00 sd 15:0:0:0: [sda] Attached SCSI disk
2023-09-05T21:59:15,366069+00:00 xhci_hcd 0000:01:00.0: hcc params 0x0200ef81 hci version 0x110 quirks 0x0000000000000410
2023-09-05T21:59:15,366396+00:00 xhci_hcd 0000:01:00.0: xHCI Host Controller
2023-09-05T21:59:15,366399+00:00 xhci_hcd 0000:01:00.0: new USB bus registered, assigned bus number 2
2023-09-05T21:59:15,366401+00:00 xhci_hcd 0000:01:00.0: Host supports USB 3.1 Enhanced SuperSpeed
2023-09-05T21:59:15,366462+00:00 usb usb1: New USB device found, idVendor=1d6b, idProduct=0002, bcdDevice= 6.05
2023-09-05T21:59:15,366464+00:00 usb usb1: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2023-09-05T21:59:15,366466+00:00 usb usb1: Product: xHCI Host Controller
2023-09-05T21:59:15,366467+00:00 usb usb1: Manufacturer: Linux 6.5.0 xhci-hcd
2023-09-05T21:59:15,366468+00:00 usb usb1: SerialNumber: 0000:01:00.0
2023-09-05T21:59:15,366604+00:00 hub 1-0:1.0: USB hub found
2023-09-05T21:59:15,366623+00:00 hub 1-0:1.0: 14 ports detected
2023-09-05T21:59:15,367120+00:00 usb usb2: We don't know the algorithms for LPM for this host, disabling LPM.
2023-09-05T21:59:15,367138+00:00 usb usb2: New USB device found, idVendor=1d6b, idProduct=0003, bcdDevice= 6.05
2023-09-05T21:59:15,367140+00:00 usb usb2: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2023-09-05T21:59:15,367141+00:00 usb usb2: Product: xHCI Host Controller
2023-09-05T21:59:15,367142+00:00 usb usb2: Manufacturer: Linux 6.5.0 xhci-hcd
2023-09-05T21:59:15,367144+00:00 usb usb2: SerialNumber: 0000:01:00.0
2023-09-05T21:59:15,367232+00:00 hub 2-0:1.0: USB hub found
2023-09-05T21:59:15,367245+00:00 hub 2-0:1.0: 8 ports detected
2023-09-05T21:59:15,367358+00:00 usb: port power management may be unreliable
2023-09-05T21:59:15,367612+00:00 xhci_hcd 0000:03:00.0: xHCI Host Controller
2023-09-05T21:59:15,367616+00:00 xhci_hcd 0000:03:00.0: new USB bus registered, assigned bus number 3
2023-09-05T21:59:15,422438+00:00 xhci_hcd 0000:03:00.0: hcc params 0x0200ef80 hci version 0x110 quirks 0x0000000000800010
2023-09-05T21:59:15,422765+00:00 xhci_hcd 0000:03:00.0: xHCI Host Controller
2023-09-05T21:59:15,422767+00:00 xhci_hcd 0000:03:00.0: new USB bus registered, assigned bus number 4
2023-09-05T21:59:15,422770+00:00 xhci_hcd 0000:03:00.0: Host supports USB 3.1 Enhanced SuperSpeed
2023-09-05T21:59:15,422815+00:00 usb usb3: New USB device found, idVendor=1d6b, idProduct=0002, bcdDevice= 6.05
2023-09-05T21:59:15,422817+00:00 usb usb3: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2023-09-05T21:59:15,422819+00:00 usb usb3: Product: xHCI Host Controller
2023-09-05T21:59:15,422820+00:00 usb usb3: Manufacturer: Linux 6.5.0 xhci-hcd
2023-09-05T21:59:15,422821+00:00 usb usb3: SerialNumber: 0000:03:00.0
2023-09-05T21:59:15,422905+00:00 hub 3-0:1.0: USB hub found
2023-09-05T21:59:15,422913+00:00 hub 3-0:1.0: 2 ports detected
2023-09-05T21:59:15,423004+00:00 usb usb4: We don't know the algorithms for LPM for this host, disabling LPM.
2023-09-05T21:59:15,423022+00:00 usb usb4: New USB device found, idVendor=1d6b, idProduct=0003, bcdDevice= 6.05
2023-09-05T21:59:15,423024+00:00 usb usb4: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2023-09-05T21:59:15,423025+00:00 usb usb4: Product: xHCI Host Controller
2023-09-05T21:59:15,423026+00:00 usb usb4: Manufacturer: Linux 6.5.0 xhci-hcd
2023-09-05T21:59:15,423027+00:00 usb usb4: SerialNumber: 0000:03:00.0
2023-09-05T21:59:15,423100+00:00 hub 4-0:1.0: USB hub found
2023-09-05T21:59:15,423110+00:00 hub 4-0:1.0: 2 ports detected
2023-09-05T21:59:15,423295+00:00 xhci_hcd 0000:0d:00.2: xHCI Host Controller
2023-09-05T21:59:15,423299+00:00 xhci_hcd 0000:0d:00.2: new USB bus registered, assigned bus number 5
2023-09-05T21:59:15,423909+00:00 xhci_hcd 0000:0d:00.2: hcc params 0x0180ff05 hci version 0x110 quirks 0x0000000000000010
2023-09-05T21:59:15,424047+00:00 xhci_hcd 0000:0d:00.2: xHCI Host Controller
2023-09-05T21:59:15,424050+00:00 xhci_hcd 0000:0d:00.2: new USB bus registered, assigned bus number 6
2023-09-05T21:59:15,424052+00:00 xhci_hcd 0000:0d:00.2: Host supports USB 3.1 Enhanced SuperSpeed
2023-09-05T21:59:15,424092+00:00 usb usb5: New USB device found, idVendor=1d6b, idProduct=0002, bcdDevice= 6.05
2023-09-05T21:59:15,424094+00:00 usb usb5: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2023-09-05T21:59:15,424095+00:00 usb usb5: Product: xHCI Host Controller
2023-09-05T21:59:15,424096+00:00 usb usb5: Manufacturer: Linux 6.5.0 xhci-hcd
2023-09-05T21:59:15,424097+00:00 usb usb5: SerialNumber: 0000:0d:00.2
2023-09-05T21:59:15,424178+00:00 hub 5-0:1.0: USB hub found
2023-09-05T21:59:15,424185+00:00 hub 5-0:1.0: 2 ports detected
2023-09-05T21:59:15,424283+00:00 usb usb6: We don't know the algorithms for LPM for this host, disabling LPM.
2023-09-05T21:59:15,424301+00:00 usb usb6: New USB device found, idVendor=1d6b, idProduct=0003, bcdDevice= 6.05
2023-09-05T21:59:15,424302+00:00 usb usb6: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2023-09-05T21:59:15,424303+00:00 usb usb6: Product: xHCI Host Controller
2023-09-05T21:59:15,424304+00:00 usb usb6: Manufacturer: Linux 6.5.0 xhci-hcd
2023-09-05T21:59:15,424305+00:00 usb usb6: SerialNumber: 0000:0d:00.2
2023-09-05T21:59:15,424381+00:00 hub 6-0:1.0: USB hub found
2023-09-05T21:59:15,424390+00:00 hub 6-0:1.0: 4 ports detected
2023-09-05T21:59:15,424574+00:00 xhci_hcd 0000:10:00.3: xHCI Host Controller
2023-09-05T21:59:15,424578+00:00 xhci_hcd 0000:10:00.3: new USB bus registered, assigned bus number 7
2023-09-05T21:59:15,424678+00:00 xhci_hcd 0000:10:00.3: hcc params 0x0278ffe5 hci version 0x110 quirks 0x0000000000000410
2023-09-05T21:59:15,424931+00:00 xhci_hcd 0000:10:00.3: xHCI Host Controller
2023-09-05T21:59:15,424935+00:00 xhci_hcd 0000:10:00.3: new USB bus registered, assigned bus number 8
2023-09-05T21:59:15,424936+00:00 xhci_hcd 0000:10:00.3: Host supports USB 3.1 Enhanced SuperSpeed
2023-09-05T21:59:15,424964+00:00 usb usb7: New USB device found, idVendor=1d6b, idProduct=0002, bcdDevice= 6.05
2023-09-05T21:59:15,424966+00:00 usb usb7: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2023-09-05T21:59:15,424967+00:00 usb usb7: Product: xHCI Host Controller
2023-09-05T21:59:15,424968+00:00 usb usb7: Manufacturer: Linux 6.5.0 xhci-hcd
2023-09-05T21:59:15,424969+00:00 usb usb7: SerialNumber: 0000:10:00.3
2023-09-05T21:59:15,425048+00:00 hub 7-0:1.0: USB hub found
2023-09-05T21:59:15,425055+00:00 hub 7-0:1.0: 4 ports detected
2023-09-05T21:59:15,425168+00:00 usb usb8: We don't know the algorithms for LPM for this host, disabling LPM.
2023-09-05T21:59:15,425189+00:00 usb usb8: New USB device found, idVendor=1d6b, idProduct=0003, bcdDevice= 6.05
2023-09-05T21:59:15,425191+00:00 usb usb8: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2023-09-05T21:59:15,425192+00:00 usb usb8: Product: xHCI Host Controller
2023-09-05T21:59:15,425193+00:00 usb usb8: Manufacturer: Linux 6.5.0 xhci-hcd
2023-09-05T21:59:15,425194+00:00 usb usb8: SerialNumber: 0000:10:00.3
2023-09-05T21:59:15,425270+00:00 hub 8-0:1.0: USB hub found
2023-09-05T21:59:15,425276+00:00 hub 8-0:1.0: 4 ports detected
2023-09-05T21:59:15,431159+00:00 stage-1-init: [Tue Sep  5 23:59:14 UTC 2023] starting device mapper and LVM...
2023-09-05T21:59:15,466527+00:00 stage-1-init: [Tue Sep  5 23:59:14 UTC 2023] checking /dev/disk/by-uuid/4b1cd989-5999-4d7c-8012-535963e2f7e5...
2023-09-05T21:59:15,467114+00:00 stage-1-init: [Tue Sep  5 23:59:14 UTC 2023] fsck (busybox 1.36.1)
2023-09-05T21:59:15,467769+00:00 stage-1-init: [Tue Sep  5 23:59:14 UTC 2023] [fsck.ext4 (1) -- /mnt-root/] fsck.ext4 -a /dev/disk/by-uuid/4b1cd989-5999-4d7c-8012-535963e2f7e5
2023-09-05T21:59:15,475388+00:00 stage-1-init: [Tue Sep  5 23:59:14 UTC 2023] /dev/disk/by-uuid/4b1cd989-5999-4d7c-8012-535963e2f7e5: clean, 16769099/122068992 files, 287249114/488246424 blocks
2023-09-05T21:59:15,483466+00:00 stage-1-init: [Tue Sep  5 23:59:14 UTC 2023] mounting /dev/disk/by-uuid/4b1cd989-5999-4d7c-8012-535963e2f7e5 on /...
2023-09-05T21:59:15,551383+00:00 EXT4-fs (sda2): mounted filesystem 4b1cd989-5999-4d7c-8012-535963e2f7e5 r/w with ordered data mode. Quota mode: none.
2023-09-05T21:59:15,552316+00:00 EXT4-fs (sda2): re-mounted 4b1cd989-5999-4d7c-8012-535963e2f7e5 r/w. Quota mode: none.
2023-09-05T21:59:15,665176+00:00 usb 7-1: new high-speed USB device number 2 using xhci_hcd
2023-09-05T21:59:15,702177+00:00 usb 1-9: new full-speed USB device number 2 using xhci_hcd
2023-09-05T21:59:15,730822+00:00 EXT4-fs (sda2): re-mounted 4b1cd989-5999-4d7c-8012-535963e2f7e5 r/w. Quota mode: none.
2023-09-05T21:59:15,731002+00:00 booting system configuration /nix/store/6zhcn3ndafmmnvx6ka1axfgv546ggfsd-nixos-system-nixos-23.05.20230902.9075cba
2023-09-05T21:59:15,755665+00:00 stage-2-init: running activation script...
2023-09-05T21:59:15,804829+00:00 usb 7-1: New USB device found, idVendor=0bda, idProduct=5411, bcdDevice= 1.03
2023-09-05T21:59:15,804833+00:00 usb 7-1: New USB device strings: Mfr=1, Product=2, SerialNumber=0
2023-09-05T21:59:15,804835+00:00 usb 7-1: Product: USB2.1 Hub
2023-09-05T21:59:15,804836+00:00 usb 7-1: Manufacturer: Generic
2023-09-05T21:59:15,841739+00:00 hub 7-1:1.0: USB hub found
2023-09-05T21:59:15,842954+00:00 hub 7-1:1.0: 2 ports detected
2023-09-05T21:59:15,880259+00:00 stage-2-init: setting up /etc...
2023-09-05T21:59:15,911667+00:00 usb 8-1: new SuperSpeed USB device number 2 using xhci_hcd
2023-09-05T21:59:15,932594+00:00 usb 8-1: New USB device found, idVendor=0bda, idProduct=0411, bcdDevice= 1.03
2023-09-05T21:59:15,932597+00:00 usb 8-1: New USB device strings: Mfr=1, Product=2, SerialNumber=0
2023-09-05T21:59:15,932599+00:00 usb 8-1: Product: USB3.2 Hub
2023-09-05T21:59:15,932601+00:00 usb 8-1: Manufacturer: Generic
2023-09-05T21:59:15,953708+00:00 hub 8-1:1.0: USB hub found
2023-09-05T21:59:15,955264+00:00 hub 8-1:1.0: 2 ports detected
2023-09-05T21:59:16,041175+00:00 usb 7-2: new high-speed USB device number 3 using xhci_hcd
2023-09-05T21:59:16,068826+00:00 usb 1-9: New USB device found, idVendor=8087, idProduct=0aa7, bcdDevice= 0.01
2023-09-05T21:59:16,068830+00:00 usb 1-9: New USB device strings: Mfr=0, Product=0, SerialNumber=0
2023-09-05T21:59:16,143248+00:00 systemd[1]: RTC configured in localtime, applying delta of 120 minutes to system time.
2023-09-05T21:59:16,154080+00:00 systemd[1]: Inserted module 'autofs4'
2023-09-05T21:59:16,171706+00:00 usb 7-2: New USB device found, idVendor=1220, idProduct=8fe0, bcdDevice= 1.00
2023-09-05T21:59:16,171709+00:00 usb 7-2: New USB device strings: Mfr=1, Product=2, SerialNumber=0
2023-09-05T21:59:16,171711+00:00 usb 7-2: Product: GoXLR
2023-09-05T21:59:16,171713+00:00 usb 7-2: Manufacturer: TC-Helicon
2023-09-05T21:59:16,174564+00:00 systemd[1]: systemd 253.6 running in system mode (+PAM +AUDIT -SELINUX +APPARMOR +IMA +SMACK +SECCOMP +GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN +IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 -PWQUALITY +P11KIT -QRENCODE +TPM2 +BZIP2 +LZ4 +XZ +ZLIB +ZSTD +BPF_FRAMEWORK -XKBCOMMON +UTMP -SYSVINIT default-hierarchy=unified)
2023-09-05T21:59:16,174568+00:00 systemd[1]: Detected architecture x86-64.
2023-09-05T21:59:16,244176+00:00 usb 7-1.1: new high-speed USB device number 4 using xhci_hcd
2023-09-05T21:59:16,256176+00:00 usb 1-13: new full-speed USB device number 3 using xhci_hcd
2023-09-05T21:59:16,334830+00:00 usb 7-1.1: New USB device found, idVendor=214b, idProduct=7250, bcdDevice= 1.00
2023-09-05T21:59:16,334832+00:00 usb 7-1.1: New USB device strings: Mfr=0, Product=1, SerialNumber=0
2023-09-05T21:59:16,334834+00:00 usb 7-1.1: Product: USB2.0 HUB
2023-09-05T21:59:16,385111+00:00 hub 7-1.1:1.0: USB hub found
2023-09-05T21:59:16,385454+00:00 hub 7-1.1:1.0: 4 ports detected
2023-09-05T21:59:16,624835+00:00 usb 1-13: New USB device found, idVendor=1e71, idProduct=170e, bcdDevice= 2.00
2023-09-05T21:59:16,624837+00:00 usb 1-13: New USB device strings: Mfr=1, Product=2, SerialNumber=3
2023-09-05T21:59:16,624839+00:00 usb 1-13: Product: NZXT USB Device
2023-09-05T21:59:16,624840+00:00 usb 1-13: Manufacturer: NZXT.-Inc.
2023-09-05T21:59:16,624842+00:00 usb 1-13: SerialNumber: 6D72167E545
2023-09-05T21:59:16,662177+00:00 usb 7-1.1.1: new high-speed USB device number 5 using xhci_hcd
2023-09-05T21:59:16,690185+00:00 systemd[1]: bpf-lsm: LSM BPF program attached
2023-09-05T21:59:16,739829+00:00 usb 7-1.1.1: New USB device found, idVendor=1a40, idProduct=0101, bcdDevice= 1.11
2023-09-05T21:59:16,739832+00:00 usb 7-1.1.1: New USB device strings: Mfr=0, Product=1, SerialNumber=0
2023-09-05T21:59:16,739834+00:00 usb 7-1.1.1: Product: USB 2.0 Hub
2023-09-05T21:59:16,801112+00:00 hub 7-1.1.1:1.0: USB hub found
2023-09-05T21:59:16,801455+00:00 hub 7-1.1.1:1.0: 4 ports detected
2023-09-05T21:59:16,845748+00:00 systemd[1]: /nix/store/k9gwy4xk7gp05hlflxgwhh94hcs3xrs9-system-units/docker.service.d/overrides.conf:18: Missing '=', ignoring line.
2023-09-05T21:59:16,848091+00:00 systemd[1]: /etc/systemd/system/cups.socket:5: ListenStream= references a path below legacy directory /var/run/, updating /var/run/cups/cups.sock \xe2\x86\x92 /run/cups/cups.sock; please update the unit file accordingly.
2023-09-05T21:59:16,862004+00:00 systemd[1]: Queued start job for default target Graphical Interface.
2023-09-05T21:59:16,867175+00:00 usb 7-1.1.2: new high-speed USB device number 6 using xhci_hcd
2023-09-05T21:59:16,877856+00:00 systemd[1]: Created slice Slice /system/modprobe.
2023-09-05T21:59:16,878362+00:00 systemd[1]: Created slice Slice /system/systemd-fsck.
2023-09-05T21:59:16,878794+00:00 systemd[1]: Created slice User and Session Slice.
2023-09-05T21:59:16,878886+00:00 systemd[1]: Started Dispatch Password Requests to Console Directory Watch.
2023-09-05T21:59:16,878973+00:00 systemd[1]: Started Forward Password Requests to Wall Directory Watch.
2023-09-05T21:59:16,879127+00:00 systemd[1]: Set up automount Arbitrary Executable File Formats File System Automount Point.
2023-09-05T21:59:16,879208+00:00 systemd[1]: Reached target Local Encrypted Volumes.
2023-09-05T21:59:16,879254+00:00 systemd[1]: Reached target Login Prompts.
2023-09-05T21:59:16,879298+00:00 systemd[1]: Reached target Containers.
2023-09-05T21:59:16,879342+00:00 systemd[1]: Reached target Path Units.
2023-09-05T21:59:16,879381+00:00 systemd[1]: Reached target Remote File Systems.
2023-09-05T21:59:16,879420+00:00 systemd[1]: Reached target Slice Units.
2023-09-05T21:59:16,879459+00:00 systemd[1]: Reached target Swaps.
2023-09-05T21:59:16,880191+00:00 systemd[1]: Listening on Process Core Dump Socket.
2023-09-05T21:59:16,880856+00:00 systemd[1]: Listening on Journal Socket (/dev/log).
2023-09-05T21:59:16,881507+00:00 systemd[1]: Listening on Journal Socket.
2023-09-05T21:59:16,882189+00:00 systemd[1]: Listening on Userspace Out-Of-Memory (OOM) Killer Socket.
2023-09-05T21:59:16,882998+00:00 systemd[1]: Listening on udev Control Socket.
2023-09-05T21:59:16,883639+00:00 systemd[1]: Listening on udev Kernel Socket.
2023-09-05T21:59:16,885074+00:00 systemd[1]: Mounting Huge Pages File System...
2023-09-05T21:59:16,886512+00:00 systemd[1]: Mounting POSIX Message Queue File System...
2023-09-05T21:59:16,888049+00:00 systemd[1]: Mounting Kernel Debug File System...
2023-09-05T21:59:16,889507+00:00 systemd[1]: Starting Create List of Static Device Nodes...
2023-09-05T21:59:16,890911+00:00 systemd[1]: Starting Load Kernel Module configfs...
2023-09-05T21:59:16,892282+00:00 systemd[1]: Starting Load Kernel Module drm...
2023-09-05T21:59:16,893588+00:00 systemd[1]: Starting Load Kernel Module efi_pstore...
2023-09-05T21:59:16,894895+00:00 systemd[1]: Starting Load Kernel Module fuse...
2023-09-05T21:59:16,896181+00:00 systemd[1]: Starting mount-pstore.service...
2023-09-05T21:59:16,896666+00:00 systemd[1]: File System Check on Root Device was skipped because of an unmet condition check (ConditionPathIsReadWrite=!/).
2023-09-05T21:59:16,897886+00:00 systemd[1]: Starting Journal Service...
2023-09-05T21:59:16,898337+00:00 pstore: Using crash dump compression: deflate
2023-09-05T21:59:16,899255+00:00 pstore: Registered efi_pstore as persistent store backend
2023-09-05T21:59:16,899270+00:00 systemd[1]: Starting Load Kernel Modules...
2023-09-05T21:59:16,900591+00:00 systemd[1]: Starting Remount Root and Kernel File Systems...
2023-09-05T21:59:16,901942+00:00 systemd[1]: Starting Coldplug All udev Devices...
2023-09-05T21:59:16,903752+00:00 fuse: init (API version 7.38)
2023-09-05T21:59:16,904633+00:00 systemd[1]: Mounted Huge Pages File System.
2023-09-05T21:59:16,905153+00:00 systemd[1]: Mounted POSIX Message Queue File System.
2023-09-05T21:59:16,905714+00:00 systemd[1]: Mounted Kernel Debug File System.
2023-09-05T21:59:16,907732+00:00 systemd-journald[708]: Collecting audit messages is disabled.
2023-09-05T21:59:16,912058+00:00 EXT4-fs (sda2): re-mounted 4b1cd989-5999-4d7c-8012-535963e2f7e5 r/w. Quota mode: none.
2023-09-05T21:59:16,918318+00:00 systemd[1]: Finished Create List of Static Device Nodes.
2023-09-05T21:59:16,919757+00:00 systemd[1]: modprobe@configfs.service: Deactivated successfully.
2023-09-05T21:59:16,922826+00:00 ACPI: bus type drm_connector registered
2023-09-05T21:59:16,938351+00:00 systemd[1]: Finished Load Kernel Module configfs.
2023-09-05T21:59:16,939160+00:00 systemd[1]: modprobe@drm.service: Deactivated successfully.
2023-09-05T21:59:16,962707+00:00 usb 7-1.1.2: New USB device found, idVendor=0fd9, idProduct=0060, bcdDevice= 1.00
2023-09-05T21:59:16,962711+00:00 usb 7-1.1.2: New USB device strings: Mfr=1, Product=2, SerialNumber=3
2023-09-05T21:59:16,962714+00:00 usb 7-1.1.2: Product: Stream Deck
2023-09-05T21:59:16,962715+00:00 usb 7-1.1.2: Manufacturer: Elgato Systems
2023-09-05T21:59:16,962717+00:00 usb 7-1.1.2: SerialNumber: AL15I1C02177
2023-09-05T21:59:16,968275+00:00 systemd[1]: Finished Load Kernel Module drm.
2023-09-05T21:59:16,968838+00:00 systemd[1]: Started Journal Service.
2023-09-05T21:59:16,971374+00:00 ccp 0000:10:00.1: enabling device (0000 -> 0002)
2023-09-05T21:59:16,971488+00:00 ccp 0000:10:00.1: ccp: unable to access the device: you might be running a broken BIOS.
2023-09-05T21:59:16,971501+00:00 ccp 0000:10:00.1: psp enabled
2023-09-05T21:59:16,978655+00:00 kvm_amd: TSC scaling supported
2023-09-05T21:59:16,978656+00:00 kvm_amd: Nested Virtualization enabled
2023-09-05T21:59:16,978657+00:00 kvm_amd: Nested Paging enabled
2023-09-05T21:59:16,978663+00:00 kvm_amd: Virtual VMLOAD VMSAVE supported
2023-09-05T21:59:16,978664+00:00 kvm_amd: Virtual GIF supported
2023-09-05T21:59:16,978665+00:00 kvm_amd: LBR virtualization supported
2023-09-05T21:59:16,997680+00:00 bridge: filtering via arp/ip/ip6tables is no longer available by default. Update your scripts to load br_netfilter if you need this.
2023-09-05T21:59:17,003486+00:00 tun: Universal TUN/TAP device driver, 1.6
2023-09-05T21:59:17,006085+00:00 Bridge firewalling registered
2023-09-05T21:59:17,021817+00:00 loop: module loaded
2023-09-05T21:59:17,068360+00:00 systemd-journald[708]: Received client request to flush runtime journal.
2023-09-05T21:59:17,121181+00:00 usb 7-1.1.3: new full-speed USB device number 7 using xhci_hcd
2023-09-05T21:59:17,190233+00:00 systemd-journald[708]: /var/log/journal/7db9449887224d229d073f714f3c3782/system.journal: Monotonic clock jumped backwards relative to last journal entry, rotating.
2023-09-05T21:59:17,190237+00:00 systemd-journald[708]: Rotating system journal.
2023-09-05T21:59:17,236570+00:00 nvidia: loading out-of-tree module taints kernel.
2023-09-05T21:59:17,236577+00:00 nvidia: module license 'NVIDIA' taints kernel.
2023-09-05T21:59:17,236578+00:00 Disabling lock debugging due to kernel taint
2023-09-05T21:59:17,236580+00:00 nvidia: module license taints kernel.
2023-09-05T21:59:17,239968+00:00 usb 7-1.1.3: New USB device found, idVendor=12c9, idProduct=2003, bcdDevice= 2.11
2023-09-05T21:59:17,239972+00:00 usb 7-1.1.3: New USB device strings: Mfr=1, Product=2, SerialNumber=0
2023-09-05T21:59:17,239974+00:00 usb 7-1.1.3: Product: USB Gaming Mouse
2023-09-05T21:59:17,239976+00:00 usb 7-1.1.3: Manufacturer: SOAI
2023-09-05T21:59:17,274466+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0C:00/input/input0
2023-09-05T21:59:17,278510+00:00 ACPI: button: Power Button [PWRB]
2023-09-05T21:59:17,278619+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXPWRBN:00/input/input1
2023-09-05T21:59:17,287141+00:00 ACPI: button: Power Button [PWRF]
2023-09-05T21:59:17,445174+00:00 usb 7-1.1.4: new high-speed USB device number 8 using xhci_hcd
2023-09-05T21:59:17,524829+00:00 usb 7-1.1.4: New USB device found, idVendor=214b, idProduct=7250, bcdDevice= 1.00
2023-09-05T21:59:17,524832+00:00 usb 7-1.1.4: New USB device strings: Mfr=0, Product=1, SerialNumber=0
2023-09-05T21:59:17,524834+00:00 usb 7-1.1.4: Product: USB2.0 HUB
2023-09-05T21:59:17,569122+00:00 hub 7-1.1.4:1.0: USB hub found
2023-09-05T21:59:17,569455+00:00 hub 7-1.1.4:1.0: 4 ports detected
2023-09-05T21:59:17,595228+00:00 piix4_smbus 0000:00:14.0: SMBus Host Controller at 0xb00, revision 0
2023-09-05T21:59:17,595231+00:00 piix4_smbus 0000:00:14.0: Using register 0x02 for SMBus port selection
2023-09-05T21:59:17,595275+00:00 hid: raw HID events driver (C) Jiri Kosina
2023-09-05T21:59:17,596200+00:00 piix4_smbus 0000:00:14.0: Auxiliary SMBus Host Controller at 0xb20
2023-09-05T21:59:17,597250+00:00 RAPL PMU: API unit is 2^-32 Joules, 1 fixed counters, 163840 ms ovfl timer
2023-09-05T21:59:17,597253+00:00 RAPL PMU: hw unit of domain package 2^-16 Joules
2023-09-05T21:59:17,598305+00:00 dca service started, version 1.12.1
2023-09-05T21:59:17,598510+00:00 nvidia-nvlink: Nvlink Core is being initialized, major device number 244

2023-09-05T21:59:17,601151+00:00 nvidia 0000:0d:00.0: vgaarb: changed VGA decodes: olddecodes=io+mem,decodes=none:owns=io+mem
2023-09-05T21:59:17,601713+00:00 cryptd: max_cpu_qlen set to 1000
2023-09-05T21:59:17,604306+00:00 pps_core: LinuxPPS API ver. 1 registered
2023-09-05T21:59:17,604308+00:00 pps_core: Software ver. 5.3.6 - Copyright 2005-2007 Rodolfo Giometti <giometti@linux.it>
2023-09-05T21:59:17,610531+00:00 AVX2 version of gcm_enc/dec engaged.
2023-09-05T21:59:17,610565+00:00 AES CTR mode by8 optimization enabled
2023-09-05T21:59:17,621845+00:00 PTP clock support registered
2023-09-05T21:59:17,622325+00:00 sp5100_tco: SP5100/SB800 TCO WatchDog Timer Driver
2023-09-05T21:59:17,628672+00:00 sp5100-tco sp5100-tco: Using 0xfeb00000 for watchdog MMIO address
2023-09-05T21:59:17,633691+00:00 sp5100-tco sp5100-tco: initialized. heartbeat=60 sec (nowayout=0)
2023-09-05T21:59:17,653035+00:00 usbcore: registered new interface driver usbhid
2023-09-05T21:59:17,653038+00:00 usbhid: USB HID core driver
2023-09-05T21:59:17,688484+00:00 mc: Linux media interface: v0.10
2023-09-05T21:59:17,688819+00:00 igb: Intel(R) Gigabit Ethernet Network Driver
2023-09-05T21:59:17,688821+00:00 igb: Copyright (c) 2007-2014 Intel Corporation.
2023-09-05T21:59:17,688861+00:00 cfg80211: Loading compiled-in X.509 certificates for regulatory database
2023-09-05T21:59:17,689004+00:00 Bluetooth: Core ver 2.22
2023-09-05T21:59:17,689018+00:00 NET: Registered PF_BLUETOOTH protocol family
2023-09-05T21:59:17,689019+00:00 Bluetooth: HCI device and connection manager initialized
2023-09-05T21:59:17,689022+00:00 Bluetooth: HCI socket layer initialized
2023-09-05T21:59:17,689025+00:00 Bluetooth: L2CAP socket layer initialized
2023-09-05T21:59:17,689030+00:00 Bluetooth: SCO socket layer initialized
2023-09-05T21:59:17,689054+00:00 hid-generic 0003:1E71:170E.0001: hiddev96,hidraw0: USB HID v1.10 Device [NZXT.-Inc. NZXT USB Device] on usb-0000:01:00.0-13/input0
2023-09-05T21:59:17,689426+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T21:59:17,689428+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T21:59:17,689430+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T21:59:17,689431+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T21:59:17,689433+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T21:59:17,689435+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T21:59:17,689436+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T21:59:17,689437+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T21:59:17,689438+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T21:59:17,689439+00:00 Elgato Systems Stream Deck: Invalid code 65535 type 1
2023-09-05T21:59:17,690849+00:00 input: Elgato Systems Stream Deck as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.2/7-1.1.2:1.0/0003:0FD9:0060.0002/input/input2
2023-09-05T21:59:17,691461+00:00 Loaded X.509 cert 'sforshee: 00b28ddf47aef9cea7'
2023-09-05T21:59:17,694277+00:00 nzxt-kraken2 0003:1E71:170E.0001: hidraw0: USB HID v1.10 Device [NZXT.-Inc. NZXT USB Device] on usb-0000:01:00.0-13/input0
2023-09-05T21:59:17,695931+00:00 intel_rapl_common: Found RAPL domain package
2023-09-05T21:59:17,695934+00:00 intel_rapl_common: Found RAPL domain core
2023-09-05T21:59:17,697931+00:00 EDAC MC: Ver: 3.0.0
2023-09-05T21:59:17,701785+00:00 MCE: In-kernel MCE decoding enabled.
2023-09-05T21:59:17,707147+00:00 usbcore: registered new interface driver btusb
2023-09-05T21:59:17,711694+00:00 snd_hda_intel 0000:0d:00.1: Disabling MSI
2023-09-05T21:59:17,711706+00:00 snd_hda_intel 0000:0d:00.1: Handle vga_switcheroo audio client
2023-09-05T21:59:17,711791+00:00 snd_hda_intel 0000:10:00.4: enabling device (0000 -> 0002)
2023-09-05T21:59:17,720703+00:00 pps pps0: new PPS source ptp0
2023-09-05T21:59:17,720754+00:00 igb 0000:09:00.0: added PHC on eth0
2023-09-05T21:59:17,720782+00:00 igb 0000:09:00.0: Intel(R) Gigabit Ethernet Network Connection
2023-09-05T21:59:17,720783+00:00 igb 0000:09:00.0: eth0: (PCIe:2.5Gb/s:Width x1) 70:85:c2:b9:65:7d
2023-09-05T21:59:17,720786+00:00 igb 0000:09:00.0: eth0: PBA No: FFFFFF-0FF
2023-09-05T21:59:17,720787+00:00 igb 0000:09:00.0: Using MSI-X interrupts. 2 rx queue(s), 2 tx queue(s)
2023-09-05T21:59:17,723717+00:00 Bluetooth: hci0: Legacy ROM 2.x revision 5.0 build 25 week 20 2015
2023-09-05T21:59:17,723721+00:00 Bluetooth: hci0: Intel device is already patched. patch num: 3c
2023-09-05T21:59:17,737276+00:00 Intel(R) Wireless WiFi driver for Linux
2023-09-05T21:59:17,737320+00:00 iwlwifi 0000:07:00.0: enabling device (0000 -> 0002)
2023-09-05T21:59:17,737652+00:00 iwlwifi 0000:07:00.0: Detected crf-id 0x0, cnv-id 0x0 wfpm id 0x0
2023-09-05T21:59:17,737659+00:00 iwlwifi 0000:07:00.0: PCI dev 24fb/2110, rev=0x220, rfid=0xd55555d5
2023-09-05T21:59:17,741060+00:00 igb 0000:09:00.0 enp9s0: renamed from eth0
2023-09-05T21:59:17,743237+00:00 hid-generic 0003:0FD9:0060.0002: input,hidraw1: USB HID v1.11 Device [Elgato Systems Stream Deck] on usb-0000:10:00.3-1.1.2/input0
2023-09-05T21:59:17,743319+00:00 input: SOAI USB Gaming Mouse as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.3/7-1.1.3:1.0/0003:12C9:2003.0003/input/input3
2023-09-05T21:59:17,743390+00:00 hid-generic 0003:12C9:2003.0003: input,hidraw2: USB HID v1.10 Mouse [SOAI USB Gaming Mouse] on usb-0000:10:00.3-1.1.3/input0
2023-09-05T21:59:17,743521+00:00 input: SOAI USB Gaming Mouse Keyboard as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.3/7-1.1.3:1.1/0003:12C9:2003.0004/input/input4
2023-09-05T21:59:17,750420+00:00 snd_hda_codec_realtek hdaudioC1D0: autoconfig for ALC1220: line_outs=3 (0x14/0x15/0x16/0x0/0x0) type:line
2023-09-05T21:59:17,750424+00:00 snd_hda_codec_realtek hdaudioC1D0:    speaker_outs=0 (0x0/0x0/0x0/0x0/0x0)
2023-09-05T21:59:17,750426+00:00 snd_hda_codec_realtek hdaudioC1D0:    hp_outs=1 (0x1b/0x0/0x0/0x0/0x0)
2023-09-05T21:59:17,750428+00:00 snd_hda_codec_realtek hdaudioC1D0:    mono: mono_out=0x0
2023-09-05T21:59:17,750430+00:00 snd_hda_codec_realtek hdaudioC1D0:    dig-out=0x1e/0x0
2023-09-05T21:59:17,750431+00:00 snd_hda_codec_realtek hdaudioC1D0:    inputs:
2023-09-05T21:59:17,750433+00:00 snd_hda_codec_realtek hdaudioC1D0:      Front Mic=0x19
2023-09-05T21:59:17,750435+00:00 snd_hda_codec_realtek hdaudioC1D0:      Rear Mic=0x18
2023-09-05T21:59:17,750436+00:00 snd_hda_codec_realtek hdaudioC1D0:      Line=0x1a
2023-09-05T21:59:17,750439+00:00 input: HDA NVidia HDMI/DP,pcm=3 as /devices/pci0000:00/0000:00:03.1/0000:0d:00.1/sound/card0/input6
2023-09-05T21:59:17,758770+00:00 iwlwifi 0000:07:00.0: loaded firmware version 29.198743027.0 3168-29.ucode op_mode iwlmvm
2023-09-05T21:59:17,764726+00:00 input: HD-Audio Generic Front Mic as /devices/pci0000:00/0000:00:08.1/0000:10:00.4/sound/card1/input10
2023-09-05T21:59:17,795251+00:00 input: SOAI USB Gaming Mouse as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.3/7-1.1.3:1.1/0003:12C9:2003.0004/input/input5
2023-09-05T21:59:17,795279+00:00 input: HDA NVidia HDMI/DP,pcm=7 as /devices/pci0000:00/0000:00:03.1/0000:0d:00.1/sound/card0/input7
2023-09-05T21:59:17,795330+00:00 input: HDA NVidia HDMI/DP,pcm=8 as /devices/pci0000:00/0000:00:03.1/0000:0d:00.1/sound/card0/input8
2023-09-05T21:59:17,795369+00:00 hid-generic 0003:12C9:2003.0004: input,hiddev96,hidraw3: USB HID v1.10 Keyboard [SOAI USB Gaming Mouse] on usb-0000:10:00.3-1.1.3/input1
2023-09-05T21:59:17,795383+00:00 input: HD-Audio Generic Rear Mic as /devices/pci0000:00/0000:00:08.1/0000:10:00.4/sound/card1/input11
2023-09-05T21:59:17,795436+00:00 input: HD-Audio Generic Line as /devices/pci0000:00/0000:00:08.1/0000:10:00.4/sound/card1/input12
2023-09-05T21:59:17,795492+00:00 hid-generic 0003:12C9:2003.0005: hiddev97,hidraw4: USB HID v1.10 Device [SOAI USB Gaming Mouse] on usb-0000:10:00.3-1.1.3/input2
2023-09-05T21:59:17,795497+00:00 input: HDA NVidia HDMI/DP,pcm=9 as /devices/pci0000:00/0000:00:03.1/0000:0d:00.1/sound/card0/input9
2023-09-05T21:59:17,795626+00:00 input: HD-Audio Generic Line Out Front as /devices/pci0000:00/0000:00:08.1/0000:10:00.4/sound/card1/input13
2023-09-05T21:59:17,795705+00:00 input: HD-Audio Generic Line Out Surround as /devices/pci0000:00/0000:00:08.1/0000:10:00.4/sound/card1/input14
2023-09-05T21:59:17,795812+00:00 input: HD-Audio Generic Line Out CLFE as /devices/pci0000:00/0000:00:08.1/0000:10:00.4/sound/card1/input15
2023-09-05T21:59:17,801841+00:00 input: HD-Audio Generic Front Headphone as /devices/pci0000:00/0000:00:08.1/0000:10:00.4/sound/card1/input16
2023-09-05T21:59:17,823298+00:00 mousedev: PS/2 mouse device common for all mice
2023-09-05T21:59:17,833258+00:00 NVRM: loading NVIDIA UNIX x86_64 Kernel Module  535.104.05  Sat Aug 19 01:15:15 UTC 2023
2023-09-05T21:59:17,848631+00:00 iwlwifi 0000:07:00.0: Detected Intel(R) Dual Band Wireless AC 3168, REV=0x220
2023-09-05T21:59:17,848699+00:00 thermal thermal_zone0: failed to read out thermal zone (-61)
2023-09-05T21:59:17,857634+00:00 nvidia-modeset: Loading NVIDIA Kernel Mode Setting Driver for UNIX platforms  535.104.05  Sat Aug 19 00:59:57 UTC 2023
2023-09-05T21:59:17,858513+00:00 usbcore: registered new interface driver snd-usb-audio
2023-09-05T21:59:17,865860+00:00 iwlwifi 0000:07:00.0: base HW address: fc:77:74:8c:d8:3b, OTP minor version: 0x0
2023-09-05T21:59:17,882729+00:00 [drm] [nvidia-drm] [GPU ID 0x00000d00] Loading driver
2023-09-05T21:59:17,895321+00:00 ieee80211 phy0: Selected rate control algorithm 'iwl-mvm-rs'
2023-09-05T21:59:17,897768+00:00 iwlwifi 0000:07:00.0 wlp7s0: renamed from wlan0
2023-09-05T21:59:17,944476+00:00 nvidia_uvm: module uses symbols nvUvmInterfaceDisableAccessCntr from proprietary module nvidia, inheriting taint.
2023-09-05T21:59:18,281467+00:00 nvidia-uvm: Loaded the UVM driver, major device number 238.
2023-09-05T21:59:19,708331+00:00 [drm] Initialized nvidia-drm 0.0.0 20160202 for 0000:0d:00.0 on minor 0
2023-09-05T21:59:19,892177+00:00 Bluetooth: BNEP (Ethernet Emulation) ver 1.3
2023-09-05T21:59:19,892182+00:00 Bluetooth: BNEP socket layer initialized
2023-09-05T21:59:19,893168+00:00 Bluetooth: MGMT ver 1.22
2023-09-05T21:59:20,194407+00:00 systemd-journald[708]: /var/log/journal/7db9449887224d229d073f714f3c3782/user-1000.journal: Monotonic clock jumped backwards relative to last journal entry, rotating.
2023-09-05T21:59:20,949993+00:00 memfd_create() without MFD_EXEC nor MFD_NOEXEC_SEAL, pid=1331 'X'
2023-09-05T21:59:22,936784+00:00 igb 0000:09:00.0 enp9s0: igb: enp9s0 NIC Link is Up 1000 Mbps Full Duplex, Flow Control: RX
2023-09-05T21:59:23,153182+00:00 NET: Registered PF_PACKET protocol family
2023-09-05T21:59:24,422346+00:00 Bluetooth: RFCOMM TTY layer initialized
2023-09-05T21:59:24,422353+00:00 Bluetooth: RFCOMM socket layer initialized
2023-09-05T21:59:24,422358+00:00 Bluetooth: RFCOMM ver 1.11
2023-09-05T21:59:25,574135+00:00 NET: Registered PF_QIPCRTR protocol family
2023-09-05T21:59:26,375771+00:00 Initializing XFRM netlink socket
2023-09-05T22:00:33,683546+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=46383 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:00:34,734659+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=46384 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:00:35,758658+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=46385 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:00:36,782718+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=46386 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:00:37,018008+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=55037 DF PROTO=TCP SPT=58962 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:00:37,806726+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=46387 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:00:38,062603+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=55038 DF PROTO=TCP SPT=58962 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:00:38,830712+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=46388 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:00:39,086655+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=55039 DF PROTO=TCP SPT=58962 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:00:40,110666+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=55040 DF PROTO=TCP SPT=58962 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:00:40,878690+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=46389 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:00:41,134629+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=55041 DF PROTO=TCP SPT=58962 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:00:42,158549+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=55042 DF PROTO=TCP SPT=58962 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:02:38,825508+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=44966 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:02:39,853313+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=44967 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:02:40,877439+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=44968 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:02:41,901190+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=44969 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:02:42,159486+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=30105 DF PROTO=TCP SPT=53562 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:02:42,925288+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=44970 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:02:43,181230+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=30106 DF PROTO=TCP SPT=53562 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:02:43,949257+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=44971 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:02:44,205274+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=30107 DF PROTO=TCP SPT=53562 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:02:45,229272+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=30108 DF PROTO=TCP SPT=53562 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:02:45,997155+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=44972 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:02:46,253159+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=30109 DF PROTO=TCP SPT=53562 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:02:47,277208+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=30110 DF PROTO=TCP SPT=53562 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:05:54,030789+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=49343 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:05:55,051431+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=49344 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:05:56,075436+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=49345 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:05:57,099407+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=49346 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:05:57,364171+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=47817 DF PROTO=TCP SPT=50276 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:05:58,123384+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=49347 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:05:58,379306+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=47818 DF PROTO=TCP SPT=50276 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:05:59,147349+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=49348 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:05:59,403321+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=47819 DF PROTO=TCP SPT=50276 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:06:00,427385+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=47820 DF PROTO=TCP SPT=50276 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:06:01,195350+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=49349 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:06:01,451344+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=47821 DF PROTO=TCP SPT=50276 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:06:02,475322+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=47822 DF PROTO=TCP SPT=50276 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:10:09,103296+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=61701 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:10:10,152243+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=61702 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:10:11,176148+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=61703 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:10:12,200125+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=61704 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:10:12,436684+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=22058 DF PROTO=TCP SPT=53964 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:10:13,224109+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=61705 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:10:13,480051+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=22059 DF PROTO=TCP SPT=53964 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:10:14,248147+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=61706 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:10:14,505035+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=22060 DF PROTO=TCP SPT=53964 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:10:15,528028+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=22061 DF PROTO=TCP SPT=53964 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:10:16,296063+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=61707 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:10:16,552001+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=22062 DF PROTO=TCP SPT=53964 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:10:17,576030+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=22063 DF PROTO=TCP SPT=53964 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:12:15,024011+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=34503 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:12:16,038715+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=34504 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:12:17,062675+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=34505 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:12:18,086709+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=34506 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:12:18,359222+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=15532 DF PROTO=TCP SPT=42398 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:12:19,110680+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=34507 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:12:19,366589+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=15533 DF PROTO=TCP SPT=42398 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:12:20,134592+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=34508 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:12:20,390577+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=15534 DF PROTO=TCP SPT=42398 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:12:21,414682+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=15535 DF PROTO=TCP SPT=42398 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:12:22,183604+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=34509 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:12:22,438585+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=15536 DF PROTO=TCP SPT=42398 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:12:23,463555+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=15537 DF PROTO=TCP SPT=42398 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:17:35,882400+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=12924 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:17:36,931584+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=12925 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:17:37,955556+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=12926 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:17:38,979545+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=12927 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:17:39,215636+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=22726 DF PROTO=TCP SPT=50898 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:17:40,004541+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=12928 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:17:40,259492+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=22727 DF PROTO=TCP SPT=50898 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:17:41,027530+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=12929 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:17:41,283493+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=22728 DF PROTO=TCP SPT=50898 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:17:42,307476+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=22729 DF PROTO=TCP SPT=50898 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:17:43,075512+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=12930 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:17:43,331455+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=22730 DF PROTO=TCP SPT=50898 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:17:44,355440+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=22731 DF PROTO=TCP SPT=50898 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:19:45,894481+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=35758 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:19:46,915150+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=35759 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:19:47,938215+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=35760 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:19:48,962146+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=35761 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:19:49,228459+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=31072 DF PROTO=TCP SPT=37038 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:19:49,986136+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=35762 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:19:50,242078+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=31073 DF PROTO=TCP SPT=37038 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:19:51,010053+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=35763 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:19:51,266015+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=31074 DF PROTO=TCP SPT=37038 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:19:52,290104+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=31075 DF PROTO=TCP SPT=37038 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:19:53,058082+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=35764 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:19:53,314003+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=31076 DF PROTO=TCP SPT=37038 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:19:54,338071+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=31077 DF PROTO=TCP SPT=37038 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:24:00,134536+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=57492 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:24:01,183667+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=57493 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:24:02,207671+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=57494 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:24:03,231689+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=57495 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:24:03,467915+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=57442 DF PROTO=TCP SPT=42506 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:24:04,255669+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=57496 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:24:04,511583+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=57443 DF PROTO=TCP SPT=42506 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:24:05,279634+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=57497 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:24:05,535613+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=57444 DF PROTO=TCP SPT=42506 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:24:06,559563+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=57445 DF PROTO=TCP SPT=42506 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:24:07,327715+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=57498 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:24:07,583560+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=57446 DF PROTO=TCP SPT=42506 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:24:08,607580+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=57447 DF PROTO=TCP SPT=42506 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:26:05,168556+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=9901 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:26:06,174562+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=9902 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:26:07,198521+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=9903 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:26:08,222521+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=9904 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:26:08,502270+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=11358 DF PROTO=TCP SPT=43722 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:26:09,246539+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=9905 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:26:09,502477+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=11359 DF PROTO=TCP SPT=43722 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:26:10,270518+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=9906 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:26:10,526495+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=11360 DF PROTO=TCP SPT=43722 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:26:11,550490+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=11361 DF PROTO=TCP SPT=43722 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:26:12,318516+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=9907 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:26:12,574419+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=11362 DF PROTO=TCP SPT=43722 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:26:13,598438+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=11363 DF PROTO=TCP SPT=43722 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:28:12,693028+00:00 usb 7-1.1.1.4: new full-speed USB device number 9 using xhci_hcd
2023-09-05T22:28:12,907011+00:00 usb 7-1.1.1.4: New USB device found, idVendor=258a, idProduct=0059, bcdDevice=10.21
2023-09-05T22:28:12,907019+00:00 usb 7-1.1.1.4: New USB device strings: Mfr=1, Product=2, SerialNumber=0
2023-09-05T22:28:12,907022+00:00 usb 7-1.1.1.4: Product: RK Bluetooth Keyboar
2023-09-05T22:28:12,907024+00:00 usb 7-1.1.1.4: Manufacturer: SINO WEALTH
2023-09-05T22:28:12,998184+00:00 input: SINO WEALTH RK Bluetooth Keyboar as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.1/7-1.1.1.4/7-1.1.1.4:1.0/0003:258A:0059.0006/input/input17
2023-09-05T22:28:13,050164+00:00 hid-generic 0003:258A:0059.0006: input,hidraw5: USB HID v1.11 Keyboard [SINO WEALTH RK Bluetooth Keyboar] on usb-0000:10:00.3-1.1.1.4/input0
2023-09-05T22:28:13,056209+00:00 input: SINO WEALTH RK Bluetooth Keyboar System Control as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.1/7-1.1.1.4/7-1.1.1.4:1.1/0003:258A:0059.0007/input/input18
2023-09-05T22:28:13,108135+00:00 input: SINO WEALTH RK Bluetooth Keyboar Consumer Control as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.1/7-1.1.1.4/7-1.1.1.4:1.1/0003:258A:0059.0007/input/input19
2023-09-05T22:28:13,108211+00:00 input: SINO WEALTH RK Bluetooth Keyboar Keyboard as /devices/pci0000:00/0000:00:08.1/0000:10:00.3/usb7/7-1/7-1.1/7-1.1.1/7-1.1.1.4/7-1.1.1.4:1.1/0003:258A:0059.0007/input/input20
2023-09-05T22:28:13,108323+00:00 hid-generic 0003:258A:0059.0007: input,hiddev98,hidraw6: USB HID v1.11 Keyboard [SINO WEALTH RK Bluetooth Keyboar] on usb-0000:10:00.3-1.1.1.4/input1
2023-09-05T22:28:32,742575+00:00 docker0: port 1(veth954905c) entered blocking state
2023-09-05T22:28:32,742578+00:00 docker0: port 1(veth954905c) entered disabled state
2023-09-05T22:28:32,742589+00:00 veth954905c: entered allmulticast mode
2023-09-05T22:28:32,742632+00:00 veth954905c: entered promiscuous mode
2023-09-05T22:28:32,918094+00:00 eth0: renamed from veth70a3478
2023-09-05T22:28:32,924121+00:00 docker0: port 1(veth954905c) entered blocking state
2023-09-05T22:28:32,924126+00:00 docker0: port 1(veth954905c) entered forwarding state
2023-09-05T22:29:18,740689+00:00 eth0: renamed from tmp15179
2023-09-05T22:29:18,764732+00:00 eth0: renamed from tmp02ac0
2023-09-05T22:29:18,821745+00:00 eth0: renamed from tmp8e801
2023-09-05T22:29:18,834686+00:00 eth0: renamed from tmp975df
2023-09-05T22:29:18,888580+00:00 eth0: renamed from tmpad95a
2023-09-05T22:29:18,932598+00:00 eth0: renamed from tmp9b722
2023-09-05T22:29:18,944529+00:00 eth0: renamed from tmp0946b
2023-09-05T22:29:18,966574+00:00 eth0: renamed from tmp486bb
2023-09-05T22:29:18,972763+00:00 eth0: renamed from tmpd9b78
2023-09-05T22:29:18,982685+00:00 eth0: renamed from tmpe18ef
2023-09-05T22:29:18,989700+00:00 eth0: renamed from tmpf986f
2023-09-05T22:29:19,008821+00:00 eth0: renamed from tmpd3e52
2023-09-05T22:29:20,160211+00:00 eth0: Caught tx_queue_len zero misconfig
2023-09-05T22:29:20,205460+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=24952 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:29:21,244752+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=24953 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:29:22,268704+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=24954 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:29:23,292748+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=24955 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:29:23,538822+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=60610 DF PROTO=TCP SPT=40470 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:29:24,316698+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=24956 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:29:24,572688+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=60611 DF PROTO=TCP SPT=40470 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:29:25,340621+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=24957 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:29:25,596636+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=60612 DF PROTO=TCP SPT=40470 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:29:26,620720+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=60613 DF PROTO=TCP SPT=40470 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:29:27,388630+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=24958 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:29:27,644586+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=60614 DF PROTO=TCP SPT=40470 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:29:28,668650+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=60615 DF PROTO=TCP SPT=40470 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:31:36,985617+00:00 eth0: renamed from tmp87e65
2023-09-05T22:31:37,012572+00:00 eth0: renamed from tmp2bc14
2023-09-05T22:31:37,062723+00:00 eth0: renamed from tmpe55c9
2023-09-05T22:31:37,098723+00:00 eth0: renamed from tmp06b7d
2023-09-05T22:31:37,121552+00:00 eth0: renamed from tmpb7b6a
2023-09-05T22:31:37,148666+00:00 eth0: renamed from tmpb9910
2023-09-05T22:31:37,175850+00:00 eth0: renamed from tmp97825
2023-09-05T22:31:37,280961+00:00 eth0: renamed from tmp15e1f
2023-09-05T22:31:37,291408+00:00 eth0: renamed from tmp80207
2023-09-05T22:31:37,301426+00:00 eth0: renamed from tmp6427c
2023-09-05T22:31:37,310406+00:00 eth0: renamed from tmp28ef7
2023-09-05T22:31:37,318753+00:00 eth0: renamed from tmp4083c
2023-09-05T22:31:37,360433+00:00 eth0: renamed from tmpd06d1
2023-09-05T22:31:37,368398+00:00 eth0: renamed from tmp109a3
2023-09-05T22:31:37,835495+00:00 eth0: renamed from tmp5b848
2023-09-05T22:31:37,865463+00:00 eth0: renamed from tmpbe53e
2023-09-05T22:31:37,973468+00:00 eth0: renamed from tmpa366f
2023-09-05T22:31:39,337461+00:00 eth0: renamed from tmp8b026
2023-09-05T22:31:52,818393+00:00 eth0: renamed from tmpdaf2c
2023-09-05T22:31:53,003379+00:00 eth0: renamed from tmp1faff
2023-09-05T22:31:59,212281+00:00 eth0: renamed from tmp1c07f
2023-09-05T22:32:09,196215+00:00 eth0: renamed from tmp9c7f0
2023-09-05T22:33:36,163101+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=2114 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:33:37,178574+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=2115 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:33:38,202536+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=2116 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:33:39,227558+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=2117 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:33:39,497617+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=957 DF PROTO=TCP SPT=36800 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:33:40,250541+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=2118 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:33:40,506554+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=958 DF PROTO=TCP SPT=36800 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:33:41,274537+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=2119 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:33:41,530490+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=959 DF PROTO=TCP SPT=36800 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:33:42,554480+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=960 DF PROTO=TCP SPT=36800 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:33:43,322489+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=2120 DF PROTO=TCP SPT=22000 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:33:43,578429+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=961 DF PROTO=TCP SPT=36800 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:33:44,602465+00:00 refused connection: IN=enp9s0 OUT= MAC=70:85:c2:b9:65:7d:f4:e5:f2:54:e9:a4:08:00 SRC=178.36.42.56 DST=192.168.100.12 LEN=60 TOS=0x00 PREC=0x00 TTL=63 ID=962 DF PROTO=TCP SPT=36800 DPT=22000 WINDOW=64240 RES=0x00 SYN URGP=0 
2023-09-05T22:59:53,602242+00:00 docker0: port 1(veth954905c) entered disabled state
2023-09-05T22:59:53,602302+00:00 veth70a3478: renamed from eth0
2023-09-05T22:59:53,635871+00:00 docker0: port 1(veth954905c) entered disabled state
2023-09-05T22:59:53,636232+00:00 veth954905c (unregistering): left allmulticast mode
2023-09-05T22:59:53,636234+00:00 veth954905c (unregistering): left promiscuous mode
2023-09-05T22:59:53,636237+00:00 docker0: port 1(veth954905c) entered disabled state
2023-09-05T23:00:05,897828+00:00 docker0: port 1(veth91ea68f) entered blocking state
2023-09-05T23:00:05,897833+00:00 docker0: port 1(veth91ea68f) entered disabled state
2023-09-05T23:00:05,897841+00:00 veth91ea68f: entered allmulticast mode
2023-09-05T23:00:05,897900+00:00 veth91ea68f: entered promiscuous mode
2023-09-05T23:00:05,897996+00:00 docker0: port 1(veth91ea68f) entered blocking state
2023-09-05T23:00:05,897999+00:00 docker0: port 1(veth91ea68f) entered forwarding state
2023-09-05T23:00:05,898182+00:00 docker0: port 1(veth91ea68f) entered disabled state
2023-09-05T23:00:06,082918+00:00 eth0: renamed from veth6f7f748
2023-09-05T23:00:06,088953+00:00 docker0: port 1(veth91ea68f) entered blocking state
2023-09-05T23:00:06,088958+00:00 docker0: port 1(veth91ea68f) entered forwarding state
2023-09-05T23:00:57,685264+00:00 eth0: Caught tx_queue_len zero misconfig
2023-09-05T23:00:58,286782+00:00 eth0: renamed from tmp1be7a
2023-09-05T23:00:58,329536+00:00 eth0: renamed from tmp2aadc
2023-09-05T23:00:58,338835+00:00 eth0: renamed from tmp44f35
2023-09-05T23:00:58,372267+00:00 eth0: renamed from tmp0ad3f
2023-09-05T23:00:58,410663+00:00 eth0: renamed from tmpdd768
2023-09-05T23:00:58,439603+00:00 eth0: renamed from tmpef6c8
2023-09-05T23:00:58,465380+00:00 eth0: renamed from tmp16052
2023-09-05T23:00:58,483647+00:00 eth0: renamed from tmp26a28
2023-09-05T23:00:58,513091+00:00 eth0: renamed from tmp0ff00
2023-09-05T23:00:58,554444+00:00 eth0: renamed from tmpcaa5e
2023-09-05T23:00:58,590535+00:00 eth0: renamed from tmp1b231
2023-09-05T23:00:58,603443+00:00 eth0: renamed from tmpdb89a
2023-09-05T23:04:43,683629+00:00 eth0: renamed from tmp3a458
2023-09-05T23:04:43,787766+00:00 eth0: renamed from tmpf462c
2023-09-05T23:04:43,857797+00:00 eth0: renamed from tmp17660
2023-09-05T23:04:43,910604+00:00 eth0: renamed from tmp5e648
2023-09-05T23:04:43,917189+00:00 eth0: renamed from tmpc4854
2023-09-05T23:04:43,925141+00:00 eth0: renamed from tmpf60cc
2023-09-05T23:04:43,959953+00:00 eth0: renamed from tmpd4b3c
2023-09-05T23:04:43,983900+00:00 eth0: renamed from tmp1ba52
2023-09-05T23:04:44,012627+00:00 eth0: renamed from tmpc4f5b
2023-09-05T23:04:44,042724+00:00 eth0: renamed from tmpd2d4d
2023-09-05T23:04:44,090652+00:00 eth0: renamed from tmp7ae36
2023-09-05T23:04:44,100538+00:00 eth0: renamed from tmpde4fd
2023-09-05T23:04:44,148650+00:00 eth0: renamed from tmpe8ea9
2023-09-05T23:04:44,436660+00:00 eth0: renamed from tmp71a4c
2023-09-05T23:04:44,916726+00:00 eth0: renamed from tmpbf356
2023-09-05T23:04:45,342886+00:00 eth0: renamed from tmpac649
2023-09-05T23:04:45,375610+00:00 eth0: renamed from tmp35c88
2023-09-05T23:04:46,607664+00:00 eth0: renamed from tmpb23b4
2023-09-05T23:04:57,404562+00:00 eth0: renamed from tmp91bfb
2023-09-05T23:05:09,114455+00:00 eth0: renamed from tmpc18c0
2023-09-05T23:05:15,785369+00:00 eth0: renamed from tmpb5ad2
2023-09-05T23:05:16,636345+00:00 eth0: renamed from tmp63cee
2023-09-05T23:07:28,092309+00:00 docker0: port 1(veth91ea68f) entered disabled state
2023-09-05T23:07:28,092375+00:00 veth6f7f748: renamed from eth0
2023-09-05T23:07:28,124871+00:00 docker0: port 1(veth91ea68f) entered disabled state
2023-09-05T23:07:28,125340+00:00 veth91ea68f (unregistering): left allmulticast mode
2023-09-05T23:07:28,125343+00:00 veth91ea68f (unregistering): left promiscuous mode
2023-09-05T23:07:28,125345+00:00 docker0: port 1(veth91ea68f) entered disabled state
2023-09-05T23:07:31,485682+00:00 docker0: port 1(vethb77dfda) entered blocking state
2023-09-05T23:07:31,485687+00:00 docker0: port 1(vethb77dfda) entered disabled state
2023-09-05T23:07:31,485701+00:00 vethb77dfda: entered allmulticast mode
2023-09-05T23:07:31,485778+00:00 vethb77dfda: entered promiscuous mode
2023-09-05T23:07:31,673156+00:00 eth0: renamed from vethf86146f
2023-09-05T23:07:31,681229+00:00 docker0: port 1(vethb77dfda) entered blocking state
2023-09-05T23:07:31,681234+00:00 docker0: port 1(vethb77dfda) entered forwarding state
2023-09-05T23:08:19,224557+00:00 eth0: renamed from tmpef155
2023-09-05T23:08:19,279571+00:00 eth0: renamed from tmpdfd8a
2023-09-05T23:08:19,310586+00:00 eth0: renamed from tmpcc622
2023-09-05T23:08:19,318508+00:00 eth0: renamed from tmped937
2023-09-05T23:08:19,327589+00:00 eth0: renamed from tmp08cb4
2023-09-05T23:08:19,628779+00:00 eth0: renamed from tmp18f58
2023-09-05T23:08:19,654980+00:00 eth0: renamed from tmp0bdd1
2023-09-05T23:08:19,686779+00:00 eth0: renamed from tmp7855d
2023-09-05T23:08:19,741623+00:00 eth0: renamed from tmpb59f6
2023-09-05T23:08:19,753673+00:00 eth0: renamed from tmp705e5
2023-09-05T23:08:19,795633+00:00 eth0: renamed from tmp0d580
2023-09-05T23:08:19,806539+00:00 eth0: renamed from tmp2bd1d
2023-09-05T23:08:20,988096+00:00 eth0: Caught tx_queue_len zero misconfig
2023-09-05T23:09:27,685017+00:00 eth0: renamed from tmp955ac
2023-09-05T23:09:27,711874+00:00 eth0: renamed from tmp23ff8
2023-09-05T23:09:27,756841+00:00 eth0: renamed from tmp059ef
2023-09-05T23:09:27,806953+00:00 eth0: renamed from tmp3bcf1
2023-09-05T23:09:27,841818+00:00 eth0: renamed from tmpea1fa
2023-09-05T23:09:27,871363+00:00 eth0: renamed from tmp728d3
2023-09-05T23:09:27,898012+00:00 eth0: renamed from tmpd0439
2023-09-05T23:09:27,920250+00:00 eth0: renamed from tmp5d5f3
2023-09-05T23:09:27,957857+00:00 eth0: renamed from tmpcc53d
2023-09-05T23:09:27,966946+00:00 eth0: renamed from tmpacc98
2023-09-05T23:09:28,004866+00:00 eth0: renamed from tmp75c3e
2023-09-05T23:09:28,015672+00:00 eth0: renamed from tmp33516
2023-09-05T23:09:28,041436+00:00 eth0: renamed from tmp2971d
2023-09-05T23:09:28,068851+00:00 eth0: renamed from tmpb848d
2023-09-05T23:09:28,239855+00:00 eth0: renamed from tmp5ab51
2023-09-05T23:09:28,376943+00:00 eth0: renamed from tmpfaf66
2023-09-05T23:09:28,445839+00:00 eth0: renamed from tmp423b9
2023-09-05T23:09:29,154864+00:00 eth0: renamed from tmp4483c
2023-09-05T23:09:41,571677+00:00 eth0: renamed from tmpd7b8b
2023-09-05T23:09:42,477663+00:00 eth0: renamed from tmpee941
2023-09-05T23:09:48,161640+00:00 eth0: renamed from tmpf64c1
2023-09-05T23:09:58,990444+00:00 eth0: renamed from tmp47db9
2023-09-05T23:44:20,121350+00:00 docker0: port 1(vethb77dfda) entered disabled state
2023-09-05T23:44:20,121401+00:00 vethf86146f: renamed from eth0
2023-09-05T23:44:20,147649+00:00 docker0: port 1(vethb77dfda) entered disabled state
2023-09-05T23:44:20,148125+00:00 vethb77dfda (unregistering): left allmulticast mode
2023-09-05T23:44:20,148128+00:00 vethb77dfda (unregistering): left promiscuous mode
2023-09-05T23:44:20,148130+00:00 docker0: port 1(vethb77dfda) entered disabled state
2023-09-05T23:44:24,483400+00:00 docker0: port 1(veth2ad3690) entered blocking state
2023-09-05T23:44:24,483406+00:00 docker0: port 1(veth2ad3690) entered disabled state
2023-09-05T23:44:24,483415+00:00 veth2ad3690: entered allmulticast mode
2023-09-05T23:44:24,483481+00:00 veth2ad3690: entered promiscuous mode
2023-09-05T23:44:24,483578+00:00 docker0: port 1(veth2ad3690) entered blocking state
2023-09-05T23:44:24,483581+00:00 docker0: port 1(veth2ad3690) entered forwarding state
2023-09-05T23:44:24,483685+00:00 docker0: port 1(veth2ad3690) entered disabled state
2023-09-05T23:44:24,668818+00:00 eth0: renamed from veth39efbb6
2023-09-05T23:44:24,682886+00:00 docker0: port 1(veth2ad3690) entered blocking state
2023-09-05T23:44:24,682889+00:00 docker0: port 1(veth2ad3690) entered forwarding state
2023-09-05T23:45:12,385239+00:00 eth0: renamed from tmp76fc1
2023-09-05T23:45:12,454248+00:00 eth0: renamed from tmp9b656
2023-09-05T23:45:12,484263+00:00 eth0: renamed from tmp28532
2023-09-05T23:45:12,527459+00:00 eth0: renamed from tmp6fc56
2023-09-05T23:45:12,538084+00:00 eth0: renamed from tmpd5cc2
2023-09-05T23:45:12,643161+00:00 eth0: renamed from tmpdba36
2023-09-05T23:45:12,651149+00:00 eth0: renamed from tmp8c8f5
2023-09-05T23:45:12,660112+00:00 eth0: renamed from tmp320b1
2023-09-05T23:45:12,669070+00:00 eth0: renamed from tmp77bc1
2023-09-05T23:45:12,677084+00:00 eth0: renamed from tmpad55d
2023-09-05T23:45:12,683076+00:00 eth0: renamed from tmp0ec2c
2023-09-05T23:45:12,721395+00:00 eth0: renamed from tmp165bd
2023-09-05T23:45:13,987538+00:00 eth0: Caught tx_queue_len zero misconfig
2023-09-05T23:46:22,605491+00:00 eth0: renamed from tmp47983
2023-09-05T23:46:22,642399+00:00 eth0: renamed from tmp678dc
2023-09-05T23:46:22,673583+00:00 eth0: renamed from tmpea5fc
2023-09-05T23:46:22,700667+00:00 eth0: renamed from tmp51e44
2023-09-05T23:46:22,721381+00:00 eth0: renamed from tmpf01af
2023-09-05T23:46:22,745370+00:00 eth0: renamed from tmp3ae90
2023-09-05T23:46:22,988394+00:00 eth0: renamed from tmpccae7
2023-09-05T23:46:23,324367+00:00 eth0: renamed from tmpf6041
2023-09-05T23:46:23,449453+00:00 eth0: renamed from tmp3f431
2023-09-05T23:46:23,936380+00:00 eth0: renamed from tmp9963e
2023-09-05T23:46:23,964324+00:00 eth0: renamed from tmpac274
2023-09-05T23:46:24,018314+00:00 eth0: renamed from tmpf1635
2023-09-05T23:46:24,073481+00:00 eth0: renamed from tmpabbbe
2023-09-05T23:46:24,120665+00:00 eth0: renamed from tmp6c9df
2023-09-05T23:46:24,184187+00:00 eth0: renamed from tmp0c002
2023-09-05T23:46:24,194252+00:00 eth0: renamed from tmp5720a
2023-09-05T23:46:24,209157+00:00 eth0: renamed from tmp4abeb
2023-09-05T23:46:25,459325+00:00 eth0: renamed from tmp6555b
2023-09-05T23:46:39,504167+00:00 eth0: renamed from tmpce259
2023-09-05T23:46:40,765119+00:00 eth0: renamed from tmpe165a
2023-09-05T23:46:41,840180+00:00 eth0: renamed from tmpfd812
2023-09-05T23:46:55,397943+00:00 eth0: renamed from tmpa39e1
2023-09-05T23:47:18,665374+00:00 docker0: port 1(veth2ad3690) entered disabled state
2023-09-05T23:47:18,665460+00:00 veth39efbb6: renamed from eth0
2023-09-05T23:47:18,696531+00:00 docker0: port 1(veth2ad3690) entered disabled state
2023-09-05T23:47:18,697068+00:00 veth2ad3690 (unregistering): left allmulticast mode
2023-09-05T23:47:18,697071+00:00 veth2ad3690 (unregistering): left promiscuous mode
2023-09-05T23:47:18,697073+00:00 docker0: port 1(veth2ad3690) entered disabled state
2023-09-05T23:47:19,035860+00:00 docker0: port 1(veth344c8ea) entered blocking state
2023-09-05T23:47:19,035865+00:00 docker0: port 1(veth344c8ea) entered disabled state
2023-09-05T23:47:19,035873+00:00 veth344c8ea: entered allmulticast mode
2023-09-05T23:47:19,035931+00:00 veth344c8ea: entered promiscuous mode
2023-09-05T23:47:19,036062+00:00 docker0: port 1(veth344c8ea) entered blocking state
2023-09-05T23:47:19,036066+00:00 docker0: port 1(veth344c8ea) entered forwarding state
2023-09-05T23:47:19,036263+00:00 docker0: port 1(veth344c8ea) entered disabled state
2023-09-05T23:47:19,223591+00:00 eth0: renamed from veth5867ea8
2023-09-05T23:47:19,234644+00:00 docker0: port 1(veth344c8ea) entered blocking state
2023-09-05T23:47:19,234648+00:00 docker0: port 1(veth344c8ea) entered forwarding state
2023-09-05T23:48:07,108385+00:00 eth0: renamed from tmp7c66f
2023-09-05T23:48:07,206074+00:00 eth0: renamed from tmpd05a1
2023-09-05T23:48:07,216115+00:00 eth0: renamed from tmp1dc13
2023-09-05T23:48:07,221954+00:00 eth0: renamed from tmpaf1e4
2023-09-05T23:48:07,235083+00:00 eth0: renamed from tmp8afb6
2023-09-05T23:48:07,288028+00:00 eth0: renamed from tmp5c18f
2023-09-05T23:48:07,329023+00:00 eth0: renamed from tmp892ee
2023-09-05T23:48:07,342128+00:00 eth0: renamed from tmpecb59
2023-09-05T23:48:07,350918+00:00 eth0: renamed from tmp65123
2023-09-05T23:48:07,546056+00:00 eth0: renamed from tmp8782e
2023-09-05T23:48:07,582129+00:00 eth0: renamed from tmp566ba
2023-09-05T23:48:07,612128+00:00 eth0: renamed from tmpc4235
2023-09-05T23:48:08,635441+00:00 eth0: Caught tx_queue_len zero misconfig
2023-09-05T23:48:49,992873+00:00 docker0: port 1(veth344c8ea) entered disabled state
2023-09-05T23:48:49,992953+00:00 veth5867ea8: renamed from eth0
2023-09-05T23:48:50,032482+00:00 docker0: port 1(veth344c8ea) entered disabled state
2023-09-05T23:48:50,032845+00:00 veth344c8ea (unregistering): left allmulticast mode
2023-09-05T23:48:50,032847+00:00 veth344c8ea (unregistering): left promiscuous mode
2023-09-05T23:48:50,032849+00:00 docker0: port 1(veth344c8ea) entered disabled state
2023-09-05T23:48:50,378551+00:00 docker0: port 1(vethb26148e) entered blocking state
2023-09-05T23:48:50,378555+00:00 docker0: port 1(vethb26148e) entered disabled state
2023-09-05T23:48:50,378566+00:00 vethb26148e: entered allmulticast mode
2023-09-05T23:48:50,378610+00:00 vethb26148e: entered promiscuous mode
2023-09-05T23:48:50,378724+00:00 docker0: port 1(vethb26148e) entered blocking state
2023-09-05T23:48:50,378727+00:00 docker0: port 1(vethb26148e) entered forwarding state
2023-09-05T23:48:50,568491+00:00 eth0: renamed from veth77866c9
2023-09-05T23:49:44,118904+00:00 eth0: renamed from tmp86629
2023-09-05T23:49:44,161838+00:00 eth0: renamed from tmpaca0e
2023-09-05T23:49:44,187687+00:00 eth0: renamed from tmp8a070
2023-09-05T23:49:44,200043+00:00 eth0: renamed from tmpa92d2
2023-09-05T23:49:44,236943+00:00 eth0: renamed from tmp9f406
2023-09-05T23:49:44,257815+00:00 eth0: renamed from tmp76eaf
2023-09-05T23:49:44,280013+00:00 eth0: renamed from tmp6cb45
2023-09-05T23:49:44,298057+00:00 eth0: renamed from tmpc81bf
2023-09-05T23:49:44,305763+00:00 eth0: renamed from tmp6f5b1
2023-09-05T23:49:44,366030+00:00 eth0: renamed from tmp75dc5
2023-09-05T23:49:44,384044+00:00 eth0: renamed from tmp9f914
2023-09-05T23:49:44,391885+00:00 eth0: renamed from tmp57f9c
2023-09-05T23:49:45,375153+00:00 eth0: Caught tx_queue_len zero misconfig
2023-09-05T23:50:39,244307+00:00 eth0: renamed from tmpbf6d5
2023-09-05T23:50:39,284326+00:00 eth0: renamed from tmpf2857
2023-09-05T23:50:39,480793+00:00 eth0: renamed from tmp8628b
2023-09-05T23:50:39,507630+00:00 eth0: renamed from tmp8d147
2023-09-05T23:50:39,537094+00:00 eth0: renamed from tmp4b174
2023-09-05T23:50:39,564399+00:00 eth0: renamed from tmp13ce9
2023-09-05T23:50:39,605748+00:00 eth0: renamed from tmp8b477
2023-09-05T23:50:39,614399+00:00 eth0: renamed from tmp441a5
2023-09-05T23:50:39,640388+00:00 eth0: renamed from tmp8333b
2023-09-05T23:50:39,672053+00:00 eth0: renamed from tmp8f0fa
2023-09-05T23:50:39,703703+00:00 eth0: renamed from tmp89688
2023-09-05T23:50:39,729106+00:00 eth0: renamed from tmp85482
2023-09-05T23:50:39,755692+00:00 eth0: renamed from tmp2ea4e
2023-09-05T23:50:39,781413+00:00 eth0: renamed from tmp04b62
2023-09-05T23:50:39,868304+00:00 eth0: renamed from tmp33e83
2023-09-05T23:50:40,022331+00:00 eth0: renamed from tmp78b50
2023-09-05T23:50:40,070350+00:00 eth0: renamed from tmp4f00b
2023-09-05T23:50:40,847286+00:00 eth0: renamed from tmp25c86
2023-09-05T23:51:10,757978+00:00 eth0: renamed from tmp21424
2023-09-05T23:51:13,717024+00:00 eth0: renamed from tmp2db1e
2023-09-05T23:51:14,265990+00:00 eth0: renamed from tmpc0fb0
2023-09-05T23:51:20,205856+00:00 eth0: renamed from tmp064cd
2023-09-06T00:07:15,960015+00:00 eth0: renamed from tmp8e257
2023-09-06T00:28:54,173762+00:00 veth77866c9: renamed from eth0
2023-09-06T00:28:54,195680+00:00 docker0: port 1(vethb26148e) entered disabled state
2023-09-06T00:28:54,207035+00:00 docker0: port 1(vethb26148e) entered disabled state
2023-09-06T00:28:54,207538+00:00 vethb26148e (unregistering): left allmulticast mode
2023-09-06T00:28:54,207541+00:00 vethb26148e (unregistering): left promiscuous mode
2023-09-06T00:28:54,207543+00:00 docker0: port 1(vethb26148e) entered disabled state
2023-09-06T00:28:59,500273+00:00 docker0: port 1(vethee49a7e) entered blocking state
2023-09-06T00:28:59,500277+00:00 docker0: port 1(vethee49a7e) entered disabled state
2023-09-06T00:28:59,500286+00:00 vethee49a7e: entered allmulticast mode
2023-09-06T00:28:59,500358+00:00 vethee49a7e: entered promiscuous mode
2023-09-06T00:28:59,686459+00:00 eth0: renamed from veth791d708
2023-09-06T00:28:59,704416+00:00 docker0: port 1(vethee49a7e) entered blocking state
2023-09-06T00:28:59,704419+00:00 docker0: port 1(vethee49a7e) entered forwarding state
2023-09-06T00:29:52,726242+00:00 eth0: renamed from tmpad255
2023-09-06T00:29:52,769424+00:00 eth0: renamed from tmp3e693
2023-09-06T00:29:52,793740+00:00 eth0: renamed from tmp49759
2023-09-06T00:29:52,824346+00:00 eth0: renamed from tmpf3705
2023-09-06T00:29:52,854163+00:00 eth0: renamed from tmpe7814
2023-09-06T00:29:52,891958+00:00 eth0: renamed from tmpd8826
2023-09-06T00:29:52,902503+00:00 eth0: renamed from tmp20dae
2023-09-06T00:29:52,967836+00:00 eth0: renamed from tmp71bf6
2023-09-06T00:29:52,989819+00:00 eth0: renamed from tmp9a4df
2023-09-06T00:29:53,004771+00:00 eth0: renamed from tmpbb926
2023-09-06T00:29:53,019777+00:00 eth0: renamed from tmpd4bd4
2023-09-06T00:29:53,036508+00:00 eth0: renamed from tmp835e1
2023-09-06T00:29:53,290506+00:00 eth0: Caught tx_queue_len zero misconfig
2023-09-06T00:30:52,225544+00:00 eth0: renamed from tmpb3cf1
2023-09-06T00:30:52,272863+00:00 eth0: renamed from tmpccd53
2023-09-06T00:30:52,284619+00:00 eth0: renamed from tmp9fa70
2023-09-06T00:30:52,357264+00:00 eth0: renamed from tmp2ba8e
2023-09-06T00:30:52,366219+00:00 eth0: renamed from tmp1d011
2023-09-06T00:30:52,376418+00:00 eth0: renamed from tmp75114
2023-09-06T00:30:52,391236+00:00 eth0: renamed from tmp0e74c
2023-09-06T00:30:52,648535+00:00 eth0: renamed from tmpfdea3
2023-09-06T00:30:52,741489+00:00 eth0: renamed from tmp7105d
2023-09-06T00:30:52,844927+00:00 eth0: renamed from tmpc026a
2023-09-06T00:30:52,993653+00:00 eth0: renamed from tmp8d352
2023-09-06T00:30:53,041418+00:00 eth0: renamed from tmp7bdd2
2023-09-06T00:30:53,368905+00:00 eth0: renamed from tmpca0f7
2023-09-06T00:30:53,487442+00:00 eth0: renamed from tmp99713
2023-09-06T00:30:53,529579+00:00 eth0: renamed from tmp9de02
2023-09-06T00:30:53,553430+00:00 eth0: renamed from tmpa451c
2023-09-06T00:30:53,591745+00:00 eth0: renamed from tmp6c796
2023-09-06T00:30:55,076436+00:00 eth0: renamed from tmp18e08
