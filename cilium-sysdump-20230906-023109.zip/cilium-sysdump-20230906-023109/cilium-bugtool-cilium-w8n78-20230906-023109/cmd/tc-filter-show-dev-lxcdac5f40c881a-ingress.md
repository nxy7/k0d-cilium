filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcdac5f40c881a direct-action not_in_hw id 7432 tag 4a5f4998c18584bf jited 
