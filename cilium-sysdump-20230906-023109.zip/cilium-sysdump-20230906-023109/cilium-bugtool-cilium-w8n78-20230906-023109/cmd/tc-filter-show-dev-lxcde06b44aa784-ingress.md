filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcde06b44aa784 direct-action not_in_hw id 7326 tag 814b3302dfd5c374 jited 
