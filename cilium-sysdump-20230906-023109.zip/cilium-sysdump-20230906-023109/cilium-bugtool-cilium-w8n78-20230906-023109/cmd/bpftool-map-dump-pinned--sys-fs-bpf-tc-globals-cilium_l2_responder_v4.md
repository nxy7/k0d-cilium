[{
        "key": {
            "ip4": 1809781164,
            "ifindex": 19
        },
        "value": {
            "responses_sent": 0
        }
    }
]
