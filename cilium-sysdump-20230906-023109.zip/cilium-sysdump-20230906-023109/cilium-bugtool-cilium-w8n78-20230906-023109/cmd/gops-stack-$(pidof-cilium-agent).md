goroutine 93 [running]:
runtime/pprof.writeGoroutineStacks({0x3b88080, 0xc000fbe0c0})
	/usr/local/go/src/runtime/pprof/pprof.go:703 +0x70
runtime/pprof.writeGoroutine({0x3b88080?, 0xc000fbe0c0?}, 0xc000672880?)
	/usr/local/go/src/runtime/pprof/pprof.go:692 +0x2b
runtime/pprof.(*Profile).WriteTo(0x360ff0b?, {0x3b88080?, 0xc000fbe0c0?}, 0xc?)
	/usr/local/go/src/runtime/pprof/pprof.go:329 +0x14b
github.com/google/gops/agent.handle({0x7f3b857715f0?, 0xc000fbe0c0}, {0xc00111a000?, 0x1?, 0x1?})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:200 +0xe5
github.com/google/gops/agent.listen({0x3bb3640, 0xc001a450b0})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:144 +0x1bc
created by github.com/google/gops/agent.Listen
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:122 +0x390

goroutine 1 [select, 1 minutes]:
github.com/cilium/cilium/pkg/hive.(*Hive).waitForSignalOrShutdown(0xc0003d1e00)
	/go/src/github.com/cilium/cilium/pkg/hive/hive.go:217 +0x17f
github.com/cilium/cilium/pkg/hive.(*Hive).Run(0xc0003d1e00)
	/go/src/github.com/cilium/cilium/pkg/hive/hive.go:198 +0x147
github.com/cilium/cilium/daemon/cmd.runApp(0x588ea40?, {0x35fe3fd?, 0x1?, 0x1?})
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:67 +0xe5
github.com/spf13/cobra.(*Command).execute(0x588ea40, {0xc000072050, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:944 +0x847
github.com/spf13/cobra.(*Command).ExecuteC(0x588ea40)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1068 +0x3bd
github.com/spf13/cobra.(*Command).Execute(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:992
github.com/cilium/cilium/daemon/cmd.Execute()
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:78 +0x65
main.main()
	/go/src/github.com/cilium/cilium/daemon/main.go:9 +0x17

goroutine 65 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0xc000a16900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:314 +0xa7
created by k8s.io/client-go/util/workqueue.newQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1bc

goroutine 66 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc000a16a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 84 [select, 1 minutes]:
io.(*pipe).read(0xc000f88600, {0xc00079016b, 0xfe95, 0x3b99110?})
	/usr/local/go/src/io/pipe.go:57 +0xb1
io.(*PipeReader).Read(0x0?, {0xc00079016b?, 0xc000c1af90?, 0xc000ebb9e0?})
	/usr/local/go/src/io/pipe.go:136 +0x25
bufio.(*Scanner).Scan(0xc00534ef28)
	/usr/local/go/src/bufio/scan.go:214 +0x876
github.com/sirupsen/logrus.(*Entry).writerScanner(0xc000a16060?, 0xc001402180, 0xc000fa6f70)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x11f
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x3d1

goroutine 85 [select, 1 minutes]:
io.(*pipe).read(0xc000f88660, {0xc000458000, 0x10000, 0x423325?})
	/usr/local/go/src/io/pipe.go:57 +0xb1
io.(*PipeReader).Read(0x7f3b854d33e8?, {0xc000458000?, 0x40e05d?, 0x0?})
	/usr/local/go/src/io/pipe.go:136 +0x25
bufio.(*Scanner).Scan(0xc00046ff28)
	/usr/local/go/src/bufio/scan.go:214 +0x876
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0?, 0xc001402190, 0xc000fa6f90)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x11f
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x3d1

goroutine 86 [select, 1 minutes]:
io.(*pipe).read(0xc000f886c0, {0xc00103a000, 0x10000, 0x423325?})
	/usr/local/go/src/io/pipe.go:57 +0xb1
io.(*PipeReader).Read(0x7f3b854b2180?, {0xc00103a000?, 0x40e05d?, 0x0?})
	/usr/local/go/src/io/pipe.go:136 +0x25
bufio.(*Scanner).Scan(0xc0003ddf28)
	/usr/local/go/src/bufio/scan.go:214 +0x876
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0?, 0xc0014021a0, 0xc000fa6fb0)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x11f
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x3d1

goroutine 87 [select, 1 minutes]:
io.(*pipe).read(0xc000f88720, {0xc00083e000, 0x10000, 0x423325?})
	/usr/local/go/src/io/pipe.go:57 +0xb1
io.(*PipeReader).Read(0x7f3b85447bd8?, {0xc00083e000?, 0x40e05d?, 0x0?})
	/usr/local/go/src/io/pipe.go:136 +0x25
bufio.(*Scanner).Scan(0xc000855f28)
	/usr/local/go/src/bufio/scan.go:214 +0x876
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0?, 0xc0014021b0, 0xc000fa6fd0)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0x11f
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x3d1

goroutine 37 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0006dd548, 0xa)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000851d68?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc0006dd530, {0xc002c409dc, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc002c409dc?, 0xc000851d08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7f3b855bc700, 0xc0006dd500}, {0xc002c409dc, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc001ba2030, {0xc0016aa500, 0x2000, 0x2500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000130050, 0xc002f2e600?, {0x3b9d990, 0xc00358b600})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001164000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000916080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 94 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7f3b85877e18, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc000efe000?, 0xc00046ed00?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc000efe000)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc000efe000)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*TCPListener).accept(0xc000efc048)
	/usr/local/go/src/net/tcpsock_posix.go:148 +0x25
net.(*TCPListener).Accept(0xc000efc048)
	/usr/local/go/src/net/tcpsock.go:297 +0x3d
net/http.(*Server).Serve(0xc0013ae000, {0x3bb3640, 0xc000efc048})
	/usr/local/go/src/net/http/server.go:3059 +0x385
net/http.(*Server).ListenAndServe(0xc0013ae000)
	/usr/local/go/src/net/http/server.go:2988 +0x7d
github.com/cilium/cilium/pkg/metrics.NewRegistry.func1.1()
	/go/src/github.com/cilium/cilium/pkg/metrics/registry.go:89 +0xb1
created by github.com/cilium/cilium/pkg/metrics.NewRegistry.func1
	/go/src/github.com/cilium/cilium/pkg/metrics/registry.go:87 +0xca

goroutine 29 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction.func1()
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:19 +0x67
created by github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:17 +0x9c

goroutine 963 [syscall, 1 minutes]:
os/signal.signal_recv()
	/usr/local/go/src/runtime/sigqueue.go:152 +0x2f
os/signal.loop()
	/usr/local/go/src/os/signal/signal_unix.go:23 +0x19
created by os/signal.Notify.func1.1
	/usr/local/go/src/os/signal/signal.go:151 +0x2a

goroutine 187 [chan receive]:
github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch.func1()
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:147 +0x77
created by github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:139 +0x72

goroutine 188 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0013bcf00)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 189 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0013bcfa0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 199 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0006dd500, 0xc0003b6800)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xc00139ced0?, 0xc0013b8ec0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 201 [select]:
github.com/cilium/cilium/pkg/l2announcer.(*L2Announcer).run(0xc001a7c480, {0x3bb5780, 0xc001acc420})
	/go/src/github.com/cilium/cilium/pkg/l2announcer/l2announcer.go:188 +0x4bf
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc0000ce050, {0x3bb5780, 0xc001acc420}, 0xc0011f0540?, {{{0xc0010bd3e0, 0x1, 0x1}}, {0x3be6410, 0xc00174e2a0}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:267 +0x530
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 195 [IO wait]:
internal/poll.runtime_pollWait(0x7f3b85877d28, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001a8c680?, 0xc000b5a000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001a8c680, {0xc000b5a000, 0x6a80, 0x6a80})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc001a8c680, {0xc000b5a000?, 0x6a7b?, 0xc001117b80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000425038, {0xc000b5a000?, 0xc000b5a000?, 0x5?})
	/usr/local/go/src/net/net.go:183 +0x45
crypto/tls.(*atLeastReader).Read(0xc001ba2840, {0xc000b5a000?, 0xc001ba2840?, 0x0?})
	/usr/local/go/src/crypto/tls/conn.go:788 +0x3d
bytes.(*Buffer).ReadFrom(0xc001805790, {0x3b720a0, 0xc001ba2840})
	/usr/local/go/src/bytes/buffer.go:202 +0x98
crypto/tls.(*Conn).readFromUntil(0xc001805500, {0x7f3b853e01d8?, 0xc001a451e8}, 0x6a80?)
	/usr/local/go/src/crypto/tls/conn.go:810 +0xe5
crypto/tls.(*Conn).readRecordOrCCS(0xc001805500, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:617 +0x116
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:583
crypto/tls.(*Conn).Read(0xc001805500, {0xc001ac0000, 0x1000, 0x0?})
	/usr/local/go/src/crypto/tls/conn.go:1316 +0x16f
bufio.(*Reader).Read(0xc0008576e0, {0xc0016f8660, 0x9, 0xc003c26208?})
	/usr/local/go/src/bufio/bufio.go:237 +0x1bb
io.ReadAtLeast({0x3b71ea0, 0xc0008576e0}, {0xc0016f8660, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
golang.org/x/net/http2.readFrameHeader({0xc0016f8660?, 0x9?, 0xc000000000?}, {0x3b71ea0?, 0xc0008576e0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x6e
golang.org/x/net/http2.(*Framer).ReadFrame(0xc0016f8620)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x95
golang.org/x/net/http2.(*clientConnReadLoop).run(0xc000468f98)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2251 +0x12e
golang.org/x/net/http2.(*ClientConn).readLoop(0xc0006dcf00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2146 +0x6f
created by golang.org/x/net/http2.(*Transport).newClientConn
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:818 +0xc1f

goroutine 67 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000ef85a0, {0xc00111e0c0, 0x0, 0x3805780, 0x6fc23ac00, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000304a00}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1078 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0009522e6, 0x10, 0x1a}, {0xc00094a5a0, 0x24}, 0xc0009b6f78?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 242 [select, 1 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 354 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000cfdc58, 0x85)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000c87e40?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000cfdc30, 0xc000ad4150)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000e9c1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc0014d1c20}, 0x1, 0xc001ad0180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000e9c258?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000e9c1e0, 0xc001ad0180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 993 [select, 1 minutes]:
github.com/cilium/cilium/pkg/maps/ctmap/gc.Enable.func1()
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:115 +0x3a5
created by github.com/cilium/cilium/pkg/maps/ctmap/gc.Enable
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:43 +0x20a

goroutine 1112 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7f3b857fb9b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc002d19100?, 0x5?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc002d19100)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc002d19100)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*TCPListener).accept(0xc001d83f68)
	/usr/local/go/src/net/tcpsock_posix.go:148 +0x25
net.(*TCPListener).Accept(0xc001d83f68)
	/usr/local/go/src/net/tcpsock.go:297 +0x3d
net/http.(*Server).Serve(0xc0002e6690, {0x3bb3640, 0xc001d83f68})
	/usr/local/go/src/net/http/server.go:3059 +0x385
net/http.(*Server).ListenAndServe(0xc0002e6690)
	/usr/local/go/src/net/http/server.go:2988 +0x7d
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:35
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:365 +0x2f
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:364 +0x85

goroutine 73 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001b1e0d8, 0xa)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0010331e0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001b1e0b0, 0xc000ef6e10)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000e9c0a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc000ef6ea0}, 0x1, 0xc001a81c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000e9c118?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000e9c0a0, 0xc001a81c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 39 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001e88028, 0x21)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000f1e740?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001e88000, 0xc000914a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0011da140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc000914ab0}, 0x1, 0xc001ba8420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0011da1b8?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0011da140, 0xc001ba8420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 75 [chan receive, 1 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 76 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc000916080}, {0x7f3b855bca38, 0xc001b1e0b0}, {0x3be8e60?, 0x35bf660}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001b2c0e0, {0x0?, 0x0?}, 0xc001a81c20, 0xc00111e3a0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001b2c0e0, 0xc001a81c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000ef2280?, {0x3b878e0, 0xc000304eb0}, 0x1, 0xc001a81c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001b2c0e0, 0xc001a81c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 198 [select, 1 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001b2c0e0, 0xc001a81c20, 0xc001a81e60, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 46 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000296180, 0xc001e90700)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xc0011a8120?, 0xc0000a37b8?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 622 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc001e88398, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x505167?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001e88370, 0xc000917cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0011da8c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc000f3d2c0}, 0x1, 0xc001ad1200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0011da938?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0011da8c0, 0xc001ad1200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumClusterwideEnvoyConfigInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_clusterwide_envoy_config.go:79 +0x330

goroutine 45 [select, 1 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001e8a000, 0xc001ba8420, 0xc001ba88a0, 0xc00139efa0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 42 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc000916e80}, {0x7f3b855bca38, 0xc001e88000}, {0x3be8e60?, 0x35c0560}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001e8a000, {0x0?, 0x0?}, 0xc001ba8420, 0xc001164120?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001e8a000, 0xc001ba8420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0009180c0?, {0x3b878e0, 0xc000130370}, 0x1, 0xc001ba8420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001e8a000, 0xc001ba8420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 224 [chan receive]:
github.com/cilium/cilium/pkg/bgpv1/manager.(*diffStore[...]).run(0x3bca720)
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/diffstore.go:105 +0x185
created by github.com/cilium/cilium/pkg/bgpv1/manager.(*diffStore[...]).Start
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/diffstore.go:85 +0x12a

goroutine 41 [chan receive, 1 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 228 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001b05010, 0x1a)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0006d2ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 215 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001b1e188, 0xe)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000a1b0c0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001b1e160, 0xc001b50720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000e9caa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc001b507b0}, 0x1, 0xc001b0d980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000e9cb18?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000e9caa0, 0xc001b0d980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 227 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0006d2cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 217 [chan receive, 1 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 218 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc000916940}, {0x7f3b855bca38, 0xc001b1e160}, {0x3be8e60?, 0x35c01a0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001b2c460, {0x0?, 0x0?}, 0xc001b0d980, 0xc00111e960?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001b2c460, 0xc001b0d980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000ef3500?, {0x3b878e0, 0xc000305ae0}, 0x1, 0xc001b0d980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001b2c460, 0xc001b0d980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 221 [select, 1 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001b2c460, 0xc001b0d980, 0xc001d8c120, 0xc001b617a0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 38 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00004e348, 0xd)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc00084fd68?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc00004e330, {0xc004c28a28, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc004c28a28?, 0xc00084fd08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7f3b855bc700, 0xc00004e300}, {0xc004c28a28, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc001ba2318, {0xc0002bac00, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0001300f0, 0xc0028ea900?, {0x3b9d990, 0xc001a8efc0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001164060)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000916940)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 222 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc00004e300, 0xc000166b00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0x6863530d010103b7?, 0x727241724f616d65?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 376 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0xc00046cfb8?)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x37
created by github.com/cilium/cilium/pkg/kvstore.Connected
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x72

goroutine 48 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0003d4b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 229 [select, 1 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 403 [select, 1 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 47 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0002961c8, 0x21)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000853d68?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc0002961b0, {0xc00237cb44, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc00237cb44?, 0xc000853d08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7f3b855bc700, 0xc000296180}, {0xc00237cb44, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc001ba26d8, {0xc0010d0c00, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000130780, 0xc003b3e000?, {0x3b9d990, 0xc002f4bc80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001164660)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000916e80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 241 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000916f10, 0x41)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0003d4a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 232 [chan receive]:
github.com/cilium/cilium/pkg/bgpv1/manager.(*diffStore[...]).run(0x3bca6c0)
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/diffstore.go:105 +0x185
created by github.com/cilium/cilium/pkg/bgpv1/manager.(*diffStore[...]).Start
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/diffstore.go:85 +0x12a

goroutine 398 [select]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).nodeEventLoop(0xc0016f6b00, 0xc00147e228, 0x3be5c20?)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/node.go:67 +0x13b
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).NodesInit.func1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/node.go:55 +0x1b8

goroutine 2102 [select, 1 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*buffer).Pop(0xc00152ca00)
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/buffer.go:80 +0x11e
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func3()
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:91 +0x3f
golang.org/x/sync/errgroup.(*Group).Go.func1()
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:75 +0x64
created by golang.org/x/sync/errgroup.(*Group).Go
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:72 +0xa5

goroutine 2589 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000457806, 0x10, 0x1a}, {0xc00093d2f0, 0x24}, 0x3be6020?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1118 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0015d0d80, {0xc001214a50, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002d2dae0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2533 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc00386e3c0, {0xc0007a9150, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc00386e3c0, {0xc0007a9150?, 0xc001b00870?, 0xc002379560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc00487eed0, {0xc0007a9150?, 0xc0023795d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc00487eed0}, {0xc0007a9150, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc002efefc0, {0xc0007a9150, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc0007a9140, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc0023797a8?, 0xc002efefc0, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7f3b85801a90, 0x5e20750}, 0xc0023799f8?, {0x0?, 0x0?}, {0x3472d60, 0xc0011db4a0}, 0xc000d3b0e0?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc00271e000, {0x3472d60?, 0xc0011db4a0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/route/v3.(*routeDiscoveryServiceStreamRoutesServer).Recv(0xc000c82a40)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/route/v3/rds.pb.go:365 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc002aca930?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 239 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001e2b0e0, {0xc0011684c0, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0001d4370}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 240 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x6974706972637365?, 0x4e0401000c016e6f?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xf0100b2ff01616d?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 257 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x201000101687461?, 0x24227b1e000a2122?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x6f672d7809010101?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 258 [chan receive, 1 minutes]:
github.com/cilium/workerpool.(*WorkerPool).run(0xc0001d43c0, {0x3bb56d8?, 0xc0001d4410})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:173 +0x65
created by github.com/cilium/workerpool.NewWithContext
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:68 +0x14e

goroutine 259 [select]:
github.com/cilium/cilium/pkg/node/manager.(*manager).backgroundSync(0xc00136ac80, {0x3bb56d8, 0xc0001d4410})
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:301 +0x2a5
github.com/cilium/workerpool.(*WorkerPool).run.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:181 +0x82
created by github.com/cilium/workerpool.(*WorkerPool).run
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:178 +0x4e

goroutine 260 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7f3b85877c38, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc0003faa20?, 0xc001f0fed0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0003faa20, {0xc001f0fed0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:31
os.(*File).Read(0xc0005be1a0, {0xc001f0fed0?, 0x3b64c00?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x5e
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc0001d4550)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:356 +0xdf
created by github.com/fsnotify/fsnotify.NewWatcher
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:150 +0x1b0

goroutine 261 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001e38120, {0xc0011686d0, 0x0, 0x3805780, 0x0, 0x0, 0x2540be400, 0x0, {0x3bb56d8, 0xc0001d45f0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 262 [select, 1 minutes]:
github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).watchForDirectoryChanges(0xc0011f0540)
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:233 +0x117
created by github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).Start
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:207 +0x3be

goroutine 263 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7f3b85877b48, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001e3c000?, 0x0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001e3c000)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc001e3c000)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*UnixListener).accept(0x407565?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x1c
net.(*UnixListener).Accept(0xc001e28d20)
	/usr/local/go/src/net/unixsock.go:260 +0x3d
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2(0xc00111f340, {0x3bb56d8?, 0xc00063db30}, 0x0?)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:83 +0xef
created by github.com/cilium/cilium/pkg/monitor/agent.ServeMonitorAPI
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:69 +0x19f

goroutine 264 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2.func1()
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:78 +0x32
created by github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:77 +0xb4

goroutine 202 [select, 1 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobTimer).start(0xc0000ce0f0, {0x3bb5780, 0xc001acc480}, 0xc001e2b0e0?, {{{0xc0010bd3e0, 0x1, 0x1}}, {0x3be6410, 0xc00174e2a0}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:384 +0x3c5
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 273 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc001f82028, 0x1)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc00138a3c0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001f82000, 0xc001f800f0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0011ea0a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc001f80180}, 0x1, 0xc001d8daa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0011ea118?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0011ea0a0, 0xc001d8daa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 325 [select, 1 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 275 [chan receive, 1 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 276 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc001e5e240}, {0x7f3b855bca38, 0xc001f82000}, {0x3be8e60?, 0x358e620}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001f8e000, {0x0?, 0x0?}, 0xc001d8daa0, 0xc0012c8080?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001f8e000, 0xc001d8daa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001f92040?, {0x3b878e0, 0xc0002780a0}, 0x1, 0xc001d8daa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001f8e000, 0xc001d8daa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 203 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7f3b85877a58, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001a8cc80?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001a8cc80)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc001a8cc80)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*UnixListener).accept(0x444640?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x1c
net.(*UnixListener).Accept(0xc001acc5a0)
	/usr/local/go/src/net/unixsock.go:260 +0x3d
google.golang.org/grpc.(*Server).Serve(0xc001171e00, {0x3bb3670?, 0xc001acc5a0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:821 +0x475
github.com/cilium/cilium/pkg/envoy.startXDSGRPCServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:56 +0xb1
created by github.com/cilium/cilium/pkg/envoy.startXDSGRPCServer
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:54 +0x198

goroutine 265 [select, 1 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001f8e000, 0xc001d8daa0, 0xc001d8dd40, 0xc00202a6c0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 204 [IO wait]:
internal/poll.runtime_pollWait(0x7f3b85877968, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001a8ce00?, 0x47b945?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001a8ce00)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc001a8ce00)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*UnixListener).accept(0x444640?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x1c
net.(*UnixListener).AcceptUnix(0xc001acd230)
	/usr/local/go/src/net/unixsock.go:247 +0x3d
github.com/cilium/cilium/pkg/envoy.StartAccessLogServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:69 +0x59
created by github.com/cilium/cilium/pkg/envoy.StartAccessLogServer
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:65 +0x514

goroutine 205 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/envoy.StartAccessLogServer.func2()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:87 +0x35
created by github.com/cilium/cilium/pkg/envoy.StartAccessLogServer
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:86 +0x590

goroutine 208 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc001a45ab8?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 266 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc00004e480, 0xc000167200)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xc00139ced0?, 0xc0013b8ec0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 289 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000d303c0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 290 [select]:
github.com/cilium/cilium/pkg/cgroups/manager.(*CgroupManager).processPodEvents(0xc000122f00)
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:243 +0x95
created by github.com/cilium/cilium/pkg/cgroups/manager.initManager
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:213 +0x1d6

goroutine 291 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002002a20, {0x3805ba0, 0x0, 0x3805780, 0x12a05f200, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000123540}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 292 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002003200, {0xc000f90f50, 0x0, 0x3805780, 0x0, 0xdf8475800, 0x0, 0x0, {0x3bb56d8, 0xc000123770}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 293 [select]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).k8sServiceHandler(0xc0016f6b00)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:677 +0xfd
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).RunK8sServiceHandler
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:690 +0x56

goroutine 294 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00202a6c0, {0xc001adf500, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000528690}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 706 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000ffe348, 0x1e)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc001edef90?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000ffe330, {0xc002ccb001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc002ccb001?, 0x2?, 0x3613591?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc000c29e00)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc000c29e00)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc000c29e00, {0x30221e0, 0xc0004769d8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc000242fc0, {0xc00208c000, 0x1000, 0x1500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0003c99a0, 0xc0031ab080?, {0x3b9d990, 0xc001263ac0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000928340)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000a39000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 472 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00072a1c8, 0x26)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc00142e600?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc00072a1b0, {0xc002dd2001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc002dd2001?, 0x2?, 0x3613591?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc000ec6c80)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc000ec6c80)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc000ec6c80, {0x30221e0, 0xc0016c9b48})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc00085bad0, {0xc001846a00, 0x1000, 0x1500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000adc550, 0xc002412000?, {0x3b9d990, 0xc001a75e00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000072ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001252740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 323 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc001236720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 267 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc00004e4c8, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc001084270?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc00004e4b0, {0xc002c74001, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc002c74001?, 0x2?, 0x3613591?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc00010ea00)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc00010ea00)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc00010ea00, {0x30221e0, 0xc0014ecb40})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc001e64060, {0xc0002ba000, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0001d4af0, 0xc0015d8540?, {0x3b9d990, 0xc000ffb9c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc00111f800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001e5e240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 298 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7f3b85877698, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001a8db80?, 0xc001840d00?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001a8db80)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc001a8db80)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*TCPListener).accept(0xc001af3620)
	/usr/local/go/src/net/tcpsock_posix.go:148 +0x25
net.(*TCPListener).Accept(0xc001af3620)
	/usr/local/go/src/net/tcpsock.go:297 +0x3d
github.com/miekg/dns.(*Server).serveTCP(0xc0003b7a00, {0x3bb3640?, 0xc001af3620})
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:454 +0x148
github.com/miekg/dns.(*Server).ActivateAndServe(0xc0003b7a00)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:372 +0x17c
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc0003b7a00)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:670 +0x20c
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:662 +0x939

goroutine 299 [IO wait]:
internal/poll.runtime_pollWait(0x7f3b85877878, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001a8dc00?, 0xc0008e0000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsgInet4(0xc001a8dc00, {0xc0008e0000, 0x200, 0x200}, {0xc0008a65a0, 0x2c, 0x2c}, 0x591c938?, 0x7f3b85669948?)
	/usr/local/go/src/internal/poll/fd_unix.go:331 +0x359
net.(*netFD).readMsgInet4(0xc001a8dc00, {0xc0008e0000?, 0x5e23660?, 0xc001e42858?}, {0xc0008a65a0?, 0xc00017a800?, 0x17?}, 0x0?, 0x16?)
	/usr/local/go/src/net/fd_posix.go:84 +0x37
net.(*UDPConn).readMsg(0x42?, {0xc0008e0000?, 0x416130?, 0xffffffffffffffff?}, {0xc0008a65a0?, 0x0?, 0x0?})
	/usr/local/go/src/net/udpsock_posix.go:101 +0x16b
net.(*UDPConn).ReadMsgUDPAddrPort(0xc000425308, {0xc0008e0000?, 0x7f3b85877878?, 0x47bc5e?}, {0xc0008a65a0?, 0xc001e429d0?, 0x47ba2e?})
	/usr/local/go/src/net/udpsock.go:203 +0x53
net.(*UDPConn).ReadMsgUDP(0xc0020569c0?, {0xc0008e0000?, 0xc00026d800?, 0xc001109b90?}, {0xc0008a65a0?, 0xc001e42a30?, 0x40e107?})
	/usr/local/go/src/net/udpsock.go:191 +0x2a
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*sessionUDPFactory).ReadRequest(0xc000425308?, 0xc000425308)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/udp.go:178 +0x5f
github.com/miekg/dns.(*Server).readUDP(0xc0003b7b00, 0xc000425308, 0xc0043103c0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:688 +0xed
github.com/miekg/dns.defaultReader.ReadUDP({0xc003acf3b0?}, 0x3b88020?, 0xc0043103c0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:174 +0x19
github.com/miekg/dns.(*Server).serveUDP(0xc0003b7b00, {0x3bc4870?, 0xc000425308?})
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:510 +0x2ae
github.com/miekg/dns.(*Server).ActivateAndServe(0xc0003b7b00)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:367 +0x125
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc0003b7b00)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:670 +0x20c
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:662 +0x939

goroutine 1001 [syscall, 1 minutes]:
syscall.Syscall6(0x451705?, 0xc000f5a5c8?, 0xc001fcbce0?, 0x443fd1?, 0xc000f5a5f0?, 0xc001fcbd10?, 0xc0020131e0?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x36
os.(*Process).blockUntilWaitable(0xc0016c46f0)
	/usr/local/go/src/os/wait_waitid.go:32 +0x87
os.(*Process).wait(0xc0016c46f0)
	/usr/local/go/src/os/exec_unix.go:22 +0x28
os.(*Process).Wait(...)
	/usr/local/go/src/os/exec.go:132
os/exec.(*Cmd).Wait(0xc00025ec60)
	/usr/local/go/src/os/exec/exec.go:890 +0x45
github.com/cilium/cilium/pkg/launcher.(*Launcher).Run.func1()
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:48 +0x45
created by github.com/cilium/cilium/pkg/launcher.(*Launcher).Run
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:47 +0x4db

goroutine 546 [chan receive, 1 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 327 [chan receive, 1 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 1121 [select]:
reflect.rselect({0xc0007b2240, 0x9, 0xc00253c798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc002882a00?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001a457b8, {0x3bb5780, 0xc0028c0510}, 0xc000184b60, {0x7f3b85801ab8, 0xc000f999f0}, 0xc0009c3560, {0x36c7bac?, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001a457b8, {0x3bb5780, 0xc0028c0510}, {0x7f3b85801ab8?, 0xc000f999f0?}, {0x36c7bac, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamClusters(0xc0003e1b30?, {0x3bc6cb0, 0xc000f999f0})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:107 +0x70
github.com/cilium/proxy/go/envoy/service/cluster/v3._ClusterDiscoveryService_StreamClusters_Handler({0x34ffc60?, 0xc001a457b8}, {0x3bc0368?, 0xc0028e6000})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:332 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001171e00, {0x3bcc8e0, 0xc00288b1e0}, 0xc0028a57a0, 0xc001acce70, 0x5880860, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001171e00, {0x3bcc8e0, 0xc00288b1e0}, 0xc0028a57a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 318 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0008b0660)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 431 [select, 1 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001f8e1c0, 0xc001ad0180, 0xc001f87620, 0xc000b19fb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 373 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc00004e048, 0x4)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc001014f60?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc00004e030, {0xc004a60001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc004a60001?, 0x2?, 0x3613591?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc0002faf00)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc0002faf00)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc0002faf00, {0x30221e0, 0xc002082ed0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc001f80390, {0xc000b9d000, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000130460, 0xc001577d40?, {0x3b9d990, 0xc000fb5140})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001164c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000916dc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 564 [select, 1 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001ce6000, 0xc0014f0060, 0xc0007c49c0, 0xc0009cbfb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 402 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001ade8d0, 0xe)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc001ae6360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 429 [select, 1 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001ce6540, 0xc0014f00c0, 0xc001f87200, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 319 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0008ce190, 0x1b)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0008b0540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 281 [chan receive]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).podsInit.func1.1()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:123 +0x131
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).podsInit.func1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:121 +0xf8

goroutine 382 [chan receive, 1 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 2290 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000ef9c20, {0xc0001cc310, 0x0, 0xc001081c80, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001e98fa0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 380 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc001e882e8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x505167?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001e882c0, 0xc001f809c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0011da3c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc001f80a50}, 0x1, 0xc0014f0060)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0011da438?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0011da3c0, 0xc0014f0060)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 492 [chan receive, 1 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func5()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:302 +0x3e
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:301 +0x2f2c

goroutine 430 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc001ad4600, 0xc0008dd100)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa00000001?, 0xc000977fa0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 2101 [select, 1 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func2()
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:73 +0x117
golang.org/x/sync/errgroup.(*Group).Go.func1()
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:75 +0x64
created by golang.org/x/sync/errgroup.(*Group).Go
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:72 +0xa5

goroutine 328 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc001adfbc0}, {0x7f3b855bca38, 0xc000cfdc30}, {0x3be8e60?, 0x35bfa20}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001f8e1c0, {0x0?, 0x0?}, 0xc001ad0180, 0xc0011ae8e0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001f8e1c0, 0xc001ad0180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0014d4080?, {0x3b878e0, 0xc000128af0}, 0x1, 0xc001ad0180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001f8e1c0, 0xc001ad0180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 554 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc001ad4648, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc001ad4630, {0xc001f36c00, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc001f36c00?, 0x0?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc002144000)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc002144000)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc002144000, {0x30221e0, 0xc001d829d8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc000dcb9e0, {0xc002129000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000131900, 0x0?, {0x3b9d990, 0xc000917800})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001165a00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0009177c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 383 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc001adfa40}, {0x7f3b855bca38, 0xc001e882c0}, {0x3be8e60?, 0x35a2620}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001ce6000, {0x0?, 0x0?}, 0xc0014f0060, 0xc001164d40?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001ce6000, 0xc0014f0060)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000918a40?, {0x3b878e0, 0xc0001310e0}, 0x1, 0xc0014f0060)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001ce6000, 0xc0014f0060)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 547 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc0009177c0}, {0x7f3b855bca38, 0xc0006838c0}, {0x3be8e60?, 0x3589640}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001ce6540, {0x0?, 0x0?}, 0xc0014f00c0, 0xc001165040?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001ce6540, 0xc0014f00c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000918b00?, {0x3b878e0, 0xc0001311d0}, 0x1, 0xc0014f00c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001ce6540, 0xc0014f00c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 401 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc001ae6540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 375 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc001e88238, 0x3)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000dfc040?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001e88210, 0xc000916f40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0011da320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc00085a000}, 0x1, 0xc001ba94a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0011da398?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0011da320, 0xc001ba94a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNodeInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:134 +0x64a

goroutine 324 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0014d2290, 0x1a)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc001236600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 372 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc00004e000, 0xc0003b6400)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0x0?, 0xc0013b9d00?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 345 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0009a2000, 0xc0009a0300)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa013f9f01?, 0xc0020657a0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 320 [select, 1 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 385 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0008b07e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 386 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc0008ce210, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0008b06c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 387 [select, 1 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 388 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0008b0960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 389 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc0008ce290, 0x8)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0008b0840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 390 [select, 1 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 391 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc001f820d8, 0x3)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc001267240?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001f820b0, 0xc002056840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000d30280)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc002056a80}, 0x1, 0xc001ba8cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000d302f8?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000d30280, 0xc001ba8cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 2466 [select]:
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00291c9c0?, {0x3b87900, 0xc000ef72c0}, 0x1, 0xc00291c9c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:238 +0x135
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0029188c0?, 0x77359400, 0x0, 0x20?, 0x20?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/leaderelection.(*LeaderElector).renew(0xc002806ea0, {0x3bb56d8?, 0xc002918870?})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/leaderelection/leaderelection.go:266 +0x125
k8s.io/client-go/tools/leaderelection.(*LeaderElector).Run(0xc002806ea0, {0x3bb56d8, 0xc0021da5f0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/leaderelection/leaderelection.go:209 +0x119
k8s.io/client-go/tools/leaderelection.RunOrDie({0x3bb56d8, 0xc0021da5f0}, {{0x3bc0b48, 0xc002806a20}, 0x37e11d600, 0x12a05f200, 0x77359400, {0xc0014e9960, 0xc0014e9970, 0x0}, ...})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/leaderelection/leaderelection.go:223 +0x94
github.com/cilium/cilium/pkg/l2announcer.(*selectedService).serviceLeaderElection(0xc00201a5b0, {0x3bb5780?, 0xc000f9a420?})
	/go/src/github.com/cilium/cilium/pkg/l2announcer/l2announcer.go:1061 +0x218
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc0021da5a0, {0x3bb5780, 0xc000f9a420}, 0x0?, {{{0xc0010bd3e0, 0x1, 0x1}}, {0x3be6410, 0xc00174e2a0}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:267 +0x530
created by github.com/cilium/cilium/pkg/hive/job.(*group).Add.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:181 +0x158

goroutine 393 [chan receive, 1 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 394 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc000916dc0}, {0x7f3b855bca38, 0xc001f820b0}, {0x3be8e60?, 0x358fc00}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0016f82a0, {0x0?, 0x0?}, 0xc001ba8cc0, 0xc0013fe200?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0016f82a0, 0xc001ba8cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0008c66c0?, {0x3b878e0, 0xc0008c85f0}, 0x1, 0xc001ba8cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0016f82a0, 0xc001ba8cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 371 [select, 1 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0016f82a0, 0xc001ba8cc0, 0xc001ba8540, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 1203 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0007ce3c6, 0x10, 0x1a}, {0xc0008a6750, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1002 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000e9c460)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 434 [select]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).serviceEventLoop(0xc0016f6b00, 0xc00147e58c, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:41 +0x131
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).servicesInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:29 +0x1b8

goroutine 1113 [semacquire, 1 minutes]:
sync.runtime_Semacquire(0x3124be0?)
	/usr/local/go/src/runtime/sema.go:62 +0x27
sync.(*WaitGroup).Wait(0xc00144a200?)
	/usr/local/go/src/sync/waitgroup.go:116 +0x4b
github.com/cilium/cilium/api/v1/health/server.(*Server).Serve(0xc00144a200)
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:278 +0x6b
github.com/cilium/cilium/pkg/health/server.(*Server).runActiveServices(0xc00144a200)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:351 +0x113
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func2()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:369 +0x26
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:368 +0xd9

goroutine 436 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0008b12c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 437 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0008ceed0, 0x7)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0008b11a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 438 [select, 1 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 439 [select]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).namespacesInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:48 +0xce
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).namespacesInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:46 +0x20a

goroutine 2103 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0xc000d9cf00, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x115
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0xc0002cc2a0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x91
google.golang.org/grpc/internal/transport.NewServerTransport.func2()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:341 +0xda
created by google.golang.org/grpc/internal/transport.NewServerTransport
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:338 +0x1bb3

goroutine 442 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0008b1440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 443 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0008cef90, 0x41)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0008b1320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 444 [select, 1 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 445 [select]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).endpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:43 +0xf8
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).endpointsInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:41 +0x285

goroutine 447 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc001f82188, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x505167?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001f82160, 0xc0008cf040)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000d30b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc0008aa210}, 0x1, 0xc001ad0ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000d30bb8?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000d30b40, 0xc001ad0ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).networkPoliciesInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/network_policy.go:74 +0x35a

goroutine 2535 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001a8f950, 0x1)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0002c09a0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc001a8f900, {0x3bb56d8, 0xc00381fd10}, {0xc000a70a40, 0x35}, 0x2, {0xc000952fa5, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 449 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc001f82238, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x505167?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001f82210, 0xc0008cf0c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000d30c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc001edfbf0}, 0x1, 0xc001ad0ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000d30cf8?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000d30c80, 0xc001ad0ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).tlsSecretInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/secret.go:90 +0x253

goroutine 450 [select, 1 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNetworkPoliciesInit.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_network_policy.go:108 +0x372
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNetworkPoliciesInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_network_policy.go:89 +0x158

goroutine 637 [IO wait]:
internal/poll.runtime_pollWait(0x7f3b858772d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc0012afa80?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0012afa80)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc0012afa80)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*UnixListener).accept(0x444640?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x1c
net.(*UnixListener).Accept(0xc0012111a0)
	/usr/local/go/src/net/unixsock.go:260 +0x3d
google.golang.org/grpc.(*Server).Serve(0xc0017d2000, {0x3bb3670?, 0xc0012111a0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:821 +0x475
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func2()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:231 +0x59
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:230 +0x230f

goroutine 688 [select, 1 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001db20e0, 0xc001e635c0, 0xc0012ad020, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 454 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumNodeInit(0xc0016f6b00, {0x3bf05a0, 0xc000c03d90}, 0xc00147e570)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:136 +0x656
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).enableK8sWatchers
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:557 +0x5c5

goroutine 455 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEndpointsInit(0xc0016f6b00, {0x3bf05a0, 0xc000c03d90}, 0xc00147e570)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:101 +0x76
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).initCiliumEndpointOrSlices
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:1074 +0x152

goroutine 252 [chan receive, 1 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 2491 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002c567e0, {0xc001645530, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00376e2d0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 338 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0000fc4f8, 0x3)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000a1b080?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0000fc4d0, 0xc0009b8150)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0011ea1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc0009b81e0}, 0x1, 0xc001ad01e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0011ea258?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0011ea1e0, 0xc001ad01e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 458 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001f822e8, 0x25)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0013ab280?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001f822c0, 0xc0008cf200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000d30dc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc000c78060}, 0x1, 0xc0008a99e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000d30e38?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000d30dc0, 0xc0008a99e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEndpointsInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:99 +0x6a

goroutine 459 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0x0?)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x37
created by github.com/cilium/cilium/pkg/kvstore.Connected
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x72

goroutine 693 [select, 1 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync.func1(0xc000902820)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:871 +0x276
created by github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:863 +0x65

goroutine 284 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc001f890e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 285 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0007c00d0, 0x10c)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc001f88fc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 2307 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002002360, {0xc0005f5a40, 0x0, 0xc0019e7200, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001c5aaa0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 425 [chan receive, 1 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 539 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0016165a8, 0x1d)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0013be900?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001616580, 0xc001071c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000e9cfa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc001636960}, 0x1, 0xc001e635c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000e9d018?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000e9cfa0, 0xc001e635c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/identitybackend.(*crdBackend).ListAndWatch(0xc001636390, {0xc0009b7f10?, 0xc0009b7f20?}, {0x3bb59e8?, 0xc0009028d8}, 0xc001e635c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/identitybackend/identity.go:396 +0x53d
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:204 +0x4d
created by github.com/cilium/cilium/pkg/allocator.(*cache).start
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:203 +0x118

goroutine 340 [chan receive, 1 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 333 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7f3b85877788, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001237140?, 0xc001c97ed0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc001237140, {0xc001c97ed0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:31
os.(*File).Read(0xc000762070, {0xc001c97ed0?, 0xa0100b2ff01746f?, 0x69747265706f7250?})
	/usr/local/go/src/os/file.go:118 +0x5e
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc000128cd0)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:356 +0xdf
created by github.com/fsnotify/fsnotify.NewWatcher
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:150 +0x1b0

goroutine 286 [select, 1 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 253 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc001070640}, {0x7f3b855bca38, 0xc001f82160}, {0x3be8e60?, 0x35c1460}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001b2c000, {0x0?, 0x0?}, 0xc001ad0ae0, 0xc00138a0e0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001b2c000, 0xc001ad0ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0007aa140?, {0x3b878e0, 0xc0001e4410}, 0x1, 0xc001ad0ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001b2c000, 0xc001ad0ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 2105 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7f3b85500960, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc002898a80?, 0xc0012ba000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002898a80, {0xc0012ba000, 0x580, 0x580})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc002898a80, {0xc0012ba000?, 0xc0012ba005?, 0x1a?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc0014033b8, {0xc0012ba000?, 0x0?, 0xc001d64c30?})
	/usr/local/go/src/net/net.go:183 +0x45
crypto/tls.(*atLeastReader).Read(0xc000435098, {0xc0012ba000?, 0xc000435098?, 0x0?})
	/usr/local/go/src/crypto/tls/conn.go:788 +0x3d
bytes.(*Buffer).ReadFrom(0xc001d64d10, {0x3b720a0, 0xc000435098})
	/usr/local/go/src/bytes/buffer.go:202 +0x98
crypto/tls.(*Conn).readFromUntil(0xc001d64a80, {0x3b88060?, 0xc0014033b8}, 0x580?)
	/usr/local/go/src/crypto/tls/conn.go:810 +0xe5
crypto/tls.(*Conn).readRecordOrCCS(0xc001d64a80, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:617 +0x116
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:583
crypto/tls.(*Conn).Read(0xc001d64a80, {0xc00169a000, 0x8000, 0x0?})
	/usr/local/go/src/crypto/tls/conn.go:1316 +0x16f
bufio.(*Reader).Read(0xc004654660, {0xc001db23c0, 0x9, 0x30?})
	/usr/local/go/src/bufio/bufio.go:237 +0x1bb
io.ReadAtLeast({0x3b71ea0, 0xc004654660}, {0xc001db23c0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
golang.org/x/net/http2.readFrameHeader({0xc001db23c0?, 0x9?, 0xc0015180c0?}, {0x3b71ea0?, 0xc004654660?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x6e
golang.org/x/net/http2.(*Framer).ReadFrame(0xc001db2380)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x95
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0xc00534c340, 0xc0020dff68?, 0x2b7fa58?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:642 +0x167
google.golang.org/grpc.(*Server).serveStreams(0xc00276a000, {0x3bcc8e0?, 0xc00534c340})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:946 +0x162
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:889 +0x46
created by google.golang.org/grpc.(*Server).handleRawConn
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:888 +0x185

goroutine 2306 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc000011b48?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 271 [chan receive, 1 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 2555 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001a8fad0, 0x23)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc001156860?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc001a8fa80, {0x3bb56d8, 0xc002e0a780}, {0xc0033cf6d0, 0x42}, 0x8, {0xc00123e185, 0x9}, {0xc001156860, 0x1, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 341 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc001e5e400}, {0x7f3b855bca38, 0xc0000fc4d0}, {0x3be8e60?, 0x35bf2a0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc00086a000, {0x0?, 0x0?}, 0xc001ad01e0, 0xc0014080a0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc00086a000, 0xc001ad01e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001f92080?, {0x3b878e0, 0xc000644190}, 0x1, 0xc001ad01e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc00086a000, 0xc001ad01e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 357 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0009c6420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 562 [select, 1 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001b2c000, 0xc001ad0ae0, 0xc0007c46c0, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 465 [chan receive, 1 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 533 [select, 1 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc00086a000, 0xc001ad01e0, 0xc001e62cc0, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 358 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc001070010, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0009c6300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 359 [select, 1 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 2380 [IO wait]:
internal/poll.runtime_pollWait(0x7f3b857fb8c8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc0042d8100?, 0xc004287000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsg(0xc0042d8100, {0xc004287000, 0x1000, 0x1000}, {0x0, 0x0, 0x0}, 0x8?)
	/usr/local/go/src/internal/poll/fd_unix.go:304 +0x3aa
net.(*netFD).readMsg(0xc0042d8100, {0xc004287000?, 0x0?, 0x0?}, {0x0?, 0xc004c0d560?, 0xc004c0d530?}, 0x4133e2?)
	/usr/local/go/src/net/fd_posix.go:78 +0x37
net.(*UnixConn).readMsg(0xc000424830, {0xc004287000?, 0x2716d3a?, 0x2fcad80?}, {0x0?, 0xc00213c830?, 0xc?})
	/usr/local/go/src/net/unixsock_posix.go:115 +0x4f
net.(*UnixConn).ReadMsgUnix(0xc000424830, {0xc004287000?, 0xc001d07bb8?, 0x2?}, {0x0?, 0xc1360fef5ce480c1?, 0xf33443229?})
	/usr/local/go/src/net/unixsock.go:143 +0x3c
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn(0xc0010c0ea0, {0x3bb56d8?, 0xc000122500}, 0xc000424830)
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:118 +0x1a6
created by github.com/cilium/cilium/pkg/envoy.StartAccessLogServer.func1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:82 +0x138

goroutine 426 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc001adf880}, {0x7f3b855bca38, 0xc001f82210}, {0x3be8e60?, 0x35bfde0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001e8a1c0, {0x0?, 0x0?}, 0xc001ad0ae0, 0xc001266d60?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001e8a1c0, 0xc001ad0ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001a94980?, {0x3b878e0, 0xc000529720}, 0x1, 0xc001ad0ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001e8a1c0, 0xc001ad0ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 272 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc001252740}, {0x7f3b855bca38, 0xc001f822c0}, {0x3be8e60?, 0x358d5a0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc00095a000, {0x0?, 0x0?}, 0xc0008a99e0, 0xc00111e0e0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc00095a000, 0xc0008a99e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc001e60100?, {0x3b878e0, 0xc0001d40f0}, 0x1, 0xc0008a99e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc00095a000, 0xc0008a99e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 486 [select, 1 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001e8a1c0, 0xc001ad0ae0, 0xc0003d83c0, 0x203a226570797422?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 360 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0009c65a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 469 [select, 1 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc00095a000, 0xc0008a99e0, 0xc000c564e0, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 361 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc001070090, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0009c6480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 362 [select, 1 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 363 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0xc0009c6720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x305
created by k8s.io/client-go/util/workqueue.newDelayingQueue
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x22a

goroutine 364 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc001070110, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x2?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/util/workqueue.(*Type).Get(0xc0009c6600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0xa5
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:450 +0x3bb
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:399 +0x595

goroutine 365 [select, 1 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:510 +0x10e
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:508 +0x68c

goroutine 535 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc001efc1c8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0009ccc08?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc001efc1b0, {0xc0012ca558, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0xc001f8b040?}, {0xc0012ca558?, 0xc0009ccd08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7f3b855bc700, 0xc001efc180}, {0xc0012ca558, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc0009c8570, {0xc0009fcc00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0009c0960, 0xc0007c43c0?, {0x3b9d990, 0xc001070680})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0014148e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001070640)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 366 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc000cfdd08, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc002121c18?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000cfdce0, 0xc000ad44e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000e9c320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc000ad45d0}, 0x1, 0xc0014f0000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc000e9c398?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc000e9c320, 0xc0014f0000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 2262 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0015d6a20, {0xc0005f48c0, 0x0, 0xc0017f1980, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001c5a190}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1036 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 466 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc001f96b00}, {0x7f3b855bca38, 0xc001e88210}, {0x3be8e60?, 0x358fc00}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0016ba000, {0x0?, 0x0?}, 0xc001ba94a0, 0xc000072180?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0016ba000, 0xc001ba94a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000ade100?, {0x3b878e0, 0xc000adc050}, 0x1, 0xc001ba94a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0016ba000, 0xc001ba94a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 471 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc0009a2048, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0012fdb98?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc0009a2030, {0xc00065e600, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc00065e600?, 0xffffffffffffffff?, 0xffffffffffffffff?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc000ec6a00)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc000ec6a00)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc000ec6a00, {0x30221e0, 0xc000ad8c18})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc00085b920, {0xc000ae7400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000adc460, 0xc0008a9e00?, {0x3b9d990, 0xc001252680})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc000072ac0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001252640)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 487 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000b56000, 0xc000b54300)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa01412f01?, 0xc0013997a0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 529 [chan receive, 1 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 256 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc0006838e8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0x505167?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0006838c0, 0xc0008aa690)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0013bc960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc001f80cf0}, 0x1, 0xc0014f00c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0013bc9d8?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0013bc960, 0xc0014f00c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func4()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:304 +0x8c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:302 +0x3d5

goroutine 332 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0009a2348, 0x3)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0033ba570?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc0009a2330, {0xc003f62001, 0x1dff, 0x1dff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc003f62001?, 0x2?, 0x3613591?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc000267680)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc000267680)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc000267680, {0x30221e0, 0xc000c7f200})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc000ea4540, {0xc0030b4a00, 0x2000, 0x2500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000128c30, 0xc0002b4000?, {0x3b9d990, 0xc0013ef440})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0011aeb60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0014d2b00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 638 [chan receive, 1 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func3()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:236 +0x3e
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:235 +0x238c

goroutine 530 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc001252640}, {0x7f3b855bca38, 0xc000cfdce0}, {0x3be8e60?, 0x359a3a0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc0010b7c00, {0x0?, 0x0?}, 0xc0014f0000, 0xc001414280?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc0010b7c00, 0xc0014f0000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000868000?, {0x3b878e0, 0xc0009c0640}, 0x1, 0xc0014f0000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc0010b7c00, 0xc0014f0000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 470 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc00072a180, 0xc00070e700)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa0154e001?, 0xc002004fa0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 344 [select, 1 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0010b7c00, 0xc0014f0000, 0xc0009c2360, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 488 [select, 1 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc0016ba000, 0xc001ba94a0, 0xc0003d87e0, 0xc000b1bfb8?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 346 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0009fe1c8, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000af7d68?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc0009fe1b0, {0xc004c288bc, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc004c288bc?, 0xc000af7d08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7f3b855bc700, 0xc0009fe180}, {0xc004c288bc, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc002082378, {0xc0020eec00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0006444b0, 0xc000c3c2c0?, {0x3b9d990, 0xc001a8ee80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0014085c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001e5e400)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 565 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc001efc300, 0xc00066df00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xc00120c820?, 0xc002127fb8?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 4357 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001102b40, {0xc000473860, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00284fc20}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 563 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc001efc180, 0xc00066db00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0x6e2065685422203a?, 0xc000361380?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 489 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000b56180, 0xc000b54700)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xc001322020?, 0xc000afbfb8?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 534 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0009fe180, 0xc0009fa700)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa012ca001?, 0xc0009d47a0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 432 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc001ad4780, 0xc0008dd600)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa01412f01?, 0xc0013997a0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 593 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc000b56048, 0x1)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000b1ed68?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000b56030, {0xc0004a1a2c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc0004a1a2c?, 0xc000b1ed08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7f3b855bc700, 0xc000b56000}, {0xc0004a1a2c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc001ba3950, {0xc000452c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000529c70, 0xc001bfeff0?, {0x3b9d990, 0xc000ffbec0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0012676c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001adf880)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 594 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc001efc348, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0020fbbb0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc001efc330, {0xc00093e000, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc00093e000?, 0xc0013994e0?, 0x40d7f0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc00068d7c0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc00068d7c0)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc00068d7c0, {0x30221e0, 0xc001ba3998})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc000f3cd50, {0xc000453000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000529db0, 0xc001123900?, {0x3b9d990, 0xc001adfa80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0012676e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001adfa40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 566 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc000b561c8, 0x4)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000fae7b0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000b561b0, {0xc0046c3001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc0046c3001?, 0x2?, 0x3613591?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc000a76140)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc000a76140)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc000a76140, {0x30221e0, 0xc001ba3aa0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc0008ab470, {0xc0010d0000, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0001e5a40, 0xc000a3d500?, {0x3b9d990, 0xc0013cde80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc00138a840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001f96b00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 595 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001ad47c8, 0x90)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0020fcd68?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc001ad47b0, {0xc003a672cc, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc003a672cc?, 0xc0020fcd08?, 0x40baf6?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
io.ReadAtLeast({0x7f3b855bc700, 0xc001ad4780}, {0xc003a672cc, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:332 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc001ba39f8, {0xc002aee000, 0x8000, 0xa000})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x88
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc000529ea0, 0xc004801000?, {0x3b9d990, 0xc004350780})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001267700)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001adfbc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 624 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001e88448, 0x3)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000df2ca0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc001e88420, 0xc000917dc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x256
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0011da960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:192 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x11179e5?, {0x3b87900, 0xc00110ef60}, 0x1, 0xc001ad1200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0011da9d8?, 0x3b9aca00, 0x0, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0xc0011da960, 0xc001ad1200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:163 +0x385
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).ciliumEnvoyConfigInit
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_envoy_config.go:84 +0x338

goroutine 625 [chan receive, 1 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 596 [chan receive, 1 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 670 [select, 1 minutes]:
github.com/cilium/cilium/pkg/datapath/loader.(*objectCache).watchTemplatesDirectory(0xc000adc7d0, {0x3bb56d8, 0xc000adceb0})
	/go/src/github.com/cilium/cilium/pkg/datapath/loader/cache.go:342 +0x225
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00135a5a0, {0xc001389990, 0x0, 0x3805780, 0x0, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000adceb0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 597 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc001624180}, {0x7f3b855bca38, 0xc001e88370}, {0x3be8e60?, 0x358d020}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001e8a7e0, {0x0?, 0x0?}, 0xc001ad1200, 0xc0012677a0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001e8a7e0, 0xc001ad1200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0008c4410?, {0x3b878e0, 0xc000529f90}, 0x1, 0xc001ad1200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001e8a7e0, 0xc001ad1200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 536 [select, 1 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001e8a7e0, 0xc001ad1200, 0xc001e63260, 0xc001ba94a0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 626 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc0014d2b00}, {0x7f3b855bca38, 0xc001e88420}, {0x3be8e60?, 0x358d860}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001ce68c0, {0x0?, 0x0?}, 0xc001ad1200, 0xc001165de0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001ce68c0, 0xc001ad1200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc000a1c0f0?, {0x3b878e0, 0xc00048a9b0}, 0x1, 0xc001ad1200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001ce68c0, 0xc001ad1200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 347 [select, 1 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0xc001ce68c0, 0xc001ad1200, 0xc0009c2840, 0xc001f96b00?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x114
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:352 +0x32a

goroutine 1111 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0xc002ca7560)
	/usr/local/go/src/net/http/transport.go:2410 +0xf2
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1766 +0x173d

goroutine 1110 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7f3b857fbb98, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc002cbe000?, 0xc002c9d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002cbe000, {0xc002c9d000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc002cbe000, {0xc002c9d000?, 0x43c147?, 0xc001fe1c30?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000bea7f0, {0xc002c9d000?, 0x0?, 0xc000f62000?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*persistConn).Read(0xc002ca7560, {0xc002c9d000?, 0xc0015c4c00?, 0xc001fe1d30?})
	/usr/local/go/src/net/http/transport.go:1943 +0x4e
bufio.(*Reader).fill(0xc000aa5bc0)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc000aa5bc0, 0x1)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*persistConn).readLoop(0xc002ca7560)
	/usr/local/go/src/net/http/transport.go:2107 +0x1ac
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1765 +0x16ea

goroutine 501 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001a6cd80, {0xc000b160c0, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002a3f810}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1442 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0015aa480, {0xc00140b6a0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000279ae0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1087 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0017bd200, {0xc00078c510, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0001e5b80}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1710 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0010f0fc0, {0xc0011111b0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002a3f1d0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2260 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001c5a0f0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0015d65a0, {0xc000fd2e80, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001c5a0f0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2817 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc000d837c0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001a6c7e0, {0xc003bff1e0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc000d837c0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 636 [syscall]:
syscall.Syscall6(0xc000d55f40?, 0xc0011549d0?, 0x50?, 0x48?, 0xc0024e9840?, 0x1000000004e14da?, 0x3b72340?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x36
golang.org/x/sys/unix.EpollWait(0x30?, {0xc001366a80?, 0xc0000ba140?, 0x3b72340?}, 0x22d13ab?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:56 +0x58
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:125
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0xc00111f920, {0xc001366a80?, 0x20, 0x20}, {0x2550da0?, 0xc00174e1c0?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x2b4
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0xc0015bb500, 0xc0015c4660?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:345 +0x2d6
github.com/cilium/ebpf/perf.(*Reader).Read(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:319
github.com/cilium/cilium/pkg/monitor/agent.(*agent).handleEvents(0xc00174e1c0, {0x3bb56d8, 0xc000d828c0})
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:340 +0x485
created by github.com/cilium/cilium/pkg/monitor/agent.(*agent).startPerfReaderLocked
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:209 +0xe5

goroutine 639 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7f3b858770f8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc00216e5a0?, 0xc002b2fed0?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00216e5a0, {0xc002b2fed0, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:31
os.(*File).Read(0xc00072c6d8, {0xc002b2fed0?, 0x0?, 0x0?})
	/usr/local/go/src/os/file.go:118 +0x5e
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0xc000d82910)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:356 +0xdf
created by github.com/fsnotify/fsnotify.NewWatcher
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:150 +0x1b0

goroutine 543 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x58c5060?}, {0x3b9db70, 0xc000a39000}, {0x7f3b855bca38, 0xc001616580}, {0x3be8e60?, 0x358dde0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:709 +0x185
k8s.io/client-go/tools/cache.(*Reflector).watch(0xc001db20e0, {0x0?, 0x0?}, 0xc001e635c0, 0xc001414ea0?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:428 +0x548
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc001db20e0, 0xc001e635c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:353 +0x34e
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:286 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x3e
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0008687c0?, {0x3b878e0, 0xc0009c0d20}, 0x1, 0xc001e635c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc001db20e0, 0xc001e635c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:285 +0x17d
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x85

goroutine 542 [chan receive, 1 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:133 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0xc5

goroutine 348 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0009a2300, 0xc0009a0700)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa01413d01?, 0xc0013987a0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 2270 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc00075bbc6, 0x10, 0x1a}, {0xc001c33260, 0x24}, 0xc0016c7b00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 490 [select, 1 minutes]:
github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch.func2()
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:138 +0x185
created by github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:135 +0x258

goroutine 2338 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc003628640)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 491 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7f3b85877008, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc002744180?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc002744180)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc002744180)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*TCPListener).accept(0xc000a144e0)
	/usr/local/go/src/net/tcpsock_posix.go:148 +0x25
net.(*TCPListener).Accept(0xc000a144e0)
	/usr/local/go/src/net/tcpsock.go:297 +0x3d
google.golang.org/grpc.(*Server).Serve(0xc00276a000, {0x3bb3640?, 0xc000a144e0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:821 +0x475
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func4()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:293 +0x65
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:292 +0x2eac

goroutine 2007 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0xc00151fd40)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1155 +0x233
created by google.golang.org/grpc/internal/transport.NewServerTransport
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:344 +0x1bf8

goroutine 634 [select, 1 minutes]:
github.com/cilium/cilium/pkg/hubble/observer.(*namespaceManager).Run(0x91812a?, {0x3bb56d8, 0xc0000ce230})
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/namespace_manager.go:50 +0xea
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:175 +0x141e

goroutine 635 [chan receive]:
github.com/cilium/cilium/pkg/hubble/observer.(*LocalObserverServer).Start(0xc000d2f680)
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/local_observer.go:121 +0xa9
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:187 +0x1645

goroutine 640 [select, 1 minutes]:
github.com/cilium/cilium/pkg/fswatcher.(*Watcher).loop(0xc001211890)
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:210 +0xdd
created by github.com/cilium/cilium/pkg/fswatcher.New
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:98 +0x1ea

goroutine 705 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000ffe300, 0xc000fc0500)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0x91818a?, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 629 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0xc0009fe4c8, 0x0)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc00214db98?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc0009fe4b0, {0xc001f37200, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0?}, {0xc001f37200?, 0xffffffffffffffff?, 0xffffffffffffffff?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2534 +0x75
encoding/json.(*Decoder).refill(0xc002145cc0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x188
encoding/json.(*Decoder).readValue(0xc002145cc0)
	/usr/local/go/src/encoding/json/stream.go:140 +0xbb
encoding/json.(*Decoder).Decode(0xc002145cc0, {0x30221e0, 0xc001d83098})
	/usr/local/go/src/encoding/json/stream.go:63 +0x78
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0xc00110f590, {0xc00215c000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x1a5
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc00048ac80, 0xc00082ab40?, {0x3b9d990, 0xc0016241c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc001436480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc001624180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xdc
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x130

goroutine 537 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc0009fe480, 0xc0009fab00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1461 +0xb27
golang.org/x/net/http2.(*clientStream).doRequest(0xa012ca001?, 0xc0009d47a0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1229 +0x34a

goroutine 976 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000d30500)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1035 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1034 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1309 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0007cf786, 0x10, 0x1a}, {0xc00093d0b0, 0x24}, 0xc001e56ea0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1033 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 4196 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002a1e360, {0xc0013d9950, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002406500}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1030 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00003f7a0, {0xc001ba3f68, 0x0, 0xc001ba3f80, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0021f5a40}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1278 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0014406c0, {0xc00011dc00, 0x0, 0xc000fdb560, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0015b3900}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 934 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001102480, {0xc0008aca80, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00048a0f0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2593 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc000130d70, {0xc001cddfa8, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc000130d70, {0xc001cddfa8?, 0xc0046735c0?, 0xc0024e7560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc0033babd0, {0xc001cddfa8?, 0xc0024e75d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc0033babd0}, {0xc001cddfa8, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc0001ad9e0, {0xc001cddfa8, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc001cddf98, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc0024e77a8?, 0xc0001ad9e0, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7f3b85801a90, 0x5e20750}, 0x0?, {0x0?, 0x0?}, {0x3472d60, 0xc0048d2000}, 0xc001ae7440?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc0026454a0, {0x3472d60?, 0xc0048d2000})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/endpoint/v3.(*endpointDiscoveryServiceStreamEndpointsServer).Recv(0xc000f91450)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:357 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc00275aa20?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 1374 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000c7a000, {0xc0020833e0, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0002794f0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2342 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002921560, {0xc0001e6380, 0x0, 0xc0007a6d50, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001e99e50}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1328 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000194900, {0xc00075e870, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000a19f90}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2289 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc000af6fd0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00148c6c0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 951 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:246 +0x116
created by github.com/cilium/cilium/pkg/stream.Multicast[...].func3
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:239 +0x3aa

goroutine 1364 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0011da780)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 4387 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x284f97f?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001705b00?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1597 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc003628000)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1133 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc000d82b40})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0014fcd80, {0xc000f99260, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc000d82b40}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1368 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0014a1440, {0xc001e3b650, 0x0, 0xc00142e810, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002e50b90}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1367 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc002aca930?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1366 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc002e50af0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0014a0ea0, {0xc00100f450, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc002e50af0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2104 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0xc00534c340)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1155 +0x233
created by google.golang.org/grpc/internal/transport.NewServerTransport
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:344 +0x1bf8

goroutine 1303 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0007cf626, 0x10, 0x1a}, {0xc00093d020, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1277 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001e577a0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1995 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0026fe000, {0xc0006c3950, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001ec65a0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 939 [semacquire, 1 minutes]:
sync.runtime_Semacquire(0x3124be0?)
	/usr/local/go/src/runtime/sema.go:62 +0x27
sync.(*WaitGroup).Wait(0xc0007e6600?)
	/usr/local/go/src/sync/waitgroup.go:116 +0x4b
github.com/cilium/cilium/api/v1/server.(*Server).Serve(0xc0007e6600)
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:385 +0x6b
github.com/cilium/cilium/daemon/cmd.runDaemon(_, _, _, {{{}}, {0x3b77d80, 0xc000c1abd0}, {0x3bf05a0, 0xc000c03d90}, {0x3bdc150, 0xc00136a800}, ...})
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:1876 +0x15f3
github.com/cilium/cilium/daemon/cmd.newDaemonPromise.func1.1()
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:1657 +0x78
created by github.com/cilium/cilium/daemon/cmd.newDaemonPromise.func1
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:1656 +0x198

goroutine 1197 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000c75026, 0x10, 0x1a}, {0xc0007b7e60, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 991 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000c74706, 0x10, 0x1a}, {0xc0007b6c90, 0x24}, 0x6f69736e65747845?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 633 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0017bc480, {0x38057e0, 0x0, 0x3805780, 0x37e11d600, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000d827d0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 943 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobObserver[...]).start(0x3ba0560, {0x3bb5780, 0xc0014d0a50?}, 0x0, {{{0xc001116920, 0x1, 0x1}}, {0x3be6410, 0xc00174e540}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:480 +0x409
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 944 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobObserver[...]).start(0x3ba05e0, {0x3bb5780, 0xc0014d0ab0?}, 0xb1a00001888, {{{0xc001116920, 0x1, 0x1}}, {0x3be6410, 0xc00174e540}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:480 +0x409
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 1276 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0015b3860})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001440240, {0xc000dd4a10, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0015b3860}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1009 [select, 1 minutes]:
github.com/cilium/cilium/pkg/hive/job.(*jobTimer).start(0xc0000cf360, {0x3bb5780, 0xc0014d0b10}, 0xc001f87020?, {{{0xc001116920, 0x1, 0x1}}, {0x3be6410, 0xc00174e540}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:384 +0x3c5
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 1332 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000c757c6, 0x10, 0x1a}, {0xc0014955c0, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1216 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0007ce686, 0x10, 0x1a}, {0xc0008a6de0, 0x24}, 0x2c225c64656d6961?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1274 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0011da6e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1010 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001467560, {0xc0011b3130, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00048aaa0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1272 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00097f7a0, {0xc001d829f0, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0015b3310}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1268 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0000ec6c0, {0xc001d822a0, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0015b2690}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1369 [IO wait]:
internal/poll.runtime_pollWait(0x7f3b857fbd78, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc000a36580?, 0xc0034dd000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc000a36580, {0xc0034dd000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc000a36580, {0xc0034dd000?, 0x4e7b66?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000b86028, {0xc0034dd000?, 0x0?, 0xc001e64b78?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*connReader).Read(0xc001e64b70, {0xc0034dd000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:782 +0x171
bufio.(*Reader).fill(0xc000470540)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc000470540, 0x4)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*conn).serve(0xc001462630, {0x3bb5780, 0xc002d11710})
	/usr/local/go/src/net/http/server.go:2030 +0x77c
created by net/http.(*Server).Serve
	/usr/local/go/src/net/http/server.go:3089 +0x5ed

goroutine 1014 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000950900, {0xc0011b3340, 0x0, 0x3805780, 0x0, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00048ad20}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1220 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000c7bb00, {0xc0003216c0, 0x0, 0xc0011b4f60, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000a18500}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2579 [select]:
reflect.rselect({0xc000950120, 0x9, 0xc004a98798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc0044d6000?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001a457b8, {0x3bb5780, 0xc004395da0}, 0xc00060c850, {0x7f3b85396e80, 0xc0016e7f90}, 0xc0021d9920, {0x36f79e0?, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001a457b8, {0x3bb5780, 0xc004395da0}, {0x7f3b85396e80?, 0xc0016e7f90?}, {0x36f79e0, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamEndpoints(0xc0020b6b30?, {0x3bc6d60, 0xc0016e7f90})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:121 +0x70
github.com/cilium/proxy/go/envoy/service/endpoint/v3._EndpointDiscoveryService_StreamEndpoints_Handler({0x34ffc60?, 0xc001a457b8}, {0x3bc0368?, 0xc00315d770})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:338 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001171e00, {0x3bcc8e0, 0xc00288b1e0}, 0xc0001adb00, 0xc001accde0, 0x58808a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001171e00, {0x3bcc8e0, 0xc00288b1e0}, 0xc0001adb00, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 1028 [sleep]:
time.Sleep(0x12a05f200)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer(0xc000df96b0)
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:123 +0x54d
created by github.com/cilium/cilium/cilium-health/launch.Launch
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:68 +0x225

goroutine 955 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0013bcc80)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 956 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0021f42d0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00004d320, {0xc000fcba10, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0021f42d0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 940 [syscall, 1 minutes]:
syscall.Syscall6(0x20?, 0x80000000000?, 0xc001e49958?, 0x4eaee6?, 0xc000082180?, 0xc001e49a08?, 0x4eae23?)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x36
golang.org/x/sys/unix.EpollWait(0x0?, {0xc0013de480?, 0xc000082180?, 0xc001e499f0?}, 0xc001e49a70?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_amd64.go:56 +0x58
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:125
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0xc00138ab40, {0xc0013de480?, 0x20, 0x20}, {0x0?, 0xc001e49ac0?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x2b4
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0xc0007c66c0, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:345 +0x2d6
github.com/cilium/ebpf/perf.(*Reader).Read(0xc000199e30?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:319 +0x46
github.com/cilium/cilium/pkg/signal.(*signalManager).start.func1()
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:266 +0x8d
created by github.com/cilium/cilium/pkg/signal.(*signalManager).start
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:263 +0x12c

goroutine 1496 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc002c10cd0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00097fb00, {0xc000dff7e0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc002c10cd0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1012 [select, 1 minutes]:
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).cycle(0xc00174f180, {0x3bb5780, 0xc0014d13b0}, 0x413bb7?, 0xc00216e000)
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:115 +0x1cb
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).run(0xc00174f180, {0x3bb5780, 0xc0014d13b0})
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:93 +0xd1
github.com/cilium/cilium/pkg/hive/job.(*jobOneShot).start(0xc0000cf630, {0x3bb5780, 0xc0014d13b0}, 0xc0007c4ea0?, {{{0xc001117480, 0x1, 0x1}}, {0x3be6410, 0xc00174f0a0}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:267 +0x530
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 1106 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc0028ad900, {0xc00094cb38, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc0028ad900, {0xc00094cb38?, 0xc0028da9a8?, 0xc002ca3560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc002d10d80, {0xc00094cb38?, 0xc002ca35d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc002d10d80}, {0xc00094cb38, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc002d1a900, {0xc00094cb38, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc00094cb28, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc002ca37a8?, 0xc002d1a900, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7f3b85801a90, 0x5e20750}, 0xc002ca39f8?, {0x0?, 0x0?}, {0x3472d60, 0xc002698c80}, 0xc00137daa0?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc002b9e0f0, {0x3472d60?, 0xc002698c80})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/listener/v3.(*listenerDiscoveryServiceStreamListenersServer).Recv(0xc001098f20)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:378 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc000ffd4d0?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 957 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x14?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0008a9980?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 958 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00004d7a0, {0xc0004aca10, 0x0, 0xc000df8cc0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0021f4370}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2365 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001dfa226, 0x10, 0x1a}, {0xc001f29260, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1219 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc002192fd0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001214260?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 938 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1.1()
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:417 +0xcd
created by github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:413 +0x9b

goroutine 1218 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc000a18460})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000c7b680, {0xc001110460, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc000a18460}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 962 [select, 1 minutes]:
github.com/cilium/cilium/pkg/stream.FromChannel[...].func1.1()
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:109 +0xde
created by github.com/cilium/cilium/pkg/stream.FromChannel[...].func1
	/go/src/github.com/cilium/cilium/pkg/stream/sources.go:106 +0xea

goroutine 1025 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00004dd40, {0xc000c7e9c0, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0021f4870}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1011 [select]:
github.com/cilium/cilium/pkg/hive/job.(*jobTimer).start(0xc0000cf4a0, {0x3bb5780, 0xc0014d0ea0}, 0x2020202020202020?, {{{0x0, 0x0, 0x0}}, {0x3be6500, 0xc001a8c200}, {0x3b77da0, ...}})
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:384 +0x3c5
created by github.com/cilium/cilium/pkg/hive/job.(*group).Start.func1
	/go/src/github.com/cilium/cilium/pkg/hive/job/job.go:137 +0x158

goroutine 2246 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000f3e186, 0x10, 0x1a}, {0xc000fe7f50, 0x24}, 0xc0014041b0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1037 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1038 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1039 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1040 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1041 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1042 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1043 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1044 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1045 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:152 +0x145
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe
	/go/src/github.com/cilium/cilium/pkg/status/status.go:142 +0x72

goroutine 1046 [IO wait]:
internal/poll.runtime_pollWait(0x7f3b858773c8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc001646480?, 0x4?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc001646480)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc001646480)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*TCPListener).accept(0xc000efc390)
	/usr/local/go/src/net/tcpsock_posix.go:148 +0x25
net.(*TCPListener).Accept(0xc000efc390)
	/usr/local/go/src/net/tcpsock.go:297 +0x3d
net/http.(*Server).Serve(0xc0013ae1e0, {0x3bb3640, 0xc000efc390})
	/usr/local/go/src/net/http/server.go:3059 +0x385
github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService.func2({0xc0010be8d0, 0xe}, {0x3bb3640, 0xc000efc390})
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:75 +0xdb
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:70 +0x6aa

goroutine 2305 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001c5aa00})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001cffe60, {0xc000731330, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001c5aa00}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1049 [IO wait]:
internal/poll.runtime_pollWait(0x7f3b857fbe68, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc002a80f00?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc002a80f00)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc002a80f00)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*UnixListener).accept(0x46e74e?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x1c
net.(*UnixListener).Accept(0xc002aca7b0)
	/usr/local/go/src/net/unixsock.go:260 +0x3d
net/http.(*Server).Serve(0xc002a4b680, {0x3bb3670, 0xc002aca7b0})
	/usr/local/go/src/net/http/server.go:3059 +0x385
github.com/cilium/cilium/api/v1/server.(*Server).Start.func1({0x3bb3670?, 0xc002aca7b0?})
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:433 +0x85
created by github.com/cilium/cilium/api/v1/server.(*Server).Start
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:431 +0x552

goroutine 2341 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x284f97f?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0013bcf00?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2183 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0026fed80, {0xc001db4ac8, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0017a07d0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1293 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0013bd180)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2008 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7f3b85500b40, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc002898800?, 0xc000d88b00?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002898800, {0xc000d88b00, 0x580, 0x580})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc002898800, {0xc000d88b00?, 0xc000d88b05?, 0x2f?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc001403358, {0xc000d88b00?, 0x3bb5710?, 0xc00187f6b0?})
	/usr/local/go/src/net/net.go:183 +0x45
crypto/tls.(*atLeastReader).Read(0xc0004347e0, {0xc000d88b00?, 0xc0004347e0?, 0x0?})
	/usr/local/go/src/crypto/tls/conn.go:788 +0x3d
bytes.(*Buffer).ReadFrom(0xc00187f790, {0x3b720a0, 0xc0004347e0})
	/usr/local/go/src/bytes/buffer.go:202 +0x98
crypto/tls.(*Conn).readFromUntil(0xc00187f500, {0x3b88060?, 0xc001403358}, 0x580?)
	/usr/local/go/src/crypto/tls/conn.go:810 +0xe5
crypto/tls.(*Conn).readRecordOrCCS(0xc00187f500, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:617 +0x116
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:583
crypto/tls.(*Conn).Read(0xc00187f500, {0xc0015e6000, 0x8000, 0xc00235acc8?})
	/usr/local/go/src/crypto/tls/conn.go:1316 +0x16f
bufio.(*Reader).Read(0xc000a176e0, {0xc001ce6820, 0x9, 0xc00235acf0?})
	/usr/local/go/src/bufio/bufio.go:237 +0x1bb
io.ReadAtLeast({0x3b71ea0, 0xc000a176e0}, {0xc001ce6820, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
golang.org/x/net/http2.readFrameHeader({0xc001ce6820?, 0x9?, 0x3b86be0?}, {0x3b71ea0?, 0xc000a176e0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x6e
golang.org/x/net/http2.(*Framer).ReadFrame(0xc001ce67e0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x95
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0xc00151fd40, 0x0?, 0x100000000000000?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:642 +0x167
google.golang.org/grpc.(*Server).serveStreams(0xc00276a000, {0x3bcc8e0?, 0xc00151fd40})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:946 +0x162
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:889 +0x46
created by google.golang.org/grpc.(*Server).handleRawConn
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:888 +0x185

goroutine 1007 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0xc00288b1e0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1155 +0x233
created by google.golang.org/grpc/internal/transport.NewServerTransport
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:344 +0x1bf8

goroutine 1006 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0xc0028ac280, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x115
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0xc000169c70)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x91
google.golang.org/grpc/internal/transport.NewServerTransport.func2()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:341 +0xda
created by google.golang.org/grpc/internal/transport.NewServerTransport
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:338 +0x1bb3

goroutine 1094 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0x7f3b857fbaa8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc002745880?, 0xc00159d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002745880, {0xc00159d000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc002745880, {0xc00159d000?, 0x4e7b66?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc0005be1c8, {0xc00159d000?, 0x0?, 0xc002c93358?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*connReader).Read(0xc002c93350, {0xc00159d000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:782 +0x171
bufio.(*Reader).fill(0xc000aa5680)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc000aa5680, 0x4)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*conn).serve(0xc0027643f0, {0x3bb5780, 0xc002aca930})
	/usr/local/go/src/net/http/server.go:2030 +0x77c
created by net/http.(*Server).Serve
	/usr/local/go/src/net/http/server.go:3089 +0x5ed

goroutine 1008 [IO wait]:
internal/poll.runtime_pollWait(0x7f3b857fbf58, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc0015afe00?, 0xc0028c2000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0015afe00, {0xc0028c2000, 0x8000, 0x8000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc0015afe00, {0xc0028c2000?, 0x1060100000000?, 0x8?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000bea6b0, {0xc0028c2000?, 0xc002c0e820?, 0x0?})
	/usr/local/go/src/net/net.go:183 +0x45
bufio.(*Reader).Read(0xc0007ff020, {0xc001b2cac0, 0x9, 0x0?})
	/usr/local/go/src/bufio/bufio.go:237 +0x1bb
io.ReadAtLeast({0x3b71ea0, 0xc0007ff020}, {0xc001b2cac0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
golang.org/x/net/http2.readFrameHeader({0xc001b2cac0?, 0x9?, 0xc002a14960?}, {0x3b71ea0?, 0xc0007ff020?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x6e
golang.org/x/net/http2.(*Framer).ReadFrame(0xc001b2ca80)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x95
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0xc00288b1e0, 0xc00139e748?, 0x405dbd?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:642 +0x167
google.golang.org/grpc.(*Server).serveStreams(0xc001171e00, {0x3bcc8e0?, 0xc00288b1e0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:946 +0x162
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:889 +0x46
created by google.golang.org/grpc.(*Server).handleRawConn
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:888 +0x185

goroutine 1122 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc0028ac410, {0xc001d82a30, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc0028ac410, {0xc001d82a30?, 0xc0028da018?, 0xc002ed3560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc0028c03f0, {0xc001d82a30?, 0xc002ed35d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc0028c03f0}, {0xc001d82a30, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc0028a57a0, {0xc001d82a30, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc001d82a20, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc002ed37a8?, 0xc0028a57a0, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7f3b85801a90, 0x5e20750}, 0xc002ed39f8?, {0x0?, 0x0?}, {0x3472d60, 0xc0033c6d20}, 0xc0007ff140?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc0028e6000, {0x3472d60?, 0xc0033c6d20})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/cluster/v3.(*clusterDiscoveryServiceStreamClustersServer).Recv(0xc000f999f0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:351 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc000184b60?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 1124 [select]:
reflect.rselect({0xc0001afb00, 0x9, 0xc002cae798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc001596200?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001a457b8, {0x3bb5780, 0xc002c92b40}, 0xc000178700, {0x7f3b85731b50, 0xc001098f20}, 0xc0015c4720, {0x36cf89b?, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001a457b8, {0x3bb5780, 0xc002c92b40}, {0x7f3b85731b50?, 0xc001098f20?}, {0x36cf89b, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamListeners(0xc0003e1b30?, {0x3bc6e10, 0xc001098f20})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:79 +0x70
github.com/cilium/proxy/go/envoy/service/listener/v3._ListenerDiscoveryService_StreamListeners_Handler({0x34ffc60?, 0xc001a457b8}, {0x3bc0368?, 0xc002b9e0f0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:359 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001171e00, {0x3bcc8e0, 0xc00288b1e0}, 0xc002d1a900, 0xc001accf90, 0x5880900, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001171e00, {0x3bcc8e0, 0xc00288b1e0}, 0xc002d1a900, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 2553 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc000131090, {0xc001dd2e08, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc000131090, {0xc001dd2e08?, 0xc0046735d8?, 0xc0011f3560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc0033bad20, {0xc001dd2e08?, 0xc0011f35d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc0033bad20}, {0xc001dd2e08, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc0001adb00, {0xc001dd2e08, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc001dd2df8, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc0011f37a8?, 0xc0001adb00, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7f3b85801a90, 0x5e20750}, 0xc0011f39f8?, {0x0?, 0x0?}, {0x3472d60, 0xc0048d23c0}, 0xc0028faa80?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc00315d770, {0x3472d60?, 0xc0048d23c0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/endpoint/v3.(*endpointDiscoveryServiceStreamEndpointsServer).Recv(0xc0016e7f90)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:357 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc0028faa20?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 1126 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/health/server.(*Server).Serve(0xc00144a200)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:373 +0xee
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer.func1()
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:91 +0x77
created by github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:89 +0x1e5

goroutine 1168 [IO wait]:
internal/poll.runtime_pollWait(0x7f3b857fc138, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc002c64a80?, 0xc004c1c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadFrom(0xc002c64a80, {0xc004c1c000, 0x200, 0x200})
	/usr/local/go/src/internal/poll/fd_unix.go:223 +0x2ab
net.(*netFD).readFrom(0xc002c64a80, {0xc004c1c000?, 0x7f3b84edaad8?, 0x72?})
	/usr/local/go/src/net/fd_posix.go:61 +0x29
net.(*IPConn).readFrom(0xc00259ee68?, {0xc004c1c000, 0x200, 0x200})
	/usr/local/go/src/net/iprawsock_posix.go:49 +0x32
net.(*IPConn).ReadFrom(0xc000bce1a8, {0xc004c1c000?, 0xc000a84208?, 0xc00259eea8?})
	/usr/local/go/src/net/iprawsock.go:129 +0x31
golang.org/x/net/icmp.(*PacketConn).ReadFrom(0xc1360ffb903ae588?, {0xc004c1c000?, 0x58c5060?, 0x58c5060?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/icmp/endpoint.go:58 +0x30
github.com/servak/go-fastping.(*Pinger).recvICMP(0xc000a841b0, 0xc00138a400, 0xc00267f260, 0xc00138a420, 0xc002afde90?)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:570 +0x145
created by github.com/servak/go-fastping.(*Pinger).run
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:425 +0x398

goroutine 1101 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc002c10f00})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002c546c0, {0xc000dff570, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc002c10f00}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1102 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x2a85c9f?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001b63f78?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1103 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002c54b40, {0xc0001c9b90, 0x0, 0xc002c4e720, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002c10fa0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2563 [select]:
reflect.rselect({0xc002920000, 0x9, 0xc00492a798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc003861e00?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001a457b8, {0x3bb5780, 0xc0043958f0}, 0xc00060c5b0, {0x7f3b857d26d0, 0xc0016e7c70}, 0xc0021d9260, {0x3696c3c?, 0x28})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001a457b8, {0x3bb5780, 0xc0043958f0}, {0x7f3b857d26d0?, 0xc0016e7c70?}, {0x3696c3c, 0x28})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamNetworkPolicies(0xc0007ddb30?, {0x3bc6ba8, 0xc0016e7c70})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:145 +0x70
github.com/cilium/proxy/go/cilium/api._NetworkPolicyDiscoveryService_StreamNetworkPolicies_Handler({0x34ffc60?, 0xc001a457b8}, {0x3bc0368?, 0xc00315d680})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/cilium/api/npds.pb.go:1690 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001171e00, {0x3bcc8e0, 0xc00288b1e0}, 0xc002efeea0, 0xc001acd020, 0x5876d00, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001171e00, {0x3bcc8e0, 0xc00288b1e0}, 0xc002efeea0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 1137 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002c54fc0, {0xc000a15500, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002c11310}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1576 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0013bd4a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1398 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0011daaa0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2387 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0013080a6, 0x10, 0x1a}, {0xc00211c510, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2582 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001a8fa50, 0x1)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0002c09a0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc001a8fa00, {0x3bb56d8, 0xc0001315e0}, {0xc000ef3380, 0x33}, 0x6, {0xc001ba1b65, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 2549 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc00386e2d0, {0xc001dd2bc8, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc00386e2d0, {0xc001dd2bc8?, 0xc001b00810?, 0xc001bbf560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc00487ed80, {0xc001dd2bc8?, 0xc001bbf5d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc00487ed80}, {0xc001dd2bc8, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc002efeea0, {0xc001dd2bc8, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc001dd2bb8, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc001bbf7a8?, 0xc002efeea0, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7f3b85801a90, 0x5e20750}, 0xc001bbf9f8?, {0x0?, 0x0?}, {0x3472d60, 0xc000b58be0}, 0xc002596ea0?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc00315d680, {0x3472d60?, 0xc000b58be0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/cilium/api.(*networkPolicyDiscoveryServiceStreamNetworkPoliciesServer).Recv(0xc0016e7c70)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/cilium/api/npds.pb.go:1709 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc00136f8c0?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 2581 [select]:
reflect.rselect({0xc002c54120, 0x9, 0xc004a94798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc003771800?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001a457b8, {0x3bb5780, 0xc00429a9f0}, 0xc001aff2d0, {0x7f3b85396e80, 0xc000f91330}, 0xc002d759e0, {0x36f79e0?, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001a457b8, {0x3bb5780, 0xc00429a9f0}, {0x7f3b85396e80?, 0xc000f91330?}, {0x36f79e0, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamEndpoints(0xc001675b30?, {0x3bc6d60, 0xc000f91330})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:121 +0x70
github.com/cilium/proxy/go/envoy/service/endpoint/v3._EndpointDiscoveryService_StreamEndpoints_Handler({0x34ffc60?, 0xc001a457b8}, {0x3bc0368?, 0xc0026453b0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:338 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001171e00, {0x3bcc8e0, 0xc00288b1e0}, 0xc0001add40, 0xc001accde0, 0x58808a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001171e00, {0x3bcc8e0, 0xc00288b1e0}, 0xc0001add40, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 1498 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0014b4120, {0xc0002e4620, 0x0, 0xc0037059e0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002c10d70}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2580 [select]:
reflect.rselect({0xc002e250e0, 0x9, 0xc004aa0798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc0040d2a00?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001a457b8, {0x3bb5780, 0xc00487f320}, 0xc001e53180, {0x7f3b85396e80, 0xc0013fc780}, 0xc00248cfc0, {0x36f79e0?, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001a457b8, {0x3bb5780, 0xc00487f320}, {0x7f3b85396e80?, 0xc0013fc780?}, {0x36f79e0, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamEndpoints(0xc001674b30?, {0x3bc6d60, 0xc0013fc780})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:121 +0x70
github.com/cilium/proxy/go/envoy/service/endpoint/v3._EndpointDiscoveryService_StreamEndpoints_Handler({0x34ffc60?, 0xc001a457b8}, {0x3bc0368?, 0xc0013afb30})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:338 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001171e00, {0x3bcc8e0, 0xc00288b1e0}, 0xc0001adc20, 0xc001accde0, 0x58808a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001171e00, {0x3bcc8e0, 0xc00288b1e0}, 0xc0001adc20, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 720 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001a6d320, {0xc001110700, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0001314f0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1155 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001d5d4c6, 0x10, 0x1a}, {0xc000ef4cf0, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1160 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0011cb200, {0xc00087e570, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000d826e0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2978 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000b58460)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2174 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0011db0e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 4106 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0015d66c0, {0xc001389a20, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc003eae2d0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1182 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001dfa586, 0x10, 0x1a}, {0xc001854cc0, 0x24}, 0xc0008a99e0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1397 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0015a2900, {0xc003bfe280, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0001e43c0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1433 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0010ee000, {0xc001111650, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00381edc0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1233 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000d308c0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1253 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000c75246, 0x10, 0x1a}, {0xc0014944e0, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1235 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc000a194f0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0007b30e0, {0xc0000bb320, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc000a194f0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1236 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0xdf8475800?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc002003200?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1237 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0007b3c20, {0xc001e53b20, 0x0, 0xc002c73470, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000a19590}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1322 [select]:
github.com/servak/go-fastping.(*Pinger).run(0xc000a841b0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:439 +0x611
created by github.com/servak/go-fastping.(*Pinger).RunLoop
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:362 +0x14a

goroutine 1393 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0004cb560, {0xc00013d880, 0x0, 0xc001595c50, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002d2d4a0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1296 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc00094d1d0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2982 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0003e8a20, {0xc0005f4e00, 0x0, 0xc0005b97a0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0027fc640}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 508 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0003e7440, {0xc000dffe80, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0038b7680}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1134 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc00078c9d8?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1135 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0014fd200, {0xc0001cac40, 0x0, 0xc000faf0e0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000d82be0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1262 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0011eaaa0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1336 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0011eabe0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1295 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc002d2d400})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0004cb0e0, {0xc00101efc0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc002d2d400}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2354 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001f21d60})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002973200, {0xc000bc8230, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001f21d60}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1347 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0009e0fe6, 0x10, 0x1a}, {0xc001f8c780, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2381 [select]:
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:103 +0x71
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:102 +0x10a

goroutine 1324 [IO wait]:
internal/poll.runtime_pollWait(0x7f3b857fbc88, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc00180ef80?, 0x20?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc00180ef80)
	/usr/local/go/src/internal/poll/fd_unix.go:614 +0x2bd
net.(*netFD).accept(0xc00180ef80)
	/usr/local/go/src/net/fd_unix.go:172 +0x35
net.(*UnixListener).accept(0x46e74e?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x1c
net.(*UnixListener).Accept(0xc000da37d0)
	/usr/local/go/src/net/unixsock.go:260 +0x3d
net/http.(*Server).Serve(0xc002a4a0f0, {0x3bb3670, 0xc000da37d0})
	/usr/local/go/src/net/http/server.go:3059 +0x385
github.com/cilium/cilium/api/v1/health/server.(*Server).Start.func1({0x3bb3670?, 0xc000da37d0?})
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:326 +0x85
created by github.com/cilium/cilium/api/v1/health/server.(*Server).Start
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:324 +0x52f

goroutine 2006 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0xc000fe30e0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x115
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0xc002029ab0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x91
google.golang.org/grpc/internal/transport.NewServerTransport.func2()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:341 +0xda
created by google.golang.org/grpc/internal/transport.NewServerTransport
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:338 +0x1bb3

goroutine 1357 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0014797a0, {0xc000c2e430, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0008c8c80}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1338 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc000add1d0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0010efd40, {0xc000fd2d50, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc000add1d0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1339 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc0014edb60?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1340 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0010f6240, {0xc0004ac540, 0x0, 0xc00136f4d0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000add270}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1061 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0001aea20, {0xc0006c3e50, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000add310}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1323 [select]:
github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:334 +0x8a
created by github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:330 +0x65

goroutine 1772 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001a7c5a0, {0xc00011de30, 0x0, 0xc003256000, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002488370}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1377 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0001946c0, {0xc002083860, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000add7c0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1165 [IO wait]:
internal/poll.runtime_pollWait(0x7f3b857fb6e8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc002c64880?, 0xc0008e4000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc002c64880, {0xc0008e4000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc002c64880, {0xc0008e4000?, 0x2?, 0x588a5a0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000bce138, {0xc0008e4000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*persistConn).Read(0xc000a54c60, {0xc0008e4000?, 0x44d520?, 0xc0020b2ec8?})
	/usr/local/go/src/net/http/transport.go:1943 +0x4e
bufio.(*Reader).fill(0xc00267efc0)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc00267efc0, 0x1)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*persistConn).readLoop(0xc000a54c60)
	/usr/local/go/src/net/http/transport.go:2107 +0x1ac
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1765 +0x16ea

goroutine 1166 [select]:
net/http.(*persistConn).writeLoop(0xc000a54c60)
	/usr/local/go/src/net/http/transport.go:2410 +0xf2
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1766 +0x173d

goroutine 1562 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0014fc120, {0xc0007a8198, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0001d5ef0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1578 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc005368190})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000951320, {0xc000dd4f00, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc005368190}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2578 [select]:
reflect.rselect({0xc0014fc7e0, 0x9, 0xc004a9c798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc003771a00?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001a457b8, {0x3bb5780, 0xc00429ac00}, 0xc001aff5e0, {0x7f3b85396e80, 0xc000f91450}, 0xc002d75b00, {0x36f79e0?, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001a457b8, {0x3bb5780, 0xc00429ac00}, {0x7f3b85396e80?, 0xc000f91450?}, {0x36f79e0, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamEndpoints(0xc002394b30?, {0x3bc6d60, 0xc000f91450})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:121 +0x70
github.com/cilium/proxy/go/envoy/service/endpoint/v3._EndpointDiscoveryService_StreamEndpoints_Handler({0x34ffc60?, 0xc001a457b8}, {0x3bc0368?, 0xc0026454a0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:338 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001171e00, {0x3bcc8e0, 0xc00288b1e0}, 0xc0001ad9e0, 0xc001accde0, 0x58808a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001171e00, {0x3bcc8e0, 0xc00288b1e0}, 0xc0001ad9e0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 2340 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001e99db0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029210e0, {0xc00126c740, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001e99db0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1497 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x284f97f?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00126de60?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2562 [select]:
net/http.(*persistConn).writeLoop(0xc002efed80)
	/usr/local/go/src/net/http/transport.go:2410 +0xf2
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1766 +0x173d

goroutine 2298 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000c752a6, 0x10, 0x1a}, {0xc001ebe1e0, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1375 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0010f99e0, {0xc00140b2e0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0008c8690}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2839 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001a8fad0, 0x26)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc00140b190?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc001a8fa80, {0x3bb56d8, 0xc0021da820}, {0xc00270aa00, 0x42}, 0xe, {0xc0009e1fa5, 0x9}, {0xc00140b190, 0x1, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 1400 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0003c9540})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001704900, {0xc0000bbf80, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0003c9540}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1327 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0003e8ea0, {0xc00075eba0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000a19ae0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1401 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x284f966?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00101e910?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1402 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001704d80, {0xc00015bab0, 0x0, 0xc000ec33e0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0003c95e0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2676 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0021f5540})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0003e6fc0, {0xc0011571c0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0021f5540}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2548 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000c7b560, {0xc0013d96b0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002919950}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2355 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc00185c501?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00082a480?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1539 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000c54c60, {0xc001cdd2a8, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000504230}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2099 [semacquire, 1 minutes]:
sync.runtime_Semacquire(0x5?)
	/usr/local/go/src/runtime/sema.go:62 +0x27
sync.(*WaitGroup).Wait(0x0?)
	/usr/local/go/src/sync/waitgroup.go:116 +0x4b
golang.org/x/sync/errgroup.(*Group).Wait(0xc00152c9c0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:53 +0x27
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify(0xc00115ae80, 0x32b8e80?, {0x3bc2a20?, 0xc00102bef0})
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:107 +0x43b
github.com/cilium/cilium/api/v1/peer._Peer_Notify_Handler({0x3027f60?, 0xc00115ae80}, {0x3bc0368, 0xc0036881e0})
	/go/src/github.com/cilium/cilium/api/v1/peer/peer_grpc.pb.go:114 +0xd0
google.golang.org/grpc.(*Server).processStreamingRPC(0xc00276a000, {0x3bcc8e0, 0xc00151fd40}, 0xc00039c900, 0xc0027506f0, 0x5876aa0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc00276a000, {0x3bcc8e0, 0xc00151fd40}, 0xc00039c900, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 2261 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000fae8d0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2346 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0001ad440, {0xc000c2f050, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0021dbb80}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1557 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002d1b200, {0xc0010797f0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0001d4aa0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1579 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x284f966?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1580 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0009517a0, {0xc00035aaf0, 0x0, 0xc005366780, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc005368230}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1665 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0011d3c20, {0xc0002f9960, 0x0, 0xc001081f50, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0053688c0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1600 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x2540be400?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0014b4120?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 1599 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc005368820})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0011d37a0, {0xc001389180, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc005368820}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2356 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029738c0, {0xc00029abd0, 0x0, 0xc001d6aba0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001f21e00}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2240 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001e98f00})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000ef9440, {0xc0012c61b0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001e98f00}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2301 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000c752c6, 0x10, 0x1a}, {0xc001ebe240, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2472 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc003628280)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1494 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc003628960)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2410 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001dfa406, 0x10, 0x1a}, {0xc001f299e0, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 1596 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0011d2a20, {0xc0009303a8, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc005369680}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2421 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001308486, 0x10, 0x1a}, {0xc00211cc00, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2100 [select, 1 minutes]:
github.com/cilium/cilium/pkg/hubble/peer.(*Service).Notify.func1()
	/go/src/github.com/cilium/cilium/pkg/hubble/peer/service.go:59 +0xcf
golang.org/x/sync/errgroup.(*Group).Go.func1()
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:75 +0x64
created by golang.org/x/sync/errgroup.(*Group).Go
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/errgroup/errgroup.go:72 +0xa5

goroutine 1644 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001f9c5a0, {0xc000531c50, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000529400}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2990 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002ca7200, {0xc000477098, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0027fd9a0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1671 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0015a2000, {0xc0014ed218, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc005369950}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2540 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc000130960, {0xc0008ac418, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc000130960, {0xc0008ac418?, 0xc004673590?, 0xc001add560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc0033baa80, {0xc0008ac418?, 0xc001add5d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc0033baa80}, {0xc0008ac418, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc0001ad8c0, {0xc0008ac418, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc0008ac408, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc001add7a8?, 0xc0001ad8c0, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7f3b85801a90, 0x5e20750}, 0xc001add9f8?, {0x0?, 0x0?}, {0x3472d60, 0xc0049da820}, 0xc00137dd40?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc0028e6c30, {0x3472d60?, 0xc0049da820})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/endpoint/v3.(*endpointDiscoveryServiceStreamEndpointsServer).Recv(0xc003c19330)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:357 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc002905f20?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 2238 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0036285a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2833 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00039d680, {0xc001368378, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002694c30}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1997 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0026ff0e0, {0xc0002b0270, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001ec6ff0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2532 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0004197a0, {0xc000c2e910, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0017a12c0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2674 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc003629720)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2258 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0028ffae0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2402 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001dfa346, 0x10, 0x1a}, {0xc001f29830, 0x24}, 0xc0013d85d0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2224 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0006d1540)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 1771 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc00535efd0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001214cc0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2529 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002c55d40, {0xc0013ed1a0, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00237f9f0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2577 [select]:
reflect.rselect({0xc001705560, 0x9, 0xc003f44798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc0049cd000?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001a457b8, {0x3bb5780, 0xc0049e13b0}, 0xc0001d9b90, {0x7f3b85396e80, 0xc003c19330}, 0xc001e76ea0, {0x36f79e0?, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001a457b8, {0x3bb5780, 0xc0049e13b0}, {0x7f3b85396e80?, 0xc003c19330?}, {0x36f79e0, 0x42})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamEndpoints(0xc004cf6b30?, {0x3bc6d60, 0xc003c19330})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:121 +0x70
github.com/cilium/proxy/go/envoy/service/endpoint/v3._EndpointDiscoveryService_StreamEndpoints_Handler({0x34ffc60?, 0xc001a457b8}, {0x3bc0368?, 0xc0028e6c30})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:338 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001171e00, {0x3bcc8e0, 0xc00288b1e0}, 0xc0001ad8c0, 0xc001accde0, 0x58808a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001171e00, {0x3bcc8e0, 0xc00288b1e0}, 0xc0001ad8c0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 2216 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0009afd86, 0x10, 0x1a}, {0xc001f287b0, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2331 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000f3e666, 0x10, 0x1a}, {0xc001fac2a0, 0x24}, 0xc00136f8c0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2328 [sleep, 1 minutes]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000f3e646, 0x10, 0x1a}, {0xc001fac240, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2335 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000b588c0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2564 [select]:
reflect.rselect({0xc0016cb440, 0x9, 0xc004926798?})
	/usr/local/go/src/runtime/select.go:589 +0x2ee
reflect.Select({0xc00351a600?, 0x9, 0x3669d80?})
	/usr/local/go/src/reflect/value.go:3052 +0x58a
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0xc001a457b8, {0x3bb5780, 0xc003f4a600}, 0xc0020d91f0, {0x7f3b85396848, 0xc000c82a40}, 0xc001e76180, {0x36e8b90?, 0x3c})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:261 +0xa45
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0xc001a457b8, {0x3bb5780, 0xc003f4a600}, {0x7f3b85396848?, 0xc000c82a40?}, {0x36e8b90, 0x3c})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:172 +0x365
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamRoutes(0xc001eeeb30?, {0x3bc6ec0, 0xc000c82a40})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:93 +0x70
github.com/cilium/proxy/go/envoy/service/route/v3._RouteDiscoveryService_StreamRoutes_Handler({0x34ffc60?, 0xc001a457b8}, {0x3bc0368?, 0xc00271e000})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/route/v3/rds.pb.go:346 +0x9f
google.golang.org/grpc.(*Server).processStreamingRPC(0xc001171e00, {0x3bcc8e0, 0xc00288b1e0}, 0xc002efefc0, 0xc001accf00, 0x5880920, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1631 +0x1384
google.golang.org/grpc.(*Server).handleStream(0xc001171e00, {0x3bcc8e0, 0xc00288b1e0}, 0xc002efefc0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1718 +0x9f0
google.golang.org/grpc.(*Server).serveStreams.func1.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x98
created by google.golang.org/grpc.(*Server).serveStreams.func1
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:957 +0x18c

goroutine 2282 [select, 1 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001d11860})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029fc120, {0xc0017c1e00, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001d11860}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2283 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0013cd880?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2284 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029fc5a0, {0xc000205ce0, 0x0, 0xc0008aadb0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001d11900}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2527 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc00335a460)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2371 [IO wait]:
internal/poll.runtime_pollWait(0x7f3b857fb238, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc0038bb480?, 0xc002019000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0038bb480, {0xc002019000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc0038bb480, {0xc002019000?, 0x2?, 0x588a5a0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc001403598, {0xc002019000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*persistConn).Read(0xc001bade60, {0xc002019000?, 0x44d520?, 0xc002354ec8?})
	/usr/local/go/src/net/http/transport.go:1943 +0x4e
bufio.(*Reader).fill(0xc001ffe6c0)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc001ffe6c0, 0x1)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*persistConn).readLoop(0xc001bade60)
	/usr/local/go/src/net/http/transport.go:2107 +0x1ac
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1765 +0x16ea

goroutine 2372 [select]:
net/http.(*persistConn).writeLoop(0xc001bade60)
	/usr/local/go/src/net/http/transport.go:2410 +0xf2
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1766 +0x173d

goroutine 2000 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001a8f9d0, 0x2)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0002c09a0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc001a8f980, {0x3bb56d8, 0xc001ec7310}, {0xc003071f40, 0x3c}, 0x3, {0xc0009e0725, 0x9}, {0xc000f65db0, 0x1, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 2383 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc000131450, {0xc001cdde58, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc000131450, {0xc001cdde58?, 0xc004673620?, 0xc002375560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc0033bafc0, {0xc001cdde58?, 0xc0023755d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc0033bafc0}, {0xc001cdde58, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc0001add40, {0xc001cdde58, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc001cdde48, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc0023757a8?, 0xc0001add40, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7f3b85801a90, 0x5e20750}, 0xc0023759f8?, {0x0?, 0x0?}, {0x3472d60, 0xc00264c820}, 0xc0021f6f00?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc0026453b0, {0x3472d60?, 0xc00264c820})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/endpoint/v3.(*endpointDiscoveryServiceStreamEndpointsServer).Recv(0xc000f91330)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:357 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc00275aa20?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 2557 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001d5c7a6, 0x10, 0x1a}, {0xc001cfa210, 0x24}, 0xc00358d9e0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2514 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0027410e0, {0xc001d6e810, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00376e6e0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2531 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002c57200, {0xc0009c8378, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0021dab40}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2561 [IO wait]:
internal/poll.runtime_pollWait(0x7f3b85500a50, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc0049f0a80?, 0xc004891000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0049f0a80, {0xc004891000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc0049f0a80, {0xc004891000?, 0x43c147?, 0xc001b6ac30?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc000a1f8c0, {0xc004891000?, 0x0?, 0xc0007cd1e0?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*persistConn).Read(0xc002efed80, {0xc004891000?, 0xc002d75320?, 0xc001b6ad30?})
	/usr/local/go/src/net/http/transport.go:1943 +0x4e
bufio.(*Reader).fill(0xc002905da0)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc002905da0, 0x1)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*persistConn).readLoop(0xc002efed80)
	/usr/local/go/src/net/http/transport.go:2107 +0x1ac
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1765 +0x16ea

goroutine 2981 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc001d62918?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2471 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0017bd680, {0xc003bfe850, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002488b40}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2980 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0027fc460})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0003e85a0, {0xc0003bde60, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0027fc460}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2733 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0011da280)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2753 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002921b00, {0xc001dd2960, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00237f130}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1765 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002effb00, {0xc001da65d0, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002488500}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3222 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc00134c050})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001ab58c0, {0xc001036420, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc00134c050}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2468 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002828360, {0xc0017b4e58, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0021da8c0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2474 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc002488f50})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002d1ac60, {0xc001036cf0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc002488f50}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2475 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc001795b01?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0009c3a40?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2476 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002d1b440, {0xc0003719d0, 0x0, 0xc002143fb0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002488ff0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2545 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001a7de60, {0xc0017b4db0, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002489590}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2677 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc0028ad950?, 0xc002895680?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0028faa20?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2567 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0xc000131220, {0xc001da6ee0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:183 +0x90
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0xc000131220, {0xc001da6ee0?, 0xc004673608?, 0xc002103560?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:177 +0x178
google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc0033bae70, {0xc001da6ee0?, 0xc0021035d8?, 0x125b807?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:514 +0x32
io.ReadAtLeast({0x3b86c40, 0xc0033bae70}, {0xc001da6ee0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:332 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:351
google.golang.org/grpc/internal/transport.(*Stream).Read(0xc0001adc20, {0xc001da6ee0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:498 +0xac
google.golang.org/grpc.(*parser).recvMsg(0xc001da6ed0, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:597 +0x47
google.golang.org/grpc.recvAndDecompress(0xc0021037a8?, 0xc0001adc20, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:729 +0x66
google.golang.org/grpc.recv(0x406571?, {0x7f3b85801a90, 0x5e20750}, 0xc0021039f8?, {0x0?, 0x0?}, {0x3472d60, 0xc0036292c0}, 0xc001ae72c0?, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:795 +0x6e
google.golang.org/grpc.(*serverStream).RecvMsg(0xc0013afb30, {0x3472d60?, 0xc0036292c0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1712 +0x178
github.com/cilium/proxy/go/envoy/service/endpoint/v3.(*endpointDiscoveryServiceStreamEndpointsServer).Recv(0xc0013fc780)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/endpoint/v3/eds.pb.go:357 +0x4c
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0xc001e53180?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:139 +0xe8
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:136 +0x31a

goroutine 2573 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001a8fad0, 0x25)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc001a8faa8?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc001a8fa80, {0x3bb56d8, 0xc0000cf180}, {0xc002497bd0, 0x42}, 0x8, {0xc000bdfce5, 0x9}, {0xc0005dee30, 0x1, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 2974 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc00293c5a0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000c7a240, {0xc0010255d0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc00293c5a0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4192 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0048d2aa0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2576 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc00123f506, 0x10, 0x1a}, {0xc0011c3d10, 0x24}, 0xc000efc390?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2975 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc004965950?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2620 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc00123fae6, 0x10, 0x1a}, {0xc000f2cab0, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2643 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000ded006, 0x10, 0x1a}, {0xc000994b10, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 3223 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000dbe8e0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2749 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc0009aeda6, 0x10, 0x1a}, {0xc00185bad0, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2678 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0003e7560, {0xc00060de30, 0x0, 0xc004b0bf20, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0021f5810}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2754 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc003628460)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 4490 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0010ed7a0, {0xc00125c590, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001e93220}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2769 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002829320, {0xc001079b40, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002864af0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4134 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc00209fe00})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002972ea0, {0xc001417800, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc00209fe00}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2756 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc00237f900})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002ad0a20, {0xc0001a7ed0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc00237f900}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2757 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x45d964b800?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001a7de60?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2758 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002ad0ea0, {0xc0002c0540, 0x0, 0xc001034690, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00237fa40}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2744 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001a8fad0, 0x24)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc000e9b530?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc001a8fa80, {0x3bb56d8, 0xc002c105f0}, {0xc0014cacd0, 0x42}, 0xa, {0xc00007f8e5, 0x9}, {0xc000e9b530, 0x1, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 2818 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc001dd33c8?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc001364b30?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 2728 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0029e97a0, {0xc000c2ec50, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc002afb900}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1770 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0024882d0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001e2bc20, {0xc000dff4e0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0024882d0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2819 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001a6cc60, {0xc000110770, 0x0, 0xc004ff69c0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000d83f40}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2806 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000c7a5a0, {0xc001dab2c0, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0035724b0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1768 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc00073a000)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 3286 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00290e480, {0xc003bfe5b0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0009685a0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3073 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00067e6c0, {0xc0002f8fc0, 0x0, 0xc001a13ec0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0049eef50}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 1776 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0015d1d40, {0xc001110430, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000645cc0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3063 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002ad1e60, {0xc000931e90, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc003b68d20}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2948 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000423200, {0xc00087f2f0, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0038b7b80}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4132 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0049dad20)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 2736 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x284f97f?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000bac350?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 3467 [IO wait]:
internal/poll.runtime_pollWait(0x7f3b85500c30, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc00262ec80?, 0xc00322f000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc00262ec80, {0xc00322f000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc00262ec80, {0xc00322f000?, 0x4e7b66?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc001112790, {0xc00322f000?, 0x0?, 0xc001c68d58?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*connReader).Read(0xc001c68d50, {0xc00322f000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:782 +0x171
bufio.(*Reader).fill(0xc0026709c0)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc0026709c0, 0x4)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*conn).serve(0xc00310c990, {0x3bb5780, 0xc000da3cb0})
	/usr/local/go/src/net/http/server.go:2030 +0x77c
created by net/http.(*Server).Serve
	/usr/local/go/src/net/http/server.go:3089 +0x5ed

goroutine 2870 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001a6c6c0, {0xc0002b0060, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0029d20f0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2927 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001e2a6c0, {0xc000a152f0, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00386fdb0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 2735 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc0049eeeb0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000c558c0, {0xc00106fc10, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc0049eeeb0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4568 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0010b9560, {0xc0003349a0, 0x0, 0xc000d9fe90, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001570d70}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3119 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc00290e5a0, {0xc000dffb00, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000645220}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3055 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001a8fad0, 0x27)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0002c09a0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc001a8fa80, {0x3bb56d8, 0xc000ece0a0}, {0xc004b121e0, 0x42}, 0xf, {0xc000c757e5, 0x9}, {0xc0010782b0, 0x1, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 3224 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0003e8480, {0xc00035b9d0, 0x0, 0xc002f65620, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00134c0f0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4613 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc001a8fbd0, 0x12)
	/usr/local/go/src/runtime/sema.go:527 +0x14c
sync.(*Cond).Wait(0xc0002c09a0?)
	/usr/local/go/src/sync/cond.go:70 +0x8c
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0xc001a8fb80, {0x3bb56d8, 0xc001afdef0}, {0xc002706660, 0x28}, 0x28, {0xc000c74685, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:132 +0x948
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:368 +0x175b

goroutine 2976 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc000c7a7e0, {0xc0001db730, 0x0, 0xc003a3f800, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00293c640}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4238 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001308286, 0x10, 0x1a}, {0xc00350df80, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 2972 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc00073a140)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 3083 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0011d2d80, {0xc001389ca0, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0046dfbd0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3220 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0021dc5a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 3317 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002eff0e0, {0xc001d623a8, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc000f5d810}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3926 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0003e78c0, {0xc001dfc888, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc003cfe910}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3629 [IO wait]:
internal/poll.runtime_pollWait(0x7f3b857fb508, 0x72)
	/usr/local/go/src/runtime/netpoll.go:306 +0x89
internal/poll.(*pollDesc).wait(0xc0016a3b00?, 0xc002fe2000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0016a3b00, {0xc002fe2000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x299
net.(*netFD).Read(0xc0016a3b00, {0xc002fe2000?, 0x43c147?, 0xc001675c30?})
	/usr/local/go/src/net/fd_posix.go:55 +0x29
net.(*conn).Read(0xc0002ae160, {0xc002fe2000?, 0x0?, 0xc002d0fba0?})
	/usr/local/go/src/net/net.go:183 +0x45
net/http.(*persistConn).Read(0xc0049f25a0, {0xc002fe2000?, 0xc00303c000?, 0xc001675d30?})
	/usr/local/go/src/net/http/transport.go:1943 +0x4e
bufio.(*Reader).fill(0xc002fd14a0)
	/usr/local/go/src/bufio/bufio.go:106 +0xff
bufio.(*Reader).Peek(0xc002fd14a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:144 +0x5d
net/http.(*persistConn).readLoop(0xc0049f25a0)
	/usr/local/go/src/net/http/transport.go:2107 +0x1ac
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1765 +0x16ea

goroutine 4136 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc002973440, {0xc000533420, 0x0, 0xc004bdf380, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00209fea0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 3630 [select]:
net/http.(*persistConn).writeLoop(0xc0049f25a0)
	/usr/local/go/src/net/http/transport.go:2410 +0xf2
created by net/http.(*Transport).dialConn
	/usr/local/go/src/net/http/transport.go:1766 +0x173d

goroutine 4135 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc002aca930?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 3531 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc001197ee6, 0x10, 0x1a}, {0xc0030cc840, 0x24}, 0xc001079cc0?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 4386 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001d51a90})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc003a08c60, {0xc0010c0ba0, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001d51a90}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4388 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc003a090e0, {0xc003a144d0, 0x0, 0xc001a9a0c0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc001d51b30}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4567 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x284f97f?, 0x443345?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0010787e0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 4188 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc000941a06, 0x10, 0x1a}, {0xc00213a930, 0x24}, 0xc00137bf00?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 4512 [sleep]:
time.Sleep(0x8bb2c97000)
	/usr/local/go/src/runtime/time.go:195 +0x135
github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer.func1({0xc00075abc6, 0x10, 0x1a}, {0xc001b0efc0, 0x24}, 0xc003715680?)
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:369 +0x9e
created by github.com/cilium/cilium/pkg/ipam.(*IPAM).StartExpirationTimer
	/go/src/github.com/cilium/cilium/pkg/ipam/allocator.go:367 +0x3a7

goroutine 4264 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc003628e60)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 4266 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc00379a1e0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0035687e0, {0xc001265060, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc00379a1e0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4267 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x284f966?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0xc2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc0010993c0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x76

goroutine 4268 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc003568c60, {0xc000638a80, 0x0, 0xc001ae98f0, 0x2540be400, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc00379a280}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4417 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc001383440, {0xc001099030, 0x0, 0x3805780, 0xdf8475800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc0030e25a0}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4394 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc003a17b00, {0xc00087eee8, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc003a28230}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4397 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc003788c60, {0xc00108e108, 0x0, 0x3805780, 0x45d964b800, 0x0, 0x0, 0x0, {0x3bb56d8, 0xc003a28780}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:269 +0x1011
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2

goroutine 4564 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0049dac80)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2ee
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1d6

goroutine 4566 [select]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3bb56d8, 0xc001570c30})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:723 +0x93
github.com/cilium/cilium/pkg/controller.(*controller).runController(0xc0010b8a20, {0xc000f71510, 0x0, 0x3805780, 0x0, 0x0, 0x77359400, 0x0, {0x3bb56d8, 0xc001570c30}})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:201 +0x11d
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:97 +0xad2
