 00:31:12 up  2:32,  0 users,  load average: 1.03, 0.62, 0.56
