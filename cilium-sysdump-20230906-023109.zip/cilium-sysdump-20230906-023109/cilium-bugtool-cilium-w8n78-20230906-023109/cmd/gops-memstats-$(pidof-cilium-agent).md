alloc: 30.47MB (31953496 bytes)
total-alloc: 605.77MB (635200264 bytes)
sys: 103.35MB (108372067 bytes)
lookups: 0
mallocs: 7692716
frees: 7473627
heap-alloc: 30.47MB (31953496 bytes)
heap-sys: 79.81MB (83689472 bytes)
heap-idle: 33.55MB (35176448 bytes)
heap-in-use: 46.27MB (48513024 bytes)
heap-released: 8.38MB (8781824 bytes)
heap-objects: 219089
stack-in-use: 8.19MB (8585216 bytes)
stack-sys: 8.19MB (8585216 bytes)
stack-mspan-inuse: 821.41KB (841120 bytes)
stack-mspan-sys: 988.12KB (1011840 bytes)
stack-mcache-inuse: 14.06KB (14400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 2.33MB (2442211 bytes)
gc-sys: 10.39MB (10895392 bytes)
next-gc: when heap-alloc >= 66.29MB (69508688 bytes)
last-gc: 2023-09-06 00:31:42.234241619 +0000 UTC
gc-pause-total: 1.38163ms
gc-pause: 44156
gc-pause-end: 1693960302234241619
num-gc: 28
num-forced-gc: 0
gc-cpu-fraction: 0.00018885369415497124
enable-gc: true
debug-gc: false
