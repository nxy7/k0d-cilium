filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc827eb49d10c9 direct-action not_in_hw id 7842 tag c3040965eccaf545 jited 
