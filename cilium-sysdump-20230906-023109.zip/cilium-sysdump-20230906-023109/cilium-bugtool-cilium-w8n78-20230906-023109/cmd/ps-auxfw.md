USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         391  0.0  0.0 725088 14848 ?        Ssl  00:31   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         415  0.0  0.0   7060  2816 ?        R    00:31   0:00  \_ ps auxfw
root         426  0.0  0.0   4960  2432 ?        R    00:31   0:00  \_ ss -t -p -a -i -s -n -e
root         434  0.0  0.0   6916  2688 ?        R    00:31   0:00  \_ top -b -n 1
root         435  0.0  0.0   6404  2304 ?        R    00:31   0:00  \_ uptime
root         436  0.0  0.0   3284  1920 ?        R    00:31   0:00  \_ dmesg --time-format=iso
root         437  0.0  0.0   2784  1664 ?        R    00:31   0:00  \_ sysctl -a
root         438  0.0  0.0   3540  1920 ?        R    00:31   0:00  \_ bpftool map show
root         439  0.0  0.0   3540  2176 ?        R    00:31   0:00  \_ bpftool prog show
root         440  0.0  0.0   3540  1792 ?        R    00:31   0:00  \_ bpftool net show
root         441  0.0  0.0   3560  1920 ?        D    00:31   0:00  \_ iptables-save -c
root         373  0.0  0.0 713560  4096 ?        Ssl  00:31   0:00 /bin/gops pprof-cpu 1
root           1  5.5  0.9 880452 152492 ?       Ssl  00:29   0:04 cilium-agent --config-dir=/tmp/cilium/config-map
root         198  0.0  0.0 714436  4608 ?        Sl   00:29   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
