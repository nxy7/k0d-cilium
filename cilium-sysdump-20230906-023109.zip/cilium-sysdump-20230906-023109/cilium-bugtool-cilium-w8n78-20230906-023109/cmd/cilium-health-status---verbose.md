Probe time:   2023-09-06T00:30:53Z
Nodes:
  k0s (localhost):
    Host connectivity to 172.17.0.2:
      ICMP to stack:   OK, RTT=226.844µs
    Endpoint connectivity to 10.244.0.206:
      ICMP to stack:   Connection timed out
