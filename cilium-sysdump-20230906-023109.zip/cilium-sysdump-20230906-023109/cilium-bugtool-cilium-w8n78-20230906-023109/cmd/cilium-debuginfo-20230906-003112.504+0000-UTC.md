# Cilium debug information

#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.27 (v1.27.4+k0s) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideEnvoyConfig", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumEnvoyConfig", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Secrets", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   True   [eth0 172.17.0.2]
Host firewall:          Disabled
CNI Chaining:           none
Cilium:                 Ok   1.14.1 (v1.14.1-c191ef6f)
NodeMonitor:            Listening for events on 32 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 32/254 allocated from 10.244.0.0/24, 
Allocated addresses:
  10.244.0.101 (streampai/livestream-migrations-8nnxm)
  10.244.0.104 (streampai/frontend-58b6bf847f-rg7lb)
  10.244.0.105 (streampai/redis-68c95977f4-bl8l4)
  10.244.0.119 (streampai/frontend-58b6bf847f-j9rzh)
  10.244.0.144 (streampai/create-minio-buckets-2hsfq)
  10.244.0.155 (streampai/kratos-migrations-km25z)
  10.244.0.171 (cert-manager/cert-manager-cainjector-6774f986b-5fqd9)
  10.244.0.172 (openebs/openebs-localpv-provisioner-7d6ccb7795-4rhmc)
  10.244.0.176 (router)
  10.244.0.18 (openebs/init-pvc-4f2ec5d9-e41b-425e-bdb7-332c06f7825a)
  10.244.0.182 (openebs/init-pvc-bf475e5e-08fc-4f1e-95bf-5e66e3b2ccb5)
  10.244.0.186 (openebs/init-pvc-a98007c1-4485-4928-9e38-355a6ab271ae)
  10.244.0.192 (streampai/kratos-77cbf98c8f-wcvxh)
  10.244.0.193 (streampai/backend-855f6c7b4-fkt9r)
  10.244.0.197 (kube-system/hubble-relay-777496bf44-ngd9p)
  10.244.0.199 (openebs/openebs-ndm-node-exporter-prqkp)
  10.244.0.206 (health)
  10.244.0.207 (kube-system/coredns-878bb57ff-j98j5)
  10.244.0.209 (streampai/streamchat-79dfbb9bb4-c954g)
  10.244.0.21 (streampai/frontend-58b6bf847f-cv4lc)
  10.244.0.212 (kube-system/metrics-server-7f86dff975-b2xzk)
  10.244.0.219 (cert-manager/cert-manager-webhook-879c48cd4-b4q2j)
  10.244.0.230 (ingress)
  10.244.0.240 (cert-manager/cert-manager-78ddc5db85-h92qs)
  10.244.0.253 (openebs/openebs-ndm-cluster-exporter-589554f487-vj8m5)
  10.244.0.28 (streampai/backend-855f6c7b4-8bqth)
  10.244.0.34 (openebs/openebs-ndm-operator-7c667b76f8-xbj7v)
  10.244.0.50 (streampai/frontend-58b6bf847f-k8mbl)
  10.244.0.57 (streampai/postgres-migrations-79t9m)
  10.244.0.77 (kube-system/hubble-ui-6b468cff75-sv8hh)
  10.244.0.84 (ambassador/traffic-manager-55d995585d-cs5xg)
  10.244.0.93 (streampai/pgweb-b74849bb6-hrcb8)
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Host Routing:           Legacy
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      136/136 healthy
  Name                                  Last success   Last error   Count   Message
  cilium-health-ep                      19s ago        never        0       no error   
  dns-garbage-collector-job             23s ago        never        0       no error   
  endpoint-1164-regeneration-recovery   never          never        0       no error   
  endpoint-1412-regeneration-recovery   never          never        0       no error   
  endpoint-1526-regeneration-recovery   never          never        0       no error   
  endpoint-1528-regeneration-recovery   never          never        0       no error   
  endpoint-1618-regeneration-recovery   never          never        0       no error   
  endpoint-17-regeneration-recovery     never          never        0       no error   
  endpoint-178-regeneration-recovery    never          never        0       no error   
  endpoint-182-regeneration-recovery    never          never        0       no error   
  endpoint-1959-regeneration-recovery   never          never        0       no error   
  endpoint-199-regeneration-recovery    never          never        0       no error   
  endpoint-1992-regeneration-recovery   never          never        0       no error   
  endpoint-2084-regeneration-recovery   never          never        0       no error   
  endpoint-2201-regeneration-recovery   never          never        0       no error   
  endpoint-246-regeneration-recovery    never          never        0       no error   
  endpoint-2589-regeneration-recovery   never          never        0       no error   
  endpoint-2682-regeneration-recovery   never          never        0       no error   
  endpoint-293-regeneration-recovery    never          never        0       no error   
  endpoint-3168-regeneration-recovery   never          never        0       no error   
  endpoint-3501-regeneration-recovery   never          never        0       no error   
  endpoint-3565-regeneration-recovery   never          never        0       no error   
  endpoint-359-regeneration-recovery    never          never        0       no error   
  endpoint-3726-regeneration-recovery   never          never        0       no error   
  endpoint-398-regeneration-recovery    never          never        0       no error   
  endpoint-443-regeneration-recovery    never          never        0       no error   
  endpoint-48-regeneration-recovery     never          never        0       no error   
  endpoint-509-regeneration-recovery    never          never        0       no error   
  endpoint-620-regeneration-recovery    never          never        0       no error   
  endpoint-628-regeneration-recovery    never          never        0       no error   
  endpoint-824-regeneration-recovery    never          never        0       no error   
  endpoint-858-regeneration-recovery    never          never        0       no error   
  endpoint-951-regeneration-recovery    never          never        0       no error   
  endpoint-gc                           1m23s ago      never        0       no error   
  ipcache-inject-labels                 20s ago        1m22s ago    0       no error   
  k8s-heartbeat                         23s ago        never        0       no error   
  link-cache                            5s ago         never        0       no error   
  metricsmap-bpf-prom-sync              3s ago         never        0       no error   
  resolve-identity-1164                 13s ago        never        0       no error   
  resolve-identity-1412                 13s ago        never        0       no error   
  resolve-identity-1526                 14s ago        never        0       no error   
  resolve-identity-1528                 1m16s ago      never        0       no error   
  resolve-identity-1618                 11s ago        never        0       no error   
  resolve-identity-17                   1m19s ago      never        0       no error   
  resolve-identity-178                  1m7s ago       never        0       no error   
  resolve-identity-182                  19s ago        never        0       no error   
  resolve-identity-1959                 1m16s ago      never        0       no error   
  resolve-identity-199                  1m18s ago      never        0       no error   
  resolve-identity-1992                 1m19s ago      never        0       no error   
  resolve-identity-2084                 1m18s ago      never        0       no error   
  resolve-identity-2201                 15s ago        never        0       no error   
  resolve-identity-246                  1m19s ago      never        0       no error   
  resolve-identity-2589                 15s ago        never        0       no error   
  resolve-identity-2682                 16s ago        never        0       no error   
  resolve-identity-293                  19s ago        never        0       no error   
  resolve-identity-3168                 1m18s ago      never        0       no error   
  resolve-identity-3501                 1m15s ago      never        0       no error   
  resolve-identity-3565                 17s ago        never        0       no error   
  resolve-identity-359                  1m14s ago      never        0       no error   
  resolve-identity-3726                 1m19s ago      never        0       no error   
  resolve-identity-398                  12s ago        never        0       no error   
  resolve-identity-443                  15s ago        never        0       no error   
  resolve-identity-48                   19s ago        never        0       no error   
  resolve-identity-509                  17s ago        never        0       no error   
  resolve-identity-620                  19s ago        never        0       no error   
  resolve-identity-628                  19s ago        never        0       no error   
  resolve-identity-824                  19s ago        never        0       no error   
  resolve-identity-858                  19s ago        never        0       no error   
  resolve-identity-951                  1m18s ago      never        0       no error   
  sync-host-ips                         20s ago        never        0       no error   
  sync-lb-maps-with-k8s-services        1m20s ago      never        0       no error   
  sync-policymap-1164                   10s ago        never        0       no error   
  sync-policymap-1412                   10s ago        never        0       no error   
  sync-policymap-1526                   10s ago        never        0       no error   
  sync-policymap-1528                   10s ago        never        0       no error   
  sync-policymap-1618                   10s ago        never        0       no error   
  sync-policymap-17                     10s ago        never        0       no error   
  sync-policymap-178                    10s ago        never        0       no error   
  sync-policymap-182                    10s ago        never        0       no error   
  sync-policymap-1959                   10s ago        never        0       no error   
  sync-policymap-199                    10s ago        never        0       no error   
  sync-policymap-1992                   10s ago        never        0       no error   
  sync-policymap-2084                   10s ago        never        0       no error   
  sync-policymap-2201                   10s ago        never        0       no error   
  sync-policymap-246                    10s ago        never        0       no error   
  sync-policymap-2589                   10s ago        never        0       no error   
  sync-policymap-2682                   10s ago        never        0       no error   
  sync-policymap-293                    10s ago        never        0       no error   
  sync-policymap-3168                   10s ago        never        0       no error   
  sync-policymap-3501                   10s ago        never        0       no error   
  sync-policymap-3565                   10s ago        never        0       no error   
  sync-policymap-359                    10s ago        never        0       no error   
  sync-policymap-3726                   10s ago        never        0       no error   
  sync-policymap-398                    10s ago        never        0       no error   
  sync-policymap-443                    10s ago        never        0       no error   
  sync-policymap-48                     10s ago        never        0       no error   
  sync-policymap-509                    10s ago        never        0       no error   
  sync-policymap-620                    10s ago        never        0       no error   
  sync-policymap-628                    10s ago        never        0       no error   
  sync-policymap-824                    10s ago        never        0       no error   
  sync-policymap-858                    10s ago        never        0       no error   
  sync-policymap-951                    10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1164)     3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1412)     2s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1526)     3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1528)     5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1618)     1s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (17)       8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (178)      7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (182)      7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1959)     5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (199)      6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1992)     9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2084)     7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2201)     4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (246)      9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2589)     4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2682)     6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (293)      9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3168)     6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3501)     4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3565)     6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (359)      3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3726)     9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (398)      2s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (443)      5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (48)       9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (509)      7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (620)      8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (628)      8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (824)      9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (858)      9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (951)      7s ago         never        0       no error   
  sync-utime                            20s ago        never        0       no error   
  template-dir-watcher                  never          never        0       no error   
  write-cni-file                        1m23s ago      never        0       no error   
Proxy Status:            OK, ip 10.244.0.176, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 256, max 65535
Hubble:                  Ok   Current/Max Flows: 2144/4095 (52.36%), Flows/s: 20.74   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 True
  Socket LB:              Enabled
  Socket LB Tracing:      Enabled
  Socket LB Coverage:     Full
  Devices:                eth0 172.17.0.2
  Mode:                   SNAT
  Backend Selection:      Random
  Session Affinity:       Enabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  XDP Acceleration:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Enabled (Range: 30000-32767) 
  - LoadBalancer:   Enabled 
  - externalIPs:    Enabled 
  - HostPort:       Enabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   73193
  TCP connection tracking       146386
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           146386
  Neighbor table                146386
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              73193
  Tunnel                        65536
Encryption:   Disabled   
```

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                   IPv6   IPv4           STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                      
17         Disabled           Disabled          25058      k8s:app.kubernetes.io/name=hubble-relay                                              10.244.0.197   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                        
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay                                                        
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=hubble-relay                                                                                    
48         Disabled           Disabled          40807      k8s:app=frontend                                                                     10.244.0.104   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
178        Disabled           Disabled          1          k8s:node-role.kubernetes.io/control-plane=true                                                      ready   
                                                           k8s:node.k0sproject.io/role=control-plane                                                                   
                                                           reserved:host                                                                                               
182        Disabled           Disabled          40807      k8s:app=frontend                                                                     10.244.0.50    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
199        Disabled           Disabled          48566      k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs               10.244.0.253   ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator                                               
                                                           k8s:io.kubernetes.pod.namespace=openebs                                                                     
                                                           k8s:name=openebs-ndm-cluster-exporter                                                                       
                                                           k8s:openebs.io/component-name=ndm-cluster-exporter                                                          
                                                           k8s:openebs.io/version=3.4.0                                                                                
246        Disabled           Disabled          33925      k8s:app.kubernetes.io/component=controller                                           10.244.0.240   ready   
                                                           k8s:app.kubernetes.io/instance=cert-manager                                                                 
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                       
                                                           k8s:app.kubernetes.io/name=cert-manager                                                                     
                                                           k8s:app.kubernetes.io/version=v1.10.0                                                                       
                                                           k8s:app=cert-manager                                                                                        
                                                           k8s:helm.sh/chart=cert-manager-v1.10.0                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager                                 
                                                           k8s:io.cilium.k8s.namespace.labels.name=cert-manager                                                        
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=cert-manager                                                        
                                                           k8s:io.kubernetes.pod.namespace=cert-manager                                                                
293        Disabled           Disabled          40807      k8s:app=frontend                                                                     10.244.0.21    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
359        Disabled           Disabled          44793      k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs               10.244.0.34    ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator                                               
                                                           k8s:io.kubernetes.pod.namespace=openebs                                                                     
                                                           k8s:name=openebs-ndm-operator                                                                               
                                                           k8s:openebs.io/component-name=ndm-operator                                                                  
                                                           k8s:openebs.io/version=3.4.0                                                                                
398        Disabled           Disabled          1847       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs               10.244.0.186   ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator                                               
                                                           k8s:io.kubernetes.pod.namespace=openebs                                                                     
443        Disabled           Disabled          3108       k8s:app=streamchat                                                                   10.244.0.209   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
509        Disabled           Disabled          11487      k8s:app=redis                                                                        10.244.0.105   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
620        Disabled           Disabled          9256       k8s:app=backend                                                                      10.244.0.28    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
628        Disabled           Disabled          11535      k8s:app=kratos                                                                       10.244.0.192   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
824        Disabled           Disabled          9256       k8s:app=backend                                                                      10.244.0.193   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
858        Disabled           Disabled          40807      k8s:app=frontend                                                                     10.244.0.119   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
951        Disabled           Disabled          28402      k8s:app.kubernetes.io/component=cainjector                                           10.244.0.171   ready   
                                                           k8s:app.kubernetes.io/instance=cert-manager                                                                 
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                       
                                                           k8s:app.kubernetes.io/name=cainjector                                                                       
                                                           k8s:app.kubernetes.io/version=v1.10.0                                                                       
                                                           k8s:app=cainjector                                                                                          
                                                           k8s:helm.sh/chart=cert-manager-v1.10.0                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager                                 
                                                           k8s:io.cilium.k8s.namespace.labels.name=cert-manager                                                        
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-cainjector                                             
                                                           k8s:io.kubernetes.pod.namespace=cert-manager                                                                
1164       Disabled           Disabled          1847       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs               10.244.0.182   ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator                                               
                                                           k8s:io.kubernetes.pod.namespace=openebs                                                                     
1412       Disabled           Disabled          2199       k8s:app=pgweb                                                                        10.244.0.93    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
1526       Disabled           Disabled          58695      k8s:batch.kubernetes.io/controller-uid=4c43bff2-13bd-4dd8-a6bc-66894484ffe2          10.244.0.57    ready   
                                                           k8s:batch.kubernetes.io/job-name=postgres-migrations                                                        
                                                           k8s:controller-uid=4c43bff2-13bd-4dd8-a6bc-66894484ffe2                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
                                                           k8s:job-name=postgres-migrations                                                                            
1528       Disabled           Disabled          13128      k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs               10.244.0.172   ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator                                               
                                                           k8s:io.kubernetes.pod.namespace=openebs                                                                     
                                                           k8s:name=openebs-localpv-provisioner                                                                        
                                                           k8s:openebs.io/component-name=openebs-localpv-provisioner                                                   
                                                           k8s:openebs.io/version=3.4.0                                                                                
1618       Disabled           Disabled          63576      k8s:app=traffic-manager                                                              10.244.0.84    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=ambassador                                   
                                                           k8s:io.cilium.k8s.namespace.labels.name=ambassador                                                          
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=traffic-manager                                                     
                                                           k8s:io.kubernetes.pod.namespace=ambassador                                                                  
                                                           k8s:telepresence=manager                                                                                    
1959       Disabled           Disabled          32957      k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system           10.244.0.212   ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=metrics-server                                                      
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=metrics-server                                                                                  
1992       Disabled           Disabled          12886      k8s:app.kubernetes.io/component=webhook                                              10.244.0.219   ready   
                                                           k8s:app.kubernetes.io/instance=cert-manager                                                                 
                                                           k8s:app.kubernetes.io/managed-by=Helm                                                                       
                                                           k8s:app.kubernetes.io/name=webhook                                                                          
                                                           k8s:app.kubernetes.io/version=v1.10.0                                                                       
                                                           k8s:app=webhook                                                                                             
                                                           k8s:helm.sh/chart=cert-manager-v1.10.0                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager                                 
                                                           k8s:io.cilium.k8s.namespace.labels.name=cert-manager                                                        
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-webhook                                                
                                                           k8s:io.kubernetes.pod.namespace=cert-manager                                                                
2084       Disabled           Disabled          5267       k8s:app.kubernetes.io/name=hubble-ui                                                 10.244.0.77    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                        
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                  
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=hubble-ui                                                                                       
2201       Disabled           Disabled          1847       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs               10.244.0.18    ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator                                               
                                                           k8s:io.kubernetes.pod.namespace=openebs                                                                     
2589       Disabled           Disabled          7207       k8s:batch.kubernetes.io/controller-uid=77988019-4ff6-4cc9-b0bc-496c50fe36e6          10.244.0.101   ready   
                                                           k8s:batch.kubernetes.io/job-name=livestream-migrations                                                      
                                                           k8s:controller-uid=77988019-4ff6-4cc9-b0bc-496c50fe36e6                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
                                                           k8s:job-name=livestream-migrations                                                                          
2682       Disabled           Disabled          707        k8s:batch.kubernetes.io/controller-uid=40d90209-752d-436b-a06a-3c40881e0092          10.244.0.155   ready   
                                                           k8s:batch.kubernetes.io/job-name=kratos-migrations                                                          
                                                           k8s:controller-uid=40d90209-752d-436b-a06a-3c40881e0092                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
                                                           k8s:job-name=kratos-migrations                                                                              
3168       Disabled           Disabled          6400       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system           10.244.0.207   ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                 
                                                           k8s:k8s-app=kube-dns                                                                                        
3501       Disabled           Disabled          8310       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs               10.244.0.199   ready   
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator                                               
                                                           k8s:io.kubernetes.pod.namespace=openebs                                                                     
                                                           k8s:name=openebs-ndm-node-exporter                                                                          
                                                           k8s:openebs.io/component-name=ndm-node-exporter                                                             
                                                           k8s:openebs.io/version=3.4.0                                                                                
3565       Disabled           Disabled          24494      k8s:batch.kubernetes.io/controller-uid=636c9c65-d057-4ed2-867f-db0fe0944e38          10.244.0.144   ready   
                                                           k8s:batch.kubernetes.io/job-name=create-minio-buckets                                                       
                                                           k8s:controller-uid=636c9c65-d057-4ed2-867f-db0fe0944e38                                                     
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai                                    
                                                           k8s:io.cilium.k8s.namespace.labels.name=streampai                                                           
                                                           k8s:io.cilium.k8s.policy.cluster=default                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=default                                                             
                                                           k8s:io.kubernetes.pod.namespace=streampai                                                                   
                                                           k8s:job-name=create-minio-buckets                                                                           
3726       Disabled           Disabled          4          reserved:health                                                                      10.244.0.206   ready   
```

#### BPF Policy Get 17

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    3900    60        0        
Allow    Egress      0          ANY          NONE         disabled    6519    38        0        

```


#### BPF CT List 17

```
Invalid argument: unknown type 17
```


#### Endpoint Get 17

```
[
  {
    "id": 17,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-17-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "cf476214-3e97-45a0-ba1d-ef62c302a99f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-17",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:29:53.115Z",
            "success-count": 1
          },
          "uuid": "7cb3ca7c-d4a5-4a2f-9308-3b26e8ccbbfe"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-17",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 18
          },
          "uuid": "9d06a55f-79bd-4565-b0d0-c0c187daa9e7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (17)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:03.921Z",
            "success-count": 9
          },
          "uuid": "b73078b1-838c-4c28-9641-894b416dc7b0"
        }
      ],
      "external-identifiers": {
        "container-id": "e781421cff8ab52b1f46cd394042165b41fe1b85d1081471b0645846e556eb8e",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "hubble-relay-777496bf44-ngd9p",
        "pod-name": "kube-system/hubble-relay-777496bf44-ngd9p"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 25058,
        "labels": [
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:k8s-app=hubble-relay",
          "k8s:app.kubernetes.io/name=hubble-relay",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=777496bf44"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=hubble-relay",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=hubble-relay"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "namedPorts": [
        {
          "name": "grpc",
          "port": 4245,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.197",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "66:42:a2:8d:ab:3f",
        "interface-index": 18,
        "interface-name": "lxcf43f6d46ba72",
        "mac": "66:16:18:31:3f:90"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 25058,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 25058,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 17

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 17

```
Timestamp              Status   State                   Message
2023-09-06T00:31:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:29:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:59Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:29:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:29:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:29:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:53Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:29:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:29:53Z   OK       ready                   Set identity for this endpoint
2023-09-06T00:29:53Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 25058

```
ID      LABELS
25058   k8s:app.kubernetes.io/name=hubble-relay
        k8s:app.kubernetes.io/part-of=cilium
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=hubble-relay
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=hubble-relay

```


#### BPF Policy Get 48

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 48

```
Invalid argument: unknown type 48
```


#### Endpoint Get 48

```
[
  {
    "id": 48,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-48-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "00e95e15-98f8-40f2-bdce-b47dfce253e1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-48",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:30:53.260Z",
            "success-count": 1
          },
          "uuid": "64437e11-a190-4557-a274-d5471ab4322c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-48",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 10
          },
          "uuid": "33d34f17-4240-468e-b3ca-f8c108bbc85a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (48)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:03.271Z",
            "success-count": 3
          },
          "uuid": "7e7ede3b-ab07-4e37-9642-f023c90286b3"
        }
      ],
      "external-identifiers": {
        "container-id": "75114dec769e79395df796a324643d5f68136603149792cdf57b4aa9781b2898",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "frontend-58b6bf847f-rg7lb",
        "pod-name": "streampai/frontend-58b6bf847f-rg7lb"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 40807,
        "labels": [
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=58b6bf847f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.104",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "6e:f4:a6:4f:30:c1",
        "interface-index": 39,
        "interface-name": "lxc4782bc321b2a",
        "mac": "86:3c:12:8d:15:6b"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 40807,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 40807,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 48

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 48

```
Timestamp              Status    State                   Message
2023-09-06T00:31:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK        regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:30:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:30:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:30:53Z   OK        ready                   Set identity for this endpoint
2023-09-06T00:30:53Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:52Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 40807

```
ID      LABELS
40807   k8s:app=frontend
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 178

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 178

```
Invalid argument: unknown type 178
```


#### Endpoint Get 178

```
[
  {
    "id": 178,
    "spec": {
      "label-configuration": {
        "user": [
          "k8s:node-role.kubernetes.io/control-plane=true"
        ]
      },
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-178-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "36d1dea6-05dd-4415-a83a-6ca05b8fb635"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-178",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:30:05.395Z",
            "success-count": 2
          },
          "uuid": "b43c5083-8409-492d-92ba-f24135d59363"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-178",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 20
          },
          "uuid": "46812117-9709-48b7-87d4-df5c09a14c74"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (178)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:05.399Z",
            "success-count": 10
          },
          "uuid": "d3763e56-e74d-4906-9f6f-45d3019006f0"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "k8s:node-role.kubernetes.io/control-plane=true",
          "reserved:host",
          "k8s:node.k0sproject.io/role=control-plane"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.k0sproject.io/role=control-plane",
          "reserved:host"
        ],
        "realized": {
          "user": [
            "k8s:node-role.kubernetes.io/control-plane=true"
          ]
        },
        "security-relevant": [
          "k8s:node-role.kubernetes.io/control-plane=true",
          "k8s:node.k0sproject.io/role=control-plane",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "22:3d:6f:f5:1b:a3",
        "interface-name": "cilium_host",
        "mac": "22:3d:6f:f5:1b:a3"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {
          "user": [
            "k8s:node-role.kubernetes.io/control-plane=true"
          ]
        },
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 178

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 178

```
Timestamp              Status   State                   Message
2023-09-06T00:31:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:30:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:05Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:30:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:30:05Z   OK       ready                   Set identity for this endpoint
2023-09-06T00:30:05Z   OK       waiting-for-identity    Triggering identity resolution due to updated identity labels
2023-09-06T00:29:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:29:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:59Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:29:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:29:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:53Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:29:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:51Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:29:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:29:51Z   OK       ready                   Set identity for this endpoint
2023-09-06T00:29:51Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 182

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 182

```
Invalid argument: unknown type 182
```


#### Endpoint Get 182

```
[
  {
    "id": 182,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-182-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "50c1be97-c5ee-4d45-aba4-d60aa54118bc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-182",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:30:53.371Z",
            "success-count": 1
          },
          "uuid": "27bc9b52-0190-490a-95b8-b262f4c50419"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-182",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.261Z",
            "success-count": 10
          },
          "uuid": "d4ee142e-f599-4658-b963-d0caa1129258"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (182)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:04.656Z",
            "success-count": 3
          },
          "uuid": "cc2b8b8d-5b09-4e43-85b4-8d70e2203153"
        }
      ],
      "external-identifiers": {
        "container-id": "2ba8ead082bc96f2cfad981d82367b351c5af55f02dfc82211444e0104478816",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "frontend-58b6bf847f-k8mbl",
        "pod-name": "streampai/frontend-58b6bf847f-k8mbl"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 40807,
        "labels": [
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=58b6bf847f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.50",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "6e:bb:f6:9a:2b:ee",
        "interface-index": 43,
        "interface-name": "lxc097a7596acc7",
        "mac": "22:b8:59:10:36:69"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 40807,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 40807,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 182

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 182

```
Timestamp              Status   State                   Message
2023-09-06T00:31:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:30:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:30:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:30:53Z   OK       ready                   Set identity for this endpoint
2023-09-06T00:30:53Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 40807

```
ID      LABELS
40807   k8s:app=frontend
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 199

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    27600   297       0        

```


#### BPF CT List 199

```
Invalid argument: unknown type 199
```


#### Endpoint Get 199

```
[
  {
    "id": 199,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-199-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "0ba7cca0-8023-4232-b5cc-3dbf49146327"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-199",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:29:54.113Z",
            "success-count": 1
          },
          "uuid": "ae21deb0-e0a8-494f-b21a-27d951609058"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-199",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 17
          },
          "uuid": "cadd054d-87b4-4d9f-91ce-bdcb9ee92ab4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (199)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:05.518Z",
            "success-count": 9
          },
          "uuid": "ce171099-a76c-488d-b7bc-6b9ce73cd8b5"
        }
      ],
      "external-identifiers": {
        "container-id": "20dae7dd2af61bd6bb9e05aa20630125feafbbbcec7687d410b5f760fe58ee73",
        "k8s-namespace": "openebs",
        "k8s-pod-name": "openebs-ndm-cluster-exporter-589554f487-vj8m5",
        "pod-name": "openebs/openebs-ndm-cluster-exporter-589554f487-vj8m5"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 48566,
        "labels": [
          "k8s:name=openebs-ndm-cluster-exporter",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:openebs.io/component-name=ndm-cluster-exporter",
          "k8s:openebs.io/version=3.4.0"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=589554f487"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:name=openebs-ndm-cluster-exporter",
          "k8s:openebs.io/component-name=ndm-cluster-exporter",
          "k8s:openebs.io/version=3.4.0"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "namedPorts": [
        {
          "name": "metrics",
          "port": 9100,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.253",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "e6:de:8a:8e:ee:75",
        "interface-index": 16,
        "interface-name": "lxcde06b44aa784",
        "mac": "06:f8:17:7d:21:e0"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 48566,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 48566,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 199

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 199

```
Timestamp              Status    State                   Message
2023-09-06T00:31:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK        regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:29:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:59Z   OK        regenerating            Regenerating endpoint: 
2023-09-06T00:29:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:29:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:54Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:29:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:54Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:29:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:29:54Z   OK        ready                   Set identity for this endpoint
2023-09-06T00:29:53Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:53Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 48566

```
ID      LABELS
48566   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator
        k8s:io.kubernetes.pod.namespace=openebs
        k8s:name=openebs-ndm-cluster-exporter
        k8s:openebs.io/component-name=ndm-cluster-exporter
        k8s:openebs.io/version=3.4.0

```


#### BPF Policy Get 246

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    84636   804       0        

```


#### BPF CT List 246

```
Invalid argument: unknown type 246
```


#### Endpoint Get 246

```
[
  {
    "id": 246,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-246-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "67330a25-3f7c-4100-8296-532b0ef8f6f1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-246",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:29:52.998Z",
            "success-count": 1
          },
          "uuid": "8d44c60f-9e15-4ee4-a6bb-4eade7bb485a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-246",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 18
          },
          "uuid": "1d55f57f-ea49-47ed-a77f-80558fafc752"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (246)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:13.013Z",
            "success-count": 10
          },
          "uuid": "73c16abd-0165-4607-80f4-bcf11b18d955"
        }
      ],
      "external-identifiers": {
        "container-id": "3e6935f3a8c5f833d6c5bea83930b0ea99d95bca22f26d827777e8d1b4b6da45",
        "k8s-namespace": "cert-manager",
        "k8s-pod-name": "cert-manager-78ddc5db85-h92qs",
        "pod-name": "cert-manager/cert-manager-78ddc5db85-h92qs"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 33925,
        "labels": [
          "k8s:app=cert-manager",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager",
          "k8s:app.kubernetes.io/name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.kubernetes.pod.namespace=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app.kubernetes.io/component=controller",
          "k8s:helm.sh/chart=cert-manager-v1.10.0",
          "k8s:app.kubernetes.io/version=v1.10.0"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=78ddc5db85"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/component=controller",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=cert-manager",
          "k8s:app.kubernetes.io/version=v1.10.0",
          "k8s:app=cert-manager",
          "k8s:helm.sh/chart=cert-manager-v1.10.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager",
          "k8s:io.kubernetes.pod.namespace=cert-manager"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "namedPorts": [
        {
          "name": "http-metrics",
          "port": 9402,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.240",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "06:a9:f0:57:19:3d",
        "interface-index": 10,
        "interface-name": "lxcd2c3af8db6db",
        "mac": "a6:42:ae:da:d1:c4"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 33925,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 33925,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 246

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 246

```
Timestamp              Status   State                   Message
2023-09-06T00:31:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:29:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:59Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:29:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:29:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:29:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:52Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:29:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:29:52Z   OK       ready                   Set identity for this endpoint
2023-09-06T00:29:52Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 33925

```
ID      LABELS
33925   k8s:app.kubernetes.io/component=controller
        k8s:app.kubernetes.io/instance=cert-manager
        k8s:app.kubernetes.io/managed-by=Helm
        k8s:app.kubernetes.io/name=cert-manager
        k8s:app.kubernetes.io/version=v1.10.0
        k8s:app=cert-manager
        k8s:helm.sh/chart=cert-manager-v1.10.0
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager
        k8s:io.cilium.k8s.namespace.labels.name=cert-manager
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=cert-manager
        k8s:io.kubernetes.pod.namespace=cert-manager

```


#### BPF Policy Get 293

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 293

```
Invalid argument: unknown type 293
```


#### Endpoint Get 293

```
[
  {
    "id": 293,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-293-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "bc35430a-5b22-47e4-a04a-89a3e99872e7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-293",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:30:53.260Z",
            "success-count": 1
          },
          "uuid": "f0c9f85c-cd07-45a3-92c6-44ce2803fd63"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-293",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.261Z",
            "success-count": 10
          },
          "uuid": "5a81db81-eb94-4d8a-a230-12c54e0d8472"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (293)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:13.268Z",
            "success-count": 4
          },
          "uuid": "378dc6a9-ab98-449c-add0-1c64d908285e"
        }
      ],
      "external-identifiers": {
        "container-id": "ccd53c451690ad454ea9efb166d43a1da356c84ea701e458753b8a1e0201053b",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "frontend-58b6bf847f-cv4lc",
        "pod-name": "streampai/frontend-58b6bf847f-cv4lc"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 40807,
        "labels": [
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=58b6bf847f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.21",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "16:0f:cb:e8:f8:ac",
        "interface-index": 37,
        "interface-name": "lxc97b3ebf9b0a3",
        "mac": "52:e2:47:6e:d7:69"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 40807,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 40807,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 293

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 293

```
Timestamp              Status    State                   Message
2023-09-06T00:31:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK        regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:30:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:30:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:30:53Z   OK        ready                   Set identity for this endpoint
2023-09-06T00:30:53Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:52Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 40807

```
ID      LABELS
40807   k8s:app=frontend
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 359

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    2750    31        0        
Allow    Egress      0          ANY          NONE         disabled    16584   151       0        

```


#### BPF CT List 359

```
Invalid argument: unknown type 359
```


#### Endpoint Get 359

```
[
  {
    "id": 359,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-359-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "64bdae26-326d-4a03-82ee-0bc4126ed5b6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-359",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:29:58.497Z",
            "success-count": 1
          },
          "uuid": "dda51e63-d60b-468b-9440-5f97f0872a53"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-359",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 13
          },
          "uuid": "aba03ad7-40f8-4baf-9271-77f172aba588"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (359)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:08.509Z",
            "success-count": 9
          },
          "uuid": "22dc0411-7e6c-4c6a-8d54-1883b00759a0"
        }
      ],
      "external-identifiers": {
        "container-id": "9a4df28f3d833e8023d609b5725f1aef9a38e837d6bf5c00b1b3f0198b236907",
        "k8s-namespace": "openebs",
        "k8s-pod-name": "openebs-ndm-operator-7c667b76f8-xbj7v",
        "pod-name": "openebs/openebs-ndm-operator-7c667b76f8-xbj7v"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 44793,
        "labels": [
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:name=openebs-ndm-operator",
          "k8s:openebs.io/component-name=ndm-operator",
          "k8s:openebs.io/version=3.4.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.kubernetes.pod.namespace=openebs"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7c667b76f8"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:name=openebs-ndm-operator",
          "k8s:openebs.io/component-name=ndm-operator",
          "k8s:openebs.io/version=3.4.0"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.34",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "aa:5d:0b:89:f1:d6",
        "interface-index": 29,
        "interface-name": "lxc67392d8dd2f9",
        "mac": "7e:64:96:7f:b8:ad"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 44793,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 44793,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 359

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 359

```
Timestamp              Status   State                   Message
2023-09-06T00:31:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:29:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:59Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:29:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:29:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:29:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:58Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:29:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:29:58Z   OK       ready                   Set identity for this endpoint
2023-09-06T00:29:58Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 44793

```
ID      LABELS
44793   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator
        k8s:io.kubernetes.pod.namespace=openebs
        k8s:name=openebs-ndm-operator
        k8s:openebs.io/component-name=ndm-operator
        k8s:openebs.io/version=3.4.0

```


#### BPF Policy Get 398

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 398

```
Invalid argument: unknown type 398
```


#### Endpoint Get 398

```
[
  {
    "id": 398,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-398-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "682adc72-5f63-4c32-8054-b30c1979c9f2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-398",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:00.098Z",
            "success-count": 1
          },
          "uuid": "6623c6ef-6d32-4feb-a9d4-24b44dea03b8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-398",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 4
          },
          "uuid": "2ec533a2-5eb0-420a-8dc0-f2d6dc0e9976"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (398)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:10.256Z",
            "success-count": 3
          },
          "uuid": "9b5a4390-0ce4-46e9-b50f-81207cefaaa6"
        }
      ],
      "external-identifiers": {
        "container-id": "6c7960827616185cd3bd0e5358616c82b446fab20f189d28742866f2f1abfb24",
        "k8s-namespace": "openebs",
        "k8s-pod-name": "init-pvc-a98007c1-4485-4928-9e38-355a6ab271ae",
        "pod-name": "openebs/init-pvc-a98007c1-4485-4928-9e38-355a6ab271ae"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1847,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.cilium.k8s.policy.cluster=default"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.kubernetes.pod.namespace=openebs"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.186",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "6e:10:4a:7b:7e:6e",
        "interface-index": 65,
        "interface-name": "lxcb390a3f00bab",
        "mac": "02:19:6f:4e:f7:bf"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1847,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1847,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 398

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 398

```
Timestamp              Status   State                   Message
2023-09-06T00:31:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:31:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:31:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:31:00Z   OK       ready                   Set identity for this endpoint
2023-09-06T00:31:00Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1847

```
ID     LABELS
1847   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator
       k8s:io.kubernetes.pod.namespace=openebs

```


#### BPF Policy Get 443

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    404     4         0        

```


#### BPF CT List 443

```
Invalid argument: unknown type 443
```


#### Endpoint Get 443

```
[
  {
    "id": 443,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-443-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "1015f111-7340-4f35-9fc6-b47ef98a87e4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-443",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:30:56.695Z",
            "success-count": 1
          },
          "uuid": "88a5574d-4a51-4942-b999-1fbdf468ad74"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-443",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 7
          },
          "uuid": "93bb4b13-4b8a-4c7a-9135-e0dd60196dd9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (443)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:07.055Z",
            "success-count": 3
          },
          "uuid": "54a38aaa-c961-4c68-8478-399f80f9696e"
        }
      ],
      "external-identifiers": {
        "container-id": "8d35234b0d8474b19d1f99c72af883f14152e697b6de361b65ef84c550c72b64",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "streamchat-79dfbb9bb4-c954g",
        "pod-name": "streampai/streamchat-79dfbb9bb4-c954g"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3108,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=streamchat",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=79dfbb9bb4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=streamchat",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.209",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "0a:aa:87:00:2e:21",
        "interface-index": 53,
        "interface-name": "lxc4efd61adef5f",
        "mac": "5e:62:80:99:33:97"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3108,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3108,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 443

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 443

```
Timestamp              Status   State                   Message
2023-09-06T00:31:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:30:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:30:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:30:56Z   OK       ready                   Set identity for this endpoint
2023-09-06T00:30:56Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3108

```
ID     LABELS
3108   k8s:app=streamchat
       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
       k8s:io.cilium.k8s.namespace.labels.name=streampai
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=default
       k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 509

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 509

```
Invalid argument: unknown type 509
```


#### Endpoint Get 509

```
[
  {
    "id": 509,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-509-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5a5e0c87-2365-4674-a076-60bcb44c9ede"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-509",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:30:54.896Z",
            "success-count": 1
          },
          "uuid": "bd6d2982-a81d-4c5f-818f-3be649a71600"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-509",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 9
          },
          "uuid": "b0ccae83-4ec6-4c68-9cb8-81c4ca8c398a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (509)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:05.456Z",
            "success-count": 3
          },
          "uuid": "1d96d657-5c4e-4462-ac35-c907c4734b82"
        }
      ],
      "external-identifiers": {
        "container-id": "fdea3861f805101a5622efc1528eeebc2936e3cf0d749f3141eac4142fb40d9b",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "redis-68c95977f4-bl8l4",
        "pod-name": "streampai/redis-68c95977f4-bl8l4"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 11487,
        "labels": [
          "k8s:app=redis",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=68c95977f4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=redis",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.105",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "42:31:e2:9f:82:88",
        "interface-index": 47,
        "interface-name": "lxc15ef011ff99c",
        "mac": "92:14:45:fd:c1:6c"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 11487,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 11487,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 509

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 509

```
Timestamp              Status    State                   Message
2023-09-06T00:31:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK        regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:30:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:30:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:30:54Z   OK        ready                   Set identity for this endpoint
2023-09-06T00:30:54Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 11487

```
ID      LABELS
11487   k8s:app=redis
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 620

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 620

```
Invalid argument: unknown type 620
```


#### Endpoint Get 620

```
[
  {
    "id": 620,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-620-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "8744fa81-d553-424f-8578-0d72d624ae5f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-620",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:30:53.302Z",
            "success-count": 1
          },
          "uuid": "a6a8b89e-af33-46f9-88b1-bc8819eed905"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-620",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.261Z",
            "success-count": 10
          },
          "uuid": "2c3cfa4d-a1b4-4698-a672-ca26c05624bc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (620)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:14.267Z",
            "success-count": 4
          },
          "uuid": "ca59ecc2-e5bd-4c5d-a469-26ba47359552"
        }
      ],
      "external-identifiers": {
        "container-id": "9fa70144308c785c329e9e1e540372ce2219a24aa328ed2a0c9a9d83bd3a002b",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "backend-855f6c7b4-8bqth",
        "pod-name": "streampai/backend-855f6c7b4-8bqth"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 9256,
        "labels": [
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=backend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=855f6c7b4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=backend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.28",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "2e:06:c0:ad:5f:9d",
        "interface-index": 35,
        "interface-name": "lxc9ab0fdf09458",
        "mac": "c2:77:0f:81:d9:80"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 9256,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 9256,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 620

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 620

```
Timestamp              Status    State                   Message
2023-09-06T00:31:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK        regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:30:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:30:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:30:53Z   OK        ready                   Set identity for this endpoint
2023-09-06T00:30:53Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:52Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 9256

```
ID     LABELS
9256   k8s:app=backend
       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
       k8s:io.cilium.k8s.namespace.labels.name=streampai
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=default
       k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 628

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    6272    56        0        

```


#### BPF CT List 628

```
Invalid argument: unknown type 628
```


#### Endpoint Get 628

```
[
  {
    "id": 628,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-628-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5974dbc6-c735-4656-9eae-a408dace2bd5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-628",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:30:53.307Z",
            "success-count": 1
          },
          "uuid": "c34cbd25-b10f-4584-a2ed-640ea658004b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-628",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.258Z",
            "success-count": 10
          },
          "uuid": "f1fa04f7-112d-4b84-abcf-f533cc300b23"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (628)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:14.456Z",
            "success-count": 4
          },
          "uuid": "27a83874-d87c-427f-a002-df34e0f0c31b"
        }
      ],
      "external-identifiers": {
        "container-id": "1d0114b03d3369e04a9b708d173edb3c3969ee0d16a3335a48ee68c8c6cf0992",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "kratos-77cbf98c8f-wcvxh",
        "pod-name": "streampai/kratos-77cbf98c8f-wcvxh"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 11535,
        "labels": [
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=kratos",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=77cbf98c8f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=kratos",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.192",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "8a:ce:ab:1c:cc:c5",
        "interface-index": 41,
        "interface-name": "lxc2d18f368a137",
        "mac": "0a:f2:22:4e:68:39"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 11535,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 11535,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 628

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 628

```
Timestamp              Status    State                   Message
2023-09-06T00:31:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK        regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:30:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:30:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:30:53Z   OK        ready                   Set identity for this endpoint
2023-09-06T00:30:53Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:52Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 11535

```
ID      LABELS
11535   k8s:app=kratos
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 824

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 824

```
Invalid argument: unknown type 824
```


#### Endpoint Get 824

```
[
  {
    "id": 824,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-824-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b3a3a311-9b76-4192-bb1e-b17eda3d4dce"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-824",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:30:53.292Z",
            "success-count": 1
          },
          "uuid": "401b7509-8e5b-45cb-9536-8f1db3a85751"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-824",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.258Z",
            "success-count": 10
          },
          "uuid": "92d96009-8012-4b50-a97f-349961d482a5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (824)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:13.457Z",
            "success-count": 4
          },
          "uuid": "9fa8175a-79bf-4b43-8340-914316f340ef"
        }
      ],
      "external-identifiers": {
        "container-id": "b3cf16f326be04d55610e93cf3edf6651643877cd2f12ce26c8c9fca16a405a6",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "backend-855f6c7b4-fkt9r",
        "pod-name": "streampai/backend-855f6c7b4-fkt9r"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 9256,
        "labels": [
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=backend",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=855f6c7b4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=backend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.193",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "22:53:7c:c2:23:1b",
        "interface-index": 33,
        "interface-name": "lxc6cffdbcb447a",
        "mac": "82:ee:55:10:c1:fc"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 9256,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 9256,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 824

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 824

```
Timestamp              Status    State                   Message
2023-09-06T00:31:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK        regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:30:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:30:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:30:53Z   OK        ready                   Set identity for this endpoint
2023-09-06T00:30:53Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:52Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 9256

```
ID     LABELS
9256   k8s:app=backend
       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
       k8s:io.cilium.k8s.namespace.labels.name=streampai
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=default
       k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 858

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 858

```
Invalid argument: unknown type 858
```


#### Endpoint Get 858

```
[
  {
    "id": 858,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-858-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "e4374ad5-7c22-49ad-a556-ae6e8350af45"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-858",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:30:53.266Z",
            "success-count": 1
          },
          "uuid": "433acbf9-7111-4b23-a3aa-4df17453858a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-858",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 10
          },
          "uuid": "c4b47877-8f38-4c7b-a3e2-d1842f102249"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (858)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:13.274Z",
            "success-count": 4
          },
          "uuid": "bb722bdc-3b4c-47ff-be2a-64ed31373716"
        }
      ],
      "external-identifiers": {
        "container-id": "0e74ceef7111173e21530d74bc5d0979ed01215a7107ce666a6edc9dcaef4b02",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "frontend-58b6bf847f-j9rzh",
        "pod-name": "streampai/frontend-58b6bf847f-j9rzh"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 40807,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=58b6bf847f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=frontend",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.119",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "36:ef:df:4d:59:5c",
        "interface-index": 45,
        "interface-name": "lxcd1d1b64f4030",
        "mac": "a6:fc:4c:03:97:3b"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 40807,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 40807,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 858

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 858

```
Timestamp              Status    State                   Message
2023-09-06T00:31:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK        regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:30:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:30:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:30:53Z   OK        ready                   Set identity for this endpoint
2023-09-06T00:30:53Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:52Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 40807

```
ID      LABELS
40807   k8s:app=frontend
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 951

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    84816   796       0        

```


#### BPF CT List 951

```
Invalid argument: unknown type 951
```


#### Endpoint Get 951

```
[
  {
    "id": 951,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-951-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "3619828d-f3cd-4cc3-8055-7c4ad49767fa"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-951",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:29:53.714Z",
            "success-count": 1
          },
          "uuid": "846362e6-35fa-47cb-96d2-7e6cca71f0e8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-951",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.258Z",
            "success-count": 18
          },
          "uuid": "3e41a190-a23e-40e4-8a8e-e40e8dbed77f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (951)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:05.118Z",
            "success-count": 9
          },
          "uuid": "13d7e835-4c0c-4cff-818c-54af11955d1f"
        }
      ],
      "external-identifiers": {
        "container-id": "f370533491f5fe30412cad575ace2cd04b9bdc51a6daf7ae1bfd2fba353237d5",
        "k8s-namespace": "cert-manager",
        "k8s-pod-name": "cert-manager-cainjector-6774f986b-5fqd9",
        "pod-name": "cert-manager/cert-manager-cainjector-6774f986b-5fqd9"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 28402,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:app.kubernetes.io/component=cainjector",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:app=cainjector",
          "k8s:helm.sh/chart=cert-manager-v1.10.0",
          "k8s:app.kubernetes.io/name=cainjector",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-cainjector",
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.kubernetes.pod.namespace=cert-manager",
          "k8s:app.kubernetes.io/version=v1.10.0"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6774f986b"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/component=cainjector",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=cainjector",
          "k8s:app.kubernetes.io/version=v1.10.0",
          "k8s:app=cainjector",
          "k8s:helm.sh/chart=cert-manager-v1.10.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-cainjector",
          "k8s:io.kubernetes.pod.namespace=cert-manager"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.171",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "0e:81:db:58:a2:b2",
        "interface-index": 14,
        "interface-name": "lxcc3b0024664c5",
        "mac": "46:df:a0:a0:aa:a9"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 28402,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 28402,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 951

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 951

```
Timestamp              Status   State                   Message
2023-09-06T00:31:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:29:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:59Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:29:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:29:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:29:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:53Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:29:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:29:53Z   OK       ready                   Set identity for this endpoint
2023-09-06T00:29:53Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 28402

```
ID      LABELS
28402   k8s:app.kubernetes.io/component=cainjector
        k8s:app.kubernetes.io/instance=cert-manager
        k8s:app.kubernetes.io/managed-by=Helm
        k8s:app.kubernetes.io/name=cainjector
        k8s:app.kubernetes.io/version=v1.10.0
        k8s:app=cainjector
        k8s:helm.sh/chart=cert-manager-v1.10.0
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager
        k8s:io.cilium.k8s.namespace.labels.name=cert-manager
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-cainjector
        k8s:io.kubernetes.pod.namespace=cert-manager

```


#### BPF Policy Get 1164

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1164

```
Invalid argument: unknown type 1164
```


#### Endpoint Get 1164

```
[
  {
    "id": 1164,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1164-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "e5e87ac5-7e29-4cd6-9743-43c89bdde2ce"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1164",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:30:58.610Z",
            "success-count": 1
          },
          "uuid": "2beaf4a6-c664-4926-9b7a-03d6ae26eba3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-1164",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 5
          },
          "uuid": "b80e8302-be8f-4989-bd3e-89e0ead2ab5a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1164)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:09.255Z",
            "success-count": 3
          },
          "uuid": "a2ed934b-d4b4-47fa-b82f-4cc513747047"
        }
      ],
      "external-identifiers": {
        "container-id": "9de02d09272542c01eb1022d5d2feb8af4978a19e8eae4ab6cbccbe51176fbf7",
        "k8s-namespace": "openebs",
        "k8s-pod-name": "init-pvc-bf475e5e-08fc-4f1e-95bf-5e66e3b2ccb5",
        "pod-name": "openebs/init-pvc-bf475e5e-08fc-4f1e-95bf-5e66e3b2ccb5"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1847,
        "labels": [
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.kubernetes.pod.namespace=openebs"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.182",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "b6:8e:44:f6:b8:f6",
        "interface-index": 61,
        "interface-name": "lxc630e7e15710e",
        "mac": "c2:33:1e:dc:6b:f2"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1847,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1847,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1164

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1164

```
Timestamp              Status   State                   Message
2023-09-06T00:31:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:30:58Z   OK       ready                   Set identity for this endpoint
2023-09-06T00:30:58Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1847

```
ID     LABELS
1847   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator
       k8s:io.kubernetes.pod.namespace=openebs

```


#### BPF Policy Get 1412

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1412

```
Invalid argument: unknown type 1412
```


#### Endpoint Get 1412

```
[
  {
    "id": 1412,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1412-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "4f9c23ce-ecd6-4a1c-a595-3313d4e518c0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1412",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:30:59.495Z",
            "success-count": 1
          },
          "uuid": "b1a17614-47b5-406d-9c9d-ede3f85f94b6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-1412",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 4
          },
          "uuid": "c4880617-ae05-46f6-9941-622c85421324"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1412)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:09.856Z",
            "success-count": 3
          },
          "uuid": "5b4033e4-db21-4a3c-92fc-6011a3e82e34"
        }
      ],
      "external-identifiers": {
        "container-id": "a451c9b5da2e2ef2ba7cbb83689fd20870e7815a66f10eb9a13fbfb2a7a9c11f",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "pgweb-b74849bb6-hrcb8",
        "pod-name": "streampai/pgweb-b74849bb6-hrcb8"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 2199,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=pgweb"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=b74849bb6"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=pgweb",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.93",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "5e:99:ae:2c:23:55",
        "interface-index": 63,
        "interface-name": "lxc3dc0cfd41a9f",
        "mac": "26:95:e8:15:41:ed"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2199,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 2199,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1412

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1412

```
Timestamp              Status   State                   Message
2023-09-06T00:31:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:30:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:30:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:30:59Z   OK       ready                   Set identity for this endpoint
2023-09-06T00:30:59Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 2199

```
ID     LABELS
2199   k8s:app=pgweb
       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
       k8s:io.cilium.k8s.namespace.labels.name=streampai
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=default
       k8s:io.kubernetes.pod.namespace=streampai

```


#### BPF Policy Get 1526

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1526

```
Invalid argument: unknown type 1526
```


#### Endpoint Get 1526

```
[
  {
    "id": 1526,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1526-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "477277a6-ac92-4450-86d5-0bd95d6441f5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1526",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:30:58.295Z",
            "success-count": 1
          },
          "uuid": "55c88e6b-8874-4090-b77d-e5c0a47feab5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-1526",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 5
          },
          "uuid": "6dbaabbd-db32-42c6-b8e0-d1419b971606"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1526)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:09.057Z",
            "success-count": 3
          },
          "uuid": "8485b415-e47a-40e0-910c-d76e9081dd7c"
        }
      ],
      "external-identifiers": {
        "container-id": "99713cfc40a39a8f32c6e4d2cc8b5a2c2bb77eefb4553337f52cfaa3a4a979fe",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "postgres-migrations-79t9m",
        "pod-name": "streampai/postgres-migrations-79t9m"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 58695,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:controller-uid=4c43bff2-13bd-4dd8-a6bc-66894484ffe2",
          "k8s:batch.kubernetes.io/job-name=postgres-migrations",
          "k8s:job-name=postgres-migrations",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:batch.kubernetes.io/controller-uid=4c43bff2-13bd-4dd8-a6bc-66894484ffe2",
          "k8s:io.cilium.k8s.policy.serviceaccount=default"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "k8s:batch.kubernetes.io/controller-uid=4c43bff2-13bd-4dd8-a6bc-66894484ffe2",
          "k8s:batch.kubernetes.io/job-name=postgres-migrations",
          "k8s:controller-uid=4c43bff2-13bd-4dd8-a6bc-66894484ffe2",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:job-name=postgres-migrations"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.57",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "9a:ff:95:7a:3a:a5",
        "interface-index": 59,
        "interface-name": "lxc454e019d1f91",
        "mac": "32:66:c4:6c:d4:9d"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 58695,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 58695,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1526

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1526

```
Timestamp              Status    State                   Message
2023-09-06T00:31:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK        regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:30:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:30:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:30:58Z   OK        ready                   Set identity for this endpoint
2023-09-06T00:30:58Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 58695

```
ID      LABELS
58695   k8s:batch.kubernetes.io/controller-uid=4c43bff2-13bd-4dd8-a6bc-66894484ffe2
        k8s:batch.kubernetes.io/job-name=postgres-migrations
        k8s:controller-uid=4c43bff2-13bd-4dd8-a6bc-66894484ffe2
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai
        k8s:job-name=postgres-migrations

```


#### BPF Policy Get 1528

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    79490   593       0        

```


#### BPF CT List 1528

```
Invalid argument: unknown type 1528
```


#### Endpoint Get 1528

```
[
  {
    "id": 1528,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1528-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "646b7fbd-2650-430b-a154-2aa0ed9b5235"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1528",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:29:55.754Z",
            "success-count": 1
          },
          "uuid": "f9a5f563-ef17-46e7-a474-5c6ae0fb9de1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-1528",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 16
          },
          "uuid": "fe4eb0fe-d375-496b-9360-95b328a91cda"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1528)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:06.517Z",
            "success-count": 9
          },
          "uuid": "91b2b732-13ec-45b0-898c-97f450156299"
        }
      ],
      "external-identifiers": {
        "container-id": "d4bd4f9f8ea7ee195fabc8036dad2fca23563e0595d4677417c45a90a245f577",
        "k8s-namespace": "openebs",
        "k8s-pod-name": "openebs-localpv-provisioner-7d6ccb7795-4rhmc",
        "pod-name": "openebs/openebs-localpv-provisioner-7d6ccb7795-4rhmc"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 13128,
        "labels": [
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:name=openebs-localpv-provisioner",
          "k8s:openebs.io/component-name=openebs-localpv-provisioner",
          "k8s:openebs.io/version=3.4.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.kubernetes.pod.namespace=openebs"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7d6ccb7795"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:name=openebs-localpv-provisioner",
          "k8s:openebs.io/component-name=openebs-localpv-provisioner",
          "k8s:openebs.io/version=3.4.0"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.172",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "02:b6:c3:46:2e:6e",
        "interface-index": 31,
        "interface-name": "lxc32e5e00a9fb8",
        "mac": "c2:95:3d:99:19:2f"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 13128,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 13128,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1528

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1528

```
Timestamp              Status    State                   Message
2023-09-06T00:31:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK        regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:29:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:59Z   OK        regenerating            Regenerating endpoint: 
2023-09-06T00:29:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:29:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:29:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:55Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:29:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:29:55Z   OK        ready                   Set identity for this endpoint
2023-09-06T00:29:54Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:54Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 13128

```
ID      LABELS
13128   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator
        k8s:io.kubernetes.pod.namespace=openebs
        k8s:name=openebs-localpv-provisioner
        k8s:openebs.io/component-name=openebs-localpv-provisioner
        k8s:openebs.io/version=3.4.0

```


#### BPF Policy Get 1618

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1618

```
Invalid argument: unknown type 1618
```


#### Endpoint Get 1618

```
[
  {
    "id": 1618,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1618-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "dd8bf55f-57d4-4500-86ce-060aad77a647"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1618",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:00.683Z",
            "success-count": 1
          },
          "uuid": "b9d0f917-e0e2-4bc3-8c66-4c9a787d5010"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-1618",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 3
          },
          "uuid": "7f38e430-eafa-4d5b-b84c-b5f79e6a4313"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1618)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:10.857Z",
            "success-count": 3
          },
          "uuid": "0f4f9949-8125-4abe-878f-0a166a2aa879"
        }
      ],
      "external-identifiers": {
        "container-id": "18e08e2c4be6e09d3c3789412f7a310c8d303bb7dd92b730f1e40242d78bd4c5",
        "k8s-namespace": "ambassador",
        "k8s-pod-name": "traffic-manager-55d995585d-cs5xg",
        "pod-name": "ambassador/traffic-manager-55d995585d-cs5xg"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 63576,
        "labels": [
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:telepresence=manager",
          "k8s:app=traffic-manager",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=ambassador",
          "k8s:io.cilium.k8s.namespace.labels.name=ambassador",
          "k8s:io.kubernetes.pod.namespace=ambassador",
          "k8s:io.cilium.k8s.policy.serviceaccount=traffic-manager"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=55d995585d"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app=traffic-manager",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=ambassador",
          "k8s:io.cilium.k8s.namespace.labels.name=ambassador",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=traffic-manager",
          "k8s:io.kubernetes.pod.namespace=ambassador",
          "k8s:telepresence=manager"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "namedPorts": [
        {
          "name": "api",
          "port": 8081,
          "protocol": "TCP"
        },
        {
          "name": "grpc-trace",
          "port": 15766,
          "protocol": "TCP"
        },
        {
          "name": "https",
          "port": 443,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.84",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "5a:a2:a3:fa:dc:a1",
        "interface-index": 67,
        "interface-name": "lxc827eb49d10c9",
        "mac": "3a:47:05:14:d0:a9"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 63576,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 63576,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1618

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1618

```
Timestamp              Status   State                   Message
2023-09-06T00:31:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:31:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:31:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:31:00Z   OK       ready                   Set identity for this endpoint
2023-09-06T00:31:00Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 63576

```
ID      LABELS
63576   k8s:app=traffic-manager
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=ambassador
        k8s:io.cilium.k8s.namespace.labels.name=ambassador
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=traffic-manager
        k8s:io.kubernetes.pod.namespace=ambassador
        k8s:telepresence=manager

```


#### BPF Policy Get 1959

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    23984   185       0        
Allow    Egress      0          ANY          NONE         disabled    12164   92        0        

```


#### BPF CT List 1959

```
Invalid argument: unknown type 1959
```


#### Endpoint Get 1959

```
[
  {
    "id": 1959,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1959-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d2b95af3-bafa-4647-a10b-bdf217466d4e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1959",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:29:56.354Z",
            "success-count": 1
          },
          "uuid": "b5186089-4e29-46bc-9f4a-fadee274fc5a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-1959",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.261Z",
            "success-count": 15
          },
          "uuid": "f4458642-fb5e-4e2f-b821-2dc7da4b0242"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1959)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:06.918Z",
            "success-count": 9
          },
          "uuid": "6e666698-7a33-4727-b92b-50eda0acc303"
        }
      ],
      "external-identifiers": {
        "container-id": "bb9269e9460449db27b60c142005050dd8e5336dd2adf44238e6e30b018dabaf",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "metrics-server-7f86dff975-b2xzk",
        "pod-name": "kube-system/metrics-server-7f86dff975-b2xzk"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 32957,
        "labels": [
          "k8s:io.cilium.k8s.policy.serviceaccount=metrics-server",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:k8s-app=metrics-server",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.kubernetes.pod.namespace=kube-system"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7f86dff975"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=metrics-server",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=metrics-server"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "namedPorts": [
        {
          "name": "https",
          "port": 10250,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.212",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "f2:d2:26:63:c2:bf",
        "interface-index": 23,
        "interface-name": "lxc4810a327af6a",
        "mac": "3e:c5:77:c1:57:89"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 32957,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 32957,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1959

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1959

```
Timestamp              Status   State                   Message
2023-09-06T00:31:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:29:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:59Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:29:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:29:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:29:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:56Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:29:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:29:56Z   OK       ready                   Set identity for this endpoint
2023-09-06T00:29:55Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 32957

```
ID      LABELS
32957   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=metrics-server
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=metrics-server

```


#### BPF Policy Get 1992

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    25051   96        0        
Allow    Egress      0          ANY          NONE         disabled    6055    25        0        

```


#### BPF CT List 1992

```
Invalid argument: unknown type 1992
```


#### Endpoint Get 1992

```
[
  {
    "id": 1992,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1992-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "bcdfc244-271e-4426-9f26-34673aa2d020"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1992",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:29:53.029Z",
            "success-count": 1
          },
          "uuid": "e7de3997-3d54-437a-a3ef-d52649ed9e7d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-1992",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.261Z",
            "success-count": 18
          },
          "uuid": "2639ea3a-39ae-4aea-92be-057df74efaac"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1992)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:13.040Z",
            "success-count": 10
          },
          "uuid": "3eddb01a-d6f1-49c5-b811-105b61c2b7c1"
        }
      ],
      "external-identifiers": {
        "container-id": "497590f0e9d4a25c785a3db55e8df58883c4635e00f3dff5eb160175d0f80221",
        "k8s-namespace": "cert-manager",
        "k8s-pod-name": "cert-manager-webhook-879c48cd4-b4q2j",
        "pod-name": "cert-manager/cert-manager-webhook-879c48cd4-b4q2j"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 12886,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:helm.sh/chart=cert-manager-v1.10.0",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-webhook",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=webhook",
          "k8s:io.kubernetes.pod.namespace=cert-manager",
          "k8s:app.kubernetes.io/component=webhook",
          "k8s:app.kubernetes.io/version=v1.10.0",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app=webhook"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=879c48cd4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/component=webhook",
          "k8s:app.kubernetes.io/instance=cert-manager",
          "k8s:app.kubernetes.io/managed-by=Helm",
          "k8s:app.kubernetes.io/name=webhook",
          "k8s:app.kubernetes.io/version=v1.10.0",
          "k8s:app=webhook",
          "k8s:helm.sh/chart=cert-manager-v1.10.0",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager",
          "k8s:io.cilium.k8s.namespace.labels.name=cert-manager",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-webhook",
          "k8s:io.kubernetes.pod.namespace=cert-manager"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "namedPorts": [
        {
          "name": "healthcheck",
          "port": 6080,
          "protocol": "TCP"
        },
        {
          "name": "https",
          "port": 10250,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.219",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "9e:20:be:e0:16:ea",
        "interface-index": 12,
        "interface-name": "lxcfe0350a80770",
        "mac": "b2:4a:f6:62:12:ff"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 12886,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 12886,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1992

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1992

```
Timestamp              Status   State                   Message
2023-09-06T00:31:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:29:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:59Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:29:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:29:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:29:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:53Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:29:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:29:53Z   OK       ready                   Set identity for this endpoint
2023-09-06T00:29:52Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 12886

```
ID      LABELS
12886   k8s:app.kubernetes.io/component=webhook
        k8s:app.kubernetes.io/instance=cert-manager
        k8s:app.kubernetes.io/managed-by=Helm
        k8s:app.kubernetes.io/name=webhook
        k8s:app.kubernetes.io/version=v1.10.0
        k8s:app=webhook
        k8s:helm.sh/chart=cert-manager-v1.10.0
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cert-manager
        k8s:io.cilium.k8s.namespace.labels.name=cert-manager
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=cert-manager-webhook
        k8s:io.kubernetes.pod.namespace=cert-manager

```


#### BPF Policy Get 2084

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2084

```
Invalid argument: unknown type 2084
```


#### Endpoint Get 2084

```
[
  {
    "id": 2084,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2084-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "a17500c1-9bcc-4e76-b0fb-b362d45c1c2b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2084",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:29:54.113Z",
            "success-count": 1
          },
          "uuid": "98303b73-20a6-49cb-af76-c623ede55f49"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-2084",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 17
          },
          "uuid": "4662e9d5-237c-4e00-b959-3cc063ec4753"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2084)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:15.317Z",
            "success-count": 10
          },
          "uuid": "0b7933bc-0339-4adb-8fd4-f4100d1c4d58"
        }
      ],
      "external-identifiers": {
        "container-id": "d88262b0ed9dc4e168da7438e638a36fb171af7106ca6a08520e58aa219eb8ee",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "hubble-ui-6b468cff75-sv8hh",
        "pod-name": "kube-system/hubble-ui-6b468cff75-sv8hh"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 5267,
        "labels": [
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:app.kubernetes.io/name=hubble-ui",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:k8s-app=hubble-ui",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6b468cff75"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=hubble-ui",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=hubble-ui"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "namedPorts": [
        {
          "name": "grpc",
          "port": 8090,
          "protocol": "TCP"
        },
        {
          "name": "http",
          "port": 8081,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.77",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "b6:b6:9c:8f:6f:8e",
        "interface-index": 21,
        "interface-name": "lxc8d6e8e4b0477",
        "mac": "ce:23:25:d8:95:26"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5267,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 5267,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2084

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2084

```
Timestamp              Status    State                   Message
2023-09-06T00:31:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK        regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:29:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:59Z   OK        regenerating            Regenerating endpoint: 
2023-09-06T00:29:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:29:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:54Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:29:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:54Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:29:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:29:54Z   OK        ready                   Set identity for this endpoint
2023-09-06T00:29:53Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:53Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 5267

```
ID     LABELS
5267   k8s:app.kubernetes.io/name=hubble-ui
       k8s:app.kubernetes.io/part-of=cilium
       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=hubble-ui
       k8s:io.kubernetes.pod.namespace=kube-system
       k8s:k8s-app=hubble-ui

```


#### BPF Policy Get 2201

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2201

```
Invalid argument: unknown type 2201
```


#### Endpoint Get 2201

```
[
  {
    "id": 2201,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2201-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "fb6ca33b-9cfb-4612-a1e7-3243d66c1855"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2201",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:30:57.495Z",
            "success-count": 1
          },
          "uuid": "bfddf8e9-5f35-44d6-a6fb-73b2a0875ecb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-2201",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 6
          },
          "uuid": "1c067a00-8f2c-4abe-90e6-bdca68683410"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2201)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:08.457Z",
            "success-count": 3
          },
          "uuid": "be47d2c7-c66e-4398-a7a2-77d5e9ee9c09"
        }
      ],
      "external-identifiers": {
        "container-id": "ca0f77d88e6aaf1334a48651a8a76e3bbe272b9d20698a863313d2ddba6aacb3",
        "k8s-namespace": "openebs",
        "k8s-pod-name": "init-pvc-4f2ec5d9-e41b-425e-bdb7-332c06f7825a",
        "pod-name": "openebs/init-pvc-4f2ec5d9-e41b-425e-bdb7-332c06f7825a"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1847,
        "labels": [
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.kubernetes.pod.namespace=openebs"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.18",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "92:2c:59:88:16:40",
        "interface-index": 57,
        "interface-name": "lxc24236c43383d",
        "mac": "5a:e4:69:fa:22:17"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1847,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1847,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2201

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2201

```
Timestamp              Status    State                   Message
2023-09-06T00:31:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK        regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:30:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:30:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:30:57Z   OK        ready                   Set identity for this endpoint
2023-09-06T00:30:57Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 1847

```
ID     LABELS
1847   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator
       k8s:io.kubernetes.pod.namespace=openebs

```


#### BPF Policy Get 2589

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    200     2         0        

```


#### BPF CT List 2589

```
Invalid argument: unknown type 2589
```


#### Endpoint Get 2589

```
[
  {
    "id": 2589,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2589-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "a5994b63-ca31-4911-9733-7f6a09d08b24"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2589",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:30:57.455Z",
            "success-count": 1
          },
          "uuid": "80a61f31-0cc5-4dbd-ac20-aee50ebfcef4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-2589",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 6
          },
          "uuid": "0680d0f7-0016-4453-b2dd-55bb73b1fba7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2589)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:08.057Z",
            "success-count": 3
          },
          "uuid": "dc244bfa-9aec-4489-91e0-6ab8ae5a93f4"
        }
      ],
      "external-identifiers": {
        "container-id": "7bdd2f09da2a2db18752b701b4b102e33364d7c708a55301c07e9e54d3a0584f",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "livestream-migrations-8nnxm",
        "pod-name": "streampai/livestream-migrations-8nnxm"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7207,
        "labels": [
          "k8s:batch.kubernetes.io/job-name=livestream-migrations",
          "k8s:batch.kubernetes.io/controller-uid=77988019-4ff6-4cc9-b0bc-496c50fe36e6",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:job-name=livestream-migrations",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:controller-uid=77988019-4ff6-4cc9-b0bc-496c50fe36e6",
          "k8s:io.cilium.k8s.policy.serviceaccount=default"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "k8s:batch.kubernetes.io/controller-uid=77988019-4ff6-4cc9-b0bc-496c50fe36e6",
          "k8s:batch.kubernetes.io/job-name=livestream-migrations",
          "k8s:controller-uid=77988019-4ff6-4cc9-b0bc-496c50fe36e6",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:job-name=livestream-migrations"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.101",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "76:06:9a:f2:1f:bc",
        "interface-index": 55,
        "interface-name": "lxcd430f9df641c",
        "mac": "16:16:64:75:1d:1a"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7207,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7207,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2589

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2589

```
Timestamp              Status    State                   Message
2023-09-06T00:31:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK        regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:30:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:30:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:30:57Z   OK        ready                   Set identity for this endpoint
2023-09-06T00:30:57Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 7207

```
ID     LABELS
7207   k8s:batch.kubernetes.io/controller-uid=77988019-4ff6-4cc9-b0bc-496c50fe36e6
       k8s:batch.kubernetes.io/job-name=livestream-migrations
       k8s:controller-uid=77988019-4ff6-4cc9-b0bc-496c50fe36e6
       k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
       k8s:io.cilium.k8s.namespace.labels.name=streampai
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=default
       k8s:io.kubernetes.pod.namespace=streampai
       k8s:job-name=livestream-migrations

```


#### BPF Policy Get 2682

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    3584    32        0        

```


#### BPF CT List 2682

```
Invalid argument: unknown type 2682
```


#### Endpoint Get 2682

```
[
  {
    "id": 2682,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2682-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c29bf271-f7cb-4244-99f2-e76553eeca57"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2682",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:30:55.896Z",
            "success-count": 1
          },
          "uuid": "0993bd4a-960e-4b01-8345-764fc00155f6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-2682",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.259Z",
            "success-count": 8
          },
          "uuid": "74a77e95-6ffc-4d89-abe2-ae3dc87c6f30"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2682)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:16.463Z",
            "success-count": 4
          },
          "uuid": "3139f7fa-9d61-449b-8064-0c3e16aeba04"
        }
      ],
      "external-identifiers": {
        "container-id": "c026a83c52408fd3346050e2ff835b5940598c69b468b976ff8dcb9fda3afd0d",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "kratos-migrations-km25z",
        "pod-name": "streampai/kratos-migrations-km25z"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 707,
        "labels": [
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:batch.kubernetes.io/job-name=kratos-migrations",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:batch.kubernetes.io/controller-uid=40d90209-752d-436b-a06a-3c40881e0092",
          "k8s:job-name=kratos-migrations",
          "k8s:controller-uid=40d90209-752d-436b-a06a-3c40881e0092"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "k8s:batch.kubernetes.io/controller-uid=40d90209-752d-436b-a06a-3c40881e0092",
          "k8s:batch.kubernetes.io/job-name=kratos-migrations",
          "k8s:controller-uid=40d90209-752d-436b-a06a-3c40881e0092",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:job-name=kratos-migrations"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.155",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "82:01:69:e5:9b:81",
        "interface-index": 51,
        "interface-name": "lxcc175dc79836e",
        "mac": "b6:c0:7c:ea:99:3d"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 707,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 707,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2682

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2682

```
Timestamp              Status   State                   Message
2023-09-06T00:31:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:30:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:30:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:30:55Z   OK       ready                   Set identity for this endpoint
2023-09-06T00:30:55Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 707

```
ID    LABELS
707   k8s:batch.kubernetes.io/controller-uid=40d90209-752d-436b-a06a-3c40881e0092
      k8s:batch.kubernetes.io/job-name=kratos-migrations
      k8s:controller-uid=40d90209-752d-436b-a06a-3c40881e0092
      k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
      k8s:io.cilium.k8s.namespace.labels.name=streampai
      k8s:io.cilium.k8s.policy.cluster=default
      k8s:io.cilium.k8s.policy.serviceaccount=default
      k8s:io.kubernetes.pod.namespace=streampai
      k8s:job-name=kratos-migrations

```


#### BPF Policy Get 3168

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    13602   122       0        
Allow    Ingress     1          ANY          NONE         disabled    14466   166       0        
Allow    Egress      0          ANY          NONE         disabled    11820   128       0        

```


#### BPF CT List 3168

```
Invalid argument: unknown type 3168
```


#### Endpoint Get 3168

```
[
  {
    "id": 3168,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3168-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "40c09b9b-e301-4935-b555-8ef5c8ed0ffd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3168",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:29:54.154Z",
            "success-count": 1
          },
          "uuid": "70661a1e-183d-4b41-b1d2-e1a73e4d79fb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-3168",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 17
          },
          "uuid": "9e5fe8ef-d7cc-4617-bbe5-9941d85bece9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3168)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:15.920Z",
            "success-count": 10
          },
          "uuid": "9f032f1c-5735-4c44-862b-d073662a5787"
        }
      ],
      "external-identifiers": {
        "container-id": "71bf6a940935ed372c3978e84a5afcc111925fcafe85ba91a8a7039f52e2f1d1",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-878bb57ff-j98j5",
        "pod-name": "kube-system/coredns-878bb57ff-j98j5"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 6400,
        "labels": [
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:k8s-app=kube-dns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=878bb57ff"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.207",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "3a:84:72:3f:4a:4b",
        "interface-index": 25,
        "interface-name": "lxc57de2208c7d6",
        "mac": "ee:62:d3:7f:dc:20"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6400,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 6400,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3168

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3168

```
Timestamp              Status    State                   Message
2023-09-06T00:31:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK        regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:29:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:59Z   OK        regenerating            Regenerating endpoint: 
2023-09-06T00:29:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:29:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:54Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:29:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:54Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:29:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:29:54Z   OK        ready                   Set identity for this endpoint
2023-09-06T00:29:53Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:53Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 6400

```
ID     LABELS
6400   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=coredns
       k8s:io.kubernetes.pod.namespace=kube-system
       k8s:k8s-app=kube-dns

```


#### BPF Policy Get 3501

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    25641   268       0        

```


#### BPF CT List 3501

```
Invalid argument: unknown type 3501
```


#### Endpoint Get 3501

```
[
  {
    "id": 3501,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3501-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "66fb40e1-a45e-4f4a-877e-6c8cb795c351"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3501",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:29:57.319Z",
            "success-count": 1
          },
          "uuid": "d212fe66-8a3c-4611-b887-faa79b5effe5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-3501",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.261Z",
            "success-count": 14
          },
          "uuid": "73eff7c3-2eb6-4379-b12a-f58fcb7a6bee"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3501)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:07.518Z",
            "success-count": 9
          },
          "uuid": "7b3f02a5-f768-4b67-abb2-21df21ab0797"
        }
      ],
      "external-identifiers": {
        "container-id": "835e1d56d93b8f2f19c75b1d41a3c9e9b1118b9aba1398cdc26b6269203e2dec",
        "k8s-namespace": "openebs",
        "k8s-pod-name": "openebs-ndm-node-exporter-prqkp",
        "pod-name": "openebs/openebs-ndm-node-exporter-prqkp"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 8310,
        "labels": [
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:name=openebs-ndm-node-exporter",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:openebs.io/component-name=ndm-node-exporter",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:openebs.io/version=3.4.0"
        ]
      },
      "labels": {
        "derived": [
          "k8s:controller-revision-hash=65597f5db8",
          "k8s:pod-template-generation=1"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator",
          "k8s:io.kubernetes.pod.namespace=openebs",
          "k8s:name=openebs-ndm-node-exporter",
          "k8s:openebs.io/component-name=ndm-node-exporter",
          "k8s:openebs.io/version=3.4.0"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "namedPorts": [
        {
          "name": "metrics",
          "port": 9101,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.199",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "36:91:b2:7c:e4:ea",
        "interface-index": 27,
        "interface-name": "lxcdac5f40c881a",
        "mac": "56:e6:51:21:0f:ff"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 8310,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 8310,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3501

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3501

```
Timestamp              Status   State                   Message
2023-09-06T00:31:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:29:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:59Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:29:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:29:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:29:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:57Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:29:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:29:57Z   OK       ready                   Set identity for this endpoint
2023-09-06T00:29:57Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 8310

```
ID     LABELS
8310   k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=openebs
       k8s:io.cilium.k8s.policy.cluster=default
       k8s:io.cilium.k8s.policy.serviceaccount=openebs-maya-operator
       k8s:io.kubernetes.pod.namespace=openebs
       k8s:name=openebs-ndm-node-exporter
       k8s:openebs.io/component-name=ndm-node-exporter
       k8s:openebs.io/version=3.4.0

```


#### BPF Policy Get 3565

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    416     4         0        

```


#### BPF CT List 3565

```
Invalid argument: unknown type 3565
```


#### Endpoint Get 3565

```
[
  {
    "id": 3565,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3565-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "ec69c002-c49d-48aa-a750-bf657af88b50"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3565",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:30:55.296Z",
            "success-count": 1
          },
          "uuid": "a362aa6e-50df-4384-8cfb-2dd14ab4608c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-3565",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.260Z",
            "success-count": 8
          },
          "uuid": "f6d312c4-844f-42c7-85eb-548a5845754f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3565)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:16.055Z",
            "success-count": 4
          },
          "uuid": "98e17afd-e467-49b2-9290-1e95b6e2ab4f"
        }
      ],
      "external-identifiers": {
        "container-id": "7105d73fb6e3dc86e9af5689689dc7cea32c3f18162f1674d59a321a7ce26b8f",
        "k8s-namespace": "streampai",
        "k8s-pod-name": "create-minio-buckets-2hsfq",
        "pod-name": "streampai/create-minio-buckets-2hsfq"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 24494,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:batch.kubernetes.io/controller-uid=636c9c65-d057-4ed2-867f-db0fe0944e38",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:controller-uid=636c9c65-d057-4ed2-867f-db0fe0944e38",
          "k8s:batch.kubernetes.io/job-name=create-minio-buckets",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:job-name=create-minio-buckets"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "k8s:batch.kubernetes.io/controller-uid=636c9c65-d057-4ed2-867f-db0fe0944e38",
          "k8s:batch.kubernetes.io/job-name=create-minio-buckets",
          "k8s:controller-uid=636c9c65-d057-4ed2-867f-db0fe0944e38",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai",
          "k8s:io.cilium.k8s.namespace.labels.name=streampai",
          "k8s:io.cilium.k8s.policy.cluster=default",
          "k8s:io.cilium.k8s.policy.serviceaccount=default",
          "k8s:io.kubernetes.pod.namespace=streampai",
          "k8s:job-name=create-minio-buckets"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.144",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "32:2a:c3:8e:1d:f0",
        "interface-index": 49,
        "interface-name": "lxcf382a3fb49e9",
        "mac": "b2:21:b4:61:5a:c6"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 24494,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 24494,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3565

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3565

```
Timestamp              Status    State                   Message
2023-09-06T00:31:02Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK        regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:30:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK        regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:30:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:30:55Z   OK        ready                   Set identity for this endpoint
2023-09-06T00:30:55Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 24494

```
ID      LABELS
24494   k8s:batch.kubernetes.io/controller-uid=636c9c65-d057-4ed2-867f-db0fe0944e38
        k8s:batch.kubernetes.io/job-name=create-minio-buckets
        k8s:controller-uid=636c9c65-d057-4ed2-867f-db0fe0944e38
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=streampai
        k8s:io.cilium.k8s.namespace.labels.name=streampai
        k8s:io.cilium.k8s.policy.cluster=default
        k8s:io.cilium.k8s.policy.serviceaccount=default
        k8s:io.kubernetes.pod.namespace=streampai
        k8s:job-name=create-minio-buckets

```


#### BPF Policy Get 3726

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    734     8         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3726

```
Invalid argument: unknown type 3726
```


#### Endpoint Get 3726

```
[
  {
    "id": 3726,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Enabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3726-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "4d90dd55-cfd5-4760-8f86-f4da8ab3bb31"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3726",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:29:52.820Z",
            "success-count": 1
          },
          "uuid": "e1355f1b-d5e2-4e98-bde4-ce24fefb6b7c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "1m0s"
          },
          "name": "sync-policymap-3726",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:02.259Z",
            "success-count": 18
          },
          "uuid": "87ccbeae-c1f4-4d93-895d-64cc5864b03d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3726)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2023-09-06T00:31:12.822Z",
            "success-count": 10
          },
          "uuid": "bd8d9795-898b-4be9-922a-678d43bbd300"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2023-09-06T00:31:02Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.244.0.206",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "6e:98:93:71:c9:4b",
        "interface-index": 6,
        "interface-name": "lxc_health",
        "mac": "9a:cc:54:68:7f:51"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 2,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 2
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Enabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3726

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3726

```
Timestamp              Status   State                   Message
2023-09-06T00:31:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:31:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:02Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:31:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:31:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:01Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:31:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:31:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:31:00Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:31:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:59Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:30:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted, Envoy Listeners added)
2023-09-06T00:30:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted, Envoy Listeners added
2023-09-06T00:30:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:30:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:30:53Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:30:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2023-09-06T00:29:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:59Z   OK       regenerating            Regenerating endpoint: 
2023-09-06T00:29:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2023-09-06T00:29:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2023-09-06T00:29:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2023-09-06T00:29:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2023-09-06T00:29:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2023-09-06T00:29:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2023-09-06T00:29:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2023-09-06T00:29:52Z   OK       regenerating            Regenerating endpoint: updated security labels
2023-09-06T00:29:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2023-09-06T00:29:52Z   OK       ready                   Set identity for this endpoint
2023-09-06T00:29:51Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Service list

```
ID    Frontend              Service Type   Backend                            
4     10.96.0.1:443         ClusterIP      1 => 172.17.0.2:6443 (active)      
8     10.96.0.10:53         ClusterIP      1 => 10.244.0.207:53 (active)      
9     10.96.0.10:9153       ClusterIP      1 => 10.244.0.207:9153 (active)    
116   10.102.228.233:80     ClusterIP      1 => 10.244.0.77:8081 (active)     
117   10.109.147.188:443    ClusterIP      1 => 10.244.0.212:10250 (active)   
118   10.105.180.26:9402    ClusterIP      1 => 10.244.0.240:9402 (active)    
119   10.108.137.97:443     ClusterIP      1 => 10.244.0.219:10250 (active)   
120   10.109.115.136:443    ClusterIP      1 => 172.17.0.2:4244 (active)      
121   10.104.172.173:80     ClusterIP      1 => 10.244.0.197:4245 (active)    
122   10.108.77.184:7000    ClusterIP      1 => 10.244.0.28:7000 (active)     
                                           2 => 10.244.0.193:7000 (active)    
123   10.105.72.35:7000     ClusterIP                                         
124   10.100.123.5:3000     ClusterIP      1 => 10.244.0.104:3000 (active)    
                                           2 => 10.244.0.50:3000 (active)     
                                           3 => 10.244.0.119:3000 (active)    
                                           4 => 10.244.0.21:3000 (active)     
125   10.110.120.45:4433    ClusterIP      1 => 10.244.0.192:4433 (active)    
126   10.109.149.13:5432    ClusterIP                                         
127   10.98.222.33:9001     ClusterIP                                         
128   10.98.222.33:9000     ClusterIP                                         
129   10.105.143.77:8081    ClusterIP                                         
130   10.106.247.125:5432   ClusterIP                                         
131   10.99.225.9:6379      ClusterIP      1 => 10.244.0.105:6379 (active)    
132   10.99.89.133:80       ClusterIP                                         
133   172.17.223.107:80     LoadBalancer                                      
134   0.0.0.0:30867         NodePort                                          
135   172.17.0.2:30867      NodePort                                          
136   10.107.136.162:443    ClusterIP                                         
```

#### Policy get

```
:
 []
Revision: 2

```


#### Cilium memory map


```
00400000-02bf5000 r-xp 00000000 08:02 43936693                           /usr/bin/cilium-agent
02bf5000-0577f000 r--p 027f5000 08:02 43936693                           /usr/bin/cilium-agent
0577f000-058a3000 rw-p 0537f000 08:02 43936693                           /usr/bin/cilium-agent
058a3000-06036000 rw-p 00000000 00:00 0 
c000000000-c002600000 rw-p 00000000 00:00 0 
c002600000-c005400000 rw-p 00000000 00:00 0 
c005400000-c005800000 rw-p 00000000 00:00 0 
c005800000-c008000000 ---p 00000000 00:00 0 
7f3b84e8e000-7f3b85023000 rw-p 00000000 00:00 0 
7f3b85023000-7f3b85064000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b85064000-7f3b850a5000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b850a5000-7f3b850e6000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b850e6000-7f3b85127000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b85127000-7f3b85168000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b85168000-7f3b851a9000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b851a9000-7f3b851ea000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b851ea000-7f3b8522b000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b8522b000-7f3b8526c000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b8526c000-7f3b852ad000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b852ad000-7f3b852ee000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b852ee000-7f3b8532f000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b8532f000-7f3b85331000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b85331000-7f3b85333000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b85333000-7f3b85335000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b85335000-7f3b85337000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b85337000-7f3b85339000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b85339000-7f3b8533b000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b8533b000-7f3b8533d000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b8533d000-7f3b8533f000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b8533f000-7f3b85341000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b85341000-7f3b85343000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b85343000-7f3b85345000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b85345000-7f3b85347000 rw-s 00000000 00:0e 52                         anon_inode:[perf_event]
7f3b85347000-7f3b87e00000 rw-p 00000000 00:00 0 
7f3b87e00000-7f3b88000000 rw-p 00000000 00:00 0 
7f3b88000000-7f3b880a9000 rw-p 00000000 00:00 0 
7f3b880a9000-7f3b98622000 ---p 00000000 00:00 0 
7f3b98622000-7f3b98623000 rw-p 00000000 00:00 0 
7f3b98623000-7f3baa4d2000 ---p 00000000 00:00 0 
7f3baa4d2000-7f3baa4d3000 rw-p 00000000 00:00 0 
7f3baa4d3000-7f3bac8a8000 ---p 00000000 00:00 0 
7f3bac8a8000-7f3bac8a9000 rw-p 00000000 00:00 0 
7f3bac8a9000-7f3bacd22000 ---p 00000000 00:00 0 
7f3bacd22000-7f3bacd23000 rw-p 00000000 00:00 0 
7f3bacd23000-7f3bacda2000 ---p 00000000 00:00 0 
7f3bacda2000-7f3bace02000 rw-p 00000000 00:00 0 
7ffc2d8a0000-7ffc2d8c1000 rw-p 00000000 00:00 0                          [stack]
7ffc2d92c000-7ffc2d930000 r--p 00000000 00:00 0                          [vvar]
7ffc2d930000-7ffc2d932000 r-xp 00000000 00:00 0                          [vdso]
ffffffffff600000-ffffffffff601000 --xp 00000000 00:00 0                  [vsyscall]

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### ipam

```
<nil>
```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0xc00174e070)({
 Events: (chan k8s.ServiceEvent) (cap=128) 0xc000f88de0,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=23) {
  (k8s.ServiceID) cert-manager/cert-manager-webhook: (*k8s.Service)(0xc001b1e420)(frontends:[10.108.137.97]/ports=[https]/selector=map[app.kubernetes.io/component:webhook app.kubernetes.io/instance:cert-manager app.kubernetes.io/name:webhook]),
  (k8s.ServiceID) streampai/backend: (*k8s.Service)(0xc0052444d0)(frontends:[10.108.77.184]/ports=[http]/selector=map[app:backend]),
  (k8s.ServiceID) ambassador/traffic-manager: (*k8s.Service)(0xc002742000)(frontends:[]/ports=[api grpc-trace]/selector=map[app:traffic-manager telepresence:manager]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0xc001b1e580)(frontends:[10.96.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0xc001b1e630)(frontends:[10.109.115.136]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/hubble-relay: (*k8s.Service)(0xc001b1e6e0)(frontends:[10.104.172.173]/ports=[]/selector=map[k8s-app:hubble-relay]),
  (k8s.ServiceID) kube-system/metrics-server: (*k8s.Service)(0xc001b1e790)(frontends:[10.109.147.188]/ports=[https]/selector=map[k8s-app:metrics-server]),
  (k8s.ServiceID) streampai/coqui: (*k8s.Service)(0xc0046a4420)(frontends:[10.105.72.35]/ports=[http]/selector=map[app:coqui]),
  (k8s.ServiceID) streampai/frontend: (*k8s.Service)(0xc001616a50)(frontends:[10.100.123.5]/ports=[http]/selector=map[app:frontend]),
  (k8s.ServiceID) streampai/postgres: (*k8s.Service)(0xc000d57d90)(frontends:[10.106.247.125]/ports=[]/selector=map[app:postgres]),
  (k8s.ServiceID) streampai/redis: (*k8s.Service)(0xc0046a48f0)(frontends:[10.99.225.9]/ports=[http]/selector=map[app:redis]),
  (k8s.ServiceID) streampai/cilium-gateway-sgtw: (*k8s.Service)(0xc0035c4580)(frontends:[10.99.89.133]/ports=[port-80]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-ui: (*k8s.Service)(0xc001b1e4d0)(frontends:[10.102.228.233]/ports=[http]/selector=map[k8s-app:hubble-ui]),
  (k8s.ServiceID) cert-manager/cert-manager: (*k8s.Service)(0xc001b1e840)(frontends:[10.105.180.26]/ports=[tcp-prometheus-servicemonitor]/selector=map[app.kubernetes.io/component:controller app.kubernetes.io/instance:cert-manager app.kubernetes.io/name:cert-manager]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0xc001b1e8f0)(frontends:[10.96.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) streampai/kratos: (*k8s.Service)(0xc0046a44d0)(frontends:[10.110.120.45]/ports=[http]/selector=map[app:kratos]),
  (k8s.ServiceID) streampai/pgweb: (*k8s.Service)(0xc005244630)(frontends:[10.105.143.77]/ports=[http]/selector=map[app:pgweb]),
  (k8s.ServiceID) openebs/openebs-ndm-cluster-exporter-service: (*k8s.Service)(0xc001b1e2c0)(frontends:[]/ports=[metrics]/selector=map[name:openebs-ndm-cluster-exporter]),
  (k8s.ServiceID) openebs/openebs-ndm-node-exporter-service: (*k8s.Service)(0xc001b1e370)(frontends:[]/ports=[metrics]/selector=map[name:openebs-ndm-node-exporter]),
  (k8s.ServiceID) kube-system/cilium-envoy: (*k8s.Service)(0xc001b1e9a0)(frontends:[]/ports=[envoy-metrics]/selector=map[k8s-app:cilium-envoy]),
  (k8s.ServiceID) streampai/livestreamdb: (*k8s.Service)(0xc0046a4630)(frontends:[10.109.149.13]/ports=[]/selector=map[app:livestreamdb]),
  (k8s.ServiceID) streampai/minio: (*k8s.Service)(0xc001616bb0)(frontends:[10.98.222.33]/ports=[main console]/selector=map[app:minio]),
  (k8s.ServiceID) ambassador/agent-injector: (*k8s.Service)(0xc004851810)(frontends:[10.107.136.162]/ports=[https]/selector=map[app:traffic-manager telepresence:manager])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=19) {
  (k8s.ServiceID) streampai/minio: (*k8s.EndpointSlices)(0xc0005beb50)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=11) "minio-bhxq4": (*k8s.Endpoints)(0xc001aa0820)()
   }
  }),
  (k8s.ServiceID) kube-system/hubble-ui: (*k8s.EndpointSlices)(0xc000bce0e8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=15) "hubble-ui-7dh9n": (*k8s.Endpoints)(0xc0027489c0)(10.244.0.77:8081/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0xc000bce0f0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-qwxbl": (*k8s.Endpoints)(0xc000ae0a90)(10.244.0.207:53/TCP,10.244.0.207:53/UDP,10.244.0.207:9153/TCP)
   }
  }),
  (k8s.ServiceID) cert-manager/cert-manager: (*k8s.EndpointSlices)(0xc000bce100)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=18) "cert-manager-nxllt": (*k8s.Endpoints)(0xc0007ac680)(10.244.0.240:9402/TCP)
   }
  }),
  (k8s.ServiceID) streampai/backend: (*k8s.EndpointSlices)(0xc000b866d0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=13) "backend-2r7j9": (*k8s.Endpoints)(0xc005372340)(10.244.0.193:7000/TCP,10.244.0.28:7000/TCP)
   }
  }),
  (k8s.ServiceID) streampai/coqui: (*k8s.EndpointSlices)(0xc000a1f010)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=11) "coqui-g5hzt": (*k8s.Endpoints)(0xc001027c70)()
   }
  }),
  (k8s.ServiceID) streampai/kratos: (*k8s.EndpointSlices)(0xc000b866e0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=12) "kratos-mc9dl": (*k8s.Endpoints)(0xc004e9bd40)(10.244.0.192:4433/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/metrics-server: (*k8s.EndpointSlices)(0xc000bce0f8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "metrics-server-x6n9q": (*k8s.Endpoints)(0xc001f905b0)(10.244.0.212:10250/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0xc000bce118)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-872dn": (*k8s.Endpoints)(0xc0015cc680)(172.17.0.2:4244/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-relay: (*k8s.EndpointSlices)(0xc000bce120)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=18) "hubble-relay-cf7z9": (*k8s.Endpoints)(0xc0014fa5b0)(10.244.0.197:4245/TCP)
   }
  }),
  (k8s.ServiceID) streampai/cilium-gateway-sgtw: (*k8s.EndpointSlices)(0xc0005be4d0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=25) "cilium-gateway-sgtw-24625": (*k8s.Endpoints)(0xc002a69930)(192.192.192.192:9999/TCP)
   }
  }),
  (k8s.ServiceID) cert-manager/cert-manager-webhook: (*k8s.EndpointSlices)(0xc000bce108)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=26) "cert-manager-webhook-7xfrp": (*k8s.Endpoints)(0xc0008cc0d0)(10.244.0.219:10250/TCP)
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0xc000bce110)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0xc001e844e0)(172.17.0.2:6443/TCP)
   }
  }),
  (k8s.ServiceID) streampai/redis: (*k8s.EndpointSlices)(0xc0005beb58)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=11) "redis-lmggk": (*k8s.Endpoints)(0xc002571040)(10.244.0.105:6379/TCP)
   }
  }),
  (k8s.ServiceID) streampai/postgres: (*k8s.EndpointSlices)(0xc000b86708)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "postgres-4nrsw": (*k8s.Endpoints)(0xc0010adee0)()
   }
  }),
  (k8s.ServiceID) ambassador/agent-injector: (*k8s.EndpointSlices)(0xc000424748)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "agent-injector-swwx5": (*k8s.Endpoints)(0xc004e9a8f0)()
   }
  }),
  (k8s.ServiceID) streampai/frontend: (*k8s.EndpointSlices)(0xc0005beb40)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "frontend-7zvj2": (*k8s.Endpoints)(0xc002c704e0)(10.244.0.104:3000/TCP,10.244.0.119:3000/TCP,10.244.0.21:3000/TCP,10.244.0.50:3000/TCP)
   }
  }),
  (k8s.ServiceID) streampai/livestreamdb: (*k8s.EndpointSlices)(0xc000a1f020)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=18) "livestreamdb-qh4w4": (*k8s.Endpoints)(0xc001e4f040)()
   }
  }),
  (k8s.ServiceID) streampai/pgweb: (*k8s.EndpointSlices)(0xc000b86700)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=11) "pgweb-r974w": (*k8s.Endpoints)(0xc0010ad380)()
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 nodeAddressing: (*linux.linuxNodeAddressing)(0x5e20750)({
  ipv6: (linux.addressFamilyIPv6) {
  },
  ipv4: (linux.addressFamilyIPv4) {
  }
 }),
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>
})

```


#### Cilium version

```
1.14.1 c191ef6f 2023-08-10T18:54:57+02:00 go version go1.20.7 linux/amd64
```


#### Kernel version

```
6.5.0
```


#### Cilium environment keys

```
enable-bgp-control-plane:false
labels:
enable-sctp:false
cnp-node-status-gc-interval:0s
ipsec-key-rotation-duration:5m0s
k8s-service-cache-size:128
bpf-ct-timeout-regular-tcp-fin:10s
enable-identity-mark:true
enable-hubble:true
cluster-health-port:4240
fqdn-regex-compile-lru-size:1024
enable-srv6:false
enable-stale-cilium-endpoint-cleanup:true
bpf-lb-maglev-map-max:0
skip-cnp-status-startup-clean:false
ipam:kubernetes
enable-xdp-prefilter:false
ipv6-service-range:auto
label-prefix-file:
sidecar-istio-proxy-image:cilium/istio_proxy
identity-allocation-mode:crd
enable-ipv6-ndp:false
enable-ipv6:false
bpf-lb-rev-nat-map-max:0
mesh-auth-rotated-identities-queue-size:1024
ipam-multi-pool-pre-allocation:default=8
iptables-lock-timeout:5s
disable-envoy-version-check:false
bpf-lb-source-range-map-max:0
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
enable-well-known-identities:false
socket-path:/var/run/cilium/cilium.sock
monitor-aggregation:medium
bpf-lb-service-backend-map-max:0
ipam-cilium-node-update-rate:15s
devices:eth0
bpf-lb-affinity-map-max:0
keep-config:false
vtep-mask:
hubble-event-queue-size:0
kube-proxy-replacement:true
api-rate-limit:
bpf-sock-rev-map-max:262144
dns-max-ips-per-restored-rule:1000
local-max-addr-scope:252
bpf-neigh-global-max:524288
http-normalize-path:true
bpf-lb-dsr-l4-xlate:frontend
enable-vtep:false
tunnel-protocol:vxlan
allow-icmp-frag-needed:true
hubble-listen-address::4244
enable-remote-node-identity:true
monitor-aggregation-interval:5s
bpf-lb-sock-hostns-only:false
enable-bpf-masquerade:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
config:
agent-health-port:9879
bpf-lb-sock:false
dnsproxy-concurrency-processing-grace-period:0s
derive-masquerade-ip-addr-from-device:
proxy-max-connection-duration-seconds:0
policy-trigger-interval:1s
enable-external-ips:false
enable-endpoint-health-checking:true
enable-k8s:true
k8s-client-burst:10
prometheus-serve-addr::9962
gateway-api-secrets-namespace:cilium-secrets
bpf-auth-map-max:524288
mtu:0
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
l2-pod-announcements-interface:
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
hubble-metrics:
local-router-ipv4:
debug-verbose:envoy
bpf-lb-service-map-max:0
enable-envoy-config:true
preallocate-bpf-maps:false
agent-labels:
enable-nat46x64-gateway:false
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
bpf-lb-maglev-table-size:16381
k8s-require-ipv6-pod-cidr:false
tofqdns-endpoint-max-ip-per-hostname:50
enable-node-port:false
enable-ipsec-key-watcher:true
set-cilium-node-taints:true
enable-ipv6-masquerade:true
endpoint-status:
http-max-grpc-timeout:0
ipv6-mcast-device:
kvstore-lease-ttl:15m0s
http-idle-timeout:0
enable-auto-protect-node-port-range:true
ipv6-pod-subnets:
enable-host-firewall:false
enable-icmp-rules:true
envoy-config-timeout:2m0s
identity-gc-interval:15m0s
install-egress-gateway-routes:false
enable-ip-masq-agent:false
bgp-announce-lb-ip:false
tofqdns-max-deferred-connection-deletes:10000
egress-masquerade-interfaces:
proxy-gid:1337
ipv6-node:auto
bpf-ct-timeout-service-tcp-grace:1m0s
disable-iptables-feeder-rules:
bpf-root:/sys/fs/bpf
tofqdns-proxy-response-max-delay:100ms
ipv4-native-routing-cidr:
enable-service-topology:false
metrics:
bpf-fragments-map-max:8192
tofqdns-pre-cache:
enable-bpf-clock-probe:false
kube-proxy-replacement-healthz-bind-address:
bpf-lb-acceleration:disabled
tofqdns-min-ttl:0
ipv6-native-routing-cidr:
log-driver:
hubble-recorder-sink-queue-size:1024
external-envoy-proxy:true
enable-ipv4-big-tcp:false
synchronize-k8s-nodes:true
enable-ipv4-masquerade:true
k8s-client-qps:5
enable-session-affinity:false
config-dir:/tmp/cilium/config-map
bgp-config-path:/var/lib/cilium/bgp/config.yaml
bypass-ip-availability-upon-restore:false
ipv6-range:auto
crd-wait-timeout:5m0s
gops-port:9890
enable-monitor:true
pprof:false
bpf-nat-global-max:524288
cni-exclusive:true
http-403-msg:
unmanaged-pod-watcher-interval:15
proxy-connect-timeout:2
enable-unreachable-routes:false
config-sources:config-map:kube-system/cilium-config
debug:false
bpf-map-event-buffers:
l2-announcements-renew-deadline:5s
ipv4-service-range:auto
ip-allocation-timeout:2m0s
state-dir:/var/run/cilium
proxy-max-requests-per-connection:0
l2-announcements-retry-period:2s
enable-local-redirect-policy:false
hubble-prefer-ipv6:false
enable-xt-socket-fallback:true
enable-host-legacy-routing:false
disable-endpoint-crd:false
enable-cilium-api-server-access:
k8s-service-proxy-name:
k8s-sync-timeout:3m0s
bpf-ct-global-tcp-max:524288
k8s-namespace:kube-system
mesh-auth-gc-interval:5m0s
hubble-monitor-events:
node-port-acceleration:disabled
cni-chaining-target:
encrypt-node:false
allow-localhost:auto
auto-direct-node-routes:false
hubble-export-file-path:
nodes-gc-interval:5m0s
pprof-address:localhost
log-opt:
hubble-export-file-max-size-mb:10
cilium-endpoint-gc-interval:5m0s
hubble-disable-tls:false
enable-l2-announcements:true
allocator-list-timeout:3m0s
hubble-skip-unknown-cgroup-ids:true
cni-log-file:/var/run/cilium/cilium-cni.log
kvstore-max-consecutive-quorum-errors:2
route-metric:0
iptables-random-fully:false
exclude-local-address:
enable-k8s-api-discovery:false
enable-bbr:false
enable-k8s-event-handover:false
prepend-iptables-chains:true
http-retry-count:3
enable-gateway-api-secrets-sync:true
node-port-algorithm:random
egress-gateway-reconciliation-trigger-interval:1s
vtep-cidr:
identity-restore-grace-period:10m0s
ipv4-node:auto
enable-hubble-recorder-api:true
enable-local-node-route:true
enable-runtime-device-detection:false
routing-mode:tunnel
kvstore:
tunnel-port:0
endpoint-gc-interval:5m0s
bpf-lb-external-clusterip:false
mesh-auth-enabled:true
enable-custom-calls:false
hubble-export-file-max-backups:5
enable-wireguard:false
egress-multi-home-ip-rule-compat:false
enable-bandwidth-manager:false
tofqdns-enable-dns-compression:true
ipv6-cluster-alloc-cidr:f00d::/64
srv6-encap-mode:reduced
ip-masq-agent-config-path:/etc/config/ip-masq-agent
datapath-mode:veth
bpf-ct-timeout-regular-any:1m0s
bpf-lb-rss-ipv4-src-cidr:
enable-cilium-endpoint-slice:false
ipv4-range:auto
bpf-lb-map-max:65536
arping-refresh-period:30s
k8s-require-ipv4-pod-cidr:false
encrypt-interface:
enable-svc-source-range-check:true
bpf-ct-timeout-regular-tcp:6h0m0s
kvstore-periodic-sync:5m0s
bpf-ct-timeout-regular-tcp-syn:1m0s
disable-cnp-status-updates:true
node-port-bind-protection:true
clustermesh-config:/var/lib/cilium/clustermesh/
mesh-auth-spire-admin-socket:
enable-health-checking:true
enable-wireguard-userspace-fallback:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
use-cilium-internal-ip-for-ipsec:false
operator-api-serve-addr:127.0.0.1:9234
http-request-timeout:3600
install-no-conntrack-iptables-rules:false
kvstore-opt:
custom-cni-conf:false
identity-change-grace-period:5s
l2-announcements-lease-duration:15s
enable-ipv6-big-tcp:false
enable-high-scale-ipcache:false
monitor-aggregation-flags:all
node-port-mode:snat
tunnel:
enable-recorder:false
mesh-auth-mutual-listener-port:0
trace-payloadlen:128
bpf-ct-timeout-service-any:1m0s
cflags:
procfs:/host/proc
log-system-load:false
node-port-range:
restore:true
enable-bpf-tproxy:false
enable-health-check-nodeport:true
enable-ipv4-fragment-tracking:true
bpf-map-dynamic-size-ratio:0.0025
hubble-export-file-compress:false
ipv4-service-loopback-address:169.254.42.1
hubble-metrics-server:
version:false
cgroup-root:/run/cilium/cgroupv2
enable-ipv4:true
ipv4-pod-subnets:
set-cilium-is-up-condition:true
bpf-policy-map-max:16384
enable-endpoint-routes:false
bpf-lb-rss-ipv6-src-cidr:
enable-mke:false
hubble-recorder-storage-path:/var/run/cilium/pcaps
bpf-filter-priority:1
dns-policy-unload-on-shutdown:false
enable-host-port:false
monitor-queue-size:0
policy-audit-mode:false
enable-k8s-networkpolicy:true
single-cluster-route:false
k8s-kubeconfig-path:
bpf-lb-dev-ip-addr-inherit:
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
dnsproxy-lock-timeout:500ms
certificates-directory:/var/run/cilium/certs
vlan-bpf-bypass:
tofqdns-proxy-port:0
bpf-lb-dsr-dispatch:opt
cluster-name:default
conntrack-gc-interval:0s
enable-ipsec:false
fixed-identity-mapping:
agent-liveness-update-interval:1s
kvstore-connectivity-timeout:2m0s
proxy-idle-timeout-seconds:60
lib-dir:/var/lib/cilium
proxy-prometheus-port:0
dnsproxy-concurrency-limit:0
bpf-lb-algorithm:random
enable-cilium-health-api-server-access:
dnsproxy-lock-count:128
join-cluster:false
policy-queue-size:100
bpf-ct-timeout-service-tcp:6h0m0s
mke-cgroup-mount:
enable-l7-proxy:true
cni-chaining-mode:none
enable-l2-pod-announcements:false
read-cni-conf:
bgp-announce-pod-cidr:false
bpf-ct-global-any-max:262144
install-iptables-rules:true
cluster-id:0
enable-k8s-endpoint-slice:true
pprof-port:6060
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
enable-gateway-api:true
enable-pmtu-discovery:false
max-controller-interval:0
cmdref:
enable-ipv4-egress-gateway:false
tofqdns-dns-reject-response-code:refused
enable-k8s-terminating-endpoint:true
vtep-endpoint:
direct-routing-device:
envoy-log:
egress-gateway-policy-map-max:16384
remove-cilium-node-taints:true
local-router-ipv6:
http-retry-timeout:0
k8s-heartbeat-timeout:30s
identity-heartbeat-timeout:30m0s
vtep-mac:
mesh-auth-queue-size:1024
hubble-socket-path:/var/run/cilium/hubble.sock
ipsec-key-file:
auto-create-cilium-node-resource:true
k8s-api-server:
bpf-lb-mode:snat
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
enable-tracing:false
hubble-event-buffer-capacity:4095
enable-policy:default
annotate-k8s-node:false
enable-l2-neigh-discovery:true
endpoint-queue-size:25
trace-sock:true
tofqdns-idle-connection-grace-period:0s
```


#### Cilium encryption


