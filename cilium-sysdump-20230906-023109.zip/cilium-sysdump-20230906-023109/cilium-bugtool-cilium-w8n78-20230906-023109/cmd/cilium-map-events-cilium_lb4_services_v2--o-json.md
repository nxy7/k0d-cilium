{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.1:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:49.905Z",
  "value": "1 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.1:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:49.905Z",
  "value": "0 1 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.115.136:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:49.905Z",
  "value": "0 0 (120) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.172.173:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:49.905Z",
  "value": "0 0 (121) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.109.205.214:5432",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.797Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.109.205.214:5432",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.797Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.106.177.129:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.797Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.97.199.60:9402",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.797Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.97.199.60:9402",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.797Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.99.31.174:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.797Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.99.31.174:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.797Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.104.95.166:9000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.797Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.104.95.166:9000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.797Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.104.95.166:9001",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.797Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.104.95.166:9001",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.797Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.102.61.253:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.797Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.102.61.253:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.797Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.99.97.244:8081",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.797Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.99.97.244:8081",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.99.92.221:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.99.92.221:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.99.92.221:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.105.100.84:4433",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.105.100.84:4433",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.105.44.85:5432",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.105.44.85:5432",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.108.234.242:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.108.234.242:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.108.234.242:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.108.234.242:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.108.234.242:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.107.193.90:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.107.193.90:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.103.234.152:6379",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.103.234.152:6379",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.107.207.153:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.107.207.153:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.106.136.193:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.106.136.193:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.99.225.125:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.99.225.125:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:53",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "0 0 (8) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.96.0.10:53",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:9153",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "0 0 (9) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.96.0.10:9153",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:51.798Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.115.136:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:52.045Z",
  "value": "114 0 (120) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.115.136:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:29:52.045Z",
  "value": "0 1 (120) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.172.173:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:05.137Z",
  "value": "0 0 (121) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.172.173:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:05.140Z",
  "value": "115 0 (121) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.104.172.173:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:05.140Z",
  "value": "0 1 (121) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.180.26:9402",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:10.166Z",
  "value": "116 0 (118) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.180.26:9402",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:10.166Z",
  "value": "0 1 (118) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.137.97:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:15.153Z",
  "value": "0 0 (119) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:53",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:20.161Z",
  "value": "0 0 (8) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:9153",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:20.161Z",
  "value": "0 0 (9) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:53",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:20.165Z",
  "value": "117 0 (8) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:53",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:20.165Z",
  "value": "0 1 (8) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:9153",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:20.165Z",
  "value": "118 0 (9) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.96.0.10:9153",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:20.165Z",
  "value": "0 1 (9) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.137.97:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:22.368Z",
  "value": "119 0 (119) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.137.97:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:22.368Z",
  "value": "0 1 (119) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.147.188:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:27.169Z",
  "value": "0 0 (117) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.228.233:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:35.185Z",
  "value": "120 0 (116) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.228.233:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:35.185Z",
  "value": "0 1 (116) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.77.184:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:51.545Z",
  "value": "0 0 (122) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.72.35:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:51.555Z",
  "value": "0 0 (123) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.123.5:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:51.568Z",
  "value": "0 0 (124) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.120.45:4433",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:51.577Z",
  "value": "0 0 (125) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.149.13:5432",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:51.589Z",
  "value": "0 0 (126) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.222.33:9001",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:51.636Z",
  "value": "0 0 (127) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.222.33:9000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:51.636Z",
  "value": "0 0 (128) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.143.77:8081",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:51.646Z",
  "value": "0 0 (129) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.106.247.125:5432",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:51.661Z",
  "value": "0 0 (130) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.225.9:6379",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:51.675Z",
  "value": "0 0 (131) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.89.133:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.397Z",
  "value": "0 0 (132) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.223.107:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.397Z",
  "value": "0 0 (133) [0x60 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:30867",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.397Z",
  "value": "0 0 (134) [0x2 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.0.2:30867",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.397Z",
  "value": "0 0 (135) [0x42 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.147.188:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.401Z",
  "value": "121 0 (117) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.147.188:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.401Z",
  "value": "0 1 (117) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.223.107:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.507Z",
  "value": "25921 0 (133) [0x60 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.89.133:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.508Z",
  "value": "25921 0 (132) [0x0 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.0.2:30867",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.508Z",
  "value": "25921 0 (135) [0x42 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:30867",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.508Z",
  "value": "25921 0 (134) [0x2 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.223.107:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.516Z",
  "value": "25921 0 (133) [0x60 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.89.133:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.516Z",
  "value": "25921 0 (132) [0x0 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.0.2:30867",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.516Z",
  "value": "25921 0 (135) [0x42 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:30867",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.516Z",
  "value": "25921 0 (134) [0x2 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.77.184:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.516Z",
  "value": "0 0 (122) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.123.5:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.516Z",
  "value": "0 0 (124) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.120.45:4433",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.516Z",
  "value": "0 0 (125) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.222.33:9000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.516Z",
  "value": "0 0 (128) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.222.33:9001",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.516Z",
  "value": "0 0 (127) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.143.77:8081",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.516Z",
  "value": "0 0 (129) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.89.133:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.517Z",
  "value": "25921 0 (132) [0x0 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.0.2:30867",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.517Z",
  "value": "25921 0 (135) [0x42 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "0.0.0.0:30867",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.517Z",
  "value": "25921 0 (134) [0x2 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.17.223.107:80",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.517Z",
  "value": "25921 0 (133) [0x60 0x4]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.77.184:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.517Z",
  "value": "0 0 (122) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.123.5:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.517Z",
  "value": "0 0 (124) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.120.45:4433",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.517Z",
  "value": "0 0 (125) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.222.33:9001",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.517Z",
  "value": "0 0 (127) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.222.33:9000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.517Z",
  "value": "0 0 (128) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.143.77:8081",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:53.517Z",
  "value": "0 0 (129) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.107.136.162:443",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:54.784Z",
  "value": "0 0 (136) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.77.184:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:55.212Z",
  "value": "122 0 (122) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.77.184:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:55.213Z",
  "value": "0 1 (122) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.77.184:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:55.218Z",
  "value": "122 0 (122) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.77.184:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:55.218Z",
  "value": "123 0 (122) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.108.77.184:7000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:55.218Z",
  "value": "0 2 (122) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.123.5:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:56.215Z",
  "value": "124 0 (124) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.123.5:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:56.215Z",
  "value": "0 1 (124) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.123.5:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:56.220Z",
  "value": "124 0 (124) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.123.5:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:56.220Z",
  "value": "125 0 (124) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.123.5:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:56.220Z",
  "value": "0 2 (124) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.123.5:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:56.224Z",
  "value": "124 0 (124) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.123.5:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:56.224Z",
  "value": "125 0 (124) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.123.5:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:56.224Z",
  "value": "126 0 (124) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.123.5:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:56.224Z",
  "value": "0 3 (124) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.123.5:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:56.230Z",
  "value": "124 0 (124) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.123.5:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:56.230Z",
  "value": "125 0 (124) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.123.5:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:56.230Z",
  "value": "126 0 (124) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.123.5:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:56.230Z",
  "value": "127 0 (124) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.123.5:3000",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:30:56.230Z",
  "value": "0 4 (124) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.120.45:4433",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:31:00.228Z",
  "value": "128 0 (125) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.110.120.45:4433",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:31:00.228Z",
  "value": "0 1 (125) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.225.9:6379",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:31:05.236Z",
  "value": "129 0 (131) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.225.9:6379",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2023-09-06T00:31:05.236Z",
  "value": "0 1 (131) [0x0 0x0]"
}

