CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2
63       cgroup_inet_ingress multi           sd_fw_ingress  
62       cgroup_inet_egress multi           sd_fw_egress   
7176     cgroup_inet4_connect multi           cil_sock4_connect
7177     cgroup_inet6_connect multi           cil_sock6_connect
7179     cgroup_inet4_post_bind multi           cil_sock4_post_bind
7174     cgroup_inet6_post_bind multi           cil_sock6_post_bind
7173     cgroup_udp4_sendmsg multi           cil_sock4_sendmsg
7172     cgroup_udp6_sendmsg multi           cil_sock6_sendmsg
7175     cgroup_udp4_recvmsg multi           cil_sock4_recvmsg
7178     cgroup_udp6_recvmsg multi           cil_sock6_recvmsg
7171     cgroup_inet4_getpeername multi           cil_sock4_getpeername
7180     cgroup_inet6_getpeername multi           cil_sock6_getpeername
/run/cilium/cgroupv2/sys-fs-fuse-connections.mount
    65       cgroup_inet_ingress multi           sd_fw_ingress  
    64       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/sys-kernel-config.mount
    67       cgroup_inet_ingress multi           sd_fw_ingress  
    66       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/sys-kernel-debug.mount
    38       cgroup_inet_ingress multi           sd_fw_ingress  
    37       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/kubepods/burstable/podbb1b5999-8373-4289-a662-2086e2be11e2/4312e0184c30ab22dd100d8d02846bf17a1b6a3bd997368a66db25befe93f0cc
    7533     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/burstable/podbb1b5999-8373-4289-a662-2086e2be11e2/71bf6a940935ed372c3978e84a5afcc111925fcafe85ba91a8a7039f52e2f1d1
    7387     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/burstable/pod4e17e3f2-6ad3-4991-9b19-2f578b1d614b/e985250bd5b6671f7a97690eef341523d12737355868efc97fdbbac5d1a5edf2
    7539     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/burstable/pod4e17e3f2-6ad3-4991-9b19-2f578b1d614b/bb9269e9460449db27b60c142005050dd8e5336dd2adf44238e6e30b018dabaf
    7419     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/burstable/pod22427fab-9a39-4cc2-a426-74ae96f5c12c/e8783aa16829c6b762ccbd7d584a845355c08a3ea05b38a72c611a8453e0e63f
    6825     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/burstable/pod22427fab-9a39-4cc2-a426-74ae96f5c12c/ebfa399b6b02e802a4544d7a53cf917c07cb088b16670b354b648be7c6d78fa6
    6855     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podbd3ce3ac-da37-4a29-8a72-4e5facf4f533/c026a83c52408fd3346050e2ff835b5940598c69b468b976ff8dcb9fda3afd0d
    7723     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podbd3ce3ac-da37-4a29-8a72-4e5facf4f533/2d4b4b61014c06877ce8ffbb7ee7da5d620d12bed28306f6de8207f43c4290d9
    7866     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod44597ca4-d5fc-4e10-bffa-eb3d057f0c21/9fa70144308c785c329e9e1e540372ce2219a24aa328ed2a0c9a9d83bd3a002b
    7648     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod44597ca4-d5fc-4e10-bffa-eb3d057f0c21/0f8b8e9272d4911f754b62a2ceba4bdc4ad2ce5757377e3775acc4eff9e544a4
    7682     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod1f988a8c-170f-43e1-af48-e87b9415e57c/497590f0e9d4a25c785a3db55e8df58883c4635e00f3dff5eb160175d0f80221
    7381     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod1f988a8c-170f-43e1-af48-e87b9415e57c/818ed5d107366c8e1ea3c665039d9f227a04f6d207088caf1d6d2c44ecd73bc9
    7527     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod8a43b218-113e-4fbe-945c-e6334796d72a/7bdd2f09da2a2db18752b701b4b102e33364d7c708a55301c07e9e54d3a0584f
    7771     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podcef60463-86d5-4447-ae90-55ff54bb1682/a5cf477eaac0cf0d27fa5ebd98da8f46edb10a44a815a41cbaae1d82c63ff82e
    7720     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podcef60463-86d5-4447-ae90-55ff54bb1682/2ba8ead082bc96f2cfad981d82367b351c5af55f02dfc82211444e0104478816
    7656     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod0acdbf1a-ca72-4890-8059-f8dda60eacaf/8d35234b0d8474b19d1f99c72af883f14152e697b6de361b65ef84c550c72b64
    7742     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod85a6f996-75d0-4a22-b357-f3c7e0194886/7105d73fb6e3dc86e9af5689689dc7cea32c3f18162f1674d59a321a7ce26b8f
    7698     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod6f440805-7855-4763-9299-e2ffdc66f2a0/18e08e2c4be6e09d3c3789412f7a310c8d303bb7dd92b730f1e40242d78bd4c5
    7857     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pode84e0674-5c1f-4ec3-8f3c-54da3c1784b9/75114dec769e79395df796a324643d5f68136603149792cdf57b4aa9781b2898
    7644     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pode84e0674-5c1f-4ec3-8f3c-54da3c1784b9/e7499fe83363d30fc5287b5c98449a92472c91488e9a77e9e02426c7fdbf83af
    7704     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod393b75cc-6f60-444f-bd9a-be1a2da57465/b3ffcc5fa56bac9d04fbe67ba3b02ff3df0830d559e146eaae8e8af8cf12c802
    7548     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod393b75cc-6f60-444f-bd9a-be1a2da57465/a3cd6405d7ca7abbc3fad2860d4114b92867aeed5d1bf95912dff89d1ebbf2ee
    7530     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod393b75cc-6f60-444f-bd9a-be1a2da57465/d88262b0ed9dc4e168da7438e638a36fb171af7106ca6a08520e58aa219eb8ee
    7384     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod2002cc00-09af-4175-be45-ece3965028fc/0e74ceef7111173e21530d74bc5d0979ed01215a7107ce666a6edc9dcaef4b02
    7657     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod2002cc00-09af-4175-be45-ece3965028fc/41754c1e47648127e5257f7e50a28338bb667b419a8d2263d40facb3e651de3e
    7701     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podc6fc33e9-2501-4335-a7ed-cd5e3e8ea943/9de02d09272542c01eb1022d5d2feb8af4978a19e8eae4ab6cbccbe51176fbf7
    7806     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod5847827a-05a6-49d9-90a8-d367663b5a93/3c8c395ae380bea7e49818c852d4ccfef8a97c1636f6ca85914371e15e5e70f0
    7860     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod5847827a-05a6-49d9-90a8-d367663b5a93/fdea3861f805101a5622efc1528eeebc2936e3cf0d749f3141eac4142fb40d9b
    7679     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod11561df7-bcc5-4fe3-b479-6c1b472b150b/ef3251296a8043ed80107fe67cd08766421abaeec65b3a1a1fa4c2ca8c50056c
    7726     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod11561df7-bcc5-4fe3-b479-6c1b472b150b/ccd53c451690ad454ea9efb166d43a1da356c84ea701e458753b8a1e0201053b
    7660     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podb9382c97-d2bd-489e-a8cc-2b1e28d83147/b3cf16f326be04d55610e93cf3edf6651643877cd2f12ce26c8c9fca16a405a6
    7645     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podb9382c97-d2bd-489e-a8cc-2b1e28d83147/97801f2dceed95074e9cb6ad1349547fc4cf3c1c0bd9abeef54904107c069ecf
    7664     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod9d49a98f-0374-4080-8883-0a8f172373f0/e781421cff8ab52b1f46cd394042165b41fe1b85d1081471b0645846e556eb8e
    7369     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod9d49a98f-0374-4080-8883-0a8f172373f0/ac233f55b65f4dbcdc6346255e42eb5ce67d325f8895542b37858ed753b0af93
    7460     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod7fa8a095-e02b-4106-8f29-6f045bb564b2/d4bd4f9f8ea7ee195fabc8036dad2fca23563e0595d4677417c45a90a245f577
    7403     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod7fa8a095-e02b-4106-8f29-6f045bb564b2/941cfaa7dc5ea7e82294255275eec64909df44edfabb1a5a483e37ab6737ce60
    7536     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podc79c68a3-a6fe-436a-8bfc-3345bdb10cf9/ea59852f98278992dfae29aa3608632c75800db531483515313dbc5a8e945940
    6843     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podc79c68a3-a6fe-436a-8bfc-3345bdb10cf9/e7404a8b9b80f843a538c6c9917f83ba261038e7baca61b75e77c1fb91ffd91f
    6828     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod82edf746-0093-4a1f-9730-ef7cb47ecc9f/ca0f77d88e6aaf1334a48651a8a76e3bbe272b9d20698a863313d2ddba6aacb3
    7774     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poda0fceb39-dff5-41d4-a849-f39887bd4f91/a451c9b5da2e2ef2ba7cbb83689fd20870e7815a66f10eb9a13fbfb2a7a9c11f
    7822     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod9b6e2c75-2acc-4649-a728-ded630529fa4/6ae97fc3a57b7af375a8dea72b2b286dc127fad2061a36d004df67a51d8e6f3f
    7457     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod9b6e2c75-2acc-4649-a728-ded630529fa4/20dae7dd2af61bd6bb9e05aa20630125feafbbbcec7687d410b5f760fe58ee73
    7366     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podf605b138-0374-4f21-a0d1-0cc7c730412e/1d0114b03d3369e04a9b708d173edb3c3969ee0d16a3335a48ee68c8c6cf0992
    7651     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podf605b138-0374-4f21-a0d1-0cc7c730412e/51a7c56673e2630b4a1267c788fd06a744218b81f685139e06e62abe8acd517d
    7825     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poda26db218-f175-4bfd-9e4a-be3bcbe19ded/f370533491f5fe30412cad575ace2cd04b9bdc51a6daf7ae1bfd2fba353237d5
    7372     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/poda26db218-f175-4bfd-9e4a-be3bcbe19ded/6801d91bb624528c51377184cbc1394344927c03377eef9e58911faf047aeed9
    7518     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod51c7469c-e983-4232-8927-4b0f42058274/99713cfc40a39a8f32c6e4d2cc8b5a2c2bb77eefb4553337f52cfaa3a4a979fe
    7790     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod30b355fb-ed2e-4a97-af27-c5bf015652e0/835e1d56d93b8f2f19c75b1d41a3c9e9b1118b9aba1398cdc26b6269203e2dec
    7435     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod30b355fb-ed2e-4a97-af27-c5bf015652e0/1c45619b207e9b8c1c4844994d09bc150bf8753ed129a093406b5f3013641662
    7542     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podd1e6a52c-f4f0-4e2e-b1f4-e3976160f692/3e6935f3a8c5f833d6c5bea83930b0ea99d95bca22f26d827777e8d1b4b6da45
    7375     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podd1e6a52c-f4f0-4e2e-b1f4-e3976160f692/498bd48e6f1b7993ef1376032680c1af5b40e818b0ae71cd3c3c7e8531f31cda
    7521     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod309940c1-7558-4706-8b87-1123dd0f4110/83d93cc6809de780df5ef30147d897614e961e106823f7e3eda46d215c6b4870
    7438     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod309940c1-7558-4706-8b87-1123dd0f4110/92b5cd9bdb6e965f91e40e84f84bde14ca4a3dbad18ace9e888d4e5b2a484590
    7191     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podd3e76d6d-442a-471e-a978-a566a4a37d9a/d5116bdbbafb36c079ab78f84f76663024a0c823bc82768964d62524d148f65a
    7545     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podd3e76d6d-442a-471e-a978-a566a4a37d9a/9a4df28f3d833e8023d609b5725f1aef9a38e837d6bf5c00b1b3f0198b236907
    7454     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod3e7348b5-8a5f-43db-b50b-332820895ced/59bda1930f3842e068f94b0afa431764d0a0cdcba64b930391e29a9953903988
    6831     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/pod3e7348b5-8a5f-43db-b50b-332820895ced/c8444d6331d5dbf6a66d0943e428d4efaba771db74278faceea4f91d97c84a20
    6822     cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods/besteffort/podb1477bd2-35ce-4744-aef9-bbdf7f1e639a/6c7960827616185cd3bd0e5358616c82b446fab20f189d28742866f2f1abfb24
    7841     cgroup_device   multi                          
/run/cilium/cgroupv2/dev-mqueue.mount
    36       cgroup_inet_ingress multi           sd_fw_ingress  
    35       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/user.slice
    161      cgroup_inet_ingress multi           sd_fw_ingress  
    160      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/user.slice/user-1000.slice
    163      cgroup_inet_ingress multi           sd_fw_ingress  
    162      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/user.slice/user-1000.slice/user@1000.service
    167      cgroup_inet_ingress multi           sd_fw_ingress  
    166      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/user.slice/user-1000.slice/session-1.scope
    169      cgroup_inet_ingress multi           sd_fw_ingress  
    168      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/init.scope
    24       cgroup_inet_ingress multi           sd_fw_ingress  
    23       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice
    61       cgroup_inet_ingress multi           sd_fw_ingress  
    60       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/system-systemd\x2dfsck.slice
    30       cgroup_inet_ingress multi           sd_fw_ingress  
    29       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    75       cgroup_inet_ingress multi           sd_fw_ingress  
    74       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/docker.service
    184      cgroup_inet_ingress multi           sd_fw_ingress  
    183      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/polkit.service
    142      cgroup_inet_ingress multi           sd_fw_ingress  
    141      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/rtkit-daemon.service
    175      cgroup_inet_ingress multi           sd_fw_ingress  
    174      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/bluetooth.service
    117      cgroup_inet_ingress multi           sd_fw_ingress  
    116      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/accounts-daemon.service
    130      cgroup_inet_ingress multi           sd_fw_ingress  
    129      cgroup_inet_egress multi           sd_fw_egress   
    128      cgroup_device   multi           sd_devices     
/run/cilium/cgroupv2/system.slice/docker-51ed2ab5fad6f6bf02ad986c04e1172dbe7ee749b8e762e2675b0c98e6621441.scope
    6816     cgroup_inet_ingress multi           sd_fw_ingress  
    6815     cgroup_inet_egress multi           sd_fw_egress   
    6819     cgroup_device   multi                          
/run/cilium/cgroupv2/system.slice/cups.socket
    103      cgroup_inet_ingress multi           sd_fw_ingress  
    102      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/wpa_supplicant.service
    188      cgroup_inet_ingress multi           sd_fw_ingress  
    187      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/system-modprobe.slice
    28       cgroup_inet_ingress multi           sd_fw_ingress  
    27       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/ModemManager.service
    190      cgroup_inet_ingress multi           sd_fw_ingress  
    189      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    53       cgroup_inet_ingress multi           sd_fw_ingress  
    52       cgroup_inet_egress multi           sd_fw_egress   
    51       cgroup_device   multi           sd_devices     
/run/cilium/cgroupv2/system.slice/syncthing.service
    155      cgroup_inet_ingress multi           sd_fw_ingress  
    154      cgroup_inet_egress multi           sd_fw_egress   
    153      cgroup_device   multi           sd_devices     
/run/cilium/cgroupv2/system.slice/power-profiles-daemon.service
    173      cgroup_inet_ingress multi           sd_fw_ingress  
    172      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/display-manager.service
    159      cgroup_inet_ingress multi           sd_fw_ingress  
    158      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/colord.service
    179      cgroup_inet_ingress multi           sd_fw_ingress  
    178      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/NetworkManager.service
    144      cgroup_inet_ingress multi           sd_fw_ingress  
    143      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/boot-efi.mount
    79       cgroup_inet_ingress multi           sd_fw_ingress  
    78       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/nscd.service
    192      cgroup_inet_ingress multi           sd_fw_ingress  
    191      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/cups-browsed.service
    137      cgroup_inet_ingress multi           sd_fw_ingress  
    136      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/docker.socket
    105      cgroup_inet_ingress multi           sd_fw_ingress  
    104      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/cups.service
    152      cgroup_inet_ingress multi           sd_fw_ingress  
    151      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/upower.service
    171      cgroup_inet_ingress multi           sd_fw_ingress  
    170      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/systemd-oomd.service
    92       cgroup_inet_ingress multi           sd_fw_ingress  
    91       cgroup_inet_egress multi           sd_fw_egress   
    90       cgroup_device   multi           sd_devices     
/run/cilium/cgroupv2/system.slice/udisks2.service
    177      cgroup_inet_ingress multi           sd_fw_ingress  
    176      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/acpid.service
    109      cgroup_inet_ingress multi           sd_fw_ingress  
    108      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/dbus.service
    119      cgroup_inet_ingress multi           sd_fw_ingress  
    118      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/systemd-timesyncd.service
    95       cgroup_inet_ingress multi           sd_fw_ingress  
    94       cgroup_inet_egress multi           sd_fw_egress   
    93       cgroup_device   multi           sd_devices     
/run/cilium/cgroupv2/system.slice/avahi-daemon.service
    115      cgroup_inet_ingress multi           sd_fw_ingress  
    114      cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    133      cgroup_inet_ingress multi           sd_fw_ingress  
    132      cgroup_inet_egress multi           sd_fw_egress   
    131      cgroup_device   multi           sd_devices     
/run/cilium/cgroupv2/proc-sys-fs-binfmt_misc.mount
    87       cgroup_inet_ingress multi           sd_fw_ingress  
    86       cgroup_inet_egress multi           sd_fw_egress   
/run/cilium/cgroupv2/dev-hugepages.mount
    34       cgroup_inet_ingress multi           sd_fw_ingress  
    33       cgroup_inet_egress multi           sd_fw_egress   
