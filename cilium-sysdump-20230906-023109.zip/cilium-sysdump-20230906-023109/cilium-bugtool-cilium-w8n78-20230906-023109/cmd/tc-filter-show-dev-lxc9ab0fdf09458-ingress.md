filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc9ab0fdf09458 direct-action not_in_hw id 7573 tag d3f278a88757dae2 jited 
