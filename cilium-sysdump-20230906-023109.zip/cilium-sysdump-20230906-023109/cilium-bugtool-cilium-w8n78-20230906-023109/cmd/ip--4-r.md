default via 172.17.0.1 dev eth0 
10.244.0.0/24 via 10.244.0.176 dev cilium_host proto kernel src 10.244.0.176 
10.244.0.176 dev cilium_host proto kernel scope link 
172.17.0.0/16 dev eth0 proto kernel scope link src 172.17.0.2 
