top - 00:31:12 up  2:32,  0 users,  load average: 1.03, 0.62, 0.56
Tasks:  17 total,   5 running,  12 sleeping,   0 stopped,   0 zombie
%Cpu(s): 33.7 us, 48.9 sy,  0.0 ni, 15.7 id,  1.7 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :  15915.0 total,    198.6 free,   6009.5 used,   9706.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   9402.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    544 root      20   0    2928   1408   1408 R  66.7   0.0   0:00.10 cat
    549 root      20   0    3916   2176   1920 D  33.3   0.0   0:00.05 cp
    550 root      20   0  786680  59008  39808 S  26.7   0.4   0:00.04 cilium
    391 root      20   0  725920  16000   9600 S  20.0   0.1   0:00.04 cilium-+
    593 root      20   0  785848  55168  38400 R  20.0   0.3   0:00.03 cilium
      1 root      20   0  880452 152876  68992 S  13.3   0.9   0:04.72 cilium-+
    551 root      20   0  785848  57472  39680 S  13.3   0.4   0:00.02 cilium
    606 root      20   0  784824  30080  23680 S   6.7   0.2   0:00.01 cilium
    198 root      20   0  714436   4608   3712 S   0.0   0.0   0:00.00 cilium-+
    373 root      20   0  713560   4096   3456 S   0.0   0.0   0:00.00 gops
    434 root      20   0    7180   3072   2816 R   0.0   0.0   0:00.00 top
    452 root      20   0  713560   4224   3584 S   0.0   0.0   0:00.00 gops
    454 root      20   0  713560   3968   3328 S   0.0   0.0   0:00.00 gops
    456 root      20   0  713304   3968   3328 S   0.0   0.0   0:00.00 gops
    613 root      20   0  783736   8704   7936 S   0.0   0.1   0:00.00 cilium
    614 root      20   0  783480   7680   7296 R   0.0   0.0   0:00.00 cilium
    616 root      20   0  783480   8576   7936 R   0.0   0.1   0:00.00 cilium
