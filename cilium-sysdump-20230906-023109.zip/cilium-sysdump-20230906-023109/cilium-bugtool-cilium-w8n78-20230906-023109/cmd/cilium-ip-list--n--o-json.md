[
  {
    "cidr": "0.0.0.0/0",
    "identity": 2
  },
  {
    "cidr": "10.244.0.18/32",
    "hostIP": "172.17.0.2",
    "identity": 1847,
    "metadata": {
      "name": "init-pvc-4f2ec5d9-e41b-425e-bdb7-332c06f7825a",
      "namespace": "openebs",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.21/32",
    "hostIP": "172.17.0.2",
    "identity": 40807,
    "metadata": {
      "name": "frontend-58b6bf847f-cv4lc",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.28/32",
    "hostIP": "172.17.0.2",
    "identity": 9256,
    "metadata": {
      "name": "backend-855f6c7b4-8bqth",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.34/32",
    "hostIP": "172.17.0.2",
    "identity": 44793,
    "metadata": {
      "name": "openebs-ndm-operator-7c667b76f8-xbj7v",
      "namespace": "openebs",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.50/32",
    "hostIP": "172.17.0.2",
    "identity": 40807,
    "metadata": {
      "name": "frontend-58b6bf847f-k8mbl",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.57/32",
    "hostIP": "172.17.0.2",
    "identity": 58695,
    "metadata": {
      "name": "postgres-migrations-79t9m",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.77/32",
    "hostIP": "172.17.0.2",
    "identity": 5267,
    "metadata": {
      "name": "hubble-ui-6b468cff75-sv8hh",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.84/32",
    "hostIP": "172.17.0.2",
    "identity": 63576,
    "metadata": {
      "name": "traffic-manager-55d995585d-cs5xg",
      "namespace": "ambassador",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.93/32",
    "hostIP": "172.17.0.2",
    "identity": 2199,
    "metadata": {
      "name": "pgweb-b74849bb6-hrcb8",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.101/32",
    "hostIP": "172.17.0.2",
    "identity": 7207,
    "metadata": {
      "name": "livestream-migrations-8nnxm",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.104/32",
    "hostIP": "172.17.0.2",
    "identity": 40807,
    "metadata": {
      "name": "frontend-58b6bf847f-rg7lb",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.105/32",
    "hostIP": "172.17.0.2",
    "identity": 11487,
    "metadata": {
      "name": "redis-68c95977f4-bl8l4",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.119/32",
    "hostIP": "172.17.0.2",
    "identity": 40807,
    "metadata": {
      "name": "frontend-58b6bf847f-j9rzh",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.144/32",
    "hostIP": "172.17.0.2",
    "identity": 24494,
    "metadata": {
      "name": "create-minio-buckets-2hsfq",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.155/32",
    "hostIP": "172.17.0.2",
    "identity": 707,
    "metadata": {
      "name": "kratos-migrations-km25z",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.171/32",
    "hostIP": "172.17.0.2",
    "identity": 28402,
    "metadata": {
      "name": "cert-manager-cainjector-6774f986b-5fqd9",
      "namespace": "cert-manager",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.172/32",
    "hostIP": "172.17.0.2",
    "identity": 13128,
    "metadata": {
      "name": "openebs-localpv-provisioner-7d6ccb7795-4rhmc",
      "namespace": "openebs",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.176/32",
    "hostIP": "172.17.0.2",
    "identity": 1
  },
  {
    "cidr": "10.244.0.182/32",
    "hostIP": "172.17.0.2",
    "identity": 1847,
    "metadata": {
      "name": "init-pvc-bf475e5e-08fc-4f1e-95bf-5e66e3b2ccb5",
      "namespace": "openebs",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.186/32",
    "hostIP": "172.17.0.2",
    "identity": 1847,
    "metadata": {
      "name": "init-pvc-a98007c1-4485-4928-9e38-355a6ab271ae",
      "namespace": "openebs",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.192/32",
    "hostIP": "172.17.0.2",
    "identity": 11535,
    "metadata": {
      "name": "kratos-77cbf98c8f-wcvxh",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.193/32",
    "hostIP": "172.17.0.2",
    "identity": 9256,
    "metadata": {
      "name": "backend-855f6c7b4-fkt9r",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.197/32",
    "hostIP": "172.17.0.2",
    "identity": 25058,
    "metadata": {
      "name": "hubble-relay-777496bf44-ngd9p",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.199/32",
    "hostIP": "172.17.0.2",
    "identity": 8310,
    "metadata": {
      "name": "openebs-ndm-node-exporter-prqkp",
      "namespace": "openebs",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.206/32",
    "hostIP": "172.17.0.2",
    "identity": 4
  },
  {
    "cidr": "10.244.0.207/32",
    "hostIP": "172.17.0.2",
    "identity": 6400,
    "metadata": {
      "name": "coredns-878bb57ff-j98j5",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.209/32",
    "hostIP": "172.17.0.2",
    "identity": 3108,
    "metadata": {
      "name": "streamchat-79dfbb9bb4-c954g",
      "namespace": "streampai",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.212/32",
    "hostIP": "172.17.0.2",
    "identity": 32957,
    "metadata": {
      "name": "metrics-server-7f86dff975-b2xzk",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.219/32",
    "hostIP": "172.17.0.2",
    "identity": 12886,
    "metadata": {
      "name": "cert-manager-webhook-879c48cd4-b4q2j",
      "namespace": "cert-manager",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.230/32",
    "hostIP": "172.17.0.2",
    "identity": 8
  },
  {
    "cidr": "10.244.0.240/32",
    "hostIP": "172.17.0.2",
    "identity": 33925,
    "metadata": {
      "name": "cert-manager-78ddc5db85-h92qs",
      "namespace": "cert-manager",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.244.0.253/32",
    "hostIP": "172.17.0.2",
    "identity": 48566,
    "metadata": {
      "name": "openebs-ndm-cluster-exporter-589554f487-vj8m5",
      "namespace": "openebs",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "172.17.0.2/32",
    "identity": 1
  }
]

