markdown output at /tmp/cilium-bugtool-20230906-003112.373+0000-UTC-1957401943/cmd/cilium-debuginfo-20230906-003112.504+0000-UTC.md
json output at /tmp/cilium-bugtool-20230906-003112.373+0000-UTC-1957401943/cmd/cilium-debuginfo-20230906-003112.504+0000-UTC.json
