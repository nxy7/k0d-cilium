filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc4efd61adef5f direct-action not_in_hw id 7730 tag 8c41a47283b501d1 jited 
